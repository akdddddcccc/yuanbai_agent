(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))a(o);new MutationObserver(o=>{for(const c of o)if(c.type==="childList")for(const u of c.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&a(u)}).observe(document,{childList:!0,subtree:!0});function n(o){const c={};return o.integrity&&(c.integrity=o.integrity),o.referrerPolicy&&(c.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?c.credentials="include":o.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function a(o){if(o.ep)return;o.ep=!0;const c=n(o);fetch(o.href,c)}})();var jh={exports:{}},cl={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var X_;function xM(){if(X_)return cl;X_=1;var r=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function n(a,o,c){var u=null;if(c!==void 0&&(u=""+c),o.key!==void 0&&(u=""+o.key),"key"in o){c={};for(var h in o)h!=="key"&&(c[h]=o[h])}else c=o;return o=c.ref,{$$typeof:r,type:a,key:u,ref:o!==void 0?o:null,props:c}}return cl.Fragment=e,cl.jsx=n,cl.jsxs=n,cl}var W_;function yM(){return W_||(W_=1,jh.exports=xM()),jh.exports}var Qe=yM(),$h={exports:{}},ot={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var q_;function SM(){if(q_)return ot;q_=1;var r=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),o=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),u=Symbol.for("react.context"),h=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),_=Symbol.for("react.activity"),v=Symbol.iterator;function x(D){return D===null||typeof D!="object"?null:(D=v&&D[v]||D["@@iterator"],typeof D=="function"?D:null)}var E={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},C=Object.assign,M={};function S(D,Y,Ee){this.props=D,this.context=Y,this.refs=M,this.updater=Ee||E}S.prototype.isReactComponent={},S.prototype.setState=function(D,Y){if(typeof D!="object"&&typeof D!="function"&&D!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,D,Y,"setState")},S.prototype.forceUpdate=function(D){this.updater.enqueueForceUpdate(this,D,"forceUpdate")};function B(){}B.prototype=S.prototype;function F(D,Y,Ee){this.props=D,this.context=Y,this.refs=M,this.updater=Ee||E}var w=F.prototype=new B;w.constructor=F,C(w,S.prototype),w.isPureReactComponent=!0;var P=Array.isArray;function U(){}var N={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function O(D,Y,Ee){var Re=Ee.ref;return{$$typeof:r,type:D,key:Y,ref:Re!==void 0?Re:null,props:Ee}}function X(D,Y){return O(D.type,Y,D.props)}function G(D){return typeof D=="object"&&D!==null&&D.$$typeof===r}function Z(D){var Y={"=":"=0",":":"=2"};return"$"+D.replace(/[=:]/g,function(Ee){return Y[Ee]})}var ce=/\/+/g;function ge(D,Y){return typeof D=="object"&&D!==null&&D.key!=null?Z(""+D.key):Y.toString(36)}function j(D){switch(D.status){case"fulfilled":return D.value;case"rejected":throw D.reason;default:switch(typeof D.status=="string"?D.then(U,U):(D.status="pending",D.then(function(Y){D.status==="pending"&&(D.status="fulfilled",D.value=Y)},function(Y){D.status==="pending"&&(D.status="rejected",D.reason=Y)})),D.status){case"fulfilled":return D.value;case"rejected":throw D.reason}}throw D}function I(D,Y,Ee,Re,Pe){var ae=typeof D;(ae==="undefined"||ae==="boolean")&&(D=null);var ye=!1;if(D===null)ye=!0;else switch(ae){case"bigint":case"string":case"number":ye=!0;break;case"object":switch(D.$$typeof){case r:case e:ye=!0;break;case g:return ye=D._init,I(ye(D._payload),Y,Ee,Re,Pe)}}if(ye)return Pe=Pe(D),ye=Re===""?"."+ge(D,0):Re,P(Pe)?(Ee="",ye!=null&&(Ee=ye.replace(ce,"$&/")+"/"),I(Pe,Y,Ee,"",function(it){return it})):Pe!=null&&(G(Pe)&&(Pe=X(Pe,Ee+(Pe.key==null||D&&D.key===Pe.key?"":(""+Pe.key).replace(ce,"$&/")+"/")+ye)),Y.push(Pe)),1;ye=0;var Me=Re===""?".":Re+":";if(P(D))for(var ze=0;ze<D.length;ze++)Re=D[ze],ae=Me+ge(Re,ze),ye+=I(Re,Y,Ee,ae,Pe);else if(ze=x(D),typeof ze=="function")for(D=ze.call(D),ze=0;!(Re=D.next()).done;)Re=Re.value,ae=Me+ge(Re,ze++),ye+=I(Re,Y,Ee,ae,Pe);else if(ae==="object"){if(typeof D.then=="function")return I(j(D),Y,Ee,Re,Pe);throw Y=String(D),Error("Objects are not valid as a React child (found: "+(Y==="[object Object]"?"object with keys {"+Object.keys(D).join(", ")+"}":Y)+"). If you meant to render a collection of children, use an array instead.")}return ye}function z(D,Y,Ee){if(D==null)return D;var Re=[],Pe=0;return I(D,Re,"","",function(ae){return Y.call(Ee,ae,Pe++)}),Re}function Q(D){if(D._status===-1){var Y=D._result;Y=Y(),Y.then(function(Ee){(D._status===0||D._status===-1)&&(D._status=1,D._result=Ee)},function(Ee){(D._status===0||D._status===-1)&&(D._status=2,D._result=Ee)}),D._status===-1&&(D._status=0,D._result=Y)}if(D._status===1)return D._result.default;throw D._result}var de=typeof reportError=="function"?reportError:function(D){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var Y=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof D=="object"&&D!==null&&typeof D.message=="string"?String(D.message):String(D),error:D});if(!window.dispatchEvent(Y))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",D);return}console.error(D)},ve={map:z,forEach:function(D,Y,Ee){z(D,function(){Y.apply(this,arguments)},Ee)},count:function(D){var Y=0;return z(D,function(){Y++}),Y},toArray:function(D){return z(D,function(Y){return Y})||[]},only:function(D){if(!G(D))throw Error("React.Children.only expected to receive a single React element child.");return D}};return ot.Activity=_,ot.Children=ve,ot.Component=S,ot.Fragment=n,ot.Profiler=o,ot.PureComponent=F,ot.StrictMode=a,ot.Suspense=p,ot.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=N,ot.__COMPILER_RUNTIME={__proto__:null,c:function(D){return N.H.useMemoCache(D)}},ot.cache=function(D){return function(){return D.apply(null,arguments)}},ot.cacheSignal=function(){return null},ot.cloneElement=function(D,Y,Ee){if(D==null)throw Error("The argument must be a React element, but you passed "+D+".");var Re=C({},D.props),Pe=D.key;if(Y!=null)for(ae in Y.key!==void 0&&(Pe=""+Y.key),Y)!T.call(Y,ae)||ae==="key"||ae==="__self"||ae==="__source"||ae==="ref"&&Y.ref===void 0||(Re[ae]=Y[ae]);var ae=arguments.length-2;if(ae===1)Re.children=Ee;else if(1<ae){for(var ye=Array(ae),Me=0;Me<ae;Me++)ye[Me]=arguments[Me+2];Re.children=ye}return O(D.type,Pe,Re)},ot.createContext=function(D){return D={$$typeof:u,_currentValue:D,_currentValue2:D,_threadCount:0,Provider:null,Consumer:null},D.Provider=D,D.Consumer={$$typeof:c,_context:D},D},ot.createElement=function(D,Y,Ee){var Re,Pe={},ae=null;if(Y!=null)for(Re in Y.key!==void 0&&(ae=""+Y.key),Y)T.call(Y,Re)&&Re!=="key"&&Re!=="__self"&&Re!=="__source"&&(Pe[Re]=Y[Re]);var ye=arguments.length-2;if(ye===1)Pe.children=Ee;else if(1<ye){for(var Me=Array(ye),ze=0;ze<ye;ze++)Me[ze]=arguments[ze+2];Pe.children=Me}if(D&&D.defaultProps)for(Re in ye=D.defaultProps,ye)Pe[Re]===void 0&&(Pe[Re]=ye[Re]);return O(D,ae,Pe)},ot.createRef=function(){return{current:null}},ot.forwardRef=function(D){return{$$typeof:h,render:D}},ot.isValidElement=G,ot.lazy=function(D){return{$$typeof:g,_payload:{_status:-1,_result:D},_init:Q}},ot.memo=function(D,Y){return{$$typeof:d,type:D,compare:Y===void 0?null:Y}},ot.startTransition=function(D){var Y=N.T,Ee={};N.T=Ee;try{var Re=D(),Pe=N.S;Pe!==null&&Pe(Ee,Re),typeof Re=="object"&&Re!==null&&typeof Re.then=="function"&&Re.then(U,de)}catch(ae){de(ae)}finally{Y!==null&&Ee.types!==null&&(Y.types=Ee.types),N.T=Y}},ot.unstable_useCacheRefresh=function(){return N.H.useCacheRefresh()},ot.use=function(D){return N.H.use(D)},ot.useActionState=function(D,Y,Ee){return N.H.useActionState(D,Y,Ee)},ot.useCallback=function(D,Y){return N.H.useCallback(D,Y)},ot.useContext=function(D){return N.H.useContext(D)},ot.useDebugValue=function(){},ot.useDeferredValue=function(D,Y){return N.H.useDeferredValue(D,Y)},ot.useEffect=function(D,Y){return N.H.useEffect(D,Y)},ot.useEffectEvent=function(D){return N.H.useEffectEvent(D)},ot.useId=function(){return N.H.useId()},ot.useImperativeHandle=function(D,Y,Ee){return N.H.useImperativeHandle(D,Y,Ee)},ot.useInsertionEffect=function(D,Y){return N.H.useInsertionEffect(D,Y)},ot.useLayoutEffect=function(D,Y){return N.H.useLayoutEffect(D,Y)},ot.useMemo=function(D,Y){return N.H.useMemo(D,Y)},ot.useOptimistic=function(D,Y){return N.H.useOptimistic(D,Y)},ot.useReducer=function(D,Y,Ee){return N.H.useReducer(D,Y,Ee)},ot.useRef=function(D){return N.H.useRef(D)},ot.useState=function(D){return N.H.useState(D)},ot.useSyncExternalStore=function(D,Y,Ee){return N.H.useSyncExternalStore(D,Y,Ee)},ot.useTransition=function(){return N.H.useTransition()},ot.version="19.2.0",ot}var Y_;function Bp(){return Y_||(Y_=1,$h.exports=SM()),$h.exports}var Je=Bp(),ed={exports:{}},ul={},td={exports:{}},nd={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var K_;function MM(){return K_||(K_=1,(function(r){function e(I,z){var Q=I.length;I.push(z);e:for(;0<Q;){var de=Q-1>>>1,ve=I[de];if(0<o(ve,z))I[de]=z,I[Q]=ve,Q=de;else break e}}function n(I){return I.length===0?null:I[0]}function a(I){if(I.length===0)return null;var z=I[0],Q=I.pop();if(Q!==z){I[0]=Q;e:for(var de=0,ve=I.length,D=ve>>>1;de<D;){var Y=2*(de+1)-1,Ee=I[Y],Re=Y+1,Pe=I[Re];if(0>o(Ee,Q))Re<ve&&0>o(Pe,Ee)?(I[de]=Pe,I[Re]=Q,de=Re):(I[de]=Ee,I[Y]=Q,de=Y);else if(Re<ve&&0>o(Pe,Q))I[de]=Pe,I[Re]=Q,de=Re;else break e}}return z}function o(I,z){var Q=I.sortIndex-z.sortIndex;return Q!==0?Q:I.id-z.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;r.unstable_now=function(){return c.now()}}else{var u=Date,h=u.now();r.unstable_now=function(){return u.now()-h}}var p=[],d=[],g=1,_=null,v=3,x=!1,E=!1,C=!1,M=!1,S=typeof setTimeout=="function"?setTimeout:null,B=typeof clearTimeout=="function"?clearTimeout:null,F=typeof setImmediate<"u"?setImmediate:null;function w(I){for(var z=n(d);z!==null;){if(z.callback===null)a(d);else if(z.startTime<=I)a(d),z.sortIndex=z.expirationTime,e(p,z);else break;z=n(d)}}function P(I){if(C=!1,w(I),!E)if(n(p)!==null)E=!0,U||(U=!0,Z());else{var z=n(d);z!==null&&j(P,z.startTime-I)}}var U=!1,N=-1,T=5,O=-1;function X(){return M?!0:!(r.unstable_now()-O<T)}function G(){if(M=!1,U){var I=r.unstable_now();O=I;var z=!0;try{e:{E=!1,C&&(C=!1,B(N),N=-1),x=!0;var Q=v;try{t:{for(w(I),_=n(p);_!==null&&!(_.expirationTime>I&&X());){var de=_.callback;if(typeof de=="function"){_.callback=null,v=_.priorityLevel;var ve=de(_.expirationTime<=I);if(I=r.unstable_now(),typeof ve=="function"){_.callback=ve,w(I),z=!0;break t}_===n(p)&&a(p),w(I)}else a(p);_=n(p)}if(_!==null)z=!0;else{var D=n(d);D!==null&&j(P,D.startTime-I),z=!1}}break e}finally{_=null,v=Q,x=!1}z=void 0}}finally{z?Z():U=!1}}}var Z;if(typeof F=="function")Z=function(){F(G)};else if(typeof MessageChannel<"u"){var ce=new MessageChannel,ge=ce.port2;ce.port1.onmessage=G,Z=function(){ge.postMessage(null)}}else Z=function(){S(G,0)};function j(I,z){N=S(function(){I(r.unstable_now())},z)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(I){I.callback=null},r.unstable_forceFrameRate=function(I){0>I||125<I?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<I?Math.floor(1e3/I):5},r.unstable_getCurrentPriorityLevel=function(){return v},r.unstable_next=function(I){switch(v){case 1:case 2:case 3:var z=3;break;default:z=v}var Q=v;v=z;try{return I()}finally{v=Q}},r.unstable_requestPaint=function(){M=!0},r.unstable_runWithPriority=function(I,z){switch(I){case 1:case 2:case 3:case 4:case 5:break;default:I=3}var Q=v;v=I;try{return z()}finally{v=Q}},r.unstable_scheduleCallback=function(I,z,Q){var de=r.unstable_now();switch(typeof Q=="object"&&Q!==null?(Q=Q.delay,Q=typeof Q=="number"&&0<Q?de+Q:de):Q=de,I){case 1:var ve=-1;break;case 2:ve=250;break;case 5:ve=1073741823;break;case 4:ve=1e4;break;default:ve=5e3}return ve=Q+ve,I={id:g++,callback:z,priorityLevel:I,startTime:Q,expirationTime:ve,sortIndex:-1},Q>de?(I.sortIndex=Q,e(d,I),n(p)===null&&I===n(d)&&(C?(B(N),N=-1):C=!0,j(P,Q-de))):(I.sortIndex=ve,e(p,I),E||x||(E=!0,U||(U=!0,Z()))),I},r.unstable_shouldYield=X,r.unstable_wrapCallback=function(I){var z=v;return function(){var Q=v;v=z;try{return I.apply(this,arguments)}finally{v=Q}}}})(nd)),nd}var Z_;function EM(){return Z_||(Z_=1,td.exports=MM()),td.exports}var id={exports:{}},Hn={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Q_;function bM(){if(Q_)return Hn;Q_=1;var r=Bp();function e(p){var d="https://react.dev/errors/"+p;if(1<arguments.length){d+="?args[]="+encodeURIComponent(arguments[1]);for(var g=2;g<arguments.length;g++)d+="&args[]="+encodeURIComponent(arguments[g])}return"Minified React error #"+p+"; visit "+d+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function n(){}var a={d:{f:n,r:function(){throw Error(e(522))},D:n,C:n,L:n,m:n,X:n,S:n,M:n},p:0,findDOMNode:null},o=Symbol.for("react.portal");function c(p,d,g){var _=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:o,key:_==null?null:""+_,children:p,containerInfo:d,implementation:g}}var u=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function h(p,d){if(p==="font")return"";if(typeof d=="string")return d==="use-credentials"?d:""}return Hn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,Hn.createPortal=function(p,d){var g=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!d||d.nodeType!==1&&d.nodeType!==9&&d.nodeType!==11)throw Error(e(299));return c(p,d,null,g)},Hn.flushSync=function(p){var d=u.T,g=a.p;try{if(u.T=null,a.p=2,p)return p()}finally{u.T=d,a.p=g,a.d.f()}},Hn.preconnect=function(p,d){typeof p=="string"&&(d?(d=d.crossOrigin,d=typeof d=="string"?d==="use-credentials"?d:"":void 0):d=null,a.d.C(p,d))},Hn.prefetchDNS=function(p){typeof p=="string"&&a.d.D(p)},Hn.preinit=function(p,d){if(typeof p=="string"&&d&&typeof d.as=="string"){var g=d.as,_=h(g,d.crossOrigin),v=typeof d.integrity=="string"?d.integrity:void 0,x=typeof d.fetchPriority=="string"?d.fetchPriority:void 0;g==="style"?a.d.S(p,typeof d.precedence=="string"?d.precedence:void 0,{crossOrigin:_,integrity:v,fetchPriority:x}):g==="script"&&a.d.X(p,{crossOrigin:_,integrity:v,fetchPriority:x,nonce:typeof d.nonce=="string"?d.nonce:void 0})}},Hn.preinitModule=function(p,d){if(typeof p=="string")if(typeof d=="object"&&d!==null){if(d.as==null||d.as==="script"){var g=h(d.as,d.crossOrigin);a.d.M(p,{crossOrigin:g,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0})}}else d==null&&a.d.M(p)},Hn.preload=function(p,d){if(typeof p=="string"&&typeof d=="object"&&d!==null&&typeof d.as=="string"){var g=d.as,_=h(g,d.crossOrigin);a.d.L(p,g,{crossOrigin:_,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0,type:typeof d.type=="string"?d.type:void 0,fetchPriority:typeof d.fetchPriority=="string"?d.fetchPriority:void 0,referrerPolicy:typeof d.referrerPolicy=="string"?d.referrerPolicy:void 0,imageSrcSet:typeof d.imageSrcSet=="string"?d.imageSrcSet:void 0,imageSizes:typeof d.imageSizes=="string"?d.imageSizes:void 0,media:typeof d.media=="string"?d.media:void 0})}},Hn.preloadModule=function(p,d){if(typeof p=="string")if(d){var g=h(d.as,d.crossOrigin);a.d.m(p,{as:typeof d.as=="string"&&d.as!=="script"?d.as:void 0,crossOrigin:g,integrity:typeof d.integrity=="string"?d.integrity:void 0})}else a.d.m(p)},Hn.requestFormReset=function(p){a.d.r(p)},Hn.unstable_batchedUpdates=function(p,d){return p(d)},Hn.useFormState=function(p,d,g){return u.H.useFormState(p,d,g)},Hn.useFormStatus=function(){return u.H.useHostTransitionStatus()},Hn.version="19.2.0",Hn}var J_;function TM(){if(J_)return id.exports;J_=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),id.exports=bM(),id.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var j_;function AM(){if(j_)return ul;j_=1;var r=EM(),e=Bp(),n=TM();function a(t){var i="https://react.dev/errors/"+t;if(1<arguments.length){i+="?args[]="+encodeURIComponent(arguments[1]);for(var s=2;s<arguments.length;s++)i+="&args[]="+encodeURIComponent(arguments[s])}return"Minified React error #"+t+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function o(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function c(t){var i=t,s=t;if(t.alternate)for(;i.return;)i=i.return;else{t=i;do i=t,(i.flags&4098)!==0&&(s=i.return),t=i.return;while(t)}return i.tag===3?s:null}function u(t){if(t.tag===13){var i=t.memoizedState;if(i===null&&(t=t.alternate,t!==null&&(i=t.memoizedState)),i!==null)return i.dehydrated}return null}function h(t){if(t.tag===31){var i=t.memoizedState;if(i===null&&(t=t.alternate,t!==null&&(i=t.memoizedState)),i!==null)return i.dehydrated}return null}function p(t){if(c(t)!==t)throw Error(a(188))}function d(t){var i=t.alternate;if(!i){if(i=c(t),i===null)throw Error(a(188));return i!==t?null:t}for(var s=t,l=i;;){var f=s.return;if(f===null)break;var m=f.alternate;if(m===null){if(l=f.return,l!==null){s=l;continue}break}if(f.child===m.child){for(m=f.child;m;){if(m===s)return p(f),t;if(m===l)return p(f),i;m=m.sibling}throw Error(a(188))}if(s.return!==l.return)s=f,l=m;else{for(var y=!1,R=f.child;R;){if(R===s){y=!0,s=f,l=m;break}if(R===l){y=!0,l=f,s=m;break}R=R.sibling}if(!y){for(R=m.child;R;){if(R===s){y=!0,s=m,l=f;break}if(R===l){y=!0,l=m,s=f;break}R=R.sibling}if(!y)throw Error(a(189))}}if(s.alternate!==l)throw Error(a(190))}if(s.tag!==3)throw Error(a(188));return s.stateNode.current===s?t:i}function g(t){var i=t.tag;if(i===5||i===26||i===27||i===6)return t;for(t=t.child;t!==null;){if(i=g(t),i!==null)return i;t=t.sibling}return null}var _=Object.assign,v=Symbol.for("react.element"),x=Symbol.for("react.transitional.element"),E=Symbol.for("react.portal"),C=Symbol.for("react.fragment"),M=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),B=Symbol.for("react.consumer"),F=Symbol.for("react.context"),w=Symbol.for("react.forward_ref"),P=Symbol.for("react.suspense"),U=Symbol.for("react.suspense_list"),N=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),O=Symbol.for("react.activity"),X=Symbol.for("react.memo_cache_sentinel"),G=Symbol.iterator;function Z(t){return t===null||typeof t!="object"?null:(t=G&&t[G]||t["@@iterator"],typeof t=="function"?t:null)}var ce=Symbol.for("react.client.reference");function ge(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===ce?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case C:return"Fragment";case S:return"Profiler";case M:return"StrictMode";case P:return"Suspense";case U:return"SuspenseList";case O:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case E:return"Portal";case F:return t.displayName||"Context";case B:return(t._context.displayName||"Context")+".Consumer";case w:var i=t.render;return t=t.displayName,t||(t=i.displayName||i.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case N:return i=t.displayName||null,i!==null?i:ge(t.type)||"Memo";case T:i=t._payload,t=t._init;try{return ge(t(i))}catch{}}return null}var j=Array.isArray,I=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,z=n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Q={pending:!1,data:null,method:null,action:null},de=[],ve=-1;function D(t){return{current:t}}function Y(t){0>ve||(t.current=de[ve],de[ve]=null,ve--)}function Ee(t,i){ve++,de[ve]=t.current,t.current=i}var Re=D(null),Pe=D(null),ae=D(null),ye=D(null);function Me(t,i){switch(Ee(ae,i),Ee(Pe,t),Ee(Re,null),i.nodeType){case 9:case 11:t=(t=i.documentElement)&&(t=t.namespaceURI)?d_(t):0;break;default:if(t=i.tagName,i=i.namespaceURI)i=d_(i),t=p_(i,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}Y(Re),Ee(Re,t)}function ze(){Y(Re),Y(Pe),Y(ae)}function it(t){t.memoizedState!==null&&Ee(ye,t);var i=Re.current,s=p_(i,t.type);i!==s&&(Ee(Pe,t),Ee(Re,s))}function je(t){Pe.current===t&&(Y(Re),Y(Pe)),ye.current===t&&(Y(ye),sl._currentValue=Q)}var Jt,pt;function Tt(t){if(Jt===void 0)try{throw Error()}catch(s){var i=s.stack.trim().match(/\n( *(at )?)/);Jt=i&&i[1]||"",pt=-1<s.stack.indexOf(`
    at`)?" (<anonymous>)":-1<s.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Jt+t+pt}var At=!1;function _t(t,i){if(!t||At)return"";At=!0;var s=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var l={DetermineComponentFrameRoot:function(){try{if(i){var xe=function(){throw Error()};if(Object.defineProperty(xe.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(xe,[])}catch(le){var oe=le}Reflect.construct(t,[],xe)}else{try{xe.call()}catch(le){oe=le}t.call(xe.prototype)}}else{try{throw Error()}catch(le){oe=le}(xe=t())&&typeof xe.catch=="function"&&xe.catch(function(){})}}catch(le){if(le&&oe&&typeof le.stack=="string")return[le.stack,oe.stack]}return[null,null]}};l.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var f=Object.getOwnPropertyDescriptor(l.DetermineComponentFrameRoot,"name");f&&f.configurable&&Object.defineProperty(l.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var m=l.DetermineComponentFrameRoot(),y=m[0],R=m[1];if(y&&R){var H=y.split(`
`),te=R.split(`
`);for(f=l=0;l<H.length&&!H[l].includes("DetermineComponentFrameRoot");)l++;for(;f<te.length&&!te[f].includes("DetermineComponentFrameRoot");)f++;if(l===H.length||f===te.length)for(l=H.length-1,f=te.length-1;1<=l&&0<=f&&H[l]!==te[f];)f--;for(;1<=l&&0<=f;l--,f--)if(H[l]!==te[f]){if(l!==1||f!==1)do if(l--,f--,0>f||H[l]!==te[f]){var pe=`
`+H[l].replace(" at new "," at ");return t.displayName&&pe.includes("<anonymous>")&&(pe=pe.replace("<anonymous>",t.displayName)),pe}while(1<=l&&0<=f);break}}}finally{At=!1,Error.prepareStackTrace=s}return(s=t?t.displayName||t.name:"")?Tt(s):""}function rn(t,i){switch(t.tag){case 26:case 27:case 5:return Tt(t.type);case 16:return Tt("Lazy");case 13:return t.child!==i&&i!==null?Tt("Suspense Fallback"):Tt("Suspense");case 19:return Tt("SuspenseList");case 0:case 15:return _t(t.type,!1);case 11:return _t(t.type.render,!1);case 1:return _t(t.type,!0);case 31:return Tt("Activity");default:return""}}function on(t){try{var i="",s=null;do i+=rn(t,s),s=t,t=t.return;while(t);return i}catch(l){return`
Error generating stack: `+l.message+`
`+l.stack}}var ln=Object.prototype.hasOwnProperty,hn=r.unstable_scheduleCallback,Qt=r.unstable_cancelCallback,cn=r.unstable_shouldYield,q=r.unstable_requestPaint,kt=r.unstable_now,Lt=r.unstable_getCurrentPriorityLevel,L=r.unstable_ImmediatePriority,b=r.unstable_UserBlockingPriority,J=r.unstable_NormalPriority,se=r.unstable_LowPriority,fe=r.unstable_IdlePriority,be=r.log,we=r.unstable_setDisableYieldValue,ue=null,he=null;function Ae(t){if(typeof be=="function"&&we(t),he&&typeof he.setStrictMode=="function")try{he.setStrictMode(ue,t)}catch{}}var Be=Math.clz32?Math.clz32:Ze,Ne=Math.log,De=Math.LN2;function Ze(t){return t>>>=0,t===0?32:31-(Ne(t)/De|0)|0}var $e=256,rt=262144,k=4194304;function Te(t){var i=t&42;if(i!==0)return i;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&261888;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function me(t,i,s){var l=t.pendingLanes;if(l===0)return 0;var f=0,m=t.suspendedLanes,y=t.pingedLanes;t=t.warmLanes;var R=l&134217727;return R!==0?(l=R&~m,l!==0?f=Te(l):(y&=R,y!==0?f=Te(y):s||(s=R&~t,s!==0&&(f=Te(s))))):(R=l&~m,R!==0?f=Te(R):y!==0?f=Te(y):s||(s=l&~t,s!==0&&(f=Te(s)))),f===0?0:i!==0&&i!==f&&(i&m)===0&&(m=f&-f,s=i&-i,m>=s||m===32&&(s&4194048)!==0)?i:f}function Ce(t,i){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&i)===0}function Ie(t,i){switch(t){case 1:case 2:case 4:case 8:case 64:return i+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Se(){var t=k;return k<<=1,(k&62914560)===0&&(k=4194304),t}function We(t){for(var i=[],s=0;31>s;s++)i.push(t);return i}function Ge(t,i){t.pendingLanes|=i,i!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function tn(t,i,s,l,f,m){var y=t.pendingLanes;t.pendingLanes=s,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=s,t.entangledLanes&=s,t.errorRecoveryDisabledLanes&=s,t.shellSuspendCounter=0;var R=t.entanglements,H=t.expirationTimes,te=t.hiddenUpdates;for(s=y&~s;0<s;){var pe=31-Be(s),xe=1<<pe;R[pe]=0,H[pe]=-1;var oe=te[pe];if(oe!==null)for(te[pe]=null,pe=0;pe<oe.length;pe++){var le=oe[pe];le!==null&&(le.lane&=-536870913)}s&=~xe}l!==0&&Ot(t,l,0),m!==0&&f===0&&t.tag!==0&&(t.suspendedLanes|=m&~(y&~i))}function Ot(t,i,s){t.pendingLanes|=i,t.suspendedLanes&=~i;var l=31-Be(i);t.entangledLanes|=i,t.entanglements[l]=t.entanglements[l]|1073741824|s&261930}function ni(t,i){var s=t.entangledLanes|=i;for(t=t.entanglements;s;){var l=31-Be(s),f=1<<l;f&i|t[l]&i&&(t[l]|=i),s&=~f}}function ii(t,i){var s=i&-i;return s=(s&42)!==0?1:xo(s),(s&(t.suspendedLanes|i))!==0?0:s}function xo(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function yo(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function So(){var t=z.p;return t!==0?t:(t=window.event,t===void 0?32:B_(t.type))}function or(t,i){var s=z.p;try{return z.p=t,i()}finally{z.p=s}}var Wi=Math.random().toString(36).slice(2),gn="__reactFiber$"+Wi,On="__reactProps$"+Wi,Kn="__reactContainer$"+Wi,Cs="__reactEvents$"+Wi,Fl="__reactListeners$"+Wi,zl="__reactHandles$"+Wi,ws="__reactResources$"+Wi,Xa="__reactMarker$"+Wi;function Wa(t){delete t[gn],delete t[On],delete t[Cs],delete t[Fl],delete t[zl]}function ua(t){var i=t[gn];if(i)return i;for(var s=t.parentNode;s;){if(i=s[Kn]||s[gn]){if(s=i.alternate,i.child!==null||s!==null&&s.child!==null)for(t=S_(t);t!==null;){if(s=t[gn])return s;t=S_(t)}return i}t=s,s=t.parentNode}return null}function fa(t){if(t=t[gn]||t[Kn]){var i=t.tag;if(i===5||i===6||i===13||i===31||i===26||i===27||i===3)return t}return null}function Ds(t){var i=t.tag;if(i===5||i===26||i===27||i===6)return t.stateNode;throw Error(a(33))}function qa(t){var i=t[ws];return i||(i=t[ws]={hoistableStyles:new Map,hoistableScripts:new Map}),i}function _n(t){t[Xa]=!0}var Hl=new Set,A={};function W(t,i){re(t,i),re(t+"Capture",i)}function re(t,i){for(A[t]=i,t=0;t<i.length;t++)Hl.add(i[t])}var ne=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),ie={},Ue={};function He(t){return ln.call(Ue,t)?!0:ln.call(ie,t)?!1:ne.test(t)?Ue[t]=!0:(ie[t]=!0,!1)}function Le(t,i,s){if(He(i))if(s===null)t.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":t.removeAttribute(i);return;case"boolean":var l=i.toLowerCase().slice(0,5);if(l!=="data-"&&l!=="aria-"){t.removeAttribute(i);return}}t.setAttribute(i,""+s)}}function ke(t,i,s){if(s===null)t.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(i);return}t.setAttribute(i,""+s)}}function Ve(t,i,s,l){if(l===null)t.removeAttribute(s);else{switch(typeof l){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(s);return}t.setAttributeNS(i,s,""+l)}}function et(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function ct(t){var i=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function Ye(t,i,s){var l=Object.getOwnPropertyDescriptor(t.constructor.prototype,i);if(!t.hasOwnProperty(i)&&typeof l<"u"&&typeof l.get=="function"&&typeof l.set=="function"){var f=l.get,m=l.set;return Object.defineProperty(t,i,{configurable:!0,get:function(){return f.call(this)},set:function(y){s=""+y,m.call(this,y)}}),Object.defineProperty(t,i,{enumerable:l.enumerable}),{getValue:function(){return s},setValue:function(y){s=""+y},stopTracking:function(){t._valueTracker=null,delete t[i]}}}}function Ct(t){if(!t._valueTracker){var i=ct(t)?"checked":"value";t._valueTracker=Ye(t,i,""+t[i])}}function nn(t){if(!t)return!1;var i=t._valueTracker;if(!i)return!0;var s=i.getValue(),l="";return t&&(l=ct(t)?t.checked?"true":"false":t.value),t=l,t!==s?(i.setValue(t),!0):!1}function Kt(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var Pt=/[\n"\\]/g;function It(t){return t.replace(Pt,function(i){return"\\"+i.charCodeAt(0).toString(16)+" "})}function Fe(t,i,s,l,f,m,y,R){t.name="",y!=null&&typeof y!="function"&&typeof y!="symbol"&&typeof y!="boolean"?t.type=y:t.removeAttribute("type"),i!=null?y==="number"?(i===0&&t.value===""||t.value!=i)&&(t.value=""+et(i)):t.value!==""+et(i)&&(t.value=""+et(i)):y!=="submit"&&y!=="reset"||t.removeAttribute("value"),i!=null?vt(t,y,et(i)):s!=null?vt(t,y,et(s)):l!=null&&t.removeAttribute("value"),f==null&&m!=null&&(t.defaultChecked=!!m),f!=null&&(t.checked=f&&typeof f!="function"&&typeof f!="symbol"),R!=null&&typeof R!="function"&&typeof R!="symbol"&&typeof R!="boolean"?t.name=""+et(R):t.removeAttribute("name")}function zn(t,i,s,l,f,m,y,R){if(m!=null&&typeof m!="function"&&typeof m!="symbol"&&typeof m!="boolean"&&(t.type=m),i!=null||s!=null){if(!(m!=="submit"&&m!=="reset"||i!=null)){Ct(t);return}s=s!=null?""+et(s):"",i=i!=null?""+et(i):s,R||i===t.value||(t.value=i),t.defaultValue=i}l=l??f,l=typeof l!="function"&&typeof l!="symbol"&&!!l,t.checked=R?t.checked:!!l,t.defaultChecked=!!l,y!=null&&typeof y!="function"&&typeof y!="symbol"&&typeof y!="boolean"&&(t.name=y),Ct(t)}function vt(t,i,s){i==="number"&&Kt(t.ownerDocument)===t||t.defaultValue===""+s||(t.defaultValue=""+s)}function bn(t,i,s,l){if(t=t.options,i){i={};for(var f=0;f<s.length;f++)i["$"+s[f]]=!0;for(s=0;s<t.length;s++)f=i.hasOwnProperty("$"+t[s].value),t[s].selected!==f&&(t[s].selected=f),f&&l&&(t[s].defaultSelected=!0)}else{for(s=""+et(s),i=null,f=0;f<t.length;f++){if(t[f].value===s){t[f].selected=!0,l&&(t[f].defaultSelected=!0);return}i!==null||t[f].disabled||(i=t[f])}i!==null&&(i.selected=!0)}}function ai(t,i,s){if(i!=null&&(i=""+et(i),i!==t.value&&(t.value=i),s==null)){t.defaultValue!==i&&(t.defaultValue=i);return}t.defaultValue=s!=null?""+et(s):""}function Di(t,i,s,l){if(i==null){if(l!=null){if(s!=null)throw Error(a(92));if(j(l)){if(1<l.length)throw Error(a(93));l=l[0]}s=l}s==null&&(s=""),i=s}s=et(i),t.defaultValue=s,l=t.textContent,l===s&&l!==""&&l!==null&&(t.value=l),Ct(t)}function si(t,i){if(i){var s=t.firstChild;if(s&&s===t.lastChild&&s.nodeType===3){s.nodeValue=i;return}}t.textContent=i}var Bt=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function an(t,i,s){var l=i.indexOf("--")===0;s==null||typeof s=="boolean"||s===""?l?t.setProperty(i,""):i==="float"?t.cssFloat="":t[i]="":l?t.setProperty(i,s):typeof s!="number"||s===0||Bt.has(i)?i==="float"?t.cssFloat=s:t[i]=(""+s).trim():t[i]=s+"px"}function Li(t,i,s){if(i!=null&&typeof i!="object")throw Error(a(62));if(t=t.style,s!=null){for(var l in s)!s.hasOwnProperty(l)||i!=null&&i.hasOwnProperty(l)||(l.indexOf("--")===0?t.setProperty(l,""):l==="float"?t.cssFloat="":t[l]="");for(var f in i)l=i[f],i.hasOwnProperty(f)&&s[f]!==l&&an(t,f,l)}else for(var m in i)i.hasOwnProperty(m)&&an(t,m,i[m])}function Ut(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var qi=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Ya=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Ls(t){return Ya.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function ha(){}var Ku=null;function Zu(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var lr=null,cr=null;function hm(t){var i=fa(t);if(i&&(t=i.stateNode)){var s=t[On]||null;e:switch(t=i.stateNode,i.type){case"input":if(Fe(t,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name),i=s.name,s.type==="radio"&&i!=null){for(s=t;s.parentNode;)s=s.parentNode;for(s=s.querySelectorAll('input[name="'+It(""+i)+'"][type="radio"]'),i=0;i<s.length;i++){var l=s[i];if(l!==t&&l.form===t.form){var f=l[On]||null;if(!f)throw Error(a(90));Fe(l,f.value,f.defaultValue,f.defaultValue,f.checked,f.defaultChecked,f.type,f.name)}}for(i=0;i<s.length;i++)l=s[i],l.form===t.form&&nn(l)}break e;case"textarea":ai(t,s.value,s.defaultValue);break e;case"select":i=s.value,i!=null&&bn(t,!!s.multiple,i,!1)}}}var Qu=!1;function dm(t,i,s){if(Qu)return t(i,s);Qu=!0;try{var l=t(i);return l}finally{if(Qu=!1,(lr!==null||cr!==null)&&(Rc(),lr&&(i=lr,t=cr,cr=lr=null,hm(i),t)))for(i=0;i<t.length;i++)hm(t[i])}}function Mo(t,i){var s=t.stateNode;if(s===null)return null;var l=s[On]||null;if(l===null)return null;s=l[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(l=!l.disabled)||(t=t.type,l=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!l;break e;default:t=!1}if(t)return null;if(s&&typeof s!="function")throw Error(a(231,i,typeof s));return s}var da=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Ju=!1;if(da)try{var Eo={};Object.defineProperty(Eo,"passive",{get:function(){Ju=!0}}),window.addEventListener("test",Eo,Eo),window.removeEventListener("test",Eo,Eo)}catch{Ju=!1}var Ka=null,ju=null,Gl=null;function pm(){if(Gl)return Gl;var t,i=ju,s=i.length,l,f="value"in Ka?Ka.value:Ka.textContent,m=f.length;for(t=0;t<s&&i[t]===f[t];t++);var y=s-t;for(l=1;l<=y&&i[s-l]===f[m-l];l++);return Gl=f.slice(t,1<l?1-l:void 0)}function Vl(t){var i=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&i===13&&(t=13)):t=i,t===10&&(t=13),32<=t||t===13?t:0}function kl(){return!0}function mm(){return!1}function Zn(t){function i(s,l,f,m,y){this._reactName=s,this._targetInst=f,this.type=l,this.nativeEvent=m,this.target=y,this.currentTarget=null;for(var R in t)t.hasOwnProperty(R)&&(s=t[R],this[R]=s?s(m):m[R]);return this.isDefaultPrevented=(m.defaultPrevented!=null?m.defaultPrevented:m.returnValue===!1)?kl:mm,this.isPropagationStopped=mm,this}return _(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var s=this.nativeEvent;s&&(s.preventDefault?s.preventDefault():typeof s.returnValue!="unknown"&&(s.returnValue=!1),this.isDefaultPrevented=kl)},stopPropagation:function(){var s=this.nativeEvent;s&&(s.stopPropagation?s.stopPropagation():typeof s.cancelBubble!="unknown"&&(s.cancelBubble=!0),this.isPropagationStopped=kl)},persist:function(){},isPersistent:kl}),i}var Ns={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Xl=Zn(Ns),bo=_({},Ns,{view:0,detail:0}),_y=Zn(bo),$u,ef,To,Wl=_({},bo,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:nf,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==To&&(To&&t.type==="mousemove"?($u=t.screenX-To.screenX,ef=t.screenY-To.screenY):ef=$u=0,To=t),$u)},movementY:function(t){return"movementY"in t?t.movementY:ef}}),gm=Zn(Wl),vy=_({},Wl,{dataTransfer:0}),xy=Zn(vy),yy=_({},bo,{relatedTarget:0}),tf=Zn(yy),Sy=_({},Ns,{animationName:0,elapsedTime:0,pseudoElement:0}),My=Zn(Sy),Ey=_({},Ns,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),by=Zn(Ey),Ty=_({},Ns,{data:0}),_m=Zn(Ty),Ay={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Ry={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Cy={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function wy(t){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(t):(t=Cy[t])?!!i[t]:!1}function nf(){return wy}var Dy=_({},bo,{key:function(t){if(t.key){var i=Ay[t.key]||t.key;if(i!=="Unidentified")return i}return t.type==="keypress"?(t=Vl(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?Ry[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:nf,charCode:function(t){return t.type==="keypress"?Vl(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?Vl(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),Ly=Zn(Dy),Ny=_({},Wl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),vm=Zn(Ny),Uy=_({},bo,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:nf}),Oy=Zn(Uy),Py=_({},Ns,{propertyName:0,elapsedTime:0,pseudoElement:0}),Iy=Zn(Py),By=_({},Wl,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),Fy=Zn(By),zy=_({},Ns,{newState:0,oldState:0}),Hy=Zn(zy),Gy=[9,13,27,32],af=da&&"CompositionEvent"in window,Ao=null;da&&"documentMode"in document&&(Ao=document.documentMode);var Vy=da&&"TextEvent"in window&&!Ao,xm=da&&(!af||Ao&&8<Ao&&11>=Ao),ym=" ",Sm=!1;function Mm(t,i){switch(t){case"keyup":return Gy.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Em(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var ur=!1;function ky(t,i){switch(t){case"compositionend":return Em(i);case"keypress":return i.which!==32?null:(Sm=!0,ym);case"textInput":return t=i.data,t===ym&&Sm?null:t;default:return null}}function Xy(t,i){if(ur)return t==="compositionend"||!af&&Mm(t,i)?(t=pm(),Gl=ju=Ka=null,ur=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return xm&&i.locale!=="ko"?null:i.data;default:return null}}var Wy={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function bm(t){var i=t&&t.nodeName&&t.nodeName.toLowerCase();return i==="input"?!!Wy[t.type]:i==="textarea"}function Tm(t,i,s,l){lr?cr?cr.push(l):cr=[l]:lr=l,i=Oc(i,"onChange"),0<i.length&&(s=new Xl("onChange","change",null,s,l),t.push({event:s,listeners:i}))}var Ro=null,Co=null;function qy(t){o_(t,0)}function ql(t){var i=Ds(t);if(nn(i))return t}function Am(t,i){if(t==="change")return i}var Rm=!1;if(da){var sf;if(da){var rf="oninput"in document;if(!rf){var Cm=document.createElement("div");Cm.setAttribute("oninput","return;"),rf=typeof Cm.oninput=="function"}sf=rf}else sf=!1;Rm=sf&&(!document.documentMode||9<document.documentMode)}function wm(){Ro&&(Ro.detachEvent("onpropertychange",Dm),Co=Ro=null)}function Dm(t){if(t.propertyName==="value"&&ql(Co)){var i=[];Tm(i,Co,t,Zu(t)),dm(qy,i)}}function Yy(t,i,s){t==="focusin"?(wm(),Ro=i,Co=s,Ro.attachEvent("onpropertychange",Dm)):t==="focusout"&&wm()}function Ky(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return ql(Co)}function Zy(t,i){if(t==="click")return ql(i)}function Qy(t,i){if(t==="input"||t==="change")return ql(i)}function Jy(t,i){return t===i&&(t!==0||1/t===1/i)||t!==t&&i!==i}var ri=typeof Object.is=="function"?Object.is:Jy;function wo(t,i){if(ri(t,i))return!0;if(typeof t!="object"||t===null||typeof i!="object"||i===null)return!1;var s=Object.keys(t),l=Object.keys(i);if(s.length!==l.length)return!1;for(l=0;l<s.length;l++){var f=s[l];if(!ln.call(i,f)||!ri(t[f],i[f]))return!1}return!0}function Lm(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function Nm(t,i){var s=Lm(t);t=0;for(var l;s;){if(s.nodeType===3){if(l=t+s.textContent.length,t<=i&&l>=i)return{node:s,offset:i-t};t=l}e:{for(;s;){if(s.nextSibling){s=s.nextSibling;break e}s=s.parentNode}s=void 0}s=Lm(s)}}function Um(t,i){return t&&i?t===i?!0:t&&t.nodeType===3?!1:i&&i.nodeType===3?Um(t,i.parentNode):"contains"in t?t.contains(i):t.compareDocumentPosition?!!(t.compareDocumentPosition(i)&16):!1:!1}function Om(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var i=Kt(t.document);i instanceof t.HTMLIFrameElement;){try{var s=typeof i.contentWindow.location.href=="string"}catch{s=!1}if(s)t=i.contentWindow;else break;i=Kt(t.document)}return i}function of(t){var i=t&&t.nodeName&&t.nodeName.toLowerCase();return i&&(i==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||i==="textarea"||t.contentEditable==="true")}var jy=da&&"documentMode"in document&&11>=document.documentMode,fr=null,lf=null,Do=null,cf=!1;function Pm(t,i,s){var l=s.window===s?s.document:s.nodeType===9?s:s.ownerDocument;cf||fr==null||fr!==Kt(l)||(l=fr,"selectionStart"in l&&of(l)?l={start:l.selectionStart,end:l.selectionEnd}:(l=(l.ownerDocument&&l.ownerDocument.defaultView||window).getSelection(),l={anchorNode:l.anchorNode,anchorOffset:l.anchorOffset,focusNode:l.focusNode,focusOffset:l.focusOffset}),Do&&wo(Do,l)||(Do=l,l=Oc(lf,"onSelect"),0<l.length&&(i=new Xl("onSelect","select",null,i,s),t.push({event:i,listeners:l}),i.target=fr)))}function Us(t,i){var s={};return s[t.toLowerCase()]=i.toLowerCase(),s["Webkit"+t]="webkit"+i,s["Moz"+t]="moz"+i,s}var hr={animationend:Us("Animation","AnimationEnd"),animationiteration:Us("Animation","AnimationIteration"),animationstart:Us("Animation","AnimationStart"),transitionrun:Us("Transition","TransitionRun"),transitionstart:Us("Transition","TransitionStart"),transitioncancel:Us("Transition","TransitionCancel"),transitionend:Us("Transition","TransitionEnd")},uf={},Im={};da&&(Im=document.createElement("div").style,"AnimationEvent"in window||(delete hr.animationend.animation,delete hr.animationiteration.animation,delete hr.animationstart.animation),"TransitionEvent"in window||delete hr.transitionend.transition);function Os(t){if(uf[t])return uf[t];if(!hr[t])return t;var i=hr[t],s;for(s in i)if(i.hasOwnProperty(s)&&s in Im)return uf[t]=i[s];return t}var Bm=Os("animationend"),Fm=Os("animationiteration"),zm=Os("animationstart"),$y=Os("transitionrun"),eS=Os("transitionstart"),tS=Os("transitioncancel"),Hm=Os("transitionend"),Gm=new Map,ff="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");ff.push("scrollEnd");function Ni(t,i){Gm.set(t,i),W(i,[t])}var Yl=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var i=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(i))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},_i=[],dr=0,hf=0;function Kl(){for(var t=dr,i=hf=dr=0;i<t;){var s=_i[i];_i[i++]=null;var l=_i[i];_i[i++]=null;var f=_i[i];_i[i++]=null;var m=_i[i];if(_i[i++]=null,l!==null&&f!==null){var y=l.pending;y===null?f.next=f:(f.next=y.next,y.next=f),l.pending=f}m!==0&&Vm(s,f,m)}}function Zl(t,i,s,l){_i[dr++]=t,_i[dr++]=i,_i[dr++]=s,_i[dr++]=l,hf|=l,t.lanes|=l,t=t.alternate,t!==null&&(t.lanes|=l)}function df(t,i,s,l){return Zl(t,i,s,l),Ql(t)}function Ps(t,i){return Zl(t,null,null,i),Ql(t)}function Vm(t,i,s){t.lanes|=s;var l=t.alternate;l!==null&&(l.lanes|=s);for(var f=!1,m=t.return;m!==null;)m.childLanes|=s,l=m.alternate,l!==null&&(l.childLanes|=s),m.tag===22&&(t=m.stateNode,t===null||t._visibility&1||(f=!0)),t=m,m=m.return;return t.tag===3?(m=t.stateNode,f&&i!==null&&(f=31-Be(s),t=m.hiddenUpdates,l=t[f],l===null?t[f]=[i]:l.push(i),i.lane=s|536870912),m):null}function Ql(t){if(50<jo)throw jo=0,Mh=null,Error(a(185));for(var i=t.return;i!==null;)t=i,i=t.return;return t.tag===3?t.stateNode:null}var pr={};function nS(t,i,s,l){this.tag=t,this.key=s,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=l,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function oi(t,i,s,l){return new nS(t,i,s,l)}function pf(t){return t=t.prototype,!(!t||!t.isReactComponent)}function pa(t,i){var s=t.alternate;return s===null?(s=oi(t.tag,i,t.key,t.mode),s.elementType=t.elementType,s.type=t.type,s.stateNode=t.stateNode,s.alternate=t,t.alternate=s):(s.pendingProps=i,s.type=t.type,s.flags=0,s.subtreeFlags=0,s.deletions=null),s.flags=t.flags&65011712,s.childLanes=t.childLanes,s.lanes=t.lanes,s.child=t.child,s.memoizedProps=t.memoizedProps,s.memoizedState=t.memoizedState,s.updateQueue=t.updateQueue,i=t.dependencies,s.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},s.sibling=t.sibling,s.index=t.index,s.ref=t.ref,s.refCleanup=t.refCleanup,s}function km(t,i){t.flags&=65011714;var s=t.alternate;return s===null?(t.childLanes=0,t.lanes=i,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=s.childLanes,t.lanes=s.lanes,t.child=s.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=s.memoizedProps,t.memoizedState=s.memoizedState,t.updateQueue=s.updateQueue,t.type=s.type,i=s.dependencies,t.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext}),t}function Jl(t,i,s,l,f,m){var y=0;if(l=t,typeof t=="function")pf(t)&&(y=1);else if(typeof t=="string")y=oM(t,s,Re.current)?26:t==="html"||t==="head"||t==="body"?27:5;else e:switch(t){case O:return t=oi(31,s,i,f),t.elementType=O,t.lanes=m,t;case C:return Is(s.children,f,m,i);case M:y=8,f|=24;break;case S:return t=oi(12,s,i,f|2),t.elementType=S,t.lanes=m,t;case P:return t=oi(13,s,i,f),t.elementType=P,t.lanes=m,t;case U:return t=oi(19,s,i,f),t.elementType=U,t.lanes=m,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case F:y=10;break e;case B:y=9;break e;case w:y=11;break e;case N:y=14;break e;case T:y=16,l=null;break e}y=29,s=Error(a(130,t===null?"null":typeof t,"")),l=null}return i=oi(y,s,i,f),i.elementType=t,i.type=l,i.lanes=m,i}function Is(t,i,s,l){return t=oi(7,t,l,i),t.lanes=s,t}function mf(t,i,s){return t=oi(6,t,null,i),t.lanes=s,t}function Xm(t){var i=oi(18,null,null,0);return i.stateNode=t,i}function gf(t,i,s){return i=oi(4,t.children!==null?t.children:[],t.key,i),i.lanes=s,i.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},i}var Wm=new WeakMap;function vi(t,i){if(typeof t=="object"&&t!==null){var s=Wm.get(t);return s!==void 0?s:(i={value:t,source:i,stack:on(i)},Wm.set(t,i),i)}return{value:t,source:i,stack:on(i)}}var mr=[],gr=0,jl=null,Lo=0,xi=[],yi=0,Za=null,Yi=1,Ki="";function ma(t,i){mr[gr++]=Lo,mr[gr++]=jl,jl=t,Lo=i}function qm(t,i,s){xi[yi++]=Yi,xi[yi++]=Ki,xi[yi++]=Za,Za=t;var l=Yi;t=Ki;var f=32-Be(l)-1;l&=~(1<<f),s+=1;var m=32-Be(i)+f;if(30<m){var y=f-f%5;m=(l&(1<<y)-1).toString(32),l>>=y,f-=y,Yi=1<<32-Be(i)+f|s<<f|l,Ki=m+t}else Yi=1<<m|s<<f|l,Ki=t}function _f(t){t.return!==null&&(ma(t,1),qm(t,1,0))}function vf(t){for(;t===jl;)jl=mr[--gr],mr[gr]=null,Lo=mr[--gr],mr[gr]=null;for(;t===Za;)Za=xi[--yi],xi[yi]=null,Ki=xi[--yi],xi[yi]=null,Yi=xi[--yi],xi[yi]=null}function Ym(t,i){xi[yi++]=Yi,xi[yi++]=Ki,xi[yi++]=Za,Yi=i.id,Ki=i.overflow,Za=t}var Pn=null,jt=null,Rt=!1,Qa=null,Si=!1,xf=Error(a(519));function Ja(t){var i=Error(a(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw No(vi(i,t)),xf}function Km(t){var i=t.stateNode,s=t.type,l=t.memoizedProps;switch(i[gn]=t,i[On]=l,s){case"dialog":yt("cancel",i),yt("close",i);break;case"iframe":case"object":case"embed":yt("load",i);break;case"video":case"audio":for(s=0;s<el.length;s++)yt(el[s],i);break;case"source":yt("error",i);break;case"img":case"image":case"link":yt("error",i),yt("load",i);break;case"details":yt("toggle",i);break;case"input":yt("invalid",i),zn(i,l.value,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name,!0);break;case"select":yt("invalid",i);break;case"textarea":yt("invalid",i),Di(i,l.value,l.defaultValue,l.children)}s=l.children,typeof s!="string"&&typeof s!="number"&&typeof s!="bigint"||i.textContent===""+s||l.suppressHydrationWarning===!0||f_(i.textContent,s)?(l.popover!=null&&(yt("beforetoggle",i),yt("toggle",i)),l.onScroll!=null&&yt("scroll",i),l.onScrollEnd!=null&&yt("scrollend",i),l.onClick!=null&&(i.onclick=ha),i=!0):i=!1,i||Ja(t,!0)}function Zm(t){for(Pn=t.return;Pn;)switch(Pn.tag){case 5:case 31:case 13:Si=!1;return;case 27:case 3:Si=!0;return;default:Pn=Pn.return}}function _r(t){if(t!==Pn)return!1;if(!Rt)return Zm(t),Rt=!0,!1;var i=t.tag,s;if((s=i!==3&&i!==27)&&((s=i===5)&&(s=t.type,s=!(s!=="form"&&s!=="button")||Bh(t.type,t.memoizedProps)),s=!s),s&&jt&&Ja(t),Zm(t),i===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(317));jt=y_(t)}else if(i===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(317));jt=y_(t)}else i===27?(i=jt,fs(t.type)?(t=Vh,Vh=null,jt=t):jt=i):jt=Pn?Ei(t.stateNode.nextSibling):null;return!0}function Bs(){jt=Pn=null,Rt=!1}function yf(){var t=Qa;return t!==null&&($n===null?$n=t:$n.push.apply($n,t),Qa=null),t}function No(t){Qa===null?Qa=[t]:Qa.push(t)}var Sf=D(null),Fs=null,ga=null;function ja(t,i,s){Ee(Sf,i._currentValue),i._currentValue=s}function _a(t){t._currentValue=Sf.current,Y(Sf)}function Mf(t,i,s){for(;t!==null;){var l=t.alternate;if((t.childLanes&i)!==i?(t.childLanes|=i,l!==null&&(l.childLanes|=i)):l!==null&&(l.childLanes&i)!==i&&(l.childLanes|=i),t===s)break;t=t.return}}function Ef(t,i,s,l){var f=t.child;for(f!==null&&(f.return=t);f!==null;){var m=f.dependencies;if(m!==null){var y=f.child;m=m.firstContext;e:for(;m!==null;){var R=m;m=f;for(var H=0;H<i.length;H++)if(R.context===i[H]){m.lanes|=s,R=m.alternate,R!==null&&(R.lanes|=s),Mf(m.return,s,t),l||(y=null);break e}m=R.next}}else if(f.tag===18){if(y=f.return,y===null)throw Error(a(341));y.lanes|=s,m=y.alternate,m!==null&&(m.lanes|=s),Mf(y,s,t),y=null}else y=f.child;if(y!==null)y.return=f;else for(y=f;y!==null;){if(y===t){y=null;break}if(f=y.sibling,f!==null){f.return=y.return,y=f;break}y=y.return}f=y}}function vr(t,i,s,l){t=null;for(var f=i,m=!1;f!==null;){if(!m){if((f.flags&524288)!==0)m=!0;else if((f.flags&262144)!==0)break}if(f.tag===10){var y=f.alternate;if(y===null)throw Error(a(387));if(y=y.memoizedProps,y!==null){var R=f.type;ri(f.pendingProps.value,y.value)||(t!==null?t.push(R):t=[R])}}else if(f===ye.current){if(y=f.alternate,y===null)throw Error(a(387));y.memoizedState.memoizedState!==f.memoizedState.memoizedState&&(t!==null?t.push(sl):t=[sl])}f=f.return}t!==null&&Ef(i,t,s,l),i.flags|=262144}function $l(t){for(t=t.firstContext;t!==null;){if(!ri(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function zs(t){Fs=t,ga=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function In(t){return Qm(Fs,t)}function ec(t,i){return Fs===null&&zs(t),Qm(t,i)}function Qm(t,i){var s=i._currentValue;if(i={context:i,memoizedValue:s,next:null},ga===null){if(t===null)throw Error(a(308));ga=i,t.dependencies={lanes:0,firstContext:i},t.flags|=524288}else ga=ga.next=i;return s}var iS=typeof AbortController<"u"?AbortController:function(){var t=[],i=this.signal={aborted:!1,addEventListener:function(s,l){t.push(l)}};this.abort=function(){i.aborted=!0,t.forEach(function(s){return s()})}},aS=r.unstable_scheduleCallback,sS=r.unstable_NormalPriority,vn={$$typeof:F,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function bf(){return{controller:new iS,data:new Map,refCount:0}}function Uo(t){t.refCount--,t.refCount===0&&aS(sS,function(){t.controller.abort()})}var Oo=null,Tf=0,xr=0,yr=null;function rS(t,i){if(Oo===null){var s=Oo=[];Tf=0,xr=Ch(),yr={status:"pending",value:void 0,then:function(l){s.push(l)}}}return Tf++,i.then(Jm,Jm),i}function Jm(){if(--Tf===0&&Oo!==null){yr!==null&&(yr.status="fulfilled");var t=Oo;Oo=null,xr=0,yr=null;for(var i=0;i<t.length;i++)(0,t[i])()}}function oS(t,i){var s=[],l={status:"pending",value:null,reason:null,then:function(f){s.push(f)}};return t.then(function(){l.status="fulfilled",l.value=i;for(var f=0;f<s.length;f++)(0,s[f])(i)},function(f){for(l.status="rejected",l.reason=f,f=0;f<s.length;f++)(0,s[f])(void 0)}),l}var jm=I.S;I.S=function(t,i){P0=kt(),typeof i=="object"&&i!==null&&typeof i.then=="function"&&rS(t,i),jm!==null&&jm(t,i)};var Hs=D(null);function Af(){var t=Hs.current;return t!==null?t:Zt.pooledCache}function tc(t,i){i===null?Ee(Hs,Hs.current):Ee(Hs,i.pool)}function $m(){var t=Af();return t===null?null:{parent:vn._currentValue,pool:t}}var Sr=Error(a(460)),Rf=Error(a(474)),nc=Error(a(542)),ic={then:function(){}};function eg(t){return t=t.status,t==="fulfilled"||t==="rejected"}function tg(t,i,s){switch(s=t[s],s===void 0?t.push(i):s!==i&&(i.then(ha,ha),i=s),i.status){case"fulfilled":return i.value;case"rejected":throw t=i.reason,ig(t),t;default:if(typeof i.status=="string")i.then(ha,ha);else{if(t=Zt,t!==null&&100<t.shellSuspendCounter)throw Error(a(482));t=i,t.status="pending",t.then(function(l){if(i.status==="pending"){var f=i;f.status="fulfilled",f.value=l}},function(l){if(i.status==="pending"){var f=i;f.status="rejected",f.reason=l}})}switch(i.status){case"fulfilled":return i.value;case"rejected":throw t=i.reason,ig(t),t}throw Vs=i,Sr}}function Gs(t){try{var i=t._init;return i(t._payload)}catch(s){throw s!==null&&typeof s=="object"&&typeof s.then=="function"?(Vs=s,Sr):s}}var Vs=null;function ng(){if(Vs===null)throw Error(a(459));var t=Vs;return Vs=null,t}function ig(t){if(t===Sr||t===nc)throw Error(a(483))}var Mr=null,Po=0;function ac(t){var i=Po;return Po+=1,Mr===null&&(Mr=[]),tg(Mr,t,i)}function Io(t,i){i=i.props.ref,t.ref=i!==void 0?i:null}function sc(t,i){throw i.$$typeof===v?Error(a(525)):(t=Object.prototype.toString.call(i),Error(a(31,t==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":t)))}function ag(t){function i(K,V){if(t){var ee=K.deletions;ee===null?(K.deletions=[V],K.flags|=16):ee.push(V)}}function s(K,V){if(!t)return null;for(;V!==null;)i(K,V),V=V.sibling;return null}function l(K){for(var V=new Map;K!==null;)K.key!==null?V.set(K.key,K):V.set(K.index,K),K=K.sibling;return V}function f(K,V){return K=pa(K,V),K.index=0,K.sibling=null,K}function m(K,V,ee){return K.index=ee,t?(ee=K.alternate,ee!==null?(ee=ee.index,ee<V?(K.flags|=67108866,V):ee):(K.flags|=67108866,V)):(K.flags|=1048576,V)}function y(K){return t&&K.alternate===null&&(K.flags|=67108866),K}function R(K,V,ee,_e){return V===null||V.tag!==6?(V=mf(ee,K.mode,_e),V.return=K,V):(V=f(V,ee),V.return=K,V)}function H(K,V,ee,_e){var tt=ee.type;return tt===C?pe(K,V,ee.props.children,_e,ee.key):V!==null&&(V.elementType===tt||typeof tt=="object"&&tt!==null&&tt.$$typeof===T&&Gs(tt)===V.type)?(V=f(V,ee.props),Io(V,ee),V.return=K,V):(V=Jl(ee.type,ee.key,ee.props,null,K.mode,_e),Io(V,ee),V.return=K,V)}function te(K,V,ee,_e){return V===null||V.tag!==4||V.stateNode.containerInfo!==ee.containerInfo||V.stateNode.implementation!==ee.implementation?(V=gf(ee,K.mode,_e),V.return=K,V):(V=f(V,ee.children||[]),V.return=K,V)}function pe(K,V,ee,_e,tt){return V===null||V.tag!==7?(V=Is(ee,K.mode,_e,tt),V.return=K,V):(V=f(V,ee),V.return=K,V)}function xe(K,V,ee){if(typeof V=="string"&&V!==""||typeof V=="number"||typeof V=="bigint")return V=mf(""+V,K.mode,ee),V.return=K,V;if(typeof V=="object"&&V!==null){switch(V.$$typeof){case x:return ee=Jl(V.type,V.key,V.props,null,K.mode,ee),Io(ee,V),ee.return=K,ee;case E:return V=gf(V,K.mode,ee),V.return=K,V;case T:return V=Gs(V),xe(K,V,ee)}if(j(V)||Z(V))return V=Is(V,K.mode,ee,null),V.return=K,V;if(typeof V.then=="function")return xe(K,ac(V),ee);if(V.$$typeof===F)return xe(K,ec(K,V),ee);sc(K,V)}return null}function oe(K,V,ee,_e){var tt=V!==null?V.key:null;if(typeof ee=="string"&&ee!==""||typeof ee=="number"||typeof ee=="bigint")return tt!==null?null:R(K,V,""+ee,_e);if(typeof ee=="object"&&ee!==null){switch(ee.$$typeof){case x:return ee.key===tt?H(K,V,ee,_e):null;case E:return ee.key===tt?te(K,V,ee,_e):null;case T:return ee=Gs(ee),oe(K,V,ee,_e)}if(j(ee)||Z(ee))return tt!==null?null:pe(K,V,ee,_e,null);if(typeof ee.then=="function")return oe(K,V,ac(ee),_e);if(ee.$$typeof===F)return oe(K,V,ec(K,ee),_e);sc(K,ee)}return null}function le(K,V,ee,_e,tt){if(typeof _e=="string"&&_e!==""||typeof _e=="number"||typeof _e=="bigint")return K=K.get(ee)||null,R(V,K,""+_e,tt);if(typeof _e=="object"&&_e!==null){switch(_e.$$typeof){case x:return K=K.get(_e.key===null?ee:_e.key)||null,H(V,K,_e,tt);case E:return K=K.get(_e.key===null?ee:_e.key)||null,te(V,K,_e,tt);case T:return _e=Gs(_e),le(K,V,ee,_e,tt)}if(j(_e)||Z(_e))return K=K.get(ee)||null,pe(V,K,_e,tt,null);if(typeof _e.then=="function")return le(K,V,ee,ac(_e),tt);if(_e.$$typeof===F)return le(K,V,ee,ec(V,_e),tt);sc(V,_e)}return null}function Xe(K,V,ee,_e){for(var tt=null,wt=null,qe=V,ft=V=0,bt=null;qe!==null&&ft<ee.length;ft++){qe.index>ft?(bt=qe,qe=null):bt=qe.sibling;var Dt=oe(K,qe,ee[ft],_e);if(Dt===null){qe===null&&(qe=bt);break}t&&qe&&Dt.alternate===null&&i(K,qe),V=m(Dt,V,ft),wt===null?tt=Dt:wt.sibling=Dt,wt=Dt,qe=bt}if(ft===ee.length)return s(K,qe),Rt&&ma(K,ft),tt;if(qe===null){for(;ft<ee.length;ft++)qe=xe(K,ee[ft],_e),qe!==null&&(V=m(qe,V,ft),wt===null?tt=qe:wt.sibling=qe,wt=qe);return Rt&&ma(K,ft),tt}for(qe=l(qe);ft<ee.length;ft++)bt=le(qe,K,ft,ee[ft],_e),bt!==null&&(t&&bt.alternate!==null&&qe.delete(bt.key===null?ft:bt.key),V=m(bt,V,ft),wt===null?tt=bt:wt.sibling=bt,wt=bt);return t&&qe.forEach(function(gs){return i(K,gs)}),Rt&&ma(K,ft),tt}function nt(K,V,ee,_e){if(ee==null)throw Error(a(151));for(var tt=null,wt=null,qe=V,ft=V=0,bt=null,Dt=ee.next();qe!==null&&!Dt.done;ft++,Dt=ee.next()){qe.index>ft?(bt=qe,qe=null):bt=qe.sibling;var gs=oe(K,qe,Dt.value,_e);if(gs===null){qe===null&&(qe=bt);break}t&&qe&&gs.alternate===null&&i(K,qe),V=m(gs,V,ft),wt===null?tt=gs:wt.sibling=gs,wt=gs,qe=bt}if(Dt.done)return s(K,qe),Rt&&ma(K,ft),tt;if(qe===null){for(;!Dt.done;ft++,Dt=ee.next())Dt=xe(K,Dt.value,_e),Dt!==null&&(V=m(Dt,V,ft),wt===null?tt=Dt:wt.sibling=Dt,wt=Dt);return Rt&&ma(K,ft),tt}for(qe=l(qe);!Dt.done;ft++,Dt=ee.next())Dt=le(qe,K,ft,Dt.value,_e),Dt!==null&&(t&&Dt.alternate!==null&&qe.delete(Dt.key===null?ft:Dt.key),V=m(Dt,V,ft),wt===null?tt=Dt:wt.sibling=Dt,wt=Dt);return t&&qe.forEach(function(vM){return i(K,vM)}),Rt&&ma(K,ft),tt}function qt(K,V,ee,_e){if(typeof ee=="object"&&ee!==null&&ee.type===C&&ee.key===null&&(ee=ee.props.children),typeof ee=="object"&&ee!==null){switch(ee.$$typeof){case x:e:{for(var tt=ee.key;V!==null;){if(V.key===tt){if(tt=ee.type,tt===C){if(V.tag===7){s(K,V.sibling),_e=f(V,ee.props.children),_e.return=K,K=_e;break e}}else if(V.elementType===tt||typeof tt=="object"&&tt!==null&&tt.$$typeof===T&&Gs(tt)===V.type){s(K,V.sibling),_e=f(V,ee.props),Io(_e,ee),_e.return=K,K=_e;break e}s(K,V);break}else i(K,V);V=V.sibling}ee.type===C?(_e=Is(ee.props.children,K.mode,_e,ee.key),_e.return=K,K=_e):(_e=Jl(ee.type,ee.key,ee.props,null,K.mode,_e),Io(_e,ee),_e.return=K,K=_e)}return y(K);case E:e:{for(tt=ee.key;V!==null;){if(V.key===tt)if(V.tag===4&&V.stateNode.containerInfo===ee.containerInfo&&V.stateNode.implementation===ee.implementation){s(K,V.sibling),_e=f(V,ee.children||[]),_e.return=K,K=_e;break e}else{s(K,V);break}else i(K,V);V=V.sibling}_e=gf(ee,K.mode,_e),_e.return=K,K=_e}return y(K);case T:return ee=Gs(ee),qt(K,V,ee,_e)}if(j(ee))return Xe(K,V,ee,_e);if(Z(ee)){if(tt=Z(ee),typeof tt!="function")throw Error(a(150));return ee=tt.call(ee),nt(K,V,ee,_e)}if(typeof ee.then=="function")return qt(K,V,ac(ee),_e);if(ee.$$typeof===F)return qt(K,V,ec(K,ee),_e);sc(K,ee)}return typeof ee=="string"&&ee!==""||typeof ee=="number"||typeof ee=="bigint"?(ee=""+ee,V!==null&&V.tag===6?(s(K,V.sibling),_e=f(V,ee),_e.return=K,K=_e):(s(K,V),_e=mf(ee,K.mode,_e),_e.return=K,K=_e),y(K)):s(K,V)}return function(K,V,ee,_e){try{Po=0;var tt=qt(K,V,ee,_e);return Mr=null,tt}catch(qe){if(qe===Sr||qe===nc)throw qe;var wt=oi(29,qe,null,K.mode);return wt.lanes=_e,wt.return=K,wt}finally{}}}var ks=ag(!0),sg=ag(!1),$a=!1;function Cf(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function wf(t,i){t=t.updateQueue,i.updateQueue===t&&(i.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function es(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function ts(t,i,s){var l=t.updateQueue;if(l===null)return null;if(l=l.shared,(Nt&2)!==0){var f=l.pending;return f===null?i.next=i:(i.next=f.next,f.next=i),l.pending=i,i=Ql(t),Vm(t,null,s),i}return Zl(t,l,i,s),Ql(t)}function Bo(t,i,s){if(i=i.updateQueue,i!==null&&(i=i.shared,(s&4194048)!==0)){var l=i.lanes;l&=t.pendingLanes,s|=l,i.lanes=s,ni(t,s)}}function Df(t,i){var s=t.updateQueue,l=t.alternate;if(l!==null&&(l=l.updateQueue,s===l)){var f=null,m=null;if(s=s.firstBaseUpdate,s!==null){do{var y={lane:s.lane,tag:s.tag,payload:s.payload,callback:null,next:null};m===null?f=m=y:m=m.next=y,s=s.next}while(s!==null);m===null?f=m=i:m=m.next=i}else f=m=i;s={baseState:l.baseState,firstBaseUpdate:f,lastBaseUpdate:m,shared:l.shared,callbacks:l.callbacks},t.updateQueue=s;return}t=s.lastBaseUpdate,t===null?s.firstBaseUpdate=i:t.next=i,s.lastBaseUpdate=i}var Lf=!1;function Fo(){if(Lf){var t=yr;if(t!==null)throw t}}function zo(t,i,s,l){Lf=!1;var f=t.updateQueue;$a=!1;var m=f.firstBaseUpdate,y=f.lastBaseUpdate,R=f.shared.pending;if(R!==null){f.shared.pending=null;var H=R,te=H.next;H.next=null,y===null?m=te:y.next=te,y=H;var pe=t.alternate;pe!==null&&(pe=pe.updateQueue,R=pe.lastBaseUpdate,R!==y&&(R===null?pe.firstBaseUpdate=te:R.next=te,pe.lastBaseUpdate=H))}if(m!==null){var xe=f.baseState;y=0,pe=te=H=null,R=m;do{var oe=R.lane&-536870913,le=oe!==R.lane;if(le?(Et&oe)===oe:(l&oe)===oe){oe!==0&&oe===xr&&(Lf=!0),pe!==null&&(pe=pe.next={lane:0,tag:R.tag,payload:R.payload,callback:null,next:null});e:{var Xe=t,nt=R;oe=i;var qt=s;switch(nt.tag){case 1:if(Xe=nt.payload,typeof Xe=="function"){xe=Xe.call(qt,xe,oe);break e}xe=Xe;break e;case 3:Xe.flags=Xe.flags&-65537|128;case 0:if(Xe=nt.payload,oe=typeof Xe=="function"?Xe.call(qt,xe,oe):Xe,oe==null)break e;xe=_({},xe,oe);break e;case 2:$a=!0}}oe=R.callback,oe!==null&&(t.flags|=64,le&&(t.flags|=8192),le=f.callbacks,le===null?f.callbacks=[oe]:le.push(oe))}else le={lane:oe,tag:R.tag,payload:R.payload,callback:R.callback,next:null},pe===null?(te=pe=le,H=xe):pe=pe.next=le,y|=oe;if(R=R.next,R===null){if(R=f.shared.pending,R===null)break;le=R,R=le.next,le.next=null,f.lastBaseUpdate=le,f.shared.pending=null}}while(!0);pe===null&&(H=xe),f.baseState=H,f.firstBaseUpdate=te,f.lastBaseUpdate=pe,m===null&&(f.shared.lanes=0),rs|=y,t.lanes=y,t.memoizedState=xe}}function rg(t,i){if(typeof t!="function")throw Error(a(191,t));t.call(i)}function og(t,i){var s=t.callbacks;if(s!==null)for(t.callbacks=null,t=0;t<s.length;t++)rg(s[t],i)}var Er=D(null),rc=D(0);function lg(t,i){t=Aa,Ee(rc,t),Ee(Er,i),Aa=t|i.baseLanes}function Nf(){Ee(rc,Aa),Ee(Er,Er.current)}function Uf(){Aa=rc.current,Y(Er),Y(rc)}var li=D(null),Mi=null;function ns(t){var i=t.alternate;Ee(dn,dn.current&1),Ee(li,t),Mi===null&&(i===null||Er.current!==null||i.memoizedState!==null)&&(Mi=t)}function Of(t){Ee(dn,dn.current),Ee(li,t),Mi===null&&(Mi=t)}function cg(t){t.tag===22?(Ee(dn,dn.current),Ee(li,t),Mi===null&&(Mi=t)):is()}function is(){Ee(dn,dn.current),Ee(li,li.current)}function ci(t){Y(li),Mi===t&&(Mi=null),Y(dn)}var dn=D(0);function oc(t){for(var i=t;i!==null;){if(i.tag===13){var s=i.memoizedState;if(s!==null&&(s=s.dehydrated,s===null||Hh(s)||Gh(s)))return i}else if(i.tag===19&&(i.memoizedProps.revealOrder==="forwards"||i.memoizedProps.revealOrder==="backwards"||i.memoizedProps.revealOrder==="unstable_legacy-backwards"||i.memoizedProps.revealOrder==="together")){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===t)break;for(;i.sibling===null;){if(i.return===null||i.return===t)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var va=0,ut=null,Xt=null,xn=null,lc=!1,br=!1,Xs=!1,cc=0,Ho=0,Tr=null,lS=0;function un(){throw Error(a(321))}function Pf(t,i){if(i===null)return!1;for(var s=0;s<i.length&&s<t.length;s++)if(!ri(t[s],i[s]))return!1;return!0}function If(t,i,s,l,f,m){return va=m,ut=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,I.H=t===null||t.memoizedState===null?qg:Jf,Xs=!1,m=s(l,f),Xs=!1,br&&(m=fg(i,s,l,f)),ug(t),m}function ug(t){I.H=ko;var i=Xt!==null&&Xt.next!==null;if(va=0,xn=Xt=ut=null,lc=!1,Ho=0,Tr=null,i)throw Error(a(300));t===null||yn||(t=t.dependencies,t!==null&&$l(t)&&(yn=!0))}function fg(t,i,s,l){ut=t;var f=0;do{if(br&&(Tr=null),Ho=0,br=!1,25<=f)throw Error(a(301));if(f+=1,xn=Xt=null,t.updateQueue!=null){var m=t.updateQueue;m.lastEffect=null,m.events=null,m.stores=null,m.memoCache!=null&&(m.memoCache.index=0)}I.H=Yg,m=i(s,l)}while(br);return m}function cS(){var t=I.H,i=t.useState()[0];return i=typeof i.then=="function"?Go(i):i,t=t.useState()[0],(Xt!==null?Xt.memoizedState:null)!==t&&(ut.flags|=1024),i}function Bf(){var t=cc!==0;return cc=0,t}function Ff(t,i,s){i.updateQueue=t.updateQueue,i.flags&=-2053,t.lanes&=~s}function zf(t){if(lc){for(t=t.memoizedState;t!==null;){var i=t.queue;i!==null&&(i.pending=null),t=t.next}lc=!1}va=0,xn=Xt=ut=null,br=!1,Ho=cc=0,Tr=null}function kn(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return xn===null?ut.memoizedState=xn=t:xn=xn.next=t,xn}function pn(){if(Xt===null){var t=ut.alternate;t=t!==null?t.memoizedState:null}else t=Xt.next;var i=xn===null?ut.memoizedState:xn.next;if(i!==null)xn=i,Xt=t;else{if(t===null)throw ut.alternate===null?Error(a(467)):Error(a(310));Xt=t,t={memoizedState:Xt.memoizedState,baseState:Xt.baseState,baseQueue:Xt.baseQueue,queue:Xt.queue,next:null},xn===null?ut.memoizedState=xn=t:xn=xn.next=t}return xn}function uc(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Go(t){var i=Ho;return Ho+=1,Tr===null&&(Tr=[]),t=tg(Tr,t,i),i=ut,(xn===null?i.memoizedState:xn.next)===null&&(i=i.alternate,I.H=i===null||i.memoizedState===null?qg:Jf),t}function fc(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return Go(t);if(t.$$typeof===F)return In(t)}throw Error(a(438,String(t)))}function Hf(t){var i=null,s=ut.updateQueue;if(s!==null&&(i=s.memoCache),i==null){var l=ut.alternate;l!==null&&(l=l.updateQueue,l!==null&&(l=l.memoCache,l!=null&&(i={data:l.data.map(function(f){return f.slice()}),index:0})))}if(i==null&&(i={data:[],index:0}),s===null&&(s=uc(),ut.updateQueue=s),s.memoCache=i,s=i.data[i.index],s===void 0)for(s=i.data[i.index]=Array(t),l=0;l<t;l++)s[l]=X;return i.index++,s}function xa(t,i){return typeof i=="function"?i(t):i}function hc(t){var i=pn();return Gf(i,Xt,t)}function Gf(t,i,s){var l=t.queue;if(l===null)throw Error(a(311));l.lastRenderedReducer=s;var f=t.baseQueue,m=l.pending;if(m!==null){if(f!==null){var y=f.next;f.next=m.next,m.next=y}i.baseQueue=f=m,l.pending=null}if(m=t.baseState,f===null)t.memoizedState=m;else{i=f.next;var R=y=null,H=null,te=i,pe=!1;do{var xe=te.lane&-536870913;if(xe!==te.lane?(Et&xe)===xe:(va&xe)===xe){var oe=te.revertLane;if(oe===0)H!==null&&(H=H.next={lane:0,revertLane:0,gesture:null,action:te.action,hasEagerState:te.hasEagerState,eagerState:te.eagerState,next:null}),xe===xr&&(pe=!0);else if((va&oe)===oe){te=te.next,oe===xr&&(pe=!0);continue}else xe={lane:0,revertLane:te.revertLane,gesture:null,action:te.action,hasEagerState:te.hasEagerState,eagerState:te.eagerState,next:null},H===null?(R=H=xe,y=m):H=H.next=xe,ut.lanes|=oe,rs|=oe;xe=te.action,Xs&&s(m,xe),m=te.hasEagerState?te.eagerState:s(m,xe)}else oe={lane:xe,revertLane:te.revertLane,gesture:te.gesture,action:te.action,hasEagerState:te.hasEagerState,eagerState:te.eagerState,next:null},H===null?(R=H=oe,y=m):H=H.next=oe,ut.lanes|=xe,rs|=xe;te=te.next}while(te!==null&&te!==i);if(H===null?y=m:H.next=R,!ri(m,t.memoizedState)&&(yn=!0,pe&&(s=yr,s!==null)))throw s;t.memoizedState=m,t.baseState=y,t.baseQueue=H,l.lastRenderedState=m}return f===null&&(l.lanes=0),[t.memoizedState,l.dispatch]}function Vf(t){var i=pn(),s=i.queue;if(s===null)throw Error(a(311));s.lastRenderedReducer=t;var l=s.dispatch,f=s.pending,m=i.memoizedState;if(f!==null){s.pending=null;var y=f=f.next;do m=t(m,y.action),y=y.next;while(y!==f);ri(m,i.memoizedState)||(yn=!0),i.memoizedState=m,i.baseQueue===null&&(i.baseState=m),s.lastRenderedState=m}return[m,l]}function hg(t,i,s){var l=ut,f=pn(),m=Rt;if(m){if(s===void 0)throw Error(a(407));s=s()}else s=i();var y=!ri((Xt||f).memoizedState,s);if(y&&(f.memoizedState=s,yn=!0),f=f.queue,Wf(mg.bind(null,l,f,t),[t]),f.getSnapshot!==i||y||xn!==null&&xn.memoizedState.tag&1){if(l.flags|=2048,Ar(9,{destroy:void 0},pg.bind(null,l,f,s,i),null),Zt===null)throw Error(a(349));m||(va&127)!==0||dg(l,i,s)}return s}function dg(t,i,s){t.flags|=16384,t={getSnapshot:i,value:s},i=ut.updateQueue,i===null?(i=uc(),ut.updateQueue=i,i.stores=[t]):(s=i.stores,s===null?i.stores=[t]:s.push(t))}function pg(t,i,s,l){i.value=s,i.getSnapshot=l,gg(i)&&_g(t)}function mg(t,i,s){return s(function(){gg(i)&&_g(t)})}function gg(t){var i=t.getSnapshot;t=t.value;try{var s=i();return!ri(t,s)}catch{return!0}}function _g(t){var i=Ps(t,2);i!==null&&ei(i,t,2)}function kf(t){var i=kn();if(typeof t=="function"){var s=t;if(t=s(),Xs){Ae(!0);try{s()}finally{Ae(!1)}}}return i.memoizedState=i.baseState=t,i.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:xa,lastRenderedState:t},i}function vg(t,i,s,l){return t.baseState=s,Gf(t,Xt,typeof l=="function"?l:xa)}function uS(t,i,s,l,f){if(mc(t))throw Error(a(485));if(t=i.action,t!==null){var m={payload:f,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(y){m.listeners.push(y)}};I.T!==null?s(!0):m.isTransition=!1,l(m),s=i.pending,s===null?(m.next=i.pending=m,xg(i,m)):(m.next=s.next,i.pending=s.next=m)}}function xg(t,i){var s=i.action,l=i.payload,f=t.state;if(i.isTransition){var m=I.T,y={};I.T=y;try{var R=s(f,l),H=I.S;H!==null&&H(y,R),yg(t,i,R)}catch(te){Xf(t,i,te)}finally{m!==null&&y.types!==null&&(m.types=y.types),I.T=m}}else try{m=s(f,l),yg(t,i,m)}catch(te){Xf(t,i,te)}}function yg(t,i,s){s!==null&&typeof s=="object"&&typeof s.then=="function"?s.then(function(l){Sg(t,i,l)},function(l){return Xf(t,i,l)}):Sg(t,i,s)}function Sg(t,i,s){i.status="fulfilled",i.value=s,Mg(i),t.state=s,i=t.pending,i!==null&&(s=i.next,s===i?t.pending=null:(s=s.next,i.next=s,xg(t,s)))}function Xf(t,i,s){var l=t.pending;if(t.pending=null,l!==null){l=l.next;do i.status="rejected",i.reason=s,Mg(i),i=i.next;while(i!==l)}t.action=null}function Mg(t){t=t.listeners;for(var i=0;i<t.length;i++)(0,t[i])()}function Eg(t,i){return i}function bg(t,i){if(Rt){var s=Zt.formState;if(s!==null){e:{var l=ut;if(Rt){if(jt){t:{for(var f=jt,m=Si;f.nodeType!==8;){if(!m){f=null;break t}if(f=Ei(f.nextSibling),f===null){f=null;break t}}m=f.data,f=m==="F!"||m==="F"?f:null}if(f){jt=Ei(f.nextSibling),l=f.data==="F!";break e}}Ja(l)}l=!1}l&&(i=s[0])}}return s=kn(),s.memoizedState=s.baseState=i,l={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Eg,lastRenderedState:i},s.queue=l,s=kg.bind(null,ut,l),l.dispatch=s,l=kf(!1),m=Qf.bind(null,ut,!1,l.queue),l=kn(),f={state:i,dispatch:null,action:t,pending:null},l.queue=f,s=uS.bind(null,ut,f,m,s),f.dispatch=s,l.memoizedState=t,[i,s,!1]}function Tg(t){var i=pn();return Ag(i,Xt,t)}function Ag(t,i,s){if(i=Gf(t,i,Eg)[0],t=hc(xa)[0],typeof i=="object"&&i!==null&&typeof i.then=="function")try{var l=Go(i)}catch(y){throw y===Sr?nc:y}else l=i;i=pn();var f=i.queue,m=f.dispatch;return s!==i.memoizedState&&(ut.flags|=2048,Ar(9,{destroy:void 0},fS.bind(null,f,s),null)),[l,m,t]}function fS(t,i){t.action=i}function Rg(t){var i=pn(),s=Xt;if(s!==null)return Ag(i,s,t);pn(),i=i.memoizedState,s=pn();var l=s.queue.dispatch;return s.memoizedState=t,[i,l,!1]}function Ar(t,i,s,l){return t={tag:t,create:s,deps:l,inst:i,next:null},i=ut.updateQueue,i===null&&(i=uc(),ut.updateQueue=i),s=i.lastEffect,s===null?i.lastEffect=t.next=t:(l=s.next,s.next=t,t.next=l,i.lastEffect=t),t}function Cg(){return pn().memoizedState}function dc(t,i,s,l){var f=kn();ut.flags|=t,f.memoizedState=Ar(1|i,{destroy:void 0},s,l===void 0?null:l)}function pc(t,i,s,l){var f=pn();l=l===void 0?null:l;var m=f.memoizedState.inst;Xt!==null&&l!==null&&Pf(l,Xt.memoizedState.deps)?f.memoizedState=Ar(i,m,s,l):(ut.flags|=t,f.memoizedState=Ar(1|i,m,s,l))}function wg(t,i){dc(8390656,8,t,i)}function Wf(t,i){pc(2048,8,t,i)}function hS(t){ut.flags|=4;var i=ut.updateQueue;if(i===null)i=uc(),ut.updateQueue=i,i.events=[t];else{var s=i.events;s===null?i.events=[t]:s.push(t)}}function Dg(t){var i=pn().memoizedState;return hS({ref:i,nextImpl:t}),function(){if((Nt&2)!==0)throw Error(a(440));return i.impl.apply(void 0,arguments)}}function Lg(t,i){return pc(4,2,t,i)}function Ng(t,i){return pc(4,4,t,i)}function Ug(t,i){if(typeof i=="function"){t=t();var s=i(t);return function(){typeof s=="function"?s():i(null)}}if(i!=null)return t=t(),i.current=t,function(){i.current=null}}function Og(t,i,s){s=s!=null?s.concat([t]):null,pc(4,4,Ug.bind(null,i,t),s)}function qf(){}function Pg(t,i){var s=pn();i=i===void 0?null:i;var l=s.memoizedState;return i!==null&&Pf(i,l[1])?l[0]:(s.memoizedState=[t,i],t)}function Ig(t,i){var s=pn();i=i===void 0?null:i;var l=s.memoizedState;if(i!==null&&Pf(i,l[1]))return l[0];if(l=t(),Xs){Ae(!0);try{t()}finally{Ae(!1)}}return s.memoizedState=[l,i],l}function Yf(t,i,s){return s===void 0||(va&1073741824)!==0&&(Et&261930)===0?t.memoizedState=i:(t.memoizedState=s,t=B0(),ut.lanes|=t,rs|=t,s)}function Bg(t,i,s,l){return ri(s,i)?s:Er.current!==null?(t=Yf(t,s,l),ri(t,i)||(yn=!0),t):(va&42)===0||(va&1073741824)!==0&&(Et&261930)===0?(yn=!0,t.memoizedState=s):(t=B0(),ut.lanes|=t,rs|=t,i)}function Fg(t,i,s,l,f){var m=z.p;z.p=m!==0&&8>m?m:8;var y=I.T,R={};I.T=R,Qf(t,!1,i,s);try{var H=f(),te=I.S;if(te!==null&&te(R,H),H!==null&&typeof H=="object"&&typeof H.then=="function"){var pe=oS(H,l);Vo(t,i,pe,hi(t))}else Vo(t,i,l,hi(t))}catch(xe){Vo(t,i,{then:function(){},status:"rejected",reason:xe},hi())}finally{z.p=m,y!==null&&R.types!==null&&(y.types=R.types),I.T=y}}function dS(){}function Kf(t,i,s,l){if(t.tag!==5)throw Error(a(476));var f=zg(t).queue;Fg(t,f,i,Q,s===null?dS:function(){return Hg(t),s(l)})}function zg(t){var i=t.memoizedState;if(i!==null)return i;i={memoizedState:Q,baseState:Q,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:xa,lastRenderedState:Q},next:null};var s={};return i.next={memoizedState:s,baseState:s,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:xa,lastRenderedState:s},next:null},t.memoizedState=i,t=t.alternate,t!==null&&(t.memoizedState=i),i}function Hg(t){var i=zg(t);i.next===null&&(i=t.alternate.memoizedState),Vo(t,i.next.queue,{},hi())}function Zf(){return In(sl)}function Gg(){return pn().memoizedState}function Vg(){return pn().memoizedState}function pS(t){for(var i=t.return;i!==null;){switch(i.tag){case 24:case 3:var s=hi();t=es(s);var l=ts(i,t,s);l!==null&&(ei(l,i,s),Bo(l,i,s)),i={cache:bf()},t.payload=i;return}i=i.return}}function mS(t,i,s){var l=hi();s={lane:l,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},mc(t)?Xg(i,s):(s=df(t,i,s,l),s!==null&&(ei(s,t,l),Wg(s,i,l)))}function kg(t,i,s){var l=hi();Vo(t,i,s,l)}function Vo(t,i,s,l){var f={lane:l,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null};if(mc(t))Xg(i,f);else{var m=t.alternate;if(t.lanes===0&&(m===null||m.lanes===0)&&(m=i.lastRenderedReducer,m!==null))try{var y=i.lastRenderedState,R=m(y,s);if(f.hasEagerState=!0,f.eagerState=R,ri(R,y))return Zl(t,i,f,0),Zt===null&&Kl(),!1}catch{}finally{}if(s=df(t,i,f,l),s!==null)return ei(s,t,l),Wg(s,i,l),!0}return!1}function Qf(t,i,s,l){if(l={lane:2,revertLane:Ch(),gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null},mc(t)){if(i)throw Error(a(479))}else i=df(t,s,l,2),i!==null&&ei(i,t,2)}function mc(t){var i=t.alternate;return t===ut||i!==null&&i===ut}function Xg(t,i){br=lc=!0;var s=t.pending;s===null?i.next=i:(i.next=s.next,s.next=i),t.pending=i}function Wg(t,i,s){if((s&4194048)!==0){var l=i.lanes;l&=t.pendingLanes,s|=l,i.lanes=s,ni(t,s)}}var ko={readContext:In,use:fc,useCallback:un,useContext:un,useEffect:un,useImperativeHandle:un,useLayoutEffect:un,useInsertionEffect:un,useMemo:un,useReducer:un,useRef:un,useState:un,useDebugValue:un,useDeferredValue:un,useTransition:un,useSyncExternalStore:un,useId:un,useHostTransitionStatus:un,useFormState:un,useActionState:un,useOptimistic:un,useMemoCache:un,useCacheRefresh:un};ko.useEffectEvent=un;var qg={readContext:In,use:fc,useCallback:function(t,i){return kn().memoizedState=[t,i===void 0?null:i],t},useContext:In,useEffect:wg,useImperativeHandle:function(t,i,s){s=s!=null?s.concat([t]):null,dc(4194308,4,Ug.bind(null,i,t),s)},useLayoutEffect:function(t,i){return dc(4194308,4,t,i)},useInsertionEffect:function(t,i){dc(4,2,t,i)},useMemo:function(t,i){var s=kn();i=i===void 0?null:i;var l=t();if(Xs){Ae(!0);try{t()}finally{Ae(!1)}}return s.memoizedState=[l,i],l},useReducer:function(t,i,s){var l=kn();if(s!==void 0){var f=s(i);if(Xs){Ae(!0);try{s(i)}finally{Ae(!1)}}}else f=i;return l.memoizedState=l.baseState=f,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:f},l.queue=t,t=t.dispatch=mS.bind(null,ut,t),[l.memoizedState,t]},useRef:function(t){var i=kn();return t={current:t},i.memoizedState=t},useState:function(t){t=kf(t);var i=t.queue,s=kg.bind(null,ut,i);return i.dispatch=s,[t.memoizedState,s]},useDebugValue:qf,useDeferredValue:function(t,i){var s=kn();return Yf(s,t,i)},useTransition:function(){var t=kf(!1);return t=Fg.bind(null,ut,t.queue,!0,!1),kn().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,i,s){var l=ut,f=kn();if(Rt){if(s===void 0)throw Error(a(407));s=s()}else{if(s=i(),Zt===null)throw Error(a(349));(Et&127)!==0||dg(l,i,s)}f.memoizedState=s;var m={value:s,getSnapshot:i};return f.queue=m,wg(mg.bind(null,l,m,t),[t]),l.flags|=2048,Ar(9,{destroy:void 0},pg.bind(null,l,m,s,i),null),s},useId:function(){var t=kn(),i=Zt.identifierPrefix;if(Rt){var s=Ki,l=Yi;s=(l&~(1<<32-Be(l)-1)).toString(32)+s,i="_"+i+"R_"+s,s=cc++,0<s&&(i+="H"+s.toString(32)),i+="_"}else s=lS++,i="_"+i+"r_"+s.toString(32)+"_";return t.memoizedState=i},useHostTransitionStatus:Zf,useFormState:bg,useActionState:bg,useOptimistic:function(t){var i=kn();i.memoizedState=i.baseState=t;var s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return i.queue=s,i=Qf.bind(null,ut,!0,s),s.dispatch=i,[t,i]},useMemoCache:Hf,useCacheRefresh:function(){return kn().memoizedState=pS.bind(null,ut)},useEffectEvent:function(t){var i=kn(),s={impl:t};return i.memoizedState=s,function(){if((Nt&2)!==0)throw Error(a(440));return s.impl.apply(void 0,arguments)}}},Jf={readContext:In,use:fc,useCallback:Pg,useContext:In,useEffect:Wf,useImperativeHandle:Og,useInsertionEffect:Lg,useLayoutEffect:Ng,useMemo:Ig,useReducer:hc,useRef:Cg,useState:function(){return hc(xa)},useDebugValue:qf,useDeferredValue:function(t,i){var s=pn();return Bg(s,Xt.memoizedState,t,i)},useTransition:function(){var t=hc(xa)[0],i=pn().memoizedState;return[typeof t=="boolean"?t:Go(t),i]},useSyncExternalStore:hg,useId:Gg,useHostTransitionStatus:Zf,useFormState:Tg,useActionState:Tg,useOptimistic:function(t,i){var s=pn();return vg(s,Xt,t,i)},useMemoCache:Hf,useCacheRefresh:Vg};Jf.useEffectEvent=Dg;var Yg={readContext:In,use:fc,useCallback:Pg,useContext:In,useEffect:Wf,useImperativeHandle:Og,useInsertionEffect:Lg,useLayoutEffect:Ng,useMemo:Ig,useReducer:Vf,useRef:Cg,useState:function(){return Vf(xa)},useDebugValue:qf,useDeferredValue:function(t,i){var s=pn();return Xt===null?Yf(s,t,i):Bg(s,Xt.memoizedState,t,i)},useTransition:function(){var t=Vf(xa)[0],i=pn().memoizedState;return[typeof t=="boolean"?t:Go(t),i]},useSyncExternalStore:hg,useId:Gg,useHostTransitionStatus:Zf,useFormState:Rg,useActionState:Rg,useOptimistic:function(t,i){var s=pn();return Xt!==null?vg(s,Xt,t,i):(s.baseState=t,[t,s.queue.dispatch])},useMemoCache:Hf,useCacheRefresh:Vg};Yg.useEffectEvent=Dg;function jf(t,i,s,l){i=t.memoizedState,s=s(l,i),s=s==null?i:_({},i,s),t.memoizedState=s,t.lanes===0&&(t.updateQueue.baseState=s)}var $f={enqueueSetState:function(t,i,s){t=t._reactInternals;var l=hi(),f=es(l);f.payload=i,s!=null&&(f.callback=s),i=ts(t,f,l),i!==null&&(ei(i,t,l),Bo(i,t,l))},enqueueReplaceState:function(t,i,s){t=t._reactInternals;var l=hi(),f=es(l);f.tag=1,f.payload=i,s!=null&&(f.callback=s),i=ts(t,f,l),i!==null&&(ei(i,t,l),Bo(i,t,l))},enqueueForceUpdate:function(t,i){t=t._reactInternals;var s=hi(),l=es(s);l.tag=2,i!=null&&(l.callback=i),i=ts(t,l,s),i!==null&&(ei(i,t,s),Bo(i,t,s))}};function Kg(t,i,s,l,f,m,y){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(l,m,y):i.prototype&&i.prototype.isPureReactComponent?!wo(s,l)||!wo(f,m):!0}function Zg(t,i,s,l){t=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(s,l),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(s,l),i.state!==t&&$f.enqueueReplaceState(i,i.state,null)}function Ws(t,i){var s=i;if("ref"in i){s={};for(var l in i)l!=="ref"&&(s[l]=i[l])}if(t=t.defaultProps){s===i&&(s=_({},s));for(var f in t)s[f]===void 0&&(s[f]=t[f])}return s}function Qg(t){Yl(t)}function Jg(t){console.error(t)}function jg(t){Yl(t)}function gc(t,i){try{var s=t.onUncaughtError;s(i.value,{componentStack:i.stack})}catch(l){setTimeout(function(){throw l})}}function $g(t,i,s){try{var l=t.onCaughtError;l(s.value,{componentStack:s.stack,errorBoundary:i.tag===1?i.stateNode:null})}catch(f){setTimeout(function(){throw f})}}function eh(t,i,s){return s=es(s),s.tag=3,s.payload={element:null},s.callback=function(){gc(t,i)},s}function e0(t){return t=es(t),t.tag=3,t}function t0(t,i,s,l){var f=s.type.getDerivedStateFromError;if(typeof f=="function"){var m=l.value;t.payload=function(){return f(m)},t.callback=function(){$g(i,s,l)}}var y=s.stateNode;y!==null&&typeof y.componentDidCatch=="function"&&(t.callback=function(){$g(i,s,l),typeof f!="function"&&(os===null?os=new Set([this]):os.add(this));var R=l.stack;this.componentDidCatch(l.value,{componentStack:R!==null?R:""})})}function gS(t,i,s,l,f){if(s.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){if(i=s.alternate,i!==null&&vr(i,s,f,!0),s=li.current,s!==null){switch(s.tag){case 31:case 13:return Mi===null?Cc():s.alternate===null&&fn===0&&(fn=3),s.flags&=-257,s.flags|=65536,s.lanes=f,l===ic?s.flags|=16384:(i=s.updateQueue,i===null?s.updateQueue=new Set([l]):i.add(l),Th(t,l,f)),!1;case 22:return s.flags|=65536,l===ic?s.flags|=16384:(i=s.updateQueue,i===null?(i={transitions:null,markerInstances:null,retryQueue:new Set([l])},s.updateQueue=i):(s=i.retryQueue,s===null?i.retryQueue=new Set([l]):s.add(l)),Th(t,l,f)),!1}throw Error(a(435,s.tag))}return Th(t,l,f),Cc(),!1}if(Rt)return i=li.current,i!==null?((i.flags&65536)===0&&(i.flags|=256),i.flags|=65536,i.lanes=f,l!==xf&&(t=Error(a(422),{cause:l}),No(vi(t,s)))):(l!==xf&&(i=Error(a(423),{cause:l}),No(vi(i,s))),t=t.current.alternate,t.flags|=65536,f&=-f,t.lanes|=f,l=vi(l,s),f=eh(t.stateNode,l,f),Df(t,f),fn!==4&&(fn=2)),!1;var m=Error(a(520),{cause:l});if(m=vi(m,s),Jo===null?Jo=[m]:Jo.push(m),fn!==4&&(fn=2),i===null)return!0;l=vi(l,s),s=i;do{switch(s.tag){case 3:return s.flags|=65536,t=f&-f,s.lanes|=t,t=eh(s.stateNode,l,t),Df(s,t),!1;case 1:if(i=s.type,m=s.stateNode,(s.flags&128)===0&&(typeof i.getDerivedStateFromError=="function"||m!==null&&typeof m.componentDidCatch=="function"&&(os===null||!os.has(m))))return s.flags|=65536,f&=-f,s.lanes|=f,f=e0(f),t0(f,t,s,l),Df(s,f),!1}s=s.return}while(s!==null);return!1}var th=Error(a(461)),yn=!1;function Bn(t,i,s,l){i.child=t===null?sg(i,null,s,l):ks(i,t.child,s,l)}function n0(t,i,s,l,f){s=s.render;var m=i.ref;if("ref"in l){var y={};for(var R in l)R!=="ref"&&(y[R]=l[R])}else y=l;return zs(i),l=If(t,i,s,y,m,f),R=Bf(),t!==null&&!yn?(Ff(t,i,f),ya(t,i,f)):(Rt&&R&&_f(i),i.flags|=1,Bn(t,i,l,f),i.child)}function i0(t,i,s,l,f){if(t===null){var m=s.type;return typeof m=="function"&&!pf(m)&&m.defaultProps===void 0&&s.compare===null?(i.tag=15,i.type=m,a0(t,i,m,l,f)):(t=Jl(s.type,null,l,i,i.mode,f),t.ref=i.ref,t.return=i,i.child=t)}if(m=t.child,!ch(t,f)){var y=m.memoizedProps;if(s=s.compare,s=s!==null?s:wo,s(y,l)&&t.ref===i.ref)return ya(t,i,f)}return i.flags|=1,t=pa(m,l),t.ref=i.ref,t.return=i,i.child=t}function a0(t,i,s,l,f){if(t!==null){var m=t.memoizedProps;if(wo(m,l)&&t.ref===i.ref)if(yn=!1,i.pendingProps=l=m,ch(t,f))(t.flags&131072)!==0&&(yn=!0);else return i.lanes=t.lanes,ya(t,i,f)}return nh(t,i,s,l,f)}function s0(t,i,s,l){var f=l.children,m=t!==null?t.memoizedState:null;if(t===null&&i.stateNode===null&&(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),l.mode==="hidden"){if((i.flags&128)!==0){if(m=m!==null?m.baseLanes|s:s,t!==null){for(l=i.child=t.child,f=0;l!==null;)f=f|l.lanes|l.childLanes,l=l.sibling;l=f&~m}else l=0,i.child=null;return r0(t,i,m,s,l)}if((s&536870912)!==0)i.memoizedState={baseLanes:0,cachePool:null},t!==null&&tc(i,m!==null?m.cachePool:null),m!==null?lg(i,m):Nf(),cg(i);else return l=i.lanes=536870912,r0(t,i,m!==null?m.baseLanes|s:s,s,l)}else m!==null?(tc(i,m.cachePool),lg(i,m),is(),i.memoizedState=null):(t!==null&&tc(i,null),Nf(),is());return Bn(t,i,f,s),i.child}function Xo(t,i){return t!==null&&t.tag===22||i.stateNode!==null||(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.sibling}function r0(t,i,s,l,f){var m=Af();return m=m===null?null:{parent:vn._currentValue,pool:m},i.memoizedState={baseLanes:s,cachePool:m},t!==null&&tc(i,null),Nf(),cg(i),t!==null&&vr(t,i,l,!0),i.childLanes=f,null}function _c(t,i){return i=xc({mode:i.mode,children:i.children},t.mode),i.ref=t.ref,t.child=i,i.return=t,i}function o0(t,i,s){return ks(i,t.child,null,s),t=_c(i,i.pendingProps),t.flags|=2,ci(i),i.memoizedState=null,t}function _S(t,i,s){var l=i.pendingProps,f=(i.flags&128)!==0;if(i.flags&=-129,t===null){if(Rt){if(l.mode==="hidden")return t=_c(i,l),i.lanes=536870912,Xo(null,t);if(Of(i),(t=jt)?(t=x_(t,Si),t=t!==null&&t.data==="&"?t:null,t!==null&&(i.memoizedState={dehydrated:t,treeContext:Za!==null?{id:Yi,overflow:Ki}:null,retryLane:536870912,hydrationErrors:null},s=Xm(t),s.return=i,i.child=s,Pn=i,jt=null)):t=null,t===null)throw Ja(i);return i.lanes=536870912,null}return _c(i,l)}var m=t.memoizedState;if(m!==null){var y=m.dehydrated;if(Of(i),f)if(i.flags&256)i.flags&=-257,i=o0(t,i,s);else if(i.memoizedState!==null)i.child=t.child,i.flags|=128,i=null;else throw Error(a(558));else if(yn||vr(t,i,s,!1),f=(s&t.childLanes)!==0,yn||f){if(l=Zt,l!==null&&(y=ii(l,s),y!==0&&y!==m.retryLane))throw m.retryLane=y,Ps(t,y),ei(l,t,y),th;Cc(),i=o0(t,i,s)}else t=m.treeContext,jt=Ei(y.nextSibling),Pn=i,Rt=!0,Qa=null,Si=!1,t!==null&&Ym(i,t),i=_c(i,l),i.flags|=4096;return i}return t=pa(t.child,{mode:l.mode,children:l.children}),t.ref=i.ref,i.child=t,t.return=i,t}function vc(t,i){var s=i.ref;if(s===null)t!==null&&t.ref!==null&&(i.flags|=4194816);else{if(typeof s!="function"&&typeof s!="object")throw Error(a(284));(t===null||t.ref!==s)&&(i.flags|=4194816)}}function nh(t,i,s,l,f){return zs(i),s=If(t,i,s,l,void 0,f),l=Bf(),t!==null&&!yn?(Ff(t,i,f),ya(t,i,f)):(Rt&&l&&_f(i),i.flags|=1,Bn(t,i,s,f),i.child)}function l0(t,i,s,l,f,m){return zs(i),i.updateQueue=null,s=fg(i,l,s,f),ug(t),l=Bf(),t!==null&&!yn?(Ff(t,i,m),ya(t,i,m)):(Rt&&l&&_f(i),i.flags|=1,Bn(t,i,s,m),i.child)}function c0(t,i,s,l,f){if(zs(i),i.stateNode===null){var m=pr,y=s.contextType;typeof y=="object"&&y!==null&&(m=In(y)),m=new s(l,m),i.memoizedState=m.state!==null&&m.state!==void 0?m.state:null,m.updater=$f,i.stateNode=m,m._reactInternals=i,m=i.stateNode,m.props=l,m.state=i.memoizedState,m.refs={},Cf(i),y=s.contextType,m.context=typeof y=="object"&&y!==null?In(y):pr,m.state=i.memoizedState,y=s.getDerivedStateFromProps,typeof y=="function"&&(jf(i,s,y,l),m.state=i.memoizedState),typeof s.getDerivedStateFromProps=="function"||typeof m.getSnapshotBeforeUpdate=="function"||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(y=m.state,typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount(),y!==m.state&&$f.enqueueReplaceState(m,m.state,null),zo(i,l,m,f),Fo(),m.state=i.memoizedState),typeof m.componentDidMount=="function"&&(i.flags|=4194308),l=!0}else if(t===null){m=i.stateNode;var R=i.memoizedProps,H=Ws(s,R);m.props=H;var te=m.context,pe=s.contextType;y=pr,typeof pe=="object"&&pe!==null&&(y=In(pe));var xe=s.getDerivedStateFromProps;pe=typeof xe=="function"||typeof m.getSnapshotBeforeUpdate=="function",R=i.pendingProps!==R,pe||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(R||te!==y)&&Zg(i,m,l,y),$a=!1;var oe=i.memoizedState;m.state=oe,zo(i,l,m,f),Fo(),te=i.memoizedState,R||oe!==te||$a?(typeof xe=="function"&&(jf(i,s,xe,l),te=i.memoizedState),(H=$a||Kg(i,s,H,l,oe,te,y))?(pe||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount()),typeof m.componentDidMount=="function"&&(i.flags|=4194308)):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=l,i.memoizedState=te),m.props=l,m.state=te,m.context=y,l=H):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),l=!1)}else{m=i.stateNode,wf(t,i),y=i.memoizedProps,pe=Ws(s,y),m.props=pe,xe=i.pendingProps,oe=m.context,te=s.contextType,H=pr,typeof te=="object"&&te!==null&&(H=In(te)),R=s.getDerivedStateFromProps,(te=typeof R=="function"||typeof m.getSnapshotBeforeUpdate=="function")||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(y!==xe||oe!==H)&&Zg(i,m,l,H),$a=!1,oe=i.memoizedState,m.state=oe,zo(i,l,m,f),Fo();var le=i.memoizedState;y!==xe||oe!==le||$a||t!==null&&t.dependencies!==null&&$l(t.dependencies)?(typeof R=="function"&&(jf(i,s,R,l),le=i.memoizedState),(pe=$a||Kg(i,s,pe,l,oe,le,H)||t!==null&&t.dependencies!==null&&$l(t.dependencies))?(te||typeof m.UNSAFE_componentWillUpdate!="function"&&typeof m.componentWillUpdate!="function"||(typeof m.componentWillUpdate=="function"&&m.componentWillUpdate(l,le,H),typeof m.UNSAFE_componentWillUpdate=="function"&&m.UNSAFE_componentWillUpdate(l,le,H)),typeof m.componentDidUpdate=="function"&&(i.flags|=4),typeof m.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof m.componentDidUpdate!="function"||y===t.memoizedProps&&oe===t.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||y===t.memoizedProps&&oe===t.memoizedState||(i.flags|=1024),i.memoizedProps=l,i.memoizedState=le),m.props=l,m.state=le,m.context=H,l=pe):(typeof m.componentDidUpdate!="function"||y===t.memoizedProps&&oe===t.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||y===t.memoizedProps&&oe===t.memoizedState||(i.flags|=1024),l=!1)}return m=l,vc(t,i),l=(i.flags&128)!==0,m||l?(m=i.stateNode,s=l&&typeof s.getDerivedStateFromError!="function"?null:m.render(),i.flags|=1,t!==null&&l?(i.child=ks(i,t.child,null,f),i.child=ks(i,null,s,f)):Bn(t,i,s,f),i.memoizedState=m.state,t=i.child):t=ya(t,i,f),t}function u0(t,i,s,l){return Bs(),i.flags|=256,Bn(t,i,s,l),i.child}var ih={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function ah(t){return{baseLanes:t,cachePool:$m()}}function sh(t,i,s){return t=t!==null?t.childLanes&~s:0,i&&(t|=fi),t}function f0(t,i,s){var l=i.pendingProps,f=!1,m=(i.flags&128)!==0,y;if((y=m)||(y=t!==null&&t.memoizedState===null?!1:(dn.current&2)!==0),y&&(f=!0,i.flags&=-129),y=(i.flags&32)!==0,i.flags&=-33,t===null){if(Rt){if(f?ns(i):is(),(t=jt)?(t=x_(t,Si),t=t!==null&&t.data!=="&"?t:null,t!==null&&(i.memoizedState={dehydrated:t,treeContext:Za!==null?{id:Yi,overflow:Ki}:null,retryLane:536870912,hydrationErrors:null},s=Xm(t),s.return=i,i.child=s,Pn=i,jt=null)):t=null,t===null)throw Ja(i);return Gh(t)?i.lanes=32:i.lanes=536870912,null}var R=l.children;return l=l.fallback,f?(is(),f=i.mode,R=xc({mode:"hidden",children:R},f),l=Is(l,f,s,null),R.return=i,l.return=i,R.sibling=l,i.child=R,l=i.child,l.memoizedState=ah(s),l.childLanes=sh(t,y,s),i.memoizedState=ih,Xo(null,l)):(ns(i),rh(i,R))}var H=t.memoizedState;if(H!==null&&(R=H.dehydrated,R!==null)){if(m)i.flags&256?(ns(i),i.flags&=-257,i=oh(t,i,s)):i.memoizedState!==null?(is(),i.child=t.child,i.flags|=128,i=null):(is(),R=l.fallback,f=i.mode,l=xc({mode:"visible",children:l.children},f),R=Is(R,f,s,null),R.flags|=2,l.return=i,R.return=i,l.sibling=R,i.child=l,ks(i,t.child,null,s),l=i.child,l.memoizedState=ah(s),l.childLanes=sh(t,y,s),i.memoizedState=ih,i=Xo(null,l));else if(ns(i),Gh(R)){if(y=R.nextSibling&&R.nextSibling.dataset,y)var te=y.dgst;y=te,l=Error(a(419)),l.stack="",l.digest=y,No({value:l,source:null,stack:null}),i=oh(t,i,s)}else if(yn||vr(t,i,s,!1),y=(s&t.childLanes)!==0,yn||y){if(y=Zt,y!==null&&(l=ii(y,s),l!==0&&l!==H.retryLane))throw H.retryLane=l,Ps(t,l),ei(y,t,l),th;Hh(R)||Cc(),i=oh(t,i,s)}else Hh(R)?(i.flags|=192,i.child=t.child,i=null):(t=H.treeContext,jt=Ei(R.nextSibling),Pn=i,Rt=!0,Qa=null,Si=!1,t!==null&&Ym(i,t),i=rh(i,l.children),i.flags|=4096);return i}return f?(is(),R=l.fallback,f=i.mode,H=t.child,te=H.sibling,l=pa(H,{mode:"hidden",children:l.children}),l.subtreeFlags=H.subtreeFlags&65011712,te!==null?R=pa(te,R):(R=Is(R,f,s,null),R.flags|=2),R.return=i,l.return=i,l.sibling=R,i.child=l,Xo(null,l),l=i.child,R=t.child.memoizedState,R===null?R=ah(s):(f=R.cachePool,f!==null?(H=vn._currentValue,f=f.parent!==H?{parent:H,pool:H}:f):f=$m(),R={baseLanes:R.baseLanes|s,cachePool:f}),l.memoizedState=R,l.childLanes=sh(t,y,s),i.memoizedState=ih,Xo(t.child,l)):(ns(i),s=t.child,t=s.sibling,s=pa(s,{mode:"visible",children:l.children}),s.return=i,s.sibling=null,t!==null&&(y=i.deletions,y===null?(i.deletions=[t],i.flags|=16):y.push(t)),i.child=s,i.memoizedState=null,s)}function rh(t,i){return i=xc({mode:"visible",children:i},t.mode),i.return=t,t.child=i}function xc(t,i){return t=oi(22,t,null,i),t.lanes=0,t}function oh(t,i,s){return ks(i,t.child,null,s),t=rh(i,i.pendingProps.children),t.flags|=2,i.memoizedState=null,t}function h0(t,i,s){t.lanes|=i;var l=t.alternate;l!==null&&(l.lanes|=i),Mf(t.return,i,s)}function lh(t,i,s,l,f,m){var y=t.memoizedState;y===null?t.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:l,tail:s,tailMode:f,treeForkCount:m}:(y.isBackwards=i,y.rendering=null,y.renderingStartTime=0,y.last=l,y.tail=s,y.tailMode=f,y.treeForkCount=m)}function d0(t,i,s){var l=i.pendingProps,f=l.revealOrder,m=l.tail;l=l.children;var y=dn.current,R=(y&2)!==0;if(R?(y=y&1|2,i.flags|=128):y&=1,Ee(dn,y),Bn(t,i,l,s),l=Rt?Lo:0,!R&&t!==null&&(t.flags&128)!==0)e:for(t=i.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&h0(t,s,i);else if(t.tag===19)h0(t,s,i);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===i)break e;for(;t.sibling===null;){if(t.return===null||t.return===i)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(f){case"forwards":for(s=i.child,f=null;s!==null;)t=s.alternate,t!==null&&oc(t)===null&&(f=s),s=s.sibling;s=f,s===null?(f=i.child,i.child=null):(f=s.sibling,s.sibling=null),lh(i,!1,f,s,m,l);break;case"backwards":case"unstable_legacy-backwards":for(s=null,f=i.child,i.child=null;f!==null;){if(t=f.alternate,t!==null&&oc(t)===null){i.child=f;break}t=f.sibling,f.sibling=s,s=f,f=t}lh(i,!0,s,null,m,l);break;case"together":lh(i,!1,null,null,void 0,l);break;default:i.memoizedState=null}return i.child}function ya(t,i,s){if(t!==null&&(i.dependencies=t.dependencies),rs|=i.lanes,(s&i.childLanes)===0)if(t!==null){if(vr(t,i,s,!1),(s&i.childLanes)===0)return null}else return null;if(t!==null&&i.child!==t.child)throw Error(a(153));if(i.child!==null){for(t=i.child,s=pa(t,t.pendingProps),i.child=s,s.return=i;t.sibling!==null;)t=t.sibling,s=s.sibling=pa(t,t.pendingProps),s.return=i;s.sibling=null}return i.child}function ch(t,i){return(t.lanes&i)!==0?!0:(t=t.dependencies,!!(t!==null&&$l(t)))}function vS(t,i,s){switch(i.tag){case 3:Me(i,i.stateNode.containerInfo),ja(i,vn,t.memoizedState.cache),Bs();break;case 27:case 5:it(i);break;case 4:Me(i,i.stateNode.containerInfo);break;case 10:ja(i,i.type,i.memoizedProps.value);break;case 31:if(i.memoizedState!==null)return i.flags|=128,Of(i),null;break;case 13:var l=i.memoizedState;if(l!==null)return l.dehydrated!==null?(ns(i),i.flags|=128,null):(s&i.child.childLanes)!==0?f0(t,i,s):(ns(i),t=ya(t,i,s),t!==null?t.sibling:null);ns(i);break;case 19:var f=(t.flags&128)!==0;if(l=(s&i.childLanes)!==0,l||(vr(t,i,s,!1),l=(s&i.childLanes)!==0),f){if(l)return d0(t,i,s);i.flags|=128}if(f=i.memoizedState,f!==null&&(f.rendering=null,f.tail=null,f.lastEffect=null),Ee(dn,dn.current),l)break;return null;case 22:return i.lanes=0,s0(t,i,s,i.pendingProps);case 24:ja(i,vn,t.memoizedState.cache)}return ya(t,i,s)}function p0(t,i,s){if(t!==null)if(t.memoizedProps!==i.pendingProps)yn=!0;else{if(!ch(t,s)&&(i.flags&128)===0)return yn=!1,vS(t,i,s);yn=(t.flags&131072)!==0}else yn=!1,Rt&&(i.flags&1048576)!==0&&qm(i,Lo,i.index);switch(i.lanes=0,i.tag){case 16:e:{var l=i.pendingProps;if(t=Gs(i.elementType),i.type=t,typeof t=="function")pf(t)?(l=Ws(t,l),i.tag=1,i=c0(null,i,t,l,s)):(i.tag=0,i=nh(null,i,t,l,s));else{if(t!=null){var f=t.$$typeof;if(f===w){i.tag=11,i=n0(null,i,t,l,s);break e}else if(f===N){i.tag=14,i=i0(null,i,t,l,s);break e}}throw i=ge(t)||t,Error(a(306,i,""))}}return i;case 0:return nh(t,i,i.type,i.pendingProps,s);case 1:return l=i.type,f=Ws(l,i.pendingProps),c0(t,i,l,f,s);case 3:e:{if(Me(i,i.stateNode.containerInfo),t===null)throw Error(a(387));l=i.pendingProps;var m=i.memoizedState;f=m.element,wf(t,i),zo(i,l,null,s);var y=i.memoizedState;if(l=y.cache,ja(i,vn,l),l!==m.cache&&Ef(i,[vn],s,!0),Fo(),l=y.element,m.isDehydrated)if(m={element:l,isDehydrated:!1,cache:y.cache},i.updateQueue.baseState=m,i.memoizedState=m,i.flags&256){i=u0(t,i,l,s);break e}else if(l!==f){f=vi(Error(a(424)),i),No(f),i=u0(t,i,l,s);break e}else{switch(t=i.stateNode.containerInfo,t.nodeType){case 9:t=t.body;break;default:t=t.nodeName==="HTML"?t.ownerDocument.body:t}for(jt=Ei(t.firstChild),Pn=i,Rt=!0,Qa=null,Si=!0,s=sg(i,null,l,s),i.child=s;s;)s.flags=s.flags&-3|4096,s=s.sibling}else{if(Bs(),l===f){i=ya(t,i,s);break e}Bn(t,i,l,s)}i=i.child}return i;case 26:return vc(t,i),t===null?(s=T_(i.type,null,i.pendingProps,null))?i.memoizedState=s:Rt||(s=i.type,t=i.pendingProps,l=Pc(ae.current).createElement(s),l[gn]=i,l[On]=t,Fn(l,s,t),_n(l),i.stateNode=l):i.memoizedState=T_(i.type,t.memoizedProps,i.pendingProps,t.memoizedState),null;case 27:return it(i),t===null&&Rt&&(l=i.stateNode=M_(i.type,i.pendingProps,ae.current),Pn=i,Si=!0,f=jt,fs(i.type)?(Vh=f,jt=Ei(l.firstChild)):jt=f),Bn(t,i,i.pendingProps.children,s),vc(t,i),t===null&&(i.flags|=4194304),i.child;case 5:return t===null&&Rt&&((f=l=jt)&&(l=KS(l,i.type,i.pendingProps,Si),l!==null?(i.stateNode=l,Pn=i,jt=Ei(l.firstChild),Si=!1,f=!0):f=!1),f||Ja(i)),it(i),f=i.type,m=i.pendingProps,y=t!==null?t.memoizedProps:null,l=m.children,Bh(f,m)?l=null:y!==null&&Bh(f,y)&&(i.flags|=32),i.memoizedState!==null&&(f=If(t,i,cS,null,null,s),sl._currentValue=f),vc(t,i),Bn(t,i,l,s),i.child;case 6:return t===null&&Rt&&((t=s=jt)&&(s=ZS(s,i.pendingProps,Si),s!==null?(i.stateNode=s,Pn=i,jt=null,t=!0):t=!1),t||Ja(i)),null;case 13:return f0(t,i,s);case 4:return Me(i,i.stateNode.containerInfo),l=i.pendingProps,t===null?i.child=ks(i,null,l,s):Bn(t,i,l,s),i.child;case 11:return n0(t,i,i.type,i.pendingProps,s);case 7:return Bn(t,i,i.pendingProps,s),i.child;case 8:return Bn(t,i,i.pendingProps.children,s),i.child;case 12:return Bn(t,i,i.pendingProps.children,s),i.child;case 10:return l=i.pendingProps,ja(i,i.type,l.value),Bn(t,i,l.children,s),i.child;case 9:return f=i.type._context,l=i.pendingProps.children,zs(i),f=In(f),l=l(f),i.flags|=1,Bn(t,i,l,s),i.child;case 14:return i0(t,i,i.type,i.pendingProps,s);case 15:return a0(t,i,i.type,i.pendingProps,s);case 19:return d0(t,i,s);case 31:return _S(t,i,s);case 22:return s0(t,i,s,i.pendingProps);case 24:return zs(i),l=In(vn),t===null?(f=Af(),f===null&&(f=Zt,m=bf(),f.pooledCache=m,m.refCount++,m!==null&&(f.pooledCacheLanes|=s),f=m),i.memoizedState={parent:l,cache:f},Cf(i),ja(i,vn,f)):((t.lanes&s)!==0&&(wf(t,i),zo(i,null,null,s),Fo()),f=t.memoizedState,m=i.memoizedState,f.parent!==l?(f={parent:l,cache:l},i.memoizedState=f,i.lanes===0&&(i.memoizedState=i.updateQueue.baseState=f),ja(i,vn,l)):(l=m.cache,ja(i,vn,l),l!==f.cache&&Ef(i,[vn],s,!0))),Bn(t,i,i.pendingProps.children,s),i.child;case 29:throw i.pendingProps}throw Error(a(156,i.tag))}function Sa(t){t.flags|=4}function uh(t,i,s,l,f){if((i=(t.mode&32)!==0)&&(i=!1),i){if(t.flags|=16777216,(f&335544128)===f)if(t.stateNode.complete)t.flags|=8192;else if(G0())t.flags|=8192;else throw Vs=ic,Rf}else t.flags&=-16777217}function m0(t,i){if(i.type!=="stylesheet"||(i.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!D_(i))if(G0())t.flags|=8192;else throw Vs=ic,Rf}function yc(t,i){i!==null&&(t.flags|=4),t.flags&16384&&(i=t.tag!==22?Se():536870912,t.lanes|=i,Dr|=i)}function Wo(t,i){if(!Rt)switch(t.tailMode){case"hidden":i=t.tail;for(var s=null;i!==null;)i.alternate!==null&&(s=i),i=i.sibling;s===null?t.tail=null:s.sibling=null;break;case"collapsed":s=t.tail;for(var l=null;s!==null;)s.alternate!==null&&(l=s),s=s.sibling;l===null?i||t.tail===null?t.tail=null:t.tail.sibling=null:l.sibling=null}}function $t(t){var i=t.alternate!==null&&t.alternate.child===t.child,s=0,l=0;if(i)for(var f=t.child;f!==null;)s|=f.lanes|f.childLanes,l|=f.subtreeFlags&65011712,l|=f.flags&65011712,f.return=t,f=f.sibling;else for(f=t.child;f!==null;)s|=f.lanes|f.childLanes,l|=f.subtreeFlags,l|=f.flags,f.return=t,f=f.sibling;return t.subtreeFlags|=l,t.childLanes=s,i}function xS(t,i,s){var l=i.pendingProps;switch(vf(i),i.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return $t(i),null;case 1:return $t(i),null;case 3:return s=i.stateNode,l=null,t!==null&&(l=t.memoizedState.cache),i.memoizedState.cache!==l&&(i.flags|=2048),_a(vn),ze(),s.pendingContext&&(s.context=s.pendingContext,s.pendingContext=null),(t===null||t.child===null)&&(_r(i)?Sa(i):t===null||t.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,yf())),$t(i),null;case 26:var f=i.type,m=i.memoizedState;return t===null?(Sa(i),m!==null?($t(i),m0(i,m)):($t(i),uh(i,f,null,l,s))):m?m!==t.memoizedState?(Sa(i),$t(i),m0(i,m)):($t(i),i.flags&=-16777217):(t=t.memoizedProps,t!==l&&Sa(i),$t(i),uh(i,f,t,l,s)),null;case 27:if(je(i),s=ae.current,f=i.type,t!==null&&i.stateNode!=null)t.memoizedProps!==l&&Sa(i);else{if(!l){if(i.stateNode===null)throw Error(a(166));return $t(i),null}t=Re.current,_r(i)?Km(i):(t=M_(f,l,s),i.stateNode=t,Sa(i))}return $t(i),null;case 5:if(je(i),f=i.type,t!==null&&i.stateNode!=null)t.memoizedProps!==l&&Sa(i);else{if(!l){if(i.stateNode===null)throw Error(a(166));return $t(i),null}if(m=Re.current,_r(i))Km(i);else{var y=Pc(ae.current);switch(m){case 1:m=y.createElementNS("http://www.w3.org/2000/svg",f);break;case 2:m=y.createElementNS("http://www.w3.org/1998/Math/MathML",f);break;default:switch(f){case"svg":m=y.createElementNS("http://www.w3.org/2000/svg",f);break;case"math":m=y.createElementNS("http://www.w3.org/1998/Math/MathML",f);break;case"script":m=y.createElement("div"),m.innerHTML="<script><\/script>",m=m.removeChild(m.firstChild);break;case"select":m=typeof l.is=="string"?y.createElement("select",{is:l.is}):y.createElement("select"),l.multiple?m.multiple=!0:l.size&&(m.size=l.size);break;default:m=typeof l.is=="string"?y.createElement(f,{is:l.is}):y.createElement(f)}}m[gn]=i,m[On]=l;e:for(y=i.child;y!==null;){if(y.tag===5||y.tag===6)m.appendChild(y.stateNode);else if(y.tag!==4&&y.tag!==27&&y.child!==null){y.child.return=y,y=y.child;continue}if(y===i)break e;for(;y.sibling===null;){if(y.return===null||y.return===i)break e;y=y.return}y.sibling.return=y.return,y=y.sibling}i.stateNode=m;e:switch(Fn(m,f,l),f){case"button":case"input":case"select":case"textarea":l=!!l.autoFocus;break e;case"img":l=!0;break e;default:l=!1}l&&Sa(i)}}return $t(i),uh(i,i.type,t===null?null:t.memoizedProps,i.pendingProps,s),null;case 6:if(t&&i.stateNode!=null)t.memoizedProps!==l&&Sa(i);else{if(typeof l!="string"&&i.stateNode===null)throw Error(a(166));if(t=ae.current,_r(i)){if(t=i.stateNode,s=i.memoizedProps,l=null,f=Pn,f!==null)switch(f.tag){case 27:case 5:l=f.memoizedProps}t[gn]=i,t=!!(t.nodeValue===s||l!==null&&l.suppressHydrationWarning===!0||f_(t.nodeValue,s)),t||Ja(i,!0)}else t=Pc(t).createTextNode(l),t[gn]=i,i.stateNode=t}return $t(i),null;case 31:if(s=i.memoizedState,t===null||t.memoizedState!==null){if(l=_r(i),s!==null){if(t===null){if(!l)throw Error(a(318));if(t=i.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(557));t[gn]=i}else Bs(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;$t(i),t=!1}else s=yf(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=s),t=!0;if(!t)return i.flags&256?(ci(i),i):(ci(i),null);if((i.flags&128)!==0)throw Error(a(558))}return $t(i),null;case 13:if(l=i.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(f=_r(i),l!==null&&l.dehydrated!==null){if(t===null){if(!f)throw Error(a(318));if(f=i.memoizedState,f=f!==null?f.dehydrated:null,!f)throw Error(a(317));f[gn]=i}else Bs(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;$t(i),f=!1}else f=yf(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=f),f=!0;if(!f)return i.flags&256?(ci(i),i):(ci(i),null)}return ci(i),(i.flags&128)!==0?(i.lanes=s,i):(s=l!==null,t=t!==null&&t.memoizedState!==null,s&&(l=i.child,f=null,l.alternate!==null&&l.alternate.memoizedState!==null&&l.alternate.memoizedState.cachePool!==null&&(f=l.alternate.memoizedState.cachePool.pool),m=null,l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(m=l.memoizedState.cachePool.pool),m!==f&&(l.flags|=2048)),s!==t&&s&&(i.child.flags|=8192),yc(i,i.updateQueue),$t(i),null);case 4:return ze(),t===null&&Nh(i.stateNode.containerInfo),$t(i),null;case 10:return _a(i.type),$t(i),null;case 19:if(Y(dn),l=i.memoizedState,l===null)return $t(i),null;if(f=(i.flags&128)!==0,m=l.rendering,m===null)if(f)Wo(l,!1);else{if(fn!==0||t!==null&&(t.flags&128)!==0)for(t=i.child;t!==null;){if(m=oc(t),m!==null){for(i.flags|=128,Wo(l,!1),t=m.updateQueue,i.updateQueue=t,yc(i,t),i.subtreeFlags=0,t=s,s=i.child;s!==null;)km(s,t),s=s.sibling;return Ee(dn,dn.current&1|2),Rt&&ma(i,l.treeForkCount),i.child}t=t.sibling}l.tail!==null&&kt()>Tc&&(i.flags|=128,f=!0,Wo(l,!1),i.lanes=4194304)}else{if(!f)if(t=oc(m),t!==null){if(i.flags|=128,f=!0,t=t.updateQueue,i.updateQueue=t,yc(i,t),Wo(l,!0),l.tail===null&&l.tailMode==="hidden"&&!m.alternate&&!Rt)return $t(i),null}else 2*kt()-l.renderingStartTime>Tc&&s!==536870912&&(i.flags|=128,f=!0,Wo(l,!1),i.lanes=4194304);l.isBackwards?(m.sibling=i.child,i.child=m):(t=l.last,t!==null?t.sibling=m:i.child=m,l.last=m)}return l.tail!==null?(t=l.tail,l.rendering=t,l.tail=t.sibling,l.renderingStartTime=kt(),t.sibling=null,s=dn.current,Ee(dn,f?s&1|2:s&1),Rt&&ma(i,l.treeForkCount),t):($t(i),null);case 22:case 23:return ci(i),Uf(),l=i.memoizedState!==null,t!==null?t.memoizedState!==null!==l&&(i.flags|=8192):l&&(i.flags|=8192),l?(s&536870912)!==0&&(i.flags&128)===0&&($t(i),i.subtreeFlags&6&&(i.flags|=8192)):$t(i),s=i.updateQueue,s!==null&&yc(i,s.retryQueue),s=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(s=t.memoizedState.cachePool.pool),l=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(l=i.memoizedState.cachePool.pool),l!==s&&(i.flags|=2048),t!==null&&Y(Hs),null;case 24:return s=null,t!==null&&(s=t.memoizedState.cache),i.memoizedState.cache!==s&&(i.flags|=2048),_a(vn),$t(i),null;case 25:return null;case 30:return null}throw Error(a(156,i.tag))}function yS(t,i){switch(vf(i),i.tag){case 1:return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 3:return _a(vn),ze(),t=i.flags,(t&65536)!==0&&(t&128)===0?(i.flags=t&-65537|128,i):null;case 26:case 27:case 5:return je(i),null;case 31:if(i.memoizedState!==null){if(ci(i),i.alternate===null)throw Error(a(340));Bs()}return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 13:if(ci(i),t=i.memoizedState,t!==null&&t.dehydrated!==null){if(i.alternate===null)throw Error(a(340));Bs()}return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 19:return Y(dn),null;case 4:return ze(),null;case 10:return _a(i.type),null;case 22:case 23:return ci(i),Uf(),t!==null&&Y(Hs),t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 24:return _a(vn),null;case 25:return null;default:return null}}function g0(t,i){switch(vf(i),i.tag){case 3:_a(vn),ze();break;case 26:case 27:case 5:je(i);break;case 4:ze();break;case 31:i.memoizedState!==null&&ci(i);break;case 13:ci(i);break;case 19:Y(dn);break;case 10:_a(i.type);break;case 22:case 23:ci(i),Uf(),t!==null&&Y(Hs);break;case 24:_a(vn)}}function qo(t,i){try{var s=i.updateQueue,l=s!==null?s.lastEffect:null;if(l!==null){var f=l.next;s=f;do{if((s.tag&t)===t){l=void 0;var m=s.create,y=s.inst;l=m(),y.destroy=l}s=s.next}while(s!==f)}}catch(R){zt(i,i.return,R)}}function as(t,i,s){try{var l=i.updateQueue,f=l!==null?l.lastEffect:null;if(f!==null){var m=f.next;l=m;do{if((l.tag&t)===t){var y=l.inst,R=y.destroy;if(R!==void 0){y.destroy=void 0,f=i;var H=s,te=R;try{te()}catch(pe){zt(f,H,pe)}}}l=l.next}while(l!==m)}}catch(pe){zt(i,i.return,pe)}}function _0(t){var i=t.updateQueue;if(i!==null){var s=t.stateNode;try{og(i,s)}catch(l){zt(t,t.return,l)}}}function v0(t,i,s){s.props=Ws(t.type,t.memoizedProps),s.state=t.memoizedState;try{s.componentWillUnmount()}catch(l){zt(t,i,l)}}function Yo(t,i){try{var s=t.ref;if(s!==null){switch(t.tag){case 26:case 27:case 5:var l=t.stateNode;break;case 30:l=t.stateNode;break;default:l=t.stateNode}typeof s=="function"?t.refCleanup=s(l):s.current=l}}catch(f){zt(t,i,f)}}function Zi(t,i){var s=t.ref,l=t.refCleanup;if(s!==null)if(typeof l=="function")try{l()}catch(f){zt(t,i,f)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof s=="function")try{s(null)}catch(f){zt(t,i,f)}else s.current=null}function x0(t){var i=t.type,s=t.memoizedProps,l=t.stateNode;try{e:switch(i){case"button":case"input":case"select":case"textarea":s.autoFocus&&l.focus();break e;case"img":s.src?l.src=s.src:s.srcSet&&(l.srcset=s.srcSet)}}catch(f){zt(t,t.return,f)}}function fh(t,i,s){try{var l=t.stateNode;VS(l,t.type,s,i),l[On]=i}catch(f){zt(t,t.return,f)}}function y0(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&fs(t.type)||t.tag===4}function hh(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||y0(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&fs(t.type)||t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function dh(t,i,s){var l=t.tag;if(l===5||l===6)t=t.stateNode,i?(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s).insertBefore(t,i):(i=s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,i.appendChild(t),s=s._reactRootContainer,s!=null||i.onclick!==null||(i.onclick=ha));else if(l!==4&&(l===27&&fs(t.type)&&(s=t.stateNode,i=null),t=t.child,t!==null))for(dh(t,i,s),t=t.sibling;t!==null;)dh(t,i,s),t=t.sibling}function Sc(t,i,s){var l=t.tag;if(l===5||l===6)t=t.stateNode,i?s.insertBefore(t,i):s.appendChild(t);else if(l!==4&&(l===27&&fs(t.type)&&(s=t.stateNode),t=t.child,t!==null))for(Sc(t,i,s),t=t.sibling;t!==null;)Sc(t,i,s),t=t.sibling}function S0(t){var i=t.stateNode,s=t.memoizedProps;try{for(var l=t.type,f=i.attributes;f.length;)i.removeAttributeNode(f[0]);Fn(i,l,s),i[gn]=t,i[On]=s}catch(m){zt(t,t.return,m)}}var Ma=!1,Sn=!1,ph=!1,M0=typeof WeakSet=="function"?WeakSet:Set,Dn=null;function SS(t,i){if(t=t.containerInfo,Ph=Vc,t=Om(t),of(t)){if("selectionStart"in t)var s={start:t.selectionStart,end:t.selectionEnd};else e:{s=(s=t.ownerDocument)&&s.defaultView||window;var l=s.getSelection&&s.getSelection();if(l&&l.rangeCount!==0){s=l.anchorNode;var f=l.anchorOffset,m=l.focusNode;l=l.focusOffset;try{s.nodeType,m.nodeType}catch{s=null;break e}var y=0,R=-1,H=-1,te=0,pe=0,xe=t,oe=null;t:for(;;){for(var le;xe!==s||f!==0&&xe.nodeType!==3||(R=y+f),xe!==m||l!==0&&xe.nodeType!==3||(H=y+l),xe.nodeType===3&&(y+=xe.nodeValue.length),(le=xe.firstChild)!==null;)oe=xe,xe=le;for(;;){if(xe===t)break t;if(oe===s&&++te===f&&(R=y),oe===m&&++pe===l&&(H=y),(le=xe.nextSibling)!==null)break;xe=oe,oe=xe.parentNode}xe=le}s=R===-1||H===-1?null:{start:R,end:H}}else s=null}s=s||{start:0,end:0}}else s=null;for(Ih={focusedElem:t,selectionRange:s},Vc=!1,Dn=i;Dn!==null;)if(i=Dn,t=i.child,(i.subtreeFlags&1028)!==0&&t!==null)t.return=i,Dn=t;else for(;Dn!==null;){switch(i=Dn,m=i.alternate,t=i.flags,i.tag){case 0:if((t&4)!==0&&(t=i.updateQueue,t=t!==null?t.events:null,t!==null))for(s=0;s<t.length;s++)f=t[s],f.ref.impl=f.nextImpl;break;case 11:case 15:break;case 1:if((t&1024)!==0&&m!==null){t=void 0,s=i,f=m.memoizedProps,m=m.memoizedState,l=s.stateNode;try{var Xe=Ws(s.type,f);t=l.getSnapshotBeforeUpdate(Xe,m),l.__reactInternalSnapshotBeforeUpdate=t}catch(nt){zt(s,s.return,nt)}}break;case 3:if((t&1024)!==0){if(t=i.stateNode.containerInfo,s=t.nodeType,s===9)zh(t);else if(s===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":zh(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(a(163))}if(t=i.sibling,t!==null){t.return=i.return,Dn=t;break}Dn=i.return}}function E0(t,i,s){var l=s.flags;switch(s.tag){case 0:case 11:case 15:ba(t,s),l&4&&qo(5,s);break;case 1:if(ba(t,s),l&4)if(t=s.stateNode,i===null)try{t.componentDidMount()}catch(y){zt(s,s.return,y)}else{var f=Ws(s.type,i.memoizedProps);i=i.memoizedState;try{t.componentDidUpdate(f,i,t.__reactInternalSnapshotBeforeUpdate)}catch(y){zt(s,s.return,y)}}l&64&&_0(s),l&512&&Yo(s,s.return);break;case 3:if(ba(t,s),l&64&&(t=s.updateQueue,t!==null)){if(i=null,s.child!==null)switch(s.child.tag){case 27:case 5:i=s.child.stateNode;break;case 1:i=s.child.stateNode}try{og(t,i)}catch(y){zt(s,s.return,y)}}break;case 27:i===null&&l&4&&S0(s);case 26:case 5:ba(t,s),i===null&&l&4&&x0(s),l&512&&Yo(s,s.return);break;case 12:ba(t,s);break;case 31:ba(t,s),l&4&&A0(t,s);break;case 13:ba(t,s),l&4&&R0(t,s),l&64&&(t=s.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(s=DS.bind(null,s),QS(t,s))));break;case 22:if(l=s.memoizedState!==null||Ma,!l){i=i!==null&&i.memoizedState!==null||Sn,f=Ma;var m=Sn;Ma=l,(Sn=i)&&!m?Ta(t,s,(s.subtreeFlags&8772)!==0):ba(t,s),Ma=f,Sn=m}break;case 30:break;default:ba(t,s)}}function b0(t){var i=t.alternate;i!==null&&(t.alternate=null,b0(i)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(i=t.stateNode,i!==null&&Wa(i)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var sn=null,Qn=!1;function Ea(t,i,s){for(s=s.child;s!==null;)T0(t,i,s),s=s.sibling}function T0(t,i,s){if(he&&typeof he.onCommitFiberUnmount=="function")try{he.onCommitFiberUnmount(ue,s)}catch{}switch(s.tag){case 26:Sn||Zi(s,i),Ea(t,i,s),s.memoizedState?s.memoizedState.count--:s.stateNode&&(s=s.stateNode,s.parentNode.removeChild(s));break;case 27:Sn||Zi(s,i);var l=sn,f=Qn;fs(s.type)&&(sn=s.stateNode,Qn=!1),Ea(t,i,s),nl(s.stateNode),sn=l,Qn=f;break;case 5:Sn||Zi(s,i);case 6:if(l=sn,f=Qn,sn=null,Ea(t,i,s),sn=l,Qn=f,sn!==null)if(Qn)try{(sn.nodeType===9?sn.body:sn.nodeName==="HTML"?sn.ownerDocument.body:sn).removeChild(s.stateNode)}catch(m){zt(s,i,m)}else try{sn.removeChild(s.stateNode)}catch(m){zt(s,i,m)}break;case 18:sn!==null&&(Qn?(t=sn,__(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,s.stateNode),Fr(t)):__(sn,s.stateNode));break;case 4:l=sn,f=Qn,sn=s.stateNode.containerInfo,Qn=!0,Ea(t,i,s),sn=l,Qn=f;break;case 0:case 11:case 14:case 15:as(2,s,i),Sn||as(4,s,i),Ea(t,i,s);break;case 1:Sn||(Zi(s,i),l=s.stateNode,typeof l.componentWillUnmount=="function"&&v0(s,i,l)),Ea(t,i,s);break;case 21:Ea(t,i,s);break;case 22:Sn=(l=Sn)||s.memoizedState!==null,Ea(t,i,s),Sn=l;break;default:Ea(t,i,s)}}function A0(t,i){if(i.memoizedState===null&&(t=i.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{Fr(t)}catch(s){zt(i,i.return,s)}}}function R0(t,i){if(i.memoizedState===null&&(t=i.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Fr(t)}catch(s){zt(i,i.return,s)}}function MS(t){switch(t.tag){case 31:case 13:case 19:var i=t.stateNode;return i===null&&(i=t.stateNode=new M0),i;case 22:return t=t.stateNode,i=t._retryCache,i===null&&(i=t._retryCache=new M0),i;default:throw Error(a(435,t.tag))}}function Mc(t,i){var s=MS(t);i.forEach(function(l){if(!s.has(l)){s.add(l);var f=LS.bind(null,t,l);l.then(f,f)}})}function Jn(t,i){var s=i.deletions;if(s!==null)for(var l=0;l<s.length;l++){var f=s[l],m=t,y=i,R=y;e:for(;R!==null;){switch(R.tag){case 27:if(fs(R.type)){sn=R.stateNode,Qn=!1;break e}break;case 5:sn=R.stateNode,Qn=!1;break e;case 3:case 4:sn=R.stateNode.containerInfo,Qn=!0;break e}R=R.return}if(sn===null)throw Error(a(160));T0(m,y,f),sn=null,Qn=!1,m=f.alternate,m!==null&&(m.return=null),f.return=null}if(i.subtreeFlags&13886)for(i=i.child;i!==null;)C0(i,t),i=i.sibling}var Ui=null;function C0(t,i){var s=t.alternate,l=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Jn(i,t),jn(t),l&4&&(as(3,t,t.return),qo(3,t),as(5,t,t.return));break;case 1:Jn(i,t),jn(t),l&512&&(Sn||s===null||Zi(s,s.return)),l&64&&Ma&&(t=t.updateQueue,t!==null&&(l=t.callbacks,l!==null&&(s=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=s===null?l:s.concat(l))));break;case 26:var f=Ui;if(Jn(i,t),jn(t),l&512&&(Sn||s===null||Zi(s,s.return)),l&4){var m=s!==null?s.memoizedState:null;if(l=t.memoizedState,s===null)if(l===null)if(t.stateNode===null){e:{l=t.type,s=t.memoizedProps,f=f.ownerDocument||f;t:switch(l){case"title":m=f.getElementsByTagName("title")[0],(!m||m[Xa]||m[gn]||m.namespaceURI==="http://www.w3.org/2000/svg"||m.hasAttribute("itemprop"))&&(m=f.createElement(l),f.head.insertBefore(m,f.querySelector("head > title"))),Fn(m,l,s),m[gn]=t,_n(m),l=m;break e;case"link":var y=C_("link","href",f).get(l+(s.href||""));if(y){for(var R=0;R<y.length;R++)if(m=y[R],m.getAttribute("href")===(s.href==null||s.href===""?null:s.href)&&m.getAttribute("rel")===(s.rel==null?null:s.rel)&&m.getAttribute("title")===(s.title==null?null:s.title)&&m.getAttribute("crossorigin")===(s.crossOrigin==null?null:s.crossOrigin)){y.splice(R,1);break t}}m=f.createElement(l),Fn(m,l,s),f.head.appendChild(m);break;case"meta":if(y=C_("meta","content",f).get(l+(s.content||""))){for(R=0;R<y.length;R++)if(m=y[R],m.getAttribute("content")===(s.content==null?null:""+s.content)&&m.getAttribute("name")===(s.name==null?null:s.name)&&m.getAttribute("property")===(s.property==null?null:s.property)&&m.getAttribute("http-equiv")===(s.httpEquiv==null?null:s.httpEquiv)&&m.getAttribute("charset")===(s.charSet==null?null:s.charSet)){y.splice(R,1);break t}}m=f.createElement(l),Fn(m,l,s),f.head.appendChild(m);break;default:throw Error(a(468,l))}m[gn]=t,_n(m),l=m}t.stateNode=l}else w_(f,t.type,t.stateNode);else t.stateNode=R_(f,l,t.memoizedProps);else m!==l?(m===null?s.stateNode!==null&&(s=s.stateNode,s.parentNode.removeChild(s)):m.count--,l===null?w_(f,t.type,t.stateNode):R_(f,l,t.memoizedProps)):l===null&&t.stateNode!==null&&fh(t,t.memoizedProps,s.memoizedProps)}break;case 27:Jn(i,t),jn(t),l&512&&(Sn||s===null||Zi(s,s.return)),s!==null&&l&4&&fh(t,t.memoizedProps,s.memoizedProps);break;case 5:if(Jn(i,t),jn(t),l&512&&(Sn||s===null||Zi(s,s.return)),t.flags&32){f=t.stateNode;try{si(f,"")}catch(Xe){zt(t,t.return,Xe)}}l&4&&t.stateNode!=null&&(f=t.memoizedProps,fh(t,f,s!==null?s.memoizedProps:f)),l&1024&&(ph=!0);break;case 6:if(Jn(i,t),jn(t),l&4){if(t.stateNode===null)throw Error(a(162));l=t.memoizedProps,s=t.stateNode;try{s.nodeValue=l}catch(Xe){zt(t,t.return,Xe)}}break;case 3:if(Fc=null,f=Ui,Ui=Ic(i.containerInfo),Jn(i,t),Ui=f,jn(t),l&4&&s!==null&&s.memoizedState.isDehydrated)try{Fr(i.containerInfo)}catch(Xe){zt(t,t.return,Xe)}ph&&(ph=!1,w0(t));break;case 4:l=Ui,Ui=Ic(t.stateNode.containerInfo),Jn(i,t),jn(t),Ui=l;break;case 12:Jn(i,t),jn(t);break;case 31:Jn(i,t),jn(t),l&4&&(l=t.updateQueue,l!==null&&(t.updateQueue=null,Mc(t,l)));break;case 13:Jn(i,t),jn(t),t.child.flags&8192&&t.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(bc=kt()),l&4&&(l=t.updateQueue,l!==null&&(t.updateQueue=null,Mc(t,l)));break;case 22:f=t.memoizedState!==null;var H=s!==null&&s.memoizedState!==null,te=Ma,pe=Sn;if(Ma=te||f,Sn=pe||H,Jn(i,t),Sn=pe,Ma=te,jn(t),l&8192)e:for(i=t.stateNode,i._visibility=f?i._visibility&-2:i._visibility|1,f&&(s===null||H||Ma||Sn||qs(t)),s=null,i=t;;){if(i.tag===5||i.tag===26){if(s===null){H=s=i;try{if(m=H.stateNode,f)y=m.style,typeof y.setProperty=="function"?y.setProperty("display","none","important"):y.display="none";else{R=H.stateNode;var xe=H.memoizedProps.style,oe=xe!=null&&xe.hasOwnProperty("display")?xe.display:null;R.style.display=oe==null||typeof oe=="boolean"?"":(""+oe).trim()}}catch(Xe){zt(H,H.return,Xe)}}}else if(i.tag===6){if(s===null){H=i;try{H.stateNode.nodeValue=f?"":H.memoizedProps}catch(Xe){zt(H,H.return,Xe)}}}else if(i.tag===18){if(s===null){H=i;try{var le=H.stateNode;f?v_(le,!0):v_(H.stateNode,!1)}catch(Xe){zt(H,H.return,Xe)}}}else if((i.tag!==22&&i.tag!==23||i.memoizedState===null||i===t)&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===t)break e;for(;i.sibling===null;){if(i.return===null||i.return===t)break e;s===i&&(s=null),i=i.return}s===i&&(s=null),i.sibling.return=i.return,i=i.sibling}l&4&&(l=t.updateQueue,l!==null&&(s=l.retryQueue,s!==null&&(l.retryQueue=null,Mc(t,s))));break;case 19:Jn(i,t),jn(t),l&4&&(l=t.updateQueue,l!==null&&(t.updateQueue=null,Mc(t,l)));break;case 30:break;case 21:break;default:Jn(i,t),jn(t)}}function jn(t){var i=t.flags;if(i&2){try{for(var s,l=t.return;l!==null;){if(y0(l)){s=l;break}l=l.return}if(s==null)throw Error(a(160));switch(s.tag){case 27:var f=s.stateNode,m=hh(t);Sc(t,m,f);break;case 5:var y=s.stateNode;s.flags&32&&(si(y,""),s.flags&=-33);var R=hh(t);Sc(t,R,y);break;case 3:case 4:var H=s.stateNode.containerInfo,te=hh(t);dh(t,te,H);break;default:throw Error(a(161))}}catch(pe){zt(t,t.return,pe)}t.flags&=-3}i&4096&&(t.flags&=-4097)}function w0(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var i=t;w0(i),i.tag===5&&i.flags&1024&&i.stateNode.reset(),t=t.sibling}}function ba(t,i){if(i.subtreeFlags&8772)for(i=i.child;i!==null;)E0(t,i.alternate,i),i=i.sibling}function qs(t){for(t=t.child;t!==null;){var i=t;switch(i.tag){case 0:case 11:case 14:case 15:as(4,i,i.return),qs(i);break;case 1:Zi(i,i.return);var s=i.stateNode;typeof s.componentWillUnmount=="function"&&v0(i,i.return,s),qs(i);break;case 27:nl(i.stateNode);case 26:case 5:Zi(i,i.return),qs(i);break;case 22:i.memoizedState===null&&qs(i);break;case 30:qs(i);break;default:qs(i)}t=t.sibling}}function Ta(t,i,s){for(s=s&&(i.subtreeFlags&8772)!==0,i=i.child;i!==null;){var l=i.alternate,f=t,m=i,y=m.flags;switch(m.tag){case 0:case 11:case 15:Ta(f,m,s),qo(4,m);break;case 1:if(Ta(f,m,s),l=m,f=l.stateNode,typeof f.componentDidMount=="function")try{f.componentDidMount()}catch(te){zt(l,l.return,te)}if(l=m,f=l.updateQueue,f!==null){var R=l.stateNode;try{var H=f.shared.hiddenCallbacks;if(H!==null)for(f.shared.hiddenCallbacks=null,f=0;f<H.length;f++)rg(H[f],R)}catch(te){zt(l,l.return,te)}}s&&y&64&&_0(m),Yo(m,m.return);break;case 27:S0(m);case 26:case 5:Ta(f,m,s),s&&l===null&&y&4&&x0(m),Yo(m,m.return);break;case 12:Ta(f,m,s);break;case 31:Ta(f,m,s),s&&y&4&&A0(f,m);break;case 13:Ta(f,m,s),s&&y&4&&R0(f,m);break;case 22:m.memoizedState===null&&Ta(f,m,s),Yo(m,m.return);break;case 30:break;default:Ta(f,m,s)}i=i.sibling}}function mh(t,i){var s=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(s=t.memoizedState.cachePool.pool),t=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(t=i.memoizedState.cachePool.pool),t!==s&&(t!=null&&t.refCount++,s!=null&&Uo(s))}function gh(t,i){t=null,i.alternate!==null&&(t=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==t&&(i.refCount++,t!=null&&Uo(t))}function Oi(t,i,s,l){if(i.subtreeFlags&10256)for(i=i.child;i!==null;)D0(t,i,s,l),i=i.sibling}function D0(t,i,s,l){var f=i.flags;switch(i.tag){case 0:case 11:case 15:Oi(t,i,s,l),f&2048&&qo(9,i);break;case 1:Oi(t,i,s,l);break;case 3:Oi(t,i,s,l),f&2048&&(t=null,i.alternate!==null&&(t=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==t&&(i.refCount++,t!=null&&Uo(t)));break;case 12:if(f&2048){Oi(t,i,s,l),t=i.stateNode;try{var m=i.memoizedProps,y=m.id,R=m.onPostCommit;typeof R=="function"&&R(y,i.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(H){zt(i,i.return,H)}}else Oi(t,i,s,l);break;case 31:Oi(t,i,s,l);break;case 13:Oi(t,i,s,l);break;case 23:break;case 22:m=i.stateNode,y=i.alternate,i.memoizedState!==null?m._visibility&2?Oi(t,i,s,l):Ko(t,i):m._visibility&2?Oi(t,i,s,l):(m._visibility|=2,Rr(t,i,s,l,(i.subtreeFlags&10256)!==0||!1)),f&2048&&mh(y,i);break;case 24:Oi(t,i,s,l),f&2048&&gh(i.alternate,i);break;default:Oi(t,i,s,l)}}function Rr(t,i,s,l,f){for(f=f&&((i.subtreeFlags&10256)!==0||!1),i=i.child;i!==null;){var m=t,y=i,R=s,H=l,te=y.flags;switch(y.tag){case 0:case 11:case 15:Rr(m,y,R,H,f),qo(8,y);break;case 23:break;case 22:var pe=y.stateNode;y.memoizedState!==null?pe._visibility&2?Rr(m,y,R,H,f):Ko(m,y):(pe._visibility|=2,Rr(m,y,R,H,f)),f&&te&2048&&mh(y.alternate,y);break;case 24:Rr(m,y,R,H,f),f&&te&2048&&gh(y.alternate,y);break;default:Rr(m,y,R,H,f)}i=i.sibling}}function Ko(t,i){if(i.subtreeFlags&10256)for(i=i.child;i!==null;){var s=t,l=i,f=l.flags;switch(l.tag){case 22:Ko(s,l),f&2048&&mh(l.alternate,l);break;case 24:Ko(s,l),f&2048&&gh(l.alternate,l);break;default:Ko(s,l)}i=i.sibling}}var Zo=8192;function Cr(t,i,s){if(t.subtreeFlags&Zo)for(t=t.child;t!==null;)L0(t,i,s),t=t.sibling}function L0(t,i,s){switch(t.tag){case 26:Cr(t,i,s),t.flags&Zo&&t.memoizedState!==null&&lM(s,Ui,t.memoizedState,t.memoizedProps);break;case 5:Cr(t,i,s);break;case 3:case 4:var l=Ui;Ui=Ic(t.stateNode.containerInfo),Cr(t,i,s),Ui=l;break;case 22:t.memoizedState===null&&(l=t.alternate,l!==null&&l.memoizedState!==null?(l=Zo,Zo=16777216,Cr(t,i,s),Zo=l):Cr(t,i,s));break;default:Cr(t,i,s)}}function N0(t){var i=t.alternate;if(i!==null&&(t=i.child,t!==null)){i.child=null;do i=t.sibling,t.sibling=null,t=i;while(t!==null)}}function Qo(t){var i=t.deletions;if((t.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var l=i[s];Dn=l,O0(l,t)}N0(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)U0(t),t=t.sibling}function U0(t){switch(t.tag){case 0:case 11:case 15:Qo(t),t.flags&2048&&as(9,t,t.return);break;case 3:Qo(t);break;case 12:Qo(t);break;case 22:var i=t.stateNode;t.memoizedState!==null&&i._visibility&2&&(t.return===null||t.return.tag!==13)?(i._visibility&=-3,Ec(t)):Qo(t);break;default:Qo(t)}}function Ec(t){var i=t.deletions;if((t.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var l=i[s];Dn=l,O0(l,t)}N0(t)}for(t=t.child;t!==null;){switch(i=t,i.tag){case 0:case 11:case 15:as(8,i,i.return),Ec(i);break;case 22:s=i.stateNode,s._visibility&2&&(s._visibility&=-3,Ec(i));break;default:Ec(i)}t=t.sibling}}function O0(t,i){for(;Dn!==null;){var s=Dn;switch(s.tag){case 0:case 11:case 15:as(8,s,i);break;case 23:case 22:if(s.memoizedState!==null&&s.memoizedState.cachePool!==null){var l=s.memoizedState.cachePool.pool;l!=null&&l.refCount++}break;case 24:Uo(s.memoizedState.cache)}if(l=s.child,l!==null)l.return=s,Dn=l;else e:for(s=t;Dn!==null;){l=Dn;var f=l.sibling,m=l.return;if(b0(l),l===s){Dn=null;break e}if(f!==null){f.return=m,Dn=f;break e}Dn=m}}}var ES={getCacheForType:function(t){var i=In(vn),s=i.data.get(t);return s===void 0&&(s=t(),i.data.set(t,s)),s},cacheSignal:function(){return In(vn).controller.signal}},bS=typeof WeakMap=="function"?WeakMap:Map,Nt=0,Zt=null,xt=null,Et=0,Ft=0,ui=null,ss=!1,wr=!1,_h=!1,Aa=0,fn=0,rs=0,Ys=0,vh=0,fi=0,Dr=0,Jo=null,$n=null,xh=!1,bc=0,P0=0,Tc=1/0,Ac=null,os=null,Tn=0,ls=null,Lr=null,Ra=0,yh=0,Sh=null,I0=null,jo=0,Mh=null;function hi(){return(Nt&2)!==0&&Et!==0?Et&-Et:I.T!==null?Ch():So()}function B0(){if(fi===0)if((Et&536870912)===0||Rt){var t=rt;rt<<=1,(rt&3932160)===0&&(rt=262144),fi=t}else fi=536870912;return t=li.current,t!==null&&(t.flags|=32),fi}function ei(t,i,s){(t===Zt&&(Ft===2||Ft===9)||t.cancelPendingCommit!==null)&&(Nr(t,0),cs(t,Et,fi,!1)),Ge(t,s),((Nt&2)===0||t!==Zt)&&(t===Zt&&((Nt&2)===0&&(Ys|=s),fn===4&&cs(t,Et,fi,!1)),Qi(t))}function F0(t,i,s){if((Nt&6)!==0)throw Error(a(327));var l=!s&&(i&127)===0&&(i&t.expiredLanes)===0||Ce(t,i),f=l?RS(t,i):bh(t,i,!0),m=l;do{if(f===0){wr&&!l&&cs(t,i,0,!1);break}else{if(s=t.current.alternate,m&&!TS(s)){f=bh(t,i,!1),m=!1;continue}if(f===2){if(m=i,t.errorRecoveryDisabledLanes&m)var y=0;else y=t.pendingLanes&-536870913,y=y!==0?y:y&536870912?536870912:0;if(y!==0){i=y;e:{var R=t;f=Jo;var H=R.current.memoizedState.isDehydrated;if(H&&(Nr(R,y).flags|=256),y=bh(R,y,!1),y!==2){if(_h&&!H){R.errorRecoveryDisabledLanes|=m,Ys|=m,f=4;break e}m=$n,$n=f,m!==null&&($n===null?$n=m:$n.push.apply($n,m))}f=y}if(m=!1,f!==2)continue}}if(f===1){Nr(t,0),cs(t,i,0,!0);break}e:{switch(l=t,m=f,m){case 0:case 1:throw Error(a(345));case 4:if((i&4194048)!==i)break;case 6:cs(l,i,fi,!ss);break e;case 2:$n=null;break;case 3:case 5:break;default:throw Error(a(329))}if((i&62914560)===i&&(f=bc+300-kt(),10<f)){if(cs(l,i,fi,!ss),me(l,0,!0)!==0)break e;Ra=i,l.timeoutHandle=m_(z0.bind(null,l,s,$n,Ac,xh,i,fi,Ys,Dr,ss,m,"Throttled",-0,0),f);break e}z0(l,s,$n,Ac,xh,i,fi,Ys,Dr,ss,m,null,-0,0)}}break}while(!0);Qi(t)}function z0(t,i,s,l,f,m,y,R,H,te,pe,xe,oe,le){if(t.timeoutHandle=-1,xe=i.subtreeFlags,xe&8192||(xe&16785408)===16785408){xe={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:ha},L0(i,m,xe);var Xe=(m&62914560)===m?bc-kt():(m&4194048)===m?P0-kt():0;if(Xe=cM(xe,Xe),Xe!==null){Ra=m,t.cancelPendingCommit=Xe(Y0.bind(null,t,i,m,s,l,f,y,R,H,pe,xe,null,oe,le)),cs(t,m,y,!te);return}}Y0(t,i,m,s,l,f,y,R,H)}function TS(t){for(var i=t;;){var s=i.tag;if((s===0||s===11||s===15)&&i.flags&16384&&(s=i.updateQueue,s!==null&&(s=s.stores,s!==null)))for(var l=0;l<s.length;l++){var f=s[l],m=f.getSnapshot;f=f.value;try{if(!ri(m(),f))return!1}catch{return!1}}if(s=i.child,i.subtreeFlags&16384&&s!==null)s.return=i,i=s;else{if(i===t)break;for(;i.sibling===null;){if(i.return===null||i.return===t)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function cs(t,i,s,l){i&=~vh,i&=~Ys,t.suspendedLanes|=i,t.pingedLanes&=~i,l&&(t.warmLanes|=i),l=t.expirationTimes;for(var f=i;0<f;){var m=31-Be(f),y=1<<m;l[m]=-1,f&=~y}s!==0&&Ot(t,s,i)}function Rc(){return(Nt&6)===0?($o(0),!1):!0}function Eh(){if(xt!==null){if(Ft===0)var t=xt.return;else t=xt,ga=Fs=null,zf(t),Mr=null,Po=0,t=xt;for(;t!==null;)g0(t.alternate,t),t=t.return;xt=null}}function Nr(t,i){var s=t.timeoutHandle;s!==-1&&(t.timeoutHandle=-1,WS(s)),s=t.cancelPendingCommit,s!==null&&(t.cancelPendingCommit=null,s()),Ra=0,Eh(),Zt=t,xt=s=pa(t.current,null),Et=i,Ft=0,ui=null,ss=!1,wr=Ce(t,i),_h=!1,Dr=fi=vh=Ys=rs=fn=0,$n=Jo=null,xh=!1,(i&8)!==0&&(i|=i&32);var l=t.entangledLanes;if(l!==0)for(t=t.entanglements,l&=i;0<l;){var f=31-Be(l),m=1<<f;i|=t[f],l&=~m}return Aa=i,Kl(),s}function H0(t,i){ut=null,I.H=ko,i===Sr||i===nc?(i=ng(),Ft=3):i===Rf?(i=ng(),Ft=4):Ft=i===th?8:i!==null&&typeof i=="object"&&typeof i.then=="function"?6:1,ui=i,xt===null&&(fn=1,gc(t,vi(i,t.current)))}function G0(){var t=li.current;return t===null?!0:(Et&4194048)===Et?Mi===null:(Et&62914560)===Et||(Et&536870912)!==0?t===Mi:!1}function V0(){var t=I.H;return I.H=ko,t===null?ko:t}function k0(){var t=I.A;return I.A=ES,t}function Cc(){fn=4,ss||(Et&4194048)!==Et&&li.current!==null||(wr=!0),(rs&134217727)===0&&(Ys&134217727)===0||Zt===null||cs(Zt,Et,fi,!1)}function bh(t,i,s){var l=Nt;Nt|=2;var f=V0(),m=k0();(Zt!==t||Et!==i)&&(Ac=null,Nr(t,i)),i=!1;var y=fn;e:do try{if(Ft!==0&&xt!==null){var R=xt,H=ui;switch(Ft){case 8:Eh(),y=6;break e;case 3:case 2:case 9:case 6:li.current===null&&(i=!0);var te=Ft;if(Ft=0,ui=null,Ur(t,R,H,te),s&&wr){y=0;break e}break;default:te=Ft,Ft=0,ui=null,Ur(t,R,H,te)}}AS(),y=fn;break}catch(pe){H0(t,pe)}while(!0);return i&&t.shellSuspendCounter++,ga=Fs=null,Nt=l,I.H=f,I.A=m,xt===null&&(Zt=null,Et=0,Kl()),y}function AS(){for(;xt!==null;)X0(xt)}function RS(t,i){var s=Nt;Nt|=2;var l=V0(),f=k0();Zt!==t||Et!==i?(Ac=null,Tc=kt()+500,Nr(t,i)):wr=Ce(t,i);e:do try{if(Ft!==0&&xt!==null){i=xt;var m=ui;t:switch(Ft){case 1:Ft=0,ui=null,Ur(t,i,m,1);break;case 2:case 9:if(eg(m)){Ft=0,ui=null,W0(i);break}i=function(){Ft!==2&&Ft!==9||Zt!==t||(Ft=7),Qi(t)},m.then(i,i);break e;case 3:Ft=7;break e;case 4:Ft=5;break e;case 7:eg(m)?(Ft=0,ui=null,W0(i)):(Ft=0,ui=null,Ur(t,i,m,7));break;case 5:var y=null;switch(xt.tag){case 26:y=xt.memoizedState;case 5:case 27:var R=xt;if(y?D_(y):R.stateNode.complete){Ft=0,ui=null;var H=R.sibling;if(H!==null)xt=H;else{var te=R.return;te!==null?(xt=te,wc(te)):xt=null}break t}}Ft=0,ui=null,Ur(t,i,m,5);break;case 6:Ft=0,ui=null,Ur(t,i,m,6);break;case 8:Eh(),fn=6;break e;default:throw Error(a(462))}}CS();break}catch(pe){H0(t,pe)}while(!0);return ga=Fs=null,I.H=l,I.A=f,Nt=s,xt!==null?0:(Zt=null,Et=0,Kl(),fn)}function CS(){for(;xt!==null&&!cn();)X0(xt)}function X0(t){var i=p0(t.alternate,t,Aa);t.memoizedProps=t.pendingProps,i===null?wc(t):xt=i}function W0(t){var i=t,s=i.alternate;switch(i.tag){case 15:case 0:i=l0(s,i,i.pendingProps,i.type,void 0,Et);break;case 11:i=l0(s,i,i.pendingProps,i.type.render,i.ref,Et);break;case 5:zf(i);default:g0(s,i),i=xt=km(i,Aa),i=p0(s,i,Aa)}t.memoizedProps=t.pendingProps,i===null?wc(t):xt=i}function Ur(t,i,s,l){ga=Fs=null,zf(i),Mr=null,Po=0;var f=i.return;try{if(gS(t,f,i,s,Et)){fn=1,gc(t,vi(s,t.current)),xt=null;return}}catch(m){if(f!==null)throw xt=f,m;fn=1,gc(t,vi(s,t.current)),xt=null;return}i.flags&32768?(Rt||l===1?t=!0:wr||(Et&536870912)!==0?t=!1:(ss=t=!0,(l===2||l===9||l===3||l===6)&&(l=li.current,l!==null&&l.tag===13&&(l.flags|=16384))),q0(i,t)):wc(i)}function wc(t){var i=t;do{if((i.flags&32768)!==0){q0(i,ss);return}t=i.return;var s=xS(i.alternate,i,Aa);if(s!==null){xt=s;return}if(i=i.sibling,i!==null){xt=i;return}xt=i=t}while(i!==null);fn===0&&(fn=5)}function q0(t,i){do{var s=yS(t.alternate,t);if(s!==null){s.flags&=32767,xt=s;return}if(s=t.return,s!==null&&(s.flags|=32768,s.subtreeFlags=0,s.deletions=null),!i&&(t=t.sibling,t!==null)){xt=t;return}xt=t=s}while(t!==null);fn=6,xt=null}function Y0(t,i,s,l,f,m,y,R,H){t.cancelPendingCommit=null;do Dc();while(Tn!==0);if((Nt&6)!==0)throw Error(a(327));if(i!==null){if(i===t.current)throw Error(a(177));if(m=i.lanes|i.childLanes,m|=hf,tn(t,s,m,y,R,H),t===Zt&&(xt=Zt=null,Et=0),Lr=i,ls=t,Ra=s,yh=m,Sh=f,I0=l,(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,NS(J,function(){return j0(),null})):(t.callbackNode=null,t.callbackPriority=0),l=(i.flags&13878)!==0,(i.subtreeFlags&13878)!==0||l){l=I.T,I.T=null,f=z.p,z.p=2,y=Nt,Nt|=4;try{SS(t,i,s)}finally{Nt=y,z.p=f,I.T=l}}Tn=1,K0(),Z0(),Q0()}}function K0(){if(Tn===1){Tn=0;var t=ls,i=Lr,s=(i.flags&13878)!==0;if((i.subtreeFlags&13878)!==0||s){s=I.T,I.T=null;var l=z.p;z.p=2;var f=Nt;Nt|=4;try{C0(i,t);var m=Ih,y=Om(t.containerInfo),R=m.focusedElem,H=m.selectionRange;if(y!==R&&R&&R.ownerDocument&&Um(R.ownerDocument.documentElement,R)){if(H!==null&&of(R)){var te=H.start,pe=H.end;if(pe===void 0&&(pe=te),"selectionStart"in R)R.selectionStart=te,R.selectionEnd=Math.min(pe,R.value.length);else{var xe=R.ownerDocument||document,oe=xe&&xe.defaultView||window;if(oe.getSelection){var le=oe.getSelection(),Xe=R.textContent.length,nt=Math.min(H.start,Xe),qt=H.end===void 0?nt:Math.min(H.end,Xe);!le.extend&&nt>qt&&(y=qt,qt=nt,nt=y);var K=Nm(R,nt),V=Nm(R,qt);if(K&&V&&(le.rangeCount!==1||le.anchorNode!==K.node||le.anchorOffset!==K.offset||le.focusNode!==V.node||le.focusOffset!==V.offset)){var ee=xe.createRange();ee.setStart(K.node,K.offset),le.removeAllRanges(),nt>qt?(le.addRange(ee),le.extend(V.node,V.offset)):(ee.setEnd(V.node,V.offset),le.addRange(ee))}}}}for(xe=[],le=R;le=le.parentNode;)le.nodeType===1&&xe.push({element:le,left:le.scrollLeft,top:le.scrollTop});for(typeof R.focus=="function"&&R.focus(),R=0;R<xe.length;R++){var _e=xe[R];_e.element.scrollLeft=_e.left,_e.element.scrollTop=_e.top}}Vc=!!Ph,Ih=Ph=null}finally{Nt=f,z.p=l,I.T=s}}t.current=i,Tn=2}}function Z0(){if(Tn===2){Tn=0;var t=ls,i=Lr,s=(i.flags&8772)!==0;if((i.subtreeFlags&8772)!==0||s){s=I.T,I.T=null;var l=z.p;z.p=2;var f=Nt;Nt|=4;try{E0(t,i.alternate,i)}finally{Nt=f,z.p=l,I.T=s}}Tn=3}}function Q0(){if(Tn===4||Tn===3){Tn=0,q();var t=ls,i=Lr,s=Ra,l=I0;(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?Tn=5:(Tn=0,Lr=ls=null,J0(t,t.pendingLanes));var f=t.pendingLanes;if(f===0&&(os=null),yo(s),i=i.stateNode,he&&typeof he.onCommitFiberRoot=="function")try{he.onCommitFiberRoot(ue,i,void 0,(i.current.flags&128)===128)}catch{}if(l!==null){i=I.T,f=z.p,z.p=2,I.T=null;try{for(var m=t.onRecoverableError,y=0;y<l.length;y++){var R=l[y];m(R.value,{componentStack:R.stack})}}finally{I.T=i,z.p=f}}(Ra&3)!==0&&Dc(),Qi(t),f=t.pendingLanes,(s&261930)!==0&&(f&42)!==0?t===Mh?jo++:(jo=0,Mh=t):jo=0,$o(0)}}function J0(t,i){(t.pooledCacheLanes&=i)===0&&(i=t.pooledCache,i!=null&&(t.pooledCache=null,Uo(i)))}function Dc(){return K0(),Z0(),Q0(),j0()}function j0(){if(Tn!==5)return!1;var t=ls,i=yh;yh=0;var s=yo(Ra),l=I.T,f=z.p;try{z.p=32>s?32:s,I.T=null,s=Sh,Sh=null;var m=ls,y=Ra;if(Tn=0,Lr=ls=null,Ra=0,(Nt&6)!==0)throw Error(a(331));var R=Nt;if(Nt|=4,U0(m.current),D0(m,m.current,y,s),Nt=R,$o(0,!1),he&&typeof he.onPostCommitFiberRoot=="function")try{he.onPostCommitFiberRoot(ue,m)}catch{}return!0}finally{z.p=f,I.T=l,J0(t,i)}}function $0(t,i,s){i=vi(s,i),i=eh(t.stateNode,i,2),t=ts(t,i,2),t!==null&&(Ge(t,2),Qi(t))}function zt(t,i,s){if(t.tag===3)$0(t,t,s);else for(;i!==null;){if(i.tag===3){$0(i,t,s);break}else if(i.tag===1){var l=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof l.componentDidCatch=="function"&&(os===null||!os.has(l))){t=vi(s,t),s=e0(2),l=ts(i,s,2),l!==null&&(t0(s,l,i,t),Ge(l,2),Qi(l));break}}i=i.return}}function Th(t,i,s){var l=t.pingCache;if(l===null){l=t.pingCache=new bS;var f=new Set;l.set(i,f)}else f=l.get(i),f===void 0&&(f=new Set,l.set(i,f));f.has(s)||(_h=!0,f.add(s),t=wS.bind(null,t,i,s),i.then(t,t))}function wS(t,i,s){var l=t.pingCache;l!==null&&l.delete(i),t.pingedLanes|=t.suspendedLanes&s,t.warmLanes&=~s,Zt===t&&(Et&s)===s&&(fn===4||fn===3&&(Et&62914560)===Et&&300>kt()-bc?(Nt&2)===0&&Nr(t,0):vh|=s,Dr===Et&&(Dr=0)),Qi(t)}function e_(t,i){i===0&&(i=Se()),t=Ps(t,i),t!==null&&(Ge(t,i),Qi(t))}function DS(t){var i=t.memoizedState,s=0;i!==null&&(s=i.retryLane),e_(t,s)}function LS(t,i){var s=0;switch(t.tag){case 31:case 13:var l=t.stateNode,f=t.memoizedState;f!==null&&(s=f.retryLane);break;case 19:l=t.stateNode;break;case 22:l=t.stateNode._retryCache;break;default:throw Error(a(314))}l!==null&&l.delete(i),e_(t,s)}function NS(t,i){return hn(t,i)}var Lc=null,Or=null,Ah=!1,Nc=!1,Rh=!1,us=0;function Qi(t){t!==Or&&t.next===null&&(Or===null?Lc=Or=t:Or=Or.next=t),Nc=!0,Ah||(Ah=!0,OS())}function $o(t,i){if(!Rh&&Nc){Rh=!0;do for(var s=!1,l=Lc;l!==null;){if(t!==0){var f=l.pendingLanes;if(f===0)var m=0;else{var y=l.suspendedLanes,R=l.pingedLanes;m=(1<<31-Be(42|t)+1)-1,m&=f&~(y&~R),m=m&201326741?m&201326741|1:m?m|2:0}m!==0&&(s=!0,a_(l,m))}else m=Et,m=me(l,l===Zt?m:0,l.cancelPendingCommit!==null||l.timeoutHandle!==-1),(m&3)===0||Ce(l,m)||(s=!0,a_(l,m));l=l.next}while(s);Rh=!1}}function US(){t_()}function t_(){Nc=Ah=!1;var t=0;us!==0&&XS()&&(t=us);for(var i=kt(),s=null,l=Lc;l!==null;){var f=l.next,m=n_(l,i);m===0?(l.next=null,s===null?Lc=f:s.next=f,f===null&&(Or=s)):(s=l,(t!==0||(m&3)!==0)&&(Nc=!0)),l=f}Tn!==0&&Tn!==5||$o(t),us!==0&&(us=0)}function n_(t,i){for(var s=t.suspendedLanes,l=t.pingedLanes,f=t.expirationTimes,m=t.pendingLanes&-62914561;0<m;){var y=31-Be(m),R=1<<y,H=f[y];H===-1?((R&s)===0||(R&l)!==0)&&(f[y]=Ie(R,i)):H<=i&&(t.expiredLanes|=R),m&=~R}if(i=Zt,s=Et,s=me(t,t===i?s:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),l=t.callbackNode,s===0||t===i&&(Ft===2||Ft===9)||t.cancelPendingCommit!==null)return l!==null&&l!==null&&Qt(l),t.callbackNode=null,t.callbackPriority=0;if((s&3)===0||Ce(t,s)){if(i=s&-s,i===t.callbackPriority)return i;switch(l!==null&&Qt(l),yo(s)){case 2:case 8:s=b;break;case 32:s=J;break;case 268435456:s=fe;break;default:s=J}return l=i_.bind(null,t),s=hn(s,l),t.callbackPriority=i,t.callbackNode=s,i}return l!==null&&l!==null&&Qt(l),t.callbackPriority=2,t.callbackNode=null,2}function i_(t,i){if(Tn!==0&&Tn!==5)return t.callbackNode=null,t.callbackPriority=0,null;var s=t.callbackNode;if(Dc()&&t.callbackNode!==s)return null;var l=Et;return l=me(t,t===Zt?l:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),l===0?null:(F0(t,l,i),n_(t,kt()),t.callbackNode!=null&&t.callbackNode===s?i_.bind(null,t):null)}function a_(t,i){if(Dc())return null;F0(t,i,!0)}function OS(){qS(function(){(Nt&6)!==0?hn(L,US):t_()})}function Ch(){if(us===0){var t=xr;t===0&&(t=$e,$e<<=1,($e&261888)===0&&($e=256)),us=t}return us}function s_(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:Ls(""+t)}function r_(t,i){var s=i.ownerDocument.createElement("input");return s.name=i.name,s.value=i.value,t.id&&s.setAttribute("form",t.id),i.parentNode.insertBefore(s,i),t=new FormData(t),s.parentNode.removeChild(s),t}function PS(t,i,s,l,f){if(i==="submit"&&s&&s.stateNode===f){var m=s_((f[On]||null).action),y=l.submitter;y&&(i=(i=y[On]||null)?s_(i.formAction):y.getAttribute("formAction"),i!==null&&(m=i,y=null));var R=new Xl("action","action",null,l,f);t.push({event:R,listeners:[{instance:null,listener:function(){if(l.defaultPrevented){if(us!==0){var H=y?r_(f,y):new FormData(f);Kf(s,{pending:!0,data:H,method:f.method,action:m},null,H)}}else typeof m=="function"&&(R.preventDefault(),H=y?r_(f,y):new FormData(f),Kf(s,{pending:!0,data:H,method:f.method,action:m},m,H))},currentTarget:f}]})}}for(var wh=0;wh<ff.length;wh++){var Dh=ff[wh],IS=Dh.toLowerCase(),BS=Dh[0].toUpperCase()+Dh.slice(1);Ni(IS,"on"+BS)}Ni(Bm,"onAnimationEnd"),Ni(Fm,"onAnimationIteration"),Ni(zm,"onAnimationStart"),Ni("dblclick","onDoubleClick"),Ni("focusin","onFocus"),Ni("focusout","onBlur"),Ni($y,"onTransitionRun"),Ni(eS,"onTransitionStart"),Ni(tS,"onTransitionCancel"),Ni(Hm,"onTransitionEnd"),re("onMouseEnter",["mouseout","mouseover"]),re("onMouseLeave",["mouseout","mouseover"]),re("onPointerEnter",["pointerout","pointerover"]),re("onPointerLeave",["pointerout","pointerover"]),W("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),W("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),W("onBeforeInput",["compositionend","keypress","textInput","paste"]),W("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),W("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),W("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var el="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),FS=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(el));function o_(t,i){i=(i&4)!==0;for(var s=0;s<t.length;s++){var l=t[s],f=l.event;l=l.listeners;e:{var m=void 0;if(i)for(var y=l.length-1;0<=y;y--){var R=l[y],H=R.instance,te=R.currentTarget;if(R=R.listener,H!==m&&f.isPropagationStopped())break e;m=R,f.currentTarget=te;try{m(f)}catch(pe){Yl(pe)}f.currentTarget=null,m=H}else for(y=0;y<l.length;y++){if(R=l[y],H=R.instance,te=R.currentTarget,R=R.listener,H!==m&&f.isPropagationStopped())break e;m=R,f.currentTarget=te;try{m(f)}catch(pe){Yl(pe)}f.currentTarget=null,m=H}}}}function yt(t,i){var s=i[Cs];s===void 0&&(s=i[Cs]=new Set);var l=t+"__bubble";s.has(l)||(l_(i,t,2,!1),s.add(l))}function Lh(t,i,s){var l=0;i&&(l|=4),l_(s,t,l,i)}var Uc="_reactListening"+Math.random().toString(36).slice(2);function Nh(t){if(!t[Uc]){t[Uc]=!0,Hl.forEach(function(s){s!=="selectionchange"&&(FS.has(s)||Lh(s,!1,t),Lh(s,!0,t))});var i=t.nodeType===9?t:t.ownerDocument;i===null||i[Uc]||(i[Uc]=!0,Lh("selectionchange",!1,i))}}function l_(t,i,s,l){switch(B_(i)){case 2:var f=hM;break;case 8:f=dM;break;default:f=Yh}s=f.bind(null,i,s,t),f=void 0,!Ju||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(f=!0),l?f!==void 0?t.addEventListener(i,s,{capture:!0,passive:f}):t.addEventListener(i,s,!0):f!==void 0?t.addEventListener(i,s,{passive:f}):t.addEventListener(i,s,!1)}function Uh(t,i,s,l,f){var m=l;if((i&1)===0&&(i&2)===0&&l!==null)e:for(;;){if(l===null)return;var y=l.tag;if(y===3||y===4){var R=l.stateNode.containerInfo;if(R===f)break;if(y===4)for(y=l.return;y!==null;){var H=y.tag;if((H===3||H===4)&&y.stateNode.containerInfo===f)return;y=y.return}for(;R!==null;){if(y=ua(R),y===null)return;if(H=y.tag,H===5||H===6||H===26||H===27){l=m=y;continue e}R=R.parentNode}}l=l.return}dm(function(){var te=m,pe=Zu(s),xe=[];e:{var oe=Gm.get(t);if(oe!==void 0){var le=Xl,Xe=t;switch(t){case"keypress":if(Vl(s)===0)break e;case"keydown":case"keyup":le=Ly;break;case"focusin":Xe="focus",le=tf;break;case"focusout":Xe="blur",le=tf;break;case"beforeblur":case"afterblur":le=tf;break;case"click":if(s.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":le=gm;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":le=xy;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":le=Oy;break;case Bm:case Fm:case zm:le=My;break;case Hm:le=Iy;break;case"scroll":case"scrollend":le=_y;break;case"wheel":le=Fy;break;case"copy":case"cut":case"paste":le=by;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":le=vm;break;case"toggle":case"beforetoggle":le=Hy}var nt=(i&4)!==0,qt=!nt&&(t==="scroll"||t==="scrollend"),K=nt?oe!==null?oe+"Capture":null:oe;nt=[];for(var V=te,ee;V!==null;){var _e=V;if(ee=_e.stateNode,_e=_e.tag,_e!==5&&_e!==26&&_e!==27||ee===null||K===null||(_e=Mo(V,K),_e!=null&&nt.push(tl(V,_e,ee))),qt)break;V=V.return}0<nt.length&&(oe=new le(oe,Xe,null,s,pe),xe.push({event:oe,listeners:nt}))}}if((i&7)===0){e:{if(oe=t==="mouseover"||t==="pointerover",le=t==="mouseout"||t==="pointerout",oe&&s!==Ku&&(Xe=s.relatedTarget||s.fromElement)&&(ua(Xe)||Xe[Kn]))break e;if((le||oe)&&(oe=pe.window===pe?pe:(oe=pe.ownerDocument)?oe.defaultView||oe.parentWindow:window,le?(Xe=s.relatedTarget||s.toElement,le=te,Xe=Xe?ua(Xe):null,Xe!==null&&(qt=c(Xe),nt=Xe.tag,Xe!==qt||nt!==5&&nt!==27&&nt!==6)&&(Xe=null)):(le=null,Xe=te),le!==Xe)){if(nt=gm,_e="onMouseLeave",K="onMouseEnter",V="mouse",(t==="pointerout"||t==="pointerover")&&(nt=vm,_e="onPointerLeave",K="onPointerEnter",V="pointer"),qt=le==null?oe:Ds(le),ee=Xe==null?oe:Ds(Xe),oe=new nt(_e,V+"leave",le,s,pe),oe.target=qt,oe.relatedTarget=ee,_e=null,ua(pe)===te&&(nt=new nt(K,V+"enter",Xe,s,pe),nt.target=ee,nt.relatedTarget=qt,_e=nt),qt=_e,le&&Xe)t:{for(nt=zS,K=le,V=Xe,ee=0,_e=K;_e;_e=nt(_e))ee++;_e=0;for(var tt=V;tt;tt=nt(tt))_e++;for(;0<ee-_e;)K=nt(K),ee--;for(;0<_e-ee;)V=nt(V),_e--;for(;ee--;){if(K===V||V!==null&&K===V.alternate){nt=K;break t}K=nt(K),V=nt(V)}nt=null}else nt=null;le!==null&&c_(xe,oe,le,nt,!1),Xe!==null&&qt!==null&&c_(xe,qt,Xe,nt,!0)}}e:{if(oe=te?Ds(te):window,le=oe.nodeName&&oe.nodeName.toLowerCase(),le==="select"||le==="input"&&oe.type==="file")var wt=Am;else if(bm(oe))if(Rm)wt=Qy;else{wt=Ky;var qe=Yy}else le=oe.nodeName,!le||le.toLowerCase()!=="input"||oe.type!=="checkbox"&&oe.type!=="radio"?te&&Ut(te.elementType)&&(wt=Am):wt=Zy;if(wt&&(wt=wt(t,te))){Tm(xe,wt,s,pe);break e}qe&&qe(t,oe,te),t==="focusout"&&te&&oe.type==="number"&&te.memoizedProps.value!=null&&vt(oe,"number",oe.value)}switch(qe=te?Ds(te):window,t){case"focusin":(bm(qe)||qe.contentEditable==="true")&&(fr=qe,lf=te,Do=null);break;case"focusout":Do=lf=fr=null;break;case"mousedown":cf=!0;break;case"contextmenu":case"mouseup":case"dragend":cf=!1,Pm(xe,s,pe);break;case"selectionchange":if(jy)break;case"keydown":case"keyup":Pm(xe,s,pe)}var ft;if(af)e:{switch(t){case"compositionstart":var bt="onCompositionStart";break e;case"compositionend":bt="onCompositionEnd";break e;case"compositionupdate":bt="onCompositionUpdate";break e}bt=void 0}else ur?Mm(t,s)&&(bt="onCompositionEnd"):t==="keydown"&&s.keyCode===229&&(bt="onCompositionStart");bt&&(xm&&s.locale!=="ko"&&(ur||bt!=="onCompositionStart"?bt==="onCompositionEnd"&&ur&&(ft=pm()):(Ka=pe,ju="value"in Ka?Ka.value:Ka.textContent,ur=!0)),qe=Oc(te,bt),0<qe.length&&(bt=new _m(bt,t,null,s,pe),xe.push({event:bt,listeners:qe}),ft?bt.data=ft:(ft=Em(s),ft!==null&&(bt.data=ft)))),(ft=Vy?ky(t,s):Xy(t,s))&&(bt=Oc(te,"onBeforeInput"),0<bt.length&&(qe=new _m("onBeforeInput","beforeinput",null,s,pe),xe.push({event:qe,listeners:bt}),qe.data=ft)),PS(xe,t,te,s,pe)}o_(xe,i)})}function tl(t,i,s){return{instance:t,listener:i,currentTarget:s}}function Oc(t,i){for(var s=i+"Capture",l=[];t!==null;){var f=t,m=f.stateNode;if(f=f.tag,f!==5&&f!==26&&f!==27||m===null||(f=Mo(t,s),f!=null&&l.unshift(tl(t,f,m)),f=Mo(t,i),f!=null&&l.push(tl(t,f,m))),t.tag===3)return l;t=t.return}return[]}function zS(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function c_(t,i,s,l,f){for(var m=i._reactName,y=[];s!==null&&s!==l;){var R=s,H=R.alternate,te=R.stateNode;if(R=R.tag,H!==null&&H===l)break;R!==5&&R!==26&&R!==27||te===null||(H=te,f?(te=Mo(s,m),te!=null&&y.unshift(tl(s,te,H))):f||(te=Mo(s,m),te!=null&&y.push(tl(s,te,H)))),s=s.return}y.length!==0&&t.push({event:i,listeners:y})}var HS=/\r\n?/g,GS=/\u0000|\uFFFD/g;function u_(t){return(typeof t=="string"?t:""+t).replace(HS,`
`).replace(GS,"")}function f_(t,i){return i=u_(i),u_(t)===i}function Wt(t,i,s,l,f,m){switch(s){case"children":typeof l=="string"?i==="body"||i==="textarea"&&l===""||si(t,l):(typeof l=="number"||typeof l=="bigint")&&i!=="body"&&si(t,""+l);break;case"className":ke(t,"class",l);break;case"tabIndex":ke(t,"tabindex",l);break;case"dir":case"role":case"viewBox":case"width":case"height":ke(t,s,l);break;case"style":Li(t,l,m);break;case"data":if(i!=="object"){ke(t,"data",l);break}case"src":case"href":if(l===""&&(i!=="a"||s!=="href")){t.removeAttribute(s);break}if(l==null||typeof l=="function"||typeof l=="symbol"||typeof l=="boolean"){t.removeAttribute(s);break}l=Ls(""+l),t.setAttribute(s,l);break;case"action":case"formAction":if(typeof l=="function"){t.setAttribute(s,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof m=="function"&&(s==="formAction"?(i!=="input"&&Wt(t,i,"name",f.name,f,null),Wt(t,i,"formEncType",f.formEncType,f,null),Wt(t,i,"formMethod",f.formMethod,f,null),Wt(t,i,"formTarget",f.formTarget,f,null)):(Wt(t,i,"encType",f.encType,f,null),Wt(t,i,"method",f.method,f,null),Wt(t,i,"target",f.target,f,null)));if(l==null||typeof l=="symbol"||typeof l=="boolean"){t.removeAttribute(s);break}l=Ls(""+l),t.setAttribute(s,l);break;case"onClick":l!=null&&(t.onclick=ha);break;case"onScroll":l!=null&&yt("scroll",t);break;case"onScrollEnd":l!=null&&yt("scrollend",t);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(a(61));if(s=l.__html,s!=null){if(f.children!=null)throw Error(a(60));t.innerHTML=s}}break;case"multiple":t.multiple=l&&typeof l!="function"&&typeof l!="symbol";break;case"muted":t.muted=l&&typeof l!="function"&&typeof l!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(l==null||typeof l=="function"||typeof l=="boolean"||typeof l=="symbol"){t.removeAttribute("xlink:href");break}s=Ls(""+l),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",s);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":l!=null&&typeof l!="function"&&typeof l!="symbol"?t.setAttribute(s,""+l):t.removeAttribute(s);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":l&&typeof l!="function"&&typeof l!="symbol"?t.setAttribute(s,""):t.removeAttribute(s);break;case"capture":case"download":l===!0?t.setAttribute(s,""):l!==!1&&l!=null&&typeof l!="function"&&typeof l!="symbol"?t.setAttribute(s,l):t.removeAttribute(s);break;case"cols":case"rows":case"size":case"span":l!=null&&typeof l!="function"&&typeof l!="symbol"&&!isNaN(l)&&1<=l?t.setAttribute(s,l):t.removeAttribute(s);break;case"rowSpan":case"start":l==null||typeof l=="function"||typeof l=="symbol"||isNaN(l)?t.removeAttribute(s):t.setAttribute(s,l);break;case"popover":yt("beforetoggle",t),yt("toggle",t),Le(t,"popover",l);break;case"xlinkActuate":Ve(t,"http://www.w3.org/1999/xlink","xlink:actuate",l);break;case"xlinkArcrole":Ve(t,"http://www.w3.org/1999/xlink","xlink:arcrole",l);break;case"xlinkRole":Ve(t,"http://www.w3.org/1999/xlink","xlink:role",l);break;case"xlinkShow":Ve(t,"http://www.w3.org/1999/xlink","xlink:show",l);break;case"xlinkTitle":Ve(t,"http://www.w3.org/1999/xlink","xlink:title",l);break;case"xlinkType":Ve(t,"http://www.w3.org/1999/xlink","xlink:type",l);break;case"xmlBase":Ve(t,"http://www.w3.org/XML/1998/namespace","xml:base",l);break;case"xmlLang":Ve(t,"http://www.w3.org/XML/1998/namespace","xml:lang",l);break;case"xmlSpace":Ve(t,"http://www.w3.org/XML/1998/namespace","xml:space",l);break;case"is":Le(t,"is",l);break;case"innerText":case"textContent":break;default:(!(2<s.length)||s[0]!=="o"&&s[0]!=="O"||s[1]!=="n"&&s[1]!=="N")&&(s=qi.get(s)||s,Le(t,s,l))}}function Oh(t,i,s,l,f,m){switch(s){case"style":Li(t,l,m);break;case"dangerouslySetInnerHTML":if(l!=null){if(typeof l!="object"||!("__html"in l))throw Error(a(61));if(s=l.__html,s!=null){if(f.children!=null)throw Error(a(60));t.innerHTML=s}}break;case"children":typeof l=="string"?si(t,l):(typeof l=="number"||typeof l=="bigint")&&si(t,""+l);break;case"onScroll":l!=null&&yt("scroll",t);break;case"onScrollEnd":l!=null&&yt("scrollend",t);break;case"onClick":l!=null&&(t.onclick=ha);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!A.hasOwnProperty(s))e:{if(s[0]==="o"&&s[1]==="n"&&(f=s.endsWith("Capture"),i=s.slice(2,f?s.length-7:void 0),m=t[On]||null,m=m!=null?m[s]:null,typeof m=="function"&&t.removeEventListener(i,m,f),typeof l=="function")){typeof m!="function"&&m!==null&&(s in t?t[s]=null:t.hasAttribute(s)&&t.removeAttribute(s)),t.addEventListener(i,l,f);break e}s in t?t[s]=l:l===!0?t.setAttribute(s,""):Le(t,s,l)}}}function Fn(t,i,s){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":yt("error",t),yt("load",t);var l=!1,f=!1,m;for(m in s)if(s.hasOwnProperty(m)){var y=s[m];if(y!=null)switch(m){case"src":l=!0;break;case"srcSet":f=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:Wt(t,i,m,y,s,null)}}f&&Wt(t,i,"srcSet",s.srcSet,s,null),l&&Wt(t,i,"src",s.src,s,null);return;case"input":yt("invalid",t);var R=m=y=f=null,H=null,te=null;for(l in s)if(s.hasOwnProperty(l)){var pe=s[l];if(pe!=null)switch(l){case"name":f=pe;break;case"type":y=pe;break;case"checked":H=pe;break;case"defaultChecked":te=pe;break;case"value":m=pe;break;case"defaultValue":R=pe;break;case"children":case"dangerouslySetInnerHTML":if(pe!=null)throw Error(a(137,i));break;default:Wt(t,i,l,pe,s,null)}}zn(t,m,R,H,te,y,f,!1);return;case"select":yt("invalid",t),l=y=m=null;for(f in s)if(s.hasOwnProperty(f)&&(R=s[f],R!=null))switch(f){case"value":m=R;break;case"defaultValue":y=R;break;case"multiple":l=R;default:Wt(t,i,f,R,s,null)}i=m,s=y,t.multiple=!!l,i!=null?bn(t,!!l,i,!1):s!=null&&bn(t,!!l,s,!0);return;case"textarea":yt("invalid",t),m=f=l=null;for(y in s)if(s.hasOwnProperty(y)&&(R=s[y],R!=null))switch(y){case"value":l=R;break;case"defaultValue":f=R;break;case"children":m=R;break;case"dangerouslySetInnerHTML":if(R!=null)throw Error(a(91));break;default:Wt(t,i,y,R,s,null)}Di(t,l,f,m);return;case"option":for(H in s)if(s.hasOwnProperty(H)&&(l=s[H],l!=null))switch(H){case"selected":t.selected=l&&typeof l!="function"&&typeof l!="symbol";break;default:Wt(t,i,H,l,s,null)}return;case"dialog":yt("beforetoggle",t),yt("toggle",t),yt("cancel",t),yt("close",t);break;case"iframe":case"object":yt("load",t);break;case"video":case"audio":for(l=0;l<el.length;l++)yt(el[l],t);break;case"image":yt("error",t),yt("load",t);break;case"details":yt("toggle",t);break;case"embed":case"source":case"link":yt("error",t),yt("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(te in s)if(s.hasOwnProperty(te)&&(l=s[te],l!=null))switch(te){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:Wt(t,i,te,l,s,null)}return;default:if(Ut(i)){for(pe in s)s.hasOwnProperty(pe)&&(l=s[pe],l!==void 0&&Oh(t,i,pe,l,s,void 0));return}}for(R in s)s.hasOwnProperty(R)&&(l=s[R],l!=null&&Wt(t,i,R,l,s,null))}function VS(t,i,s,l){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var f=null,m=null,y=null,R=null,H=null,te=null,pe=null;for(le in s){var xe=s[le];if(s.hasOwnProperty(le)&&xe!=null)switch(le){case"checked":break;case"value":break;case"defaultValue":H=xe;default:l.hasOwnProperty(le)||Wt(t,i,le,null,l,xe)}}for(var oe in l){var le=l[oe];if(xe=s[oe],l.hasOwnProperty(oe)&&(le!=null||xe!=null))switch(oe){case"type":m=le;break;case"name":f=le;break;case"checked":te=le;break;case"defaultChecked":pe=le;break;case"value":y=le;break;case"defaultValue":R=le;break;case"children":case"dangerouslySetInnerHTML":if(le!=null)throw Error(a(137,i));break;default:le!==xe&&Wt(t,i,oe,le,l,xe)}}Fe(t,y,R,H,te,pe,m,f);return;case"select":le=y=R=oe=null;for(m in s)if(H=s[m],s.hasOwnProperty(m)&&H!=null)switch(m){case"value":break;case"multiple":le=H;default:l.hasOwnProperty(m)||Wt(t,i,m,null,l,H)}for(f in l)if(m=l[f],H=s[f],l.hasOwnProperty(f)&&(m!=null||H!=null))switch(f){case"value":oe=m;break;case"defaultValue":R=m;break;case"multiple":y=m;default:m!==H&&Wt(t,i,f,m,l,H)}i=R,s=y,l=le,oe!=null?bn(t,!!s,oe,!1):!!l!=!!s&&(i!=null?bn(t,!!s,i,!0):bn(t,!!s,s?[]:"",!1));return;case"textarea":le=oe=null;for(R in s)if(f=s[R],s.hasOwnProperty(R)&&f!=null&&!l.hasOwnProperty(R))switch(R){case"value":break;case"children":break;default:Wt(t,i,R,null,l,f)}for(y in l)if(f=l[y],m=s[y],l.hasOwnProperty(y)&&(f!=null||m!=null))switch(y){case"value":oe=f;break;case"defaultValue":le=f;break;case"children":break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(a(91));break;default:f!==m&&Wt(t,i,y,f,l,m)}ai(t,oe,le);return;case"option":for(var Xe in s)if(oe=s[Xe],s.hasOwnProperty(Xe)&&oe!=null&&!l.hasOwnProperty(Xe))switch(Xe){case"selected":t.selected=!1;break;default:Wt(t,i,Xe,null,l,oe)}for(H in l)if(oe=l[H],le=s[H],l.hasOwnProperty(H)&&oe!==le&&(oe!=null||le!=null))switch(H){case"selected":t.selected=oe&&typeof oe!="function"&&typeof oe!="symbol";break;default:Wt(t,i,H,oe,l,le)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var nt in s)oe=s[nt],s.hasOwnProperty(nt)&&oe!=null&&!l.hasOwnProperty(nt)&&Wt(t,i,nt,null,l,oe);for(te in l)if(oe=l[te],le=s[te],l.hasOwnProperty(te)&&oe!==le&&(oe!=null||le!=null))switch(te){case"children":case"dangerouslySetInnerHTML":if(oe!=null)throw Error(a(137,i));break;default:Wt(t,i,te,oe,l,le)}return;default:if(Ut(i)){for(var qt in s)oe=s[qt],s.hasOwnProperty(qt)&&oe!==void 0&&!l.hasOwnProperty(qt)&&Oh(t,i,qt,void 0,l,oe);for(pe in l)oe=l[pe],le=s[pe],!l.hasOwnProperty(pe)||oe===le||oe===void 0&&le===void 0||Oh(t,i,pe,oe,l,le);return}}for(var K in s)oe=s[K],s.hasOwnProperty(K)&&oe!=null&&!l.hasOwnProperty(K)&&Wt(t,i,K,null,l,oe);for(xe in l)oe=l[xe],le=s[xe],!l.hasOwnProperty(xe)||oe===le||oe==null&&le==null||Wt(t,i,xe,oe,l,le)}function h_(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function kS(){if(typeof performance.getEntriesByType=="function"){for(var t=0,i=0,s=performance.getEntriesByType("resource"),l=0;l<s.length;l++){var f=s[l],m=f.transferSize,y=f.initiatorType,R=f.duration;if(m&&R&&h_(y)){for(y=0,R=f.responseEnd,l+=1;l<s.length;l++){var H=s[l],te=H.startTime;if(te>R)break;var pe=H.transferSize,xe=H.initiatorType;pe&&h_(xe)&&(H=H.responseEnd,y+=pe*(H<R?1:(R-te)/(H-te)))}if(--l,i+=8*(m+y)/(f.duration/1e3),t++,10<t)break}}if(0<t)return i/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var Ph=null,Ih=null;function Pc(t){return t.nodeType===9?t:t.ownerDocument}function d_(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function p_(t,i){if(t===0)switch(i){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&i==="foreignObject"?0:t}function Bh(t,i){return t==="textarea"||t==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.children=="bigint"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Fh=null;function XS(){var t=window.event;return t&&t.type==="popstate"?t===Fh?!1:(Fh=t,!0):(Fh=null,!1)}var m_=typeof setTimeout=="function"?setTimeout:void 0,WS=typeof clearTimeout=="function"?clearTimeout:void 0,g_=typeof Promise=="function"?Promise:void 0,qS=typeof queueMicrotask=="function"?queueMicrotask:typeof g_<"u"?function(t){return g_.resolve(null).then(t).catch(YS)}:m_;function YS(t){setTimeout(function(){throw t})}function fs(t){return t==="head"}function __(t,i){var s=i,l=0;do{var f=s.nextSibling;if(t.removeChild(s),f&&f.nodeType===8)if(s=f.data,s==="/$"||s==="/&"){if(l===0){t.removeChild(f),Fr(i);return}l--}else if(s==="$"||s==="$?"||s==="$~"||s==="$!"||s==="&")l++;else if(s==="html")nl(t.ownerDocument.documentElement);else if(s==="head"){s=t.ownerDocument.head,nl(s);for(var m=s.firstChild;m;){var y=m.nextSibling,R=m.nodeName;m[Xa]||R==="SCRIPT"||R==="STYLE"||R==="LINK"&&m.rel.toLowerCase()==="stylesheet"||s.removeChild(m),m=y}}else s==="body"&&nl(t.ownerDocument.body);s=f}while(s);Fr(i)}function v_(t,i){var s=t;t=0;do{var l=s.nextSibling;if(s.nodeType===1?i?(s._stashedDisplay=s.style.display,s.style.display="none"):(s.style.display=s._stashedDisplay||"",s.getAttribute("style")===""&&s.removeAttribute("style")):s.nodeType===3&&(i?(s._stashedText=s.nodeValue,s.nodeValue=""):s.nodeValue=s._stashedText||""),l&&l.nodeType===8)if(s=l.data,s==="/$"){if(t===0)break;t--}else s!=="$"&&s!=="$?"&&s!=="$~"&&s!=="$!"||t++;s=l}while(s)}function zh(t){var i=t.firstChild;for(i&&i.nodeType===10&&(i=i.nextSibling);i;){var s=i;switch(i=i.nextSibling,s.nodeName){case"HTML":case"HEAD":case"BODY":zh(s),Wa(s);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(s.rel.toLowerCase()==="stylesheet")continue}t.removeChild(s)}}function KS(t,i,s,l){for(;t.nodeType===1;){var f=s;if(t.nodeName.toLowerCase()!==i.toLowerCase()){if(!l&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(l){if(!t[Xa])switch(i){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(m=t.getAttribute("rel"),m==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(m!==f.rel||t.getAttribute("href")!==(f.href==null||f.href===""?null:f.href)||t.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin)||t.getAttribute("title")!==(f.title==null?null:f.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(m=t.getAttribute("src"),(m!==(f.src==null?null:f.src)||t.getAttribute("type")!==(f.type==null?null:f.type)||t.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin))&&m&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(i==="input"&&t.type==="hidden"){var m=f.name==null?null:""+f.name;if(f.type==="hidden"&&t.getAttribute("name")===m)return t}else return t;if(t=Ei(t.nextSibling),t===null)break}return null}function ZS(t,i,s){if(i==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!s||(t=Ei(t.nextSibling),t===null))return null;return t}function x_(t,i){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!i||(t=Ei(t.nextSibling),t===null))return null;return t}function Hh(t){return t.data==="$?"||t.data==="$~"}function Gh(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function QS(t,i){var s=t.ownerDocument;if(t.data==="$~")t._reactRetry=i;else if(t.data!=="$?"||s.readyState!=="loading")i();else{var l=function(){i(),s.removeEventListener("DOMContentLoaded",l)};s.addEventListener("DOMContentLoaded",l),t._reactRetry=l}}function Ei(t){for(;t!=null;t=t.nextSibling){var i=t.nodeType;if(i===1||i===3)break;if(i===8){if(i=t.data,i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"||i==="F!"||i==="F")break;if(i==="/$"||i==="/&")return null}}return t}var Vh=null;function y_(t){t=t.nextSibling;for(var i=0;t;){if(t.nodeType===8){var s=t.data;if(s==="/$"||s==="/&"){if(i===0)return Ei(t.nextSibling);i--}else s!=="$"&&s!=="$!"&&s!=="$?"&&s!=="$~"&&s!=="&"||i++}t=t.nextSibling}return null}function S_(t){t=t.previousSibling;for(var i=0;t;){if(t.nodeType===8){var s=t.data;if(s==="$"||s==="$!"||s==="$?"||s==="$~"||s==="&"){if(i===0)return t;i--}else s!=="/$"&&s!=="/&"||i++}t=t.previousSibling}return null}function M_(t,i,s){switch(i=Pc(s),t){case"html":if(t=i.documentElement,!t)throw Error(a(452));return t;case"head":if(t=i.head,!t)throw Error(a(453));return t;case"body":if(t=i.body,!t)throw Error(a(454));return t;default:throw Error(a(451))}}function nl(t){for(var i=t.attributes;i.length;)t.removeAttributeNode(i[0]);Wa(t)}var bi=new Map,E_=new Set;function Ic(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var Ca=z.d;z.d={f:JS,r:jS,D:$S,C:eM,L:tM,m:nM,X:aM,S:iM,M:sM};function JS(){var t=Ca.f(),i=Rc();return t||i}function jS(t){var i=fa(t);i!==null&&i.tag===5&&i.type==="form"?Hg(i):Ca.r(t)}var Pr=typeof document>"u"?null:document;function b_(t,i,s){var l=Pr;if(l&&typeof i=="string"&&i){var f=It(i);f='link[rel="'+t+'"][href="'+f+'"]',typeof s=="string"&&(f+='[crossorigin="'+s+'"]'),E_.has(f)||(E_.add(f),t={rel:t,crossOrigin:s,href:i},l.querySelector(f)===null&&(i=l.createElement("link"),Fn(i,"link",t),_n(i),l.head.appendChild(i)))}}function $S(t){Ca.D(t),b_("dns-prefetch",t,null)}function eM(t,i){Ca.C(t,i),b_("preconnect",t,i)}function tM(t,i,s){Ca.L(t,i,s);var l=Pr;if(l&&t&&i){var f='link[rel="preload"][as="'+It(i)+'"]';i==="image"&&s&&s.imageSrcSet?(f+='[imagesrcset="'+It(s.imageSrcSet)+'"]',typeof s.imageSizes=="string"&&(f+='[imagesizes="'+It(s.imageSizes)+'"]')):f+='[href="'+It(t)+'"]';var m=f;switch(i){case"style":m=Ir(t);break;case"script":m=Br(t)}bi.has(m)||(t=_({rel:"preload",href:i==="image"&&s&&s.imageSrcSet?void 0:t,as:i},s),bi.set(m,t),l.querySelector(f)!==null||i==="style"&&l.querySelector(il(m))||i==="script"&&l.querySelector(al(m))||(i=l.createElement("link"),Fn(i,"link",t),_n(i),l.head.appendChild(i)))}}function nM(t,i){Ca.m(t,i);var s=Pr;if(s&&t){var l=i&&typeof i.as=="string"?i.as:"script",f='link[rel="modulepreload"][as="'+It(l)+'"][href="'+It(t)+'"]',m=f;switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":m=Br(t)}if(!bi.has(m)&&(t=_({rel:"modulepreload",href:t},i),bi.set(m,t),s.querySelector(f)===null)){switch(l){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(s.querySelector(al(m)))return}l=s.createElement("link"),Fn(l,"link",t),_n(l),s.head.appendChild(l)}}}function iM(t,i,s){Ca.S(t,i,s);var l=Pr;if(l&&t){var f=qa(l).hoistableStyles,m=Ir(t);i=i||"default";var y=f.get(m);if(!y){var R={loading:0,preload:null};if(y=l.querySelector(il(m)))R.loading=5;else{t=_({rel:"stylesheet",href:t,"data-precedence":i},s),(s=bi.get(m))&&kh(t,s);var H=y=l.createElement("link");_n(H),Fn(H,"link",t),H._p=new Promise(function(te,pe){H.onload=te,H.onerror=pe}),H.addEventListener("load",function(){R.loading|=1}),H.addEventListener("error",function(){R.loading|=2}),R.loading|=4,Bc(y,i,l)}y={type:"stylesheet",instance:y,count:1,state:R},f.set(m,y)}}}function aM(t,i){Ca.X(t,i);var s=Pr;if(s&&t){var l=qa(s).hoistableScripts,f=Br(t),m=l.get(f);m||(m=s.querySelector(al(f)),m||(t=_({src:t,async:!0},i),(i=bi.get(f))&&Xh(t,i),m=s.createElement("script"),_n(m),Fn(m,"link",t),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},l.set(f,m))}}function sM(t,i){Ca.M(t,i);var s=Pr;if(s&&t){var l=qa(s).hoistableScripts,f=Br(t),m=l.get(f);m||(m=s.querySelector(al(f)),m||(t=_({src:t,async:!0,type:"module"},i),(i=bi.get(f))&&Xh(t,i),m=s.createElement("script"),_n(m),Fn(m,"link",t),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},l.set(f,m))}}function T_(t,i,s,l){var f=(f=ae.current)?Ic(f):null;if(!f)throw Error(a(446));switch(t){case"meta":case"title":return null;case"style":return typeof s.precedence=="string"&&typeof s.href=="string"?(i=Ir(s.href),s=qa(f).hoistableStyles,l=s.get(i),l||(l={type:"style",instance:null,count:0,state:null},s.set(i,l)),l):{type:"void",instance:null,count:0,state:null};case"link":if(s.rel==="stylesheet"&&typeof s.href=="string"&&typeof s.precedence=="string"){t=Ir(s.href);var m=qa(f).hoistableStyles,y=m.get(t);if(y||(f=f.ownerDocument||f,y={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},m.set(t,y),(m=f.querySelector(il(t)))&&!m._p&&(y.instance=m,y.state.loading=5),bi.has(t)||(s={rel:"preload",as:"style",href:s.href,crossOrigin:s.crossOrigin,integrity:s.integrity,media:s.media,hrefLang:s.hrefLang,referrerPolicy:s.referrerPolicy},bi.set(t,s),m||rM(f,t,s,y.state))),i&&l===null)throw Error(a(528,""));return y}if(i&&l!==null)throw Error(a(529,""));return null;case"script":return i=s.async,s=s.src,typeof s=="string"&&i&&typeof i!="function"&&typeof i!="symbol"?(i=Br(s),s=qa(f).hoistableScripts,l=s.get(i),l||(l={type:"script",instance:null,count:0,state:null},s.set(i,l)),l):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,t))}}function Ir(t){return'href="'+It(t)+'"'}function il(t){return'link[rel="stylesheet"]['+t+"]"}function A_(t){return _({},t,{"data-precedence":t.precedence,precedence:null})}function rM(t,i,s,l){t.querySelector('link[rel="preload"][as="style"]['+i+"]")?l.loading=1:(i=t.createElement("link"),l.preload=i,i.addEventListener("load",function(){return l.loading|=1}),i.addEventListener("error",function(){return l.loading|=2}),Fn(i,"link",s),_n(i),t.head.appendChild(i))}function Br(t){return'[src="'+It(t)+'"]'}function al(t){return"script[async]"+t}function R_(t,i,s){if(i.count++,i.instance===null)switch(i.type){case"style":var l=t.querySelector('style[data-href~="'+It(s.href)+'"]');if(l)return i.instance=l,_n(l),l;var f=_({},s,{"data-href":s.href,"data-precedence":s.precedence,href:null,precedence:null});return l=(t.ownerDocument||t).createElement("style"),_n(l),Fn(l,"style",f),Bc(l,s.precedence,t),i.instance=l;case"stylesheet":f=Ir(s.href);var m=t.querySelector(il(f));if(m)return i.state.loading|=4,i.instance=m,_n(m),m;l=A_(s),(f=bi.get(f))&&kh(l,f),m=(t.ownerDocument||t).createElement("link"),_n(m);var y=m;return y._p=new Promise(function(R,H){y.onload=R,y.onerror=H}),Fn(m,"link",l),i.state.loading|=4,Bc(m,s.precedence,t),i.instance=m;case"script":return m=Br(s.src),(f=t.querySelector(al(m)))?(i.instance=f,_n(f),f):(l=s,(f=bi.get(m))&&(l=_({},s),Xh(l,f)),t=t.ownerDocument||t,f=t.createElement("script"),_n(f),Fn(f,"link",l),t.head.appendChild(f),i.instance=f);case"void":return null;default:throw Error(a(443,i.type))}else i.type==="stylesheet"&&(i.state.loading&4)===0&&(l=i.instance,i.state.loading|=4,Bc(l,s.precedence,t));return i.instance}function Bc(t,i,s){for(var l=s.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),f=l.length?l[l.length-1]:null,m=f,y=0;y<l.length;y++){var R=l[y];if(R.dataset.precedence===i)m=R;else if(m!==f)break}m?m.parentNode.insertBefore(t,m.nextSibling):(i=s.nodeType===9?s.head:s,i.insertBefore(t,i.firstChild))}function kh(t,i){t.crossOrigin==null&&(t.crossOrigin=i.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=i.referrerPolicy),t.title==null&&(t.title=i.title)}function Xh(t,i){t.crossOrigin==null&&(t.crossOrigin=i.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=i.referrerPolicy),t.integrity==null&&(t.integrity=i.integrity)}var Fc=null;function C_(t,i,s){if(Fc===null){var l=new Map,f=Fc=new Map;f.set(s,l)}else f=Fc,l=f.get(s),l||(l=new Map,f.set(s,l));if(l.has(t))return l;for(l.set(t,null),s=s.getElementsByTagName(t),f=0;f<s.length;f++){var m=s[f];if(!(m[Xa]||m[gn]||t==="link"&&m.getAttribute("rel")==="stylesheet")&&m.namespaceURI!=="http://www.w3.org/2000/svg"){var y=m.getAttribute(i)||"";y=t+y;var R=l.get(y);R?R.push(m):l.set(y,[m])}}return l}function w_(t,i,s){t=t.ownerDocument||t,t.head.insertBefore(s,i==="title"?t.querySelector("head > title"):null)}function oM(t,i,s){if(s===1||i.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof i.precedence!="string"||typeof i.href!="string"||i.href==="")break;return!0;case"link":if(typeof i.rel!="string"||typeof i.href!="string"||i.href===""||i.onLoad||i.onError)break;switch(i.rel){case"stylesheet":return t=i.disabled,typeof i.precedence=="string"&&t==null;default:return!0}case"script":if(i.async&&typeof i.async!="function"&&typeof i.async!="symbol"&&!i.onLoad&&!i.onError&&i.src&&typeof i.src=="string")return!0}return!1}function D_(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function lM(t,i,s,l){if(s.type==="stylesheet"&&(typeof l.media!="string"||matchMedia(l.media).matches!==!1)&&(s.state.loading&4)===0){if(s.instance===null){var f=Ir(l.href),m=i.querySelector(il(f));if(m){i=m._p,i!==null&&typeof i=="object"&&typeof i.then=="function"&&(t.count++,t=zc.bind(t),i.then(t,t)),s.state.loading|=4,s.instance=m,_n(m);return}m=i.ownerDocument||i,l=A_(l),(f=bi.get(f))&&kh(l,f),m=m.createElement("link"),_n(m);var y=m;y._p=new Promise(function(R,H){y.onload=R,y.onerror=H}),Fn(m,"link",l),s.instance=m}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(s,i),(i=s.state.preload)&&(s.state.loading&3)===0&&(t.count++,s=zc.bind(t),i.addEventListener("load",s),i.addEventListener("error",s))}}var Wh=0;function cM(t,i){return t.stylesheets&&t.count===0&&Gc(t,t.stylesheets),0<t.count||0<t.imgCount?function(s){var l=setTimeout(function(){if(t.stylesheets&&Gc(t,t.stylesheets),t.unsuspend){var m=t.unsuspend;t.unsuspend=null,m()}},6e4+i);0<t.imgBytes&&Wh===0&&(Wh=62500*kS());var f=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&Gc(t,t.stylesheets),t.unsuspend)){var m=t.unsuspend;t.unsuspend=null,m()}},(t.imgBytes>Wh?50:800)+i);return t.unsuspend=s,function(){t.unsuspend=null,clearTimeout(l),clearTimeout(f)}}:null}function zc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Gc(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var Hc=null;function Gc(t,i){t.stylesheets=null,t.unsuspend!==null&&(t.count++,Hc=new Map,i.forEach(uM,t),Hc=null,zc.call(t))}function uM(t,i){if(!(i.state.loading&4)){var s=Hc.get(t);if(s)var l=s.get(null);else{s=new Map,Hc.set(t,s);for(var f=t.querySelectorAll("link[data-precedence],style[data-precedence]"),m=0;m<f.length;m++){var y=f[m];(y.nodeName==="LINK"||y.getAttribute("media")!=="not all")&&(s.set(y.dataset.precedence,y),l=y)}l&&s.set(null,l)}f=i.instance,y=f.getAttribute("data-precedence"),m=s.get(y)||l,m===l&&s.set(null,f),s.set(y,f),this.count++,l=zc.bind(this),f.addEventListener("load",l),f.addEventListener("error",l),m?m.parentNode.insertBefore(f,m.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(f,t.firstChild)),i.state.loading|=4}}var sl={$$typeof:F,Provider:null,Consumer:null,_currentValue:Q,_currentValue2:Q,_threadCount:0};function fM(t,i,s,l,f,m,y,R,H){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=We(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=We(0),this.hiddenUpdates=We(null),this.identifierPrefix=l,this.onUncaughtError=f,this.onCaughtError=m,this.onRecoverableError=y,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=H,this.incompleteTransitions=new Map}function L_(t,i,s,l,f,m,y,R,H,te,pe,xe){return t=new fM(t,i,s,y,H,te,pe,xe,R),i=1,m===!0&&(i|=24),m=oi(3,null,null,i),t.current=m,m.stateNode=t,i=bf(),i.refCount++,t.pooledCache=i,i.refCount++,m.memoizedState={element:l,isDehydrated:s,cache:i},Cf(m),t}function N_(t){return t?(t=pr,t):pr}function U_(t,i,s,l,f,m){f=N_(f),l.context===null?l.context=f:l.pendingContext=f,l=es(i),l.payload={element:s},m=m===void 0?null:m,m!==null&&(l.callback=m),s=ts(t,l,i),s!==null&&(ei(s,t,i),Bo(s,t,i))}function O_(t,i){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var s=t.retryLane;t.retryLane=s!==0&&s<i?s:i}}function qh(t,i){O_(t,i),(t=t.alternate)&&O_(t,i)}function P_(t){if(t.tag===13||t.tag===31){var i=Ps(t,67108864);i!==null&&ei(i,t,67108864),qh(t,67108864)}}function I_(t){if(t.tag===13||t.tag===31){var i=hi();i=xo(i);var s=Ps(t,i);s!==null&&ei(s,t,i),qh(t,i)}}var Vc=!0;function hM(t,i,s,l){var f=I.T;I.T=null;var m=z.p;try{z.p=2,Yh(t,i,s,l)}finally{z.p=m,I.T=f}}function dM(t,i,s,l){var f=I.T;I.T=null;var m=z.p;try{z.p=8,Yh(t,i,s,l)}finally{z.p=m,I.T=f}}function Yh(t,i,s,l){if(Vc){var f=Kh(l);if(f===null)Uh(t,i,l,kc,s),F_(t,l);else if(mM(f,t,i,s,l))l.stopPropagation();else if(F_(t,l),i&4&&-1<pM.indexOf(t)){for(;f!==null;){var m=fa(f);if(m!==null)switch(m.tag){case 3:if(m=m.stateNode,m.current.memoizedState.isDehydrated){var y=Te(m.pendingLanes);if(y!==0){var R=m;for(R.pendingLanes|=2,R.entangledLanes|=2;y;){var H=1<<31-Be(y);R.entanglements[1]|=H,y&=~H}Qi(m),(Nt&6)===0&&(Tc=kt()+500,$o(0))}}break;case 31:case 13:R=Ps(m,2),R!==null&&ei(R,m,2),Rc(),qh(m,2)}if(m=Kh(l),m===null&&Uh(t,i,l,kc,s),m===f)break;f=m}f!==null&&l.stopPropagation()}else Uh(t,i,l,null,s)}}function Kh(t){return t=Zu(t),Zh(t)}var kc=null;function Zh(t){if(kc=null,t=ua(t),t!==null){var i=c(t);if(i===null)t=null;else{var s=i.tag;if(s===13){if(t=u(i),t!==null)return t;t=null}else if(s===31){if(t=h(i),t!==null)return t;t=null}else if(s===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;t=null}else i!==t&&(t=null)}}return kc=t,null}function B_(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Lt()){case L:return 2;case b:return 8;case J:case se:return 32;case fe:return 268435456;default:return 32}default:return 32}}var Qh=!1,hs=null,ds=null,ps=null,rl=new Map,ol=new Map,ms=[],pM="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function F_(t,i){switch(t){case"focusin":case"focusout":hs=null;break;case"dragenter":case"dragleave":ds=null;break;case"mouseover":case"mouseout":ps=null;break;case"pointerover":case"pointerout":rl.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":ol.delete(i.pointerId)}}function ll(t,i,s,l,f,m){return t===null||t.nativeEvent!==m?(t={blockedOn:i,domEventName:s,eventSystemFlags:l,nativeEvent:m,targetContainers:[f]},i!==null&&(i=fa(i),i!==null&&P_(i)),t):(t.eventSystemFlags|=l,i=t.targetContainers,f!==null&&i.indexOf(f)===-1&&i.push(f),t)}function mM(t,i,s,l,f){switch(i){case"focusin":return hs=ll(hs,t,i,s,l,f),!0;case"dragenter":return ds=ll(ds,t,i,s,l,f),!0;case"mouseover":return ps=ll(ps,t,i,s,l,f),!0;case"pointerover":var m=f.pointerId;return rl.set(m,ll(rl.get(m)||null,t,i,s,l,f)),!0;case"gotpointercapture":return m=f.pointerId,ol.set(m,ll(ol.get(m)||null,t,i,s,l,f)),!0}return!1}function z_(t){var i=ua(t.target);if(i!==null){var s=c(i);if(s!==null){if(i=s.tag,i===13){if(i=u(s),i!==null){t.blockedOn=i,or(t.priority,function(){I_(s)});return}}else if(i===31){if(i=h(s),i!==null){t.blockedOn=i,or(t.priority,function(){I_(s)});return}}else if(i===3&&s.stateNode.current.memoizedState.isDehydrated){t.blockedOn=s.tag===3?s.stateNode.containerInfo:null;return}}}t.blockedOn=null}function Xc(t){if(t.blockedOn!==null)return!1;for(var i=t.targetContainers;0<i.length;){var s=Kh(t.nativeEvent);if(s===null){s=t.nativeEvent;var l=new s.constructor(s.type,s);Ku=l,s.target.dispatchEvent(l),Ku=null}else return i=fa(s),i!==null&&P_(i),t.blockedOn=s,!1;i.shift()}return!0}function H_(t,i,s){Xc(t)&&s.delete(i)}function gM(){Qh=!1,hs!==null&&Xc(hs)&&(hs=null),ds!==null&&Xc(ds)&&(ds=null),ps!==null&&Xc(ps)&&(ps=null),rl.forEach(H_),ol.forEach(H_)}function Wc(t,i){t.blockedOn===i&&(t.blockedOn=null,Qh||(Qh=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,gM)))}var qc=null;function G_(t){qc!==t&&(qc=t,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){qc===t&&(qc=null);for(var i=0;i<t.length;i+=3){var s=t[i],l=t[i+1],f=t[i+2];if(typeof l!="function"){if(Zh(l||s)===null)continue;break}var m=fa(s);m!==null&&(t.splice(i,3),i-=3,Kf(m,{pending:!0,data:f,method:s.method,action:l},l,f))}}))}function Fr(t){function i(H){return Wc(H,t)}hs!==null&&Wc(hs,t),ds!==null&&Wc(ds,t),ps!==null&&Wc(ps,t),rl.forEach(i),ol.forEach(i);for(var s=0;s<ms.length;s++){var l=ms[s];l.blockedOn===t&&(l.blockedOn=null)}for(;0<ms.length&&(s=ms[0],s.blockedOn===null);)z_(s),s.blockedOn===null&&ms.shift();if(s=(t.ownerDocument||t).$$reactFormReplay,s!=null)for(l=0;l<s.length;l+=3){var f=s[l],m=s[l+1],y=f[On]||null;if(typeof m=="function")y||G_(s);else if(y){var R=null;if(m&&m.hasAttribute("formAction")){if(f=m,y=m[On]||null)R=y.formAction;else if(Zh(f)!==null)continue}else R=y.action;typeof R=="function"?s[l+1]=R:(s.splice(l,3),l-=3),G_(s)}}}function V_(){function t(m){m.canIntercept&&m.info==="react-transition"&&m.intercept({handler:function(){return new Promise(function(y){return f=y})},focusReset:"manual",scroll:"manual"})}function i(){f!==null&&(f(),f=null),l||setTimeout(s,20)}function s(){if(!l&&!navigation.transition){var m=navigation.currentEntry;m&&m.url!=null&&navigation.navigate(m.url,{state:m.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var l=!1,f=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",i),navigation.addEventListener("navigateerror",i),setTimeout(s,100),function(){l=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",i),navigation.removeEventListener("navigateerror",i),f!==null&&(f(),f=null)}}}function Jh(t){this._internalRoot=t}Yc.prototype.render=Jh.prototype.render=function(t){var i=this._internalRoot;if(i===null)throw Error(a(409));var s=i.current,l=hi();U_(s,l,t,i,null,null)},Yc.prototype.unmount=Jh.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var i=t.containerInfo;U_(t.current,2,null,t,null,null),Rc(),i[Kn]=null}};function Yc(t){this._internalRoot=t}Yc.prototype.unstable_scheduleHydration=function(t){if(t){var i=So();t={blockedOn:null,target:t,priority:i};for(var s=0;s<ms.length&&i!==0&&i<ms[s].priority;s++);ms.splice(s,0,t),s===0&&z_(t)}};var k_=e.version;if(k_!=="19.2.0")throw Error(a(527,k_,"19.2.0"));z.findDOMNode=function(t){var i=t._reactInternals;if(i===void 0)throw typeof t.render=="function"?Error(a(188)):(t=Object.keys(t).join(","),Error(a(268,t)));return t=d(i),t=t!==null?g(t):null,t=t===null?null:t.stateNode,t};var _M={bundleType:0,version:"19.2.0",rendererPackageName:"react-dom",currentDispatcherRef:I,reconcilerVersion:"19.2.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Kc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Kc.isDisabled&&Kc.supportsFiber)try{ue=Kc.inject(_M),he=Kc}catch{}}return ul.createRoot=function(t,i){if(!o(t))throw Error(a(299));var s=!1,l="",f=Qg,m=Jg,y=jg;return i!=null&&(i.unstable_strictMode===!0&&(s=!0),i.identifierPrefix!==void 0&&(l=i.identifierPrefix),i.onUncaughtError!==void 0&&(f=i.onUncaughtError),i.onCaughtError!==void 0&&(m=i.onCaughtError),i.onRecoverableError!==void 0&&(y=i.onRecoverableError)),i=L_(t,1,!1,null,null,s,l,null,f,m,y,V_),t[Kn]=i.current,Nh(t),new Jh(i)},ul.hydrateRoot=function(t,i,s){if(!o(t))throw Error(a(299));var l=!1,f="",m=Qg,y=Jg,R=jg,H=null;return s!=null&&(s.unstable_strictMode===!0&&(l=!0),s.identifierPrefix!==void 0&&(f=s.identifierPrefix),s.onUncaughtError!==void 0&&(m=s.onUncaughtError),s.onCaughtError!==void 0&&(y=s.onCaughtError),s.onRecoverableError!==void 0&&(R=s.onRecoverableError),s.formState!==void 0&&(H=s.formState)),i=L_(t,1,!0,i,s??null,l,f,H,m,y,R,V_),i.context=N_(null),s=i.current,l=hi(),l=xo(l),f=es(l),f.callback=null,ts(s,f,l),s=l,i.current.lanes=s,Ge(i,s),Qi(i),t[Kn]=i.current,Nh(t),new Yc(i)},ul.version="19.2.0",ul}var $_;function RM(){if($_)return ed.exports;$_=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(e){console.error(e)}}return r(),ed.exports=AM(),ed.exports}var CM=RM();const wM=Je.createContext({color:"currentColor",size:"1em",weight:"regular",mirrored:!1}),Fp=Je.forwardRef((r,e)=>{const{alt:n,color:a,size:o,weight:c,mirrored:u,children:h,weights:p,...d}=r,{color:g="currentColor",size:_,weight:v="regular",mirrored:x=!1,...E}=Je.useContext(wM);return Je.createElement("svg",{ref:e,xmlns:"http://www.w3.org/2000/svg",width:o??_,height:o??_,fill:a??g,viewBox:"0 0 256 256",transform:u||x?"scale(-1, 1)":void 0,...E,...d},!!n&&Je.createElement("title",null,n),h,p.get(c??v))});Fp.displayName="IconBase";const DM=new Map([["bold",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M204,64V168a12,12,0,0,1-24,0V93L72.49,200.49a12,12,0,0,1-17-17L163,76H88a12,12,0,0,1,0-24H192A12,12,0,0,1,204,64Z"}))],["duotone",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M192,64V168L88,64Z",opacity:"0.2"}),Je.createElement("path",{d:"M192,56H88a8,8,0,0,0-5.66,13.66L128.69,116,58.34,186.34a8,8,0,0,0,11.32,11.32L140,127.31l46.34,46.35A8,8,0,0,0,200,168V64A8,8,0,0,0,192,56Zm-8,92.69-38.34-38.34h0L107.31,72H184Z"}))],["fill",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M200,64V168a8,8,0,0,1-13.66,5.66L140,127.31,69.66,197.66a8,8,0,0,1-11.32-11.32L128.69,116,82.34,69.66A8,8,0,0,1,88,56H192A8,8,0,0,1,200,64Z"}))],["light",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M198,64V168a6,6,0,0,1-12,0V78.48L68.24,196.24a6,6,0,0,1-8.48-8.48L177.52,70H88a6,6,0,0,1,0-12H192A6,6,0,0,1,198,64Z"}))],["regular",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"}))],["thin",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M196,64V168a4,4,0,0,1-8,0V73.66L66.83,194.83a4,4,0,0,1-5.66-5.66L182.34,68H88a4,4,0,0,1,0-8H192A4,4,0,0,1,196,64Z"}))]]),bx=Je.forwardRef((r,e)=>Je.createElement(Fp,{ref:e,...r,weights:DM}));bx.displayName="ArrowUpRightIcon";const Tx=bx,LM=new Map([["bold",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M229.26,90.4a108,108,0,0,1-177.63,114A108,108,0,0,1,195.41,43.63l20.1-20.11a12,12,0,0,1,17,17l-96,96a12,12,0,1,1-17-17l24-24a36,36,0,1,0,19.76,39.65,12,12,0,0,1,23.53,4.74,60,60,0,1,1-25.73-62L178.3,60.74a84,84,0,1,0,28.46,38,12,12,0,1,1,22.5-8.35Z"}))],["duotone",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M176,128a48,48,0,1,1-48-48A48,48,0,0,1,176,128Z",opacity:"0.2"}),Je.createElement("path",{d:"M221.87,83.16A104.1,104.1,0,1,1,195.67,49l22.67-22.68a8,8,0,0,1,11.32,11.32l-96,96a8,8,0,0,1-11.32-11.32l27.72-27.72a40,40,0,1,0,17.87,31.09,8,8,0,1,1,16-.9,56,56,0,1,1-22.38-41.65L184.3,60.39a87.88,87.88,0,1,0,23.13,29.67,8,8,0,0,1,14.44-6.9Z"}))],["fill",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M221.87,83.16A104.1,104.1,0,1,1,195.67,49l22.67-22.68a8,8,0,0,1,11.32,11.32L167.6,99.71h0l-37.71,37.71-23.95,23.95a40,40,0,0,0,62-35.67,8,8,0,1,1,16-.9,56,56,0,0,1-95.5,42.79h0a56,56,0,0,1,73.13-84.43L184.3,60.39a87.88,87.88,0,1,0,23.13,29.67,8,8,0,0,1,14.44-6.9Z"}))],["light",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M220.06,84a102.06,102.06,0,1,1-24.31-32.27l24-24a6,6,0,0,1,8.48,8.49l-96,96a6,6,0,1,1-8.48-8.49l29.39-29.4a42,42,0,1,0,16.78,31.24,6,6,0,1,1,12-.68A54,54,0,1,1,161.7,85.83l25.54-25.55a89.91,89.91,0,1,0,22,28.93A6,6,0,1,1,220.06,84Z"}))],["regular",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M221.87,83.16A104.1,104.1,0,1,1,195.67,49l22.67-22.68a8,8,0,0,1,11.32,11.32l-96,96a8,8,0,0,1-11.32-11.32l27.72-27.72a40,40,0,1,0,17.87,31.09,8,8,0,1,1,16-.9,56,56,0,1,1-22.38-41.65L184.3,60.39a87.88,87.88,0,1,0,23.13,29.67,8,8,0,0,1,14.44-6.9Z"}))],["thin",Je.createElement(Je.Fragment,null,Je.createElement("path",{d:"M218.26,84.89a100.16,100.16,0,1,1-22.44-30.37l25.35-25.35a4,4,0,1,1,5.66,5.66l-96,96a4,4,0,0,1-5.66-5.66l31-31a44,44,0,1,0,15.78,31.3,4,4,0,0,1,8-.46,52,52,0,1,1-18.1-36.51l28.34-28.33A92,92,0,0,0,63,193.05,92,92,0,0,0,211,88.33a4,4,0,1,1,7.22-3.44Z"}))]]),Ax=Je.forwardRef((r,e)=>Je.createElement(Fp,{ref:e,...r,weights:LM}));Ax.displayName="TargetIcon";const NM=Ax;/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const zp="185",UM=0,ev=1,OM=2,bu=1,PM=2,Ml=3,za=0,qn=1,ta=2,Ba=0,no=1,tv=2,nv=3,iv=4,IM=5,er=100,BM=101,FM=102,zM=103,HM=104,GM=200,VM=201,kM=202,XM=203,kd=204,Xd=205,WM=206,qM=207,YM=208,KM=209,ZM=210,QM=211,JM=212,jM=213,$M=214,Wd=0,qd=1,Yd=2,ro=3,Kd=4,Zd=5,Qd=6,Jd=7,Hp=0,eE=1,tE=2,aa=0,Rx=1,Cx=2,wx=3,Gp=4,Dx=5,Lx=6,Nx=7,av="attached",nE="detached",Ux=300,ar=301,oo=302,ad=303,sd=304,Vu=306,lo=1e3,na=1001,Nu=1002,An=1003,Ox=1004,El=1005,Rn=1006,Tu=1007,Pa=1008,mi=1009,Px=1010,Ix=1011,Cl=1012,Vp=1013,ra=1014,Ri=1015,Ha=1016,kp=1017,Xp=1018,wl=1020,Bx=35902,Fx=35899,zx=1021,Hx=1022,Ci=1023,Ga=1026,nr=1027,Wp=1028,qp=1029,sr=1030,Yp=1031,Kp=1033,Au=33776,Ru=33777,Cu=33778,wu=33779,jd=35840,$d=35841,ep=35842,tp=35843,np=36196,ip=37492,ap=37496,sp=37488,rp=37489,Uu=37490,op=37491,lp=37808,cp=37809,up=37810,fp=37811,hp=37812,dp=37813,pp=37814,mp=37815,gp=37816,_p=37817,vp=37818,xp=37819,yp=37820,Sp=37821,Mp=36492,Ep=36494,bp=36495,Tp=36283,Ap=36284,Ou=36285,Rp=36286,Dl=2300,Ll=2301,rd=2302,sv=2303,rv=2400,ov=2401,lv=2402,iE=2500,aE=0,Gx=1,Cp=2,sE=3200,Pu=0,rE=1,Ts="",Nn="srgb",gi="srgb-linear",Iu="linear",Ht="srgb",zr=7680,cv=519,oE=512,lE=513,cE=514,Zp=515,uE=516,fE=517,Qp=518,hE=519,wp=35044,uv="300 es",ia=2e3,Nl=2001;function dE(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function pE(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}function Ul(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function mE(){const r=Ul("canvas");return r.style.display="block",r}const fv={};function Bu(...r){const e="THREE."+r.shift();console.log(e,...r)}function Vx(r){const e=r[0];if(typeof e=="string"&&e.startsWith("TSL:")){const n=r[1];n&&n.isStackTrace?r[0]+=" "+n.getLocation():r[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return r}function Ke(...r){r=Vx(r);const e="THREE."+r.shift();{const n=r[0];n&&n.isStackTrace?console.warn(n.getError(e)):console.warn(e,...r)}}function at(...r){r=Vx(r);const e="THREE."+r.shift();{const n=r[0];n&&n.isStackTrace?console.error(n.getError(e)):console.error(e,...r)}}function io(...r){const e=r.join(" ");e in fv||(fv[e]=!0,Ke(...r))}function gE(r,e,n){return new Promise(function(a,o){function c(){switch(r.clientWaitSync(e,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:o();break;case r.TIMEOUT_EXPIRED:setTimeout(c,n);break;default:a()}}setTimeout(c,n)})}const _E={[Wd]:qd,[Yd]:Qd,[Kd]:Jd,[ro]:Zd,[qd]:Wd,[Qd]:Yd,[Jd]:Kd,[Zd]:ro};class rr{addEventListener(e,n){this._listeners===void 0&&(this._listeners={});const a=this._listeners;a[e]===void 0&&(a[e]=[]),a[e].indexOf(n)===-1&&a[e].push(n)}hasEventListener(e,n){const a=this._listeners;return a===void 0?!1:a[e]!==void 0&&a[e].indexOf(n)!==-1}removeEventListener(e,n){const a=this._listeners;if(a===void 0)return;const o=a[e];if(o!==void 0){const c=o.indexOf(n);c!==-1&&o.splice(c,1)}}dispatchEvent(e){const n=this._listeners;if(n===void 0)return;const a=n[e.type];if(a!==void 0){e.target=this;const o=a.slice(0);for(let c=0,u=o.length;c<u;c++)o[c].call(this,e);e.target=null}}}const Gn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let hv=1234567;const Tl=Math.PI/180,co=180/Math.PI;function Hi(){const r=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0,a=Math.random()*4294967295|0;return(Gn[r&255]+Gn[r>>8&255]+Gn[r>>16&255]+Gn[r>>24&255]+"-"+Gn[e&255]+Gn[e>>8&255]+"-"+Gn[e>>16&15|64]+Gn[e>>24&255]+"-"+Gn[n&63|128]+Gn[n>>8&255]+"-"+Gn[n>>16&255]+Gn[n>>24&255]+Gn[a&255]+Gn[a>>8&255]+Gn[a>>16&255]+Gn[a>>24&255]).toLowerCase()}function Mt(r,e,n){return Math.max(e,Math.min(n,r))}function Jp(r,e){return(r%e+e)%e}function vE(r,e,n,a,o){return a+(r-e)*(o-a)/(n-e)}function xE(r,e,n){return r!==e?(n-r)/(e-r):0}function Al(r,e,n){return(1-n)*r+n*e}function yE(r,e,n,a){return Al(r,e,1-Math.exp(-n*a))}function SE(r,e=1){return e-Math.abs(Jp(r,e*2)-e)}function ME(r,e,n){return r<=e?0:r>=n?1:(r=(r-e)/(n-e),r*r*(3-2*r))}function EE(r,e,n){return r<=e?0:r>=n?1:(r=(r-e)/(n-e),r*r*r*(r*(r*6-15)+10))}function bE(r,e){return r+Math.floor(Math.random()*(e-r+1))}function TE(r,e){return r+Math.random()*(e-r)}function AE(r){return r*(.5-Math.random())}function RE(r){r!==void 0&&(hv=r);let e=hv+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function CE(r){return r*Tl}function wE(r){return r*co}function DE(r){return(r&r-1)===0&&r!==0}function LE(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))}function NE(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function UE(r,e,n,a,o){const c=Math.cos,u=Math.sin,h=c(n/2),p=u(n/2),d=c((e+a)/2),g=u((e+a)/2),_=c((e-a)/2),v=u((e-a)/2),x=c((a-e)/2),E=u((a-e)/2);switch(o){case"XYX":r.set(h*g,p*_,p*v,h*d);break;case"YZY":r.set(p*v,h*g,p*_,h*d);break;case"ZXZ":r.set(p*_,p*v,h*g,h*d);break;case"XZX":r.set(h*g,p*E,p*x,h*d);break;case"YXY":r.set(p*x,h*g,p*E,h*d);break;case"ZYZ":r.set(p*E,p*x,h*g,h*d);break;default:Ke("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+o)}}function Fi(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function Gt(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const OE={DEG2RAD:Tl,RAD2DEG:co,generateUUID:Hi,clamp:Mt,euclideanModulo:Jp,mapLinear:vE,inverseLerp:xE,lerp:Al,damp:yE,pingpong:SE,smoothstep:ME,smootherstep:EE,randInt:bE,randFloat:TE,randFloatSpread:AE,seededRandom:RE,degToRad:CE,radToDeg:wE,isPowerOfTwo:DE,ceilPowerOfTwo:LE,floorPowerOfTwo:NE,setQuaternionFromProperEuler:UE,normalize:Gt,denormalize:Fi},om=class om{constructor(e=0,n=0){this.x=e,this.y=n}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,n){return this.x=e,this.y=n,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const n=this.x,a=this.y,o=e.elements;return this.x=o[0]*n+o[3]*a+o[6],this.y=o[1]*n+o[4]*a+o[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,n){return this.x=Mt(this.x,e.x,n.x),this.y=Mt(this.y,e.y,n.y),this}clampScalar(e,n){return this.x=Mt(this.x,e,n),this.y=Mt(this.y,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Mt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(e)/n;return Math.acos(Mt(a,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,a=this.y-e.y;return n*n+a*a}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this}rotateAround(e,n){const a=Math.cos(n),o=Math.sin(n),c=this.x-e.x,u=this.y-e.y;return this.x=c*a-u*o+e.x,this.y=c*o+u*a+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};om.prototype.isVector2=!0;let gt=om;class ka{constructor(e=0,n=0,a=0,o=1){this.isQuaternion=!0,this._x=e,this._y=n,this._z=a,this._w=o}static slerpFlat(e,n,a,o,c,u,h){let p=a[o+0],d=a[o+1],g=a[o+2],_=a[o+3],v=c[u+0],x=c[u+1],E=c[u+2],C=c[u+3];if(_!==C||p!==v||d!==x||g!==E){let M=p*v+d*x+g*E+_*C;M<0&&(v=-v,x=-x,E=-E,C=-C,M=-M);let S=1-h;if(M<.9995){const B=Math.acos(M),F=Math.sin(B);S=Math.sin(S*B)/F,h=Math.sin(h*B)/F,p=p*S+v*h,d=d*S+x*h,g=g*S+E*h,_=_*S+C*h}else{p=p*S+v*h,d=d*S+x*h,g=g*S+E*h,_=_*S+C*h;const B=1/Math.sqrt(p*p+d*d+g*g+_*_);p*=B,d*=B,g*=B,_*=B}}e[n]=p,e[n+1]=d,e[n+2]=g,e[n+3]=_}static multiplyQuaternionsFlat(e,n,a,o,c,u){const h=a[o],p=a[o+1],d=a[o+2],g=a[o+3],_=c[u],v=c[u+1],x=c[u+2],E=c[u+3];return e[n]=h*E+g*_+p*x-d*v,e[n+1]=p*E+g*v+d*_-h*x,e[n+2]=d*E+g*x+h*v-p*_,e[n+3]=g*E-h*_-p*v-d*x,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,n,a,o){return this._x=e,this._y=n,this._z=a,this._w=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,n=!0){const a=e._x,o=e._y,c=e._z,u=e._order,h=Math.cos,p=Math.sin,d=h(a/2),g=h(o/2),_=h(c/2),v=p(a/2),x=p(o/2),E=p(c/2);switch(u){case"XYZ":this._x=v*g*_+d*x*E,this._y=d*x*_-v*g*E,this._z=d*g*E+v*x*_,this._w=d*g*_-v*x*E;break;case"YXZ":this._x=v*g*_+d*x*E,this._y=d*x*_-v*g*E,this._z=d*g*E-v*x*_,this._w=d*g*_+v*x*E;break;case"ZXY":this._x=v*g*_-d*x*E,this._y=d*x*_+v*g*E,this._z=d*g*E+v*x*_,this._w=d*g*_-v*x*E;break;case"ZYX":this._x=v*g*_-d*x*E,this._y=d*x*_+v*g*E,this._z=d*g*E-v*x*_,this._w=d*g*_+v*x*E;break;case"YZX":this._x=v*g*_+d*x*E,this._y=d*x*_+v*g*E,this._z=d*g*E-v*x*_,this._w=d*g*_-v*x*E;break;case"XZY":this._x=v*g*_-d*x*E,this._y=d*x*_-v*g*E,this._z=d*g*E+v*x*_,this._w=d*g*_+v*x*E;break;default:Ke("Quaternion: .setFromEuler() encountered an unknown order: "+u)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,n){const a=n/2,o=Math.sin(a);return this._x=e.x*o,this._y=e.y*o,this._z=e.z*o,this._w=Math.cos(a),this._onChangeCallback(),this}setFromRotationMatrix(e){const n=e.elements,a=n[0],o=n[4],c=n[8],u=n[1],h=n[5],p=n[9],d=n[2],g=n[6],_=n[10],v=a+h+_;if(v>0){const x=.5/Math.sqrt(v+1);this._w=.25/x,this._x=(g-p)*x,this._y=(c-d)*x,this._z=(u-o)*x}else if(a>h&&a>_){const x=2*Math.sqrt(1+a-h-_);this._w=(g-p)/x,this._x=.25*x,this._y=(o+u)/x,this._z=(c+d)/x}else if(h>_){const x=2*Math.sqrt(1+h-a-_);this._w=(c-d)/x,this._x=(o+u)/x,this._y=.25*x,this._z=(p+g)/x}else{const x=2*Math.sqrt(1+_-a-h);this._w=(u-o)/x,this._x=(c+d)/x,this._y=(p+g)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(e,n){let a=e.dot(n)+1;return a<1e-8?(a=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=a):(this._x=0,this._y=-e.z,this._z=e.y,this._w=a)):(this._x=e.y*n.z-e.z*n.y,this._y=e.z*n.x-e.x*n.z,this._z=e.x*n.y-e.y*n.x,this._w=a),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Mt(this.dot(e),-1,1)))}rotateTowards(e,n){const a=this.angleTo(e);if(a===0)return this;const o=Math.min(1,n/a);return this.slerp(e,o),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,n){const a=e._x,o=e._y,c=e._z,u=e._w,h=n._x,p=n._y,d=n._z,g=n._w;return this._x=a*g+u*h+o*d-c*p,this._y=o*g+u*p+c*h-a*d,this._z=c*g+u*d+a*p-o*h,this._w=u*g-a*h-o*p-c*d,this._onChangeCallback(),this}slerp(e,n){let a=e._x,o=e._y,c=e._z,u=e._w,h=this.dot(e);h<0&&(a=-a,o=-o,c=-c,u=-u,h=-h);let p=1-n;if(h<.9995){const d=Math.acos(h),g=Math.sin(d);p=Math.sin(p*d)/g,n=Math.sin(n*d)/g,this._x=this._x*p+a*n,this._y=this._y*p+o*n,this._z=this._z*p+c*n,this._w=this._w*p+u*n,this._onChangeCallback()}else this._x=this._x*p+a*n,this._y=this._y*p+o*n,this._z=this._z*p+c*n,this._w=this._w*p+u*n,this.normalize();return this}slerpQuaternions(e,n,a){return this.copy(e).slerp(n,a)}random(){const e=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),a=Math.random(),o=Math.sqrt(1-a),c=Math.sqrt(a);return this.set(o*Math.sin(e),o*Math.cos(e),c*Math.sin(n),c*Math.cos(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,n=0){return this._x=e[n],this._y=e[n+1],this._z=e[n+2],this._w=e[n+3],this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._w,e}fromBufferAttribute(e,n){return this._x=e.getX(n),this._y=e.getY(n),this._z=e.getZ(n),this._w=e.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const lm=class lm{constructor(e=0,n=0,a=0){this.x=e,this.y=n,this.z=a}set(e,n,a){return a===void 0&&(a=this.z),this.x=e,this.y=n,this.z=a,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,n){return this.x=e.x*n.x,this.y=e.y*n.y,this.z=e.z*n.z,this}applyEuler(e){return this.applyQuaternion(dv.setFromEuler(e))}applyAxisAngle(e,n){return this.applyQuaternion(dv.setFromAxisAngle(e,n))}applyMatrix3(e){const n=this.x,a=this.y,o=this.z,c=e.elements;return this.x=c[0]*n+c[3]*a+c[6]*o,this.y=c[1]*n+c[4]*a+c[7]*o,this.z=c[2]*n+c[5]*a+c[8]*o,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const n=this.x,a=this.y,o=this.z,c=e.elements,u=1/(c[3]*n+c[7]*a+c[11]*o+c[15]);return this.x=(c[0]*n+c[4]*a+c[8]*o+c[12])*u,this.y=(c[1]*n+c[5]*a+c[9]*o+c[13])*u,this.z=(c[2]*n+c[6]*a+c[10]*o+c[14])*u,this}applyQuaternion(e){const n=this.x,a=this.y,o=this.z,c=e.x,u=e.y,h=e.z,p=e.w,d=2*(u*o-h*a),g=2*(h*n-c*o),_=2*(c*a-u*n);return this.x=n+p*d+u*_-h*g,this.y=a+p*g+h*d-c*_,this.z=o+p*_+c*g-u*d,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const n=this.x,a=this.y,o=this.z,c=e.elements;return this.x=c[0]*n+c[4]*a+c[8]*o,this.y=c[1]*n+c[5]*a+c[9]*o,this.z=c[2]*n+c[6]*a+c[10]*o,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,n){return this.x=Mt(this.x,e.x,n.x),this.y=Mt(this.y,e.y,n.y),this.z=Mt(this.z,e.z,n.z),this}clampScalar(e,n){return this.x=Mt(this.x,e,n),this.y=Mt(this.y,e,n),this.z=Mt(this.z,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Mt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this.z=e.z+(n.z-e.z)*a,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,n){const a=e.x,o=e.y,c=e.z,u=n.x,h=n.y,p=n.z;return this.x=o*p-c*h,this.y=c*u-a*p,this.z=a*h-o*u,this}projectOnVector(e){const n=e.lengthSq();if(n===0)return this.set(0,0,0);const a=e.dot(this)/n;return this.copy(e).multiplyScalar(a)}projectOnPlane(e){return od.copy(this).projectOnVector(e),this.sub(od)}reflect(e){return this.sub(od.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(e)/n;return Math.acos(Mt(a,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,a=this.y-e.y,o=this.z-e.z;return n*n+a*a+o*o}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,n,a){const o=Math.sin(n)*e;return this.x=o*Math.sin(a),this.y=Math.cos(n)*e,this.z=o*Math.cos(a),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,n,a){return this.x=e*Math.sin(n),this.y=a,this.z=e*Math.cos(n),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(e){const n=this.setFromMatrixColumn(e,0).length(),a=this.setFromMatrixColumn(e,1).length(),o=this.setFromMatrixColumn(e,2).length();return this.x=n,this.y=a,this.z=o,this}setFromMatrixColumn(e,n){return this.fromArray(e.elements,n*4)}setFromMatrix3Column(e,n){return this.fromArray(e.elements,n*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,n=Math.random()*2-1,a=Math.sqrt(1-n*n);return this.x=a*Math.cos(e),this.y=n,this.z=a*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};lm.prototype.isVector3=!0;let $=lm;const od=new $,dv=new ka,cm=class cm{constructor(e,n,a,o,c,u,h,p,d){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,n,a,o,c,u,h,p,d)}set(e,n,a,o,c,u,h,p,d){const g=this.elements;return g[0]=e,g[1]=o,g[2]=h,g[3]=n,g[4]=c,g[5]=p,g[6]=a,g[7]=u,g[8]=d,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const n=this.elements,a=e.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],this}extractBasis(e,n,a){return e.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),a.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const n=e.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const a=e.elements,o=n.elements,c=this.elements,u=a[0],h=a[3],p=a[6],d=a[1],g=a[4],_=a[7],v=a[2],x=a[5],E=a[8],C=o[0],M=o[3],S=o[6],B=o[1],F=o[4],w=o[7],P=o[2],U=o[5],N=o[8];return c[0]=u*C+h*B+p*P,c[3]=u*M+h*F+p*U,c[6]=u*S+h*w+p*N,c[1]=d*C+g*B+_*P,c[4]=d*M+g*F+_*U,c[7]=d*S+g*w+_*N,c[2]=v*C+x*B+E*P,c[5]=v*M+x*F+E*U,c[8]=v*S+x*w+E*N,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[3]*=e,n[6]*=e,n[1]*=e,n[4]*=e,n[7]*=e,n[2]*=e,n[5]*=e,n[8]*=e,this}determinant(){const e=this.elements,n=e[0],a=e[1],o=e[2],c=e[3],u=e[4],h=e[5],p=e[6],d=e[7],g=e[8];return n*u*g-n*h*d-a*c*g+a*h*p+o*c*d-o*u*p}invert(){const e=this.elements,n=e[0],a=e[1],o=e[2],c=e[3],u=e[4],h=e[5],p=e[6],d=e[7],g=e[8],_=g*u-h*d,v=h*p-g*c,x=d*c-u*p,E=n*_+a*v+o*x;if(E===0)return this.set(0,0,0,0,0,0,0,0,0);const C=1/E;return e[0]=_*C,e[1]=(o*d-g*a)*C,e[2]=(h*a-o*u)*C,e[3]=v*C,e[4]=(g*n-o*p)*C,e[5]=(o*c-h*n)*C,e[6]=x*C,e[7]=(a*p-d*n)*C,e[8]=(u*n-a*c)*C,this}transpose(){let e;const n=this.elements;return e=n[1],n[1]=n[3],n[3]=e,e=n[2],n[2]=n[6],n[6]=e,e=n[5],n[5]=n[7],n[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const n=this.elements;return e[0]=n[0],e[1]=n[3],e[2]=n[6],e[3]=n[1],e[4]=n[4],e[5]=n[7],e[6]=n[2],e[7]=n[5],e[8]=n[8],this}setUvTransform(e,n,a,o,c,u,h){const p=Math.cos(c),d=Math.sin(c);return this.set(a*p,a*d,-a*(p*u+d*h)+u+e,-o*d,o*p,-o*(-d*u+p*h)+h+n,0,0,1),this}scale(e,n){return io("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(ld.makeScale(e,n)),this}rotate(e){return io("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(ld.makeRotation(-e)),this}translate(e,n){return io("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(ld.makeTranslation(e,n)),this}makeTranslation(e,n){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,n,0,0,1),this}makeRotation(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,-a,0,a,n,0,0,0,1),this}makeScale(e,n){return this.set(e,0,0,0,n,0,0,0,1),this}equals(e){const n=this.elements,a=e.elements;for(let o=0;o<9;o++)if(n[o]!==a[o])return!1;return!0}fromArray(e,n=0){for(let a=0;a<9;a++)this.elements[a]=e[a+n];return this}toArray(e=[],n=0){const a=this.elements;return e[n]=a[0],e[n+1]=a[1],e[n+2]=a[2],e[n+3]=a[3],e[n+4]=a[4],e[n+5]=a[5],e[n+6]=a[6],e[n+7]=a[7],e[n+8]=a[8],e}clone(){return new this.constructor().fromArray(this.elements)}};cm.prototype.isMatrix3=!0;let lt=cm;const ld=new lt,pv=new lt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),mv=new lt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function PE(){const r={enabled:!0,workingColorSpace:gi,spaces:{},convert:function(o,c,u){return this.enabled===!1||c===u||!c||!u||(this.spaces[c].transfer===Ht&&(o.r=Fa(o.r),o.g=Fa(o.g),o.b=Fa(o.b)),this.spaces[c].primaries!==this.spaces[u].primaries&&(o.applyMatrix3(this.spaces[c].toXYZ),o.applyMatrix3(this.spaces[u].fromXYZ)),this.spaces[u].transfer===Ht&&(o.r=ao(o.r),o.g=ao(o.g),o.b=ao(o.b))),o},workingToColorSpace:function(o,c){return this.convert(o,this.workingColorSpace,c)},colorSpaceToWorking:function(o,c){return this.convert(o,c,this.workingColorSpace)},getPrimaries:function(o){return this.spaces[o].primaries},getTransfer:function(o){return o===Ts?Iu:this.spaces[o].transfer},getToneMappingMode:function(o){return this.spaces[o].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(o,c=this.workingColorSpace){return o.fromArray(this.spaces[c].luminanceCoefficients)},define:function(o){Object.assign(this.spaces,o)},_getMatrix:function(o,c,u){return o.copy(this.spaces[c].toXYZ).multiply(this.spaces[u].fromXYZ)},_getDrawingBufferColorSpace:function(o){return this.spaces[o].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(o=this.workingColorSpace){return this.spaces[o].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(o,c){return io("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),r.workingToColorSpace(o,c)},toWorkingColorSpace:function(o,c){return io("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),r.colorSpaceToWorking(o,c)}},e=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],a=[.3127,.329];return r.define({[gi]:{primaries:e,whitePoint:a,transfer:Iu,toXYZ:pv,fromXYZ:mv,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Nn},outputColorSpaceConfig:{drawingBufferColorSpace:Nn}},[Nn]:{primaries:e,whitePoint:a,transfer:Ht,toXYZ:pv,fromXYZ:mv,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Nn}}}),r}const St=PE();function Fa(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function ao(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Hr;class IE{static getDataURL(e,n="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let a;if(e instanceof HTMLCanvasElement)a=e;else{Hr===void 0&&(Hr=Ul("canvas")),Hr.width=e.width,Hr.height=e.height;const o=Hr.getContext("2d");e instanceof ImageData?o.putImageData(e,0,0):o.drawImage(e,0,0,e.width,e.height),a=Hr}return a.toDataURL(n)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const n=Ul("canvas");n.width=e.width,n.height=e.height;const a=n.getContext("2d");a.drawImage(e,0,0,e.width,e.height);const o=a.getImageData(0,0,e.width,e.height),c=o.data;for(let u=0;u<c.length;u++)c[u]=Fa(c[u]/255)*255;return a.putImageData(o,0,0),n}else if(e.data){const n=e.data.slice(0);for(let a=0;a<n.length;a++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[a]=Math.floor(Fa(n[a]/255)*255):n[a]=Fa(n[a]);return{data:n,width:e.width,height:e.height}}else return Ke("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let BE=0;class jp{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:BE++}),this.uuid=Hi(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const n=this.data;return typeof HTMLVideoElement<"u"&&n instanceof HTMLVideoElement?e.set(n.videoWidth,n.videoHeight,0):typeof VideoFrame<"u"&&n instanceof VideoFrame?e.set(n.displayWidth,n.displayHeight,0):n!==null?e.set(n.width,n.height,n.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const a={uuid:this.uuid,url:""},o=this.data;if(o!==null){let c;if(Array.isArray(o)){c=[];for(let u=0,h=o.length;u<h;u++)o[u].isDataTexture?c.push(cd(o[u].image)):c.push(cd(o[u]))}else c=cd(o);a.url=c}return n||(e.images[this.uuid]=a),a}}function cd(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?IE.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(Ke("Texture: Unable to serialize Texture."),{})}let FE=0;const ud=new $;class Un extends rr{constructor(e=Un.DEFAULT_IMAGE,n=Un.DEFAULT_MAPPING,a=na,o=na,c=Rn,u=Pa,h=Ci,p=mi,d=Un.DEFAULT_ANISOTROPY,g=Ts){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:FE++}),this.uuid=Hi(),this.name="",this.source=new jp(e),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=a,this.wrapT=o,this.magFilter=c,this.minFilter=u,this.anisotropy=d,this.format=h,this.internalFormat=null,this.type=p,this.offset=new gt(0,0),this.repeat=new gt(1,1),this.center=new gt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new lt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=g,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(ud).x}get height(){return this.source.getSize(ud).y}get depth(){return this.source.getSize(ud).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const n in e){const a=e[n];if(a===void 0){Ke(`Texture.setValues(): parameter '${n}' has value of undefined.`);continue}const o=this[n];if(o===void 0){Ke(`Texture.setValues(): property '${n}' does not exist.`);continue}o&&a&&o.isVector2&&a.isVector2||o&&a&&o.isVector3&&a.isVector3||o&&a&&o.isMatrix3&&a.isMatrix3?o.copy(a):this[n]=a}}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const a={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(a.userData=this.userData),n||(e.textures[this.uuid]=a),a}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Ux)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case lo:e.x=e.x-Math.floor(e.x);break;case na:e.x=e.x<0?0:1;break;case Nu:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case lo:e.y=e.y-Math.floor(e.y);break;case na:e.y=e.y<0?0:1;break;case Nu:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Un.DEFAULT_IMAGE=null;Un.DEFAULT_MAPPING=Ux;Un.DEFAULT_ANISOTROPY=1;const um=class um{constructor(e=0,n=0,a=0,o=1){this.x=e,this.y=n,this.z=a,this.w=o}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,n,a,o){return this.x=e,this.y=n,this.z=a,this.w=o,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this.w=e.w+n.w,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this.w+=e.w*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this.w=e.w-n.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const n=this.x,a=this.y,o=this.z,c=this.w,u=e.elements;return this.x=u[0]*n+u[4]*a+u[8]*o+u[12]*c,this.y=u[1]*n+u[5]*a+u[9]*o+u[13]*c,this.z=u[2]*n+u[6]*a+u[10]*o+u[14]*c,this.w=u[3]*n+u[7]*a+u[11]*o+u[15]*c,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const n=Math.sqrt(1-e.w*e.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/n,this.y=e.y/n,this.z=e.z/n),this}setAxisAngleFromRotationMatrix(e){let n,a,o,c;const p=e.elements,d=p[0],g=p[4],_=p[8],v=p[1],x=p[5],E=p[9],C=p[2],M=p[6],S=p[10];if(Math.abs(g-v)<.01&&Math.abs(_-C)<.01&&Math.abs(E-M)<.01){if(Math.abs(g+v)<.1&&Math.abs(_+C)<.1&&Math.abs(E+M)<.1&&Math.abs(d+x+S-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const F=(d+1)/2,w=(x+1)/2,P=(S+1)/2,U=(g+v)/4,N=(_+C)/4,T=(E+M)/4;return F>w&&F>P?F<.01?(a=0,o=.707106781,c=.707106781):(a=Math.sqrt(F),o=U/a,c=N/a):w>P?w<.01?(a=.707106781,o=0,c=.707106781):(o=Math.sqrt(w),a=U/o,c=T/o):P<.01?(a=.707106781,o=.707106781,c=0):(c=Math.sqrt(P),a=N/c,o=T/c),this.set(a,o,c,n),this}let B=Math.sqrt((M-E)*(M-E)+(_-C)*(_-C)+(v-g)*(v-g));return Math.abs(B)<.001&&(B=1),this.x=(M-E)/B,this.y=(_-C)/B,this.z=(v-g)/B,this.w=Math.acos((d+x+S-1)/2),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,n){return this.x=Mt(this.x,e.x,n.x),this.y=Mt(this.y,e.y,n.y),this.z=Mt(this.z,e.z,n.z),this.w=Mt(this.w,e.w,n.w),this}clampScalar(e,n){return this.x=Mt(this.x,e,n),this.y=Mt(this.y,e,n),this.z=Mt(this.z,e,n),this.w=Mt(this.w,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Mt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this.w+=(e.w-this.w)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this.z=e.z+(n.z-e.z)*a,this.w=e.w+(n.w-e.w)*a,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this.w=e[n+3],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e[n+3]=this.w,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this.w=e.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};um.prototype.isVector4=!0;let Yt=um;class zE extends rr{constructor(e=1,n=1,a={}){super(),a=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Rn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},a),this.isRenderTarget=!0,this.width=e,this.height=n,this.depth=a.depth,this.scissor=new Yt(0,0,e,n),this.scissorTest=!1,this.viewport=new Yt(0,0,e,n),this.textures=[];const o={width:e,height:n,depth:a.depth},c=new Un(o),u=a.count;for(let h=0;h<u;h++)this.textures[h]=c.clone(),this.textures[h].isRenderTargetTexture=!0,this.textures[h].renderTarget=this;this._setTextureOptions(a),this.depthBuffer=a.depthBuffer,this.stencilBuffer=a.stencilBuffer,this.resolveDepthBuffer=a.resolveDepthBuffer,this.resolveStencilBuffer=a.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=a.depthTexture,this.samples=a.samples,this.multiview=a.multiview,this.useArrayDepthTexture=a.useArrayDepthTexture}_setTextureOptions(e={}){const n={minFilter:Rn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(n.mapping=e.mapping),e.wrapS!==void 0&&(n.wrapS=e.wrapS),e.wrapT!==void 0&&(n.wrapT=e.wrapT),e.wrapR!==void 0&&(n.wrapR=e.wrapR),e.magFilter!==void 0&&(n.magFilter=e.magFilter),e.minFilter!==void 0&&(n.minFilter=e.minFilter),e.format!==void 0&&(n.format=e.format),e.type!==void 0&&(n.type=e.type),e.anisotropy!==void 0&&(n.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(n.colorSpace=e.colorSpace),e.flipY!==void 0&&(n.flipY=e.flipY),e.generateMipmaps!==void 0&&(n.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(n.internalFormat=e.internalFormat);for(let a=0;a<this.textures.length;a++)this.textures[a].setValues(n)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,n,a=1){if(this.width!==e||this.height!==n||this.depth!==a){this.width=e,this.height=n,this.depth=a;for(let o=0,c=this.textures.length;o<c;o++)this.textures[o].image.width=e,this.textures[o].image.height=n,this.textures[o].image.depth=a,this.textures[o].isData3DTexture!==!0&&(this.textures[o].isArrayTexture=this.textures[o].image.depth>1);this.dispose()}this.viewport.set(0,0,e,n),this.scissor.set(0,0,e,n)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,a=e.textures.length;n<a;n++){this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0,this.textures[n].renderTarget=this;const o=Object.assign({},e.textures[n].image);this.textures[n].source=new jp(o)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class sa extends zE{constructor(e=1,n=1,a={}){super(e,n,a),this.isWebGLRenderTarget=!0}}class kx extends Un{constructor(e=null,n=1,a=1,o=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:n,height:a,depth:o},this.magFilter=An,this.minFilter=An,this.wrapR=na,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class HE extends Un{constructor(e=null,n=1,a=1,o=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:n,height:a,depth:o},this.magFilter=An,this.minFilter=An,this.wrapR=na,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Gu=class Gu{constructor(e,n,a,o,c,u,h,p,d,g,_,v,x,E,C,M){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,n,a,o,c,u,h,p,d,g,_,v,x,E,C,M)}set(e,n,a,o,c,u,h,p,d,g,_,v,x,E,C,M){const S=this.elements;return S[0]=e,S[4]=n,S[8]=a,S[12]=o,S[1]=c,S[5]=u,S[9]=h,S[13]=p,S[2]=d,S[6]=g,S[10]=_,S[14]=v,S[3]=x,S[7]=E,S[11]=C,S[15]=M,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Gu().fromArray(this.elements)}copy(e){const n=this.elements,a=e.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],n[9]=a[9],n[10]=a[10],n[11]=a[11],n[12]=a[12],n[13]=a[13],n[14]=a[14],n[15]=a[15],this}copyPosition(e){const n=this.elements,a=e.elements;return n[12]=a[12],n[13]=a[13],n[14]=a[14],this}setFromMatrix3(e){const n=e.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(e,n,a){return this.determinantAffine()===0?(e.set(1,0,0),n.set(0,1,0),a.set(0,0,1),this):(e.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),a.setFromMatrixColumn(this,2),this)}makeBasis(e,n,a){return this.set(e.x,n.x,a.x,0,e.y,n.y,a.y,0,e.z,n.z,a.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const n=this.elements,a=e.elements,o=1/Gr.setFromMatrixColumn(e,0).length(),c=1/Gr.setFromMatrixColumn(e,1).length(),u=1/Gr.setFromMatrixColumn(e,2).length();return n[0]=a[0]*o,n[1]=a[1]*o,n[2]=a[2]*o,n[3]=0,n[4]=a[4]*c,n[5]=a[5]*c,n[6]=a[6]*c,n[7]=0,n[8]=a[8]*u,n[9]=a[9]*u,n[10]=a[10]*u,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(e){const n=this.elements,a=e.x,o=e.y,c=e.z,u=Math.cos(a),h=Math.sin(a),p=Math.cos(o),d=Math.sin(o),g=Math.cos(c),_=Math.sin(c);if(e.order==="XYZ"){const v=u*g,x=u*_,E=h*g,C=h*_;n[0]=p*g,n[4]=-p*_,n[8]=d,n[1]=x+E*d,n[5]=v-C*d,n[9]=-h*p,n[2]=C-v*d,n[6]=E+x*d,n[10]=u*p}else if(e.order==="YXZ"){const v=p*g,x=p*_,E=d*g,C=d*_;n[0]=v+C*h,n[4]=E*h-x,n[8]=u*d,n[1]=u*_,n[5]=u*g,n[9]=-h,n[2]=x*h-E,n[6]=C+v*h,n[10]=u*p}else if(e.order==="ZXY"){const v=p*g,x=p*_,E=d*g,C=d*_;n[0]=v-C*h,n[4]=-u*_,n[8]=E+x*h,n[1]=x+E*h,n[5]=u*g,n[9]=C-v*h,n[2]=-u*d,n[6]=h,n[10]=u*p}else if(e.order==="ZYX"){const v=u*g,x=u*_,E=h*g,C=h*_;n[0]=p*g,n[4]=E*d-x,n[8]=v*d+C,n[1]=p*_,n[5]=C*d+v,n[9]=x*d-E,n[2]=-d,n[6]=h*p,n[10]=u*p}else if(e.order==="YZX"){const v=u*p,x=u*d,E=h*p,C=h*d;n[0]=p*g,n[4]=C-v*_,n[8]=E*_+x,n[1]=_,n[5]=u*g,n[9]=-h*g,n[2]=-d*g,n[6]=x*_+E,n[10]=v-C*_}else if(e.order==="XZY"){const v=u*p,x=u*d,E=h*p,C=h*d;n[0]=p*g,n[4]=-_,n[8]=d*g,n[1]=v*_+C,n[5]=u*g,n[9]=x*_-E,n[2]=E*_-x,n[6]=h*g,n[10]=C*_+v}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(e){return this.compose(GE,e,VE)}lookAt(e,n,a){const o=this.elements;return di.subVectors(e,n),di.lengthSq()===0&&(di.z=1),di.normalize(),_s.crossVectors(a,di),_s.lengthSq()===0&&(Math.abs(a.z)===1?di.x+=1e-4:di.z+=1e-4,di.normalize(),_s.crossVectors(a,di)),_s.normalize(),Zc.crossVectors(di,_s),o[0]=_s.x,o[4]=Zc.x,o[8]=di.x,o[1]=_s.y,o[5]=Zc.y,o[9]=di.y,o[2]=_s.z,o[6]=Zc.z,o[10]=di.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const a=e.elements,o=n.elements,c=this.elements,u=a[0],h=a[4],p=a[8],d=a[12],g=a[1],_=a[5],v=a[9],x=a[13],E=a[2],C=a[6],M=a[10],S=a[14],B=a[3],F=a[7],w=a[11],P=a[15],U=o[0],N=o[4],T=o[8],O=o[12],X=o[1],G=o[5],Z=o[9],ce=o[13],ge=o[2],j=o[6],I=o[10],z=o[14],Q=o[3],de=o[7],ve=o[11],D=o[15];return c[0]=u*U+h*X+p*ge+d*Q,c[4]=u*N+h*G+p*j+d*de,c[8]=u*T+h*Z+p*I+d*ve,c[12]=u*O+h*ce+p*z+d*D,c[1]=g*U+_*X+v*ge+x*Q,c[5]=g*N+_*G+v*j+x*de,c[9]=g*T+_*Z+v*I+x*ve,c[13]=g*O+_*ce+v*z+x*D,c[2]=E*U+C*X+M*ge+S*Q,c[6]=E*N+C*G+M*j+S*de,c[10]=E*T+C*Z+M*I+S*ve,c[14]=E*O+C*ce+M*z+S*D,c[3]=B*U+F*X+w*ge+P*Q,c[7]=B*N+F*G+w*j+P*de,c[11]=B*T+F*Z+w*I+P*ve,c[15]=B*O+F*ce+w*z+P*D,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[4]*=e,n[8]*=e,n[12]*=e,n[1]*=e,n[5]*=e,n[9]*=e,n[13]*=e,n[2]*=e,n[6]*=e,n[10]*=e,n[14]*=e,n[3]*=e,n[7]*=e,n[11]*=e,n[15]*=e,this}determinant(){const e=this.elements,n=e[0],a=e[4],o=e[8],c=e[12],u=e[1],h=e[5],p=e[9],d=e[13],g=e[2],_=e[6],v=e[10],x=e[14],E=e[3],C=e[7],M=e[11],S=e[15],B=p*x-d*v,F=h*x-d*_,w=h*v-p*_,P=u*x-d*g,U=u*v-p*g,N=u*_-h*g;return n*(C*B-M*F+S*w)-a*(E*B-M*P+S*U)+o*(E*F-C*P+S*N)-c*(E*w-C*U+M*N)}determinantAffine(){const e=this.elements,n=e[0],a=e[4],o=e[8],c=e[1],u=e[5],h=e[9],p=e[2],d=e[6],g=e[10];return n*(u*g-h*d)-a*(c*g-h*p)+o*(c*d-u*p)}transpose(){const e=this.elements;let n;return n=e[1],e[1]=e[4],e[4]=n,n=e[2],e[2]=e[8],e[8]=n,n=e[6],e[6]=e[9],e[9]=n,n=e[3],e[3]=e[12],e[12]=n,n=e[7],e[7]=e[13],e[13]=n,n=e[11],e[11]=e[14],e[14]=n,this}setPosition(e,n,a){const o=this.elements;return e.isVector3?(o[12]=e.x,o[13]=e.y,o[14]=e.z):(o[12]=e,o[13]=n,o[14]=a),this}invert(){const e=this.elements,n=e[0],a=e[1],o=e[2],c=e[3],u=e[4],h=e[5],p=e[6],d=e[7],g=e[8],_=e[9],v=e[10],x=e[11],E=e[12],C=e[13],M=e[14],S=e[15],B=n*h-a*u,F=n*p-o*u,w=n*d-c*u,P=a*p-o*h,U=a*d-c*h,N=o*d-c*p,T=g*C-_*E,O=g*M-v*E,X=g*S-x*E,G=_*M-v*C,Z=_*S-x*C,ce=v*S-x*M,ge=B*ce-F*Z+w*G+P*X-U*O+N*T;if(ge===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const j=1/ge;return e[0]=(h*ce-p*Z+d*G)*j,e[1]=(o*Z-a*ce-c*G)*j,e[2]=(C*N-M*U+S*P)*j,e[3]=(v*U-_*N-x*P)*j,e[4]=(p*X-u*ce-d*O)*j,e[5]=(n*ce-o*X+c*O)*j,e[6]=(M*w-E*N-S*F)*j,e[7]=(g*N-v*w+x*F)*j,e[8]=(u*Z-h*X+d*T)*j,e[9]=(a*X-n*Z-c*T)*j,e[10]=(E*U-C*w+S*B)*j,e[11]=(_*w-g*U-x*B)*j,e[12]=(h*O-u*G-p*T)*j,e[13]=(n*G-a*O+o*T)*j,e[14]=(C*F-E*P-M*B)*j,e[15]=(g*P-_*F+v*B)*j,this}scale(e){const n=this.elements,a=e.x,o=e.y,c=e.z;return n[0]*=a,n[4]*=o,n[8]*=c,n[1]*=a,n[5]*=o,n[9]*=c,n[2]*=a,n[6]*=o,n[10]*=c,n[3]*=a,n[7]*=o,n[11]*=c,this}getMaxScaleOnAxis(){const e=this.elements,n=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],a=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],o=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(n,a,o))}makeTranslation(e,n,a){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,n,0,0,1,a,0,0,0,1),this}makeRotationX(e){const n=Math.cos(e),a=Math.sin(e);return this.set(1,0,0,0,0,n,-a,0,0,a,n,0,0,0,0,1),this}makeRotationY(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,0,a,0,0,1,0,0,-a,0,n,0,0,0,0,1),this}makeRotationZ(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,-a,0,0,a,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,n){const a=Math.cos(n),o=Math.sin(n),c=1-a,u=e.x,h=e.y,p=e.z,d=c*u,g=c*h;return this.set(d*u+a,d*h-o*p,d*p+o*h,0,d*h+o*p,g*h+a,g*p-o*u,0,d*p-o*h,g*p+o*u,c*p*p+a,0,0,0,0,1),this}makeScale(e,n,a){return this.set(e,0,0,0,0,n,0,0,0,0,a,0,0,0,0,1),this}makeShear(e,n,a,o,c,u){return this.set(1,a,c,0,e,1,u,0,n,o,1,0,0,0,0,1),this}compose(e,n,a){const o=this.elements,c=n._x,u=n._y,h=n._z,p=n._w,d=c+c,g=u+u,_=h+h,v=c*d,x=c*g,E=c*_,C=u*g,M=u*_,S=h*_,B=p*d,F=p*g,w=p*_,P=a.x,U=a.y,N=a.z;return o[0]=(1-(C+S))*P,o[1]=(x+w)*P,o[2]=(E-F)*P,o[3]=0,o[4]=(x-w)*U,o[5]=(1-(v+S))*U,o[6]=(M+B)*U,o[7]=0,o[8]=(E+F)*N,o[9]=(M-B)*N,o[10]=(1-(v+C))*N,o[11]=0,o[12]=e.x,o[13]=e.y,o[14]=e.z,o[15]=1,this}decompose(e,n,a){const o=this.elements;e.x=o[12],e.y=o[13],e.z=o[14];const c=this.determinantAffine();if(c===0)return a.set(1,1,1),n.identity(),this;let u=Gr.set(o[0],o[1],o[2]).length();const h=Gr.set(o[4],o[5],o[6]).length(),p=Gr.set(o[8],o[9],o[10]).length();c<0&&(u=-u),Pi.copy(this);const d=1/u,g=1/h,_=1/p;return Pi.elements[0]*=d,Pi.elements[1]*=d,Pi.elements[2]*=d,Pi.elements[4]*=g,Pi.elements[5]*=g,Pi.elements[6]*=g,Pi.elements[8]*=_,Pi.elements[9]*=_,Pi.elements[10]*=_,n.setFromRotationMatrix(Pi),a.x=u,a.y=h,a.z=p,this}makePerspective(e,n,a,o,c,u,h=ia,p=!1){const d=this.elements,g=2*c/(n-e),_=2*c/(a-o),v=(n+e)/(n-e),x=(a+o)/(a-o);let E,C;if(p)E=c/(u-c),C=u*c/(u-c);else if(h===ia)E=-(u+c)/(u-c),C=-2*u*c/(u-c);else if(h===Nl)E=-u/(u-c),C=-u*c/(u-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+h);return d[0]=g,d[4]=0,d[8]=v,d[12]=0,d[1]=0,d[5]=_,d[9]=x,d[13]=0,d[2]=0,d[6]=0,d[10]=E,d[14]=C,d[3]=0,d[7]=0,d[11]=-1,d[15]=0,this}makeOrthographic(e,n,a,o,c,u,h=ia,p=!1){const d=this.elements,g=2/(n-e),_=2/(a-o),v=-(n+e)/(n-e),x=-(a+o)/(a-o);let E,C;if(p)E=1/(u-c),C=u/(u-c);else if(h===ia)E=-2/(u-c),C=-(u+c)/(u-c);else if(h===Nl)E=-1/(u-c),C=-c/(u-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+h);return d[0]=g,d[4]=0,d[8]=0,d[12]=v,d[1]=0,d[5]=_,d[9]=0,d[13]=x,d[2]=0,d[6]=0,d[10]=E,d[14]=C,d[3]=0,d[7]=0,d[11]=0,d[15]=1,this}equals(e){const n=this.elements,a=e.elements;for(let o=0;o<16;o++)if(n[o]!==a[o])return!1;return!0}fromArray(e,n=0){for(let a=0;a<16;a++)this.elements[a]=e[a+n];return this}toArray(e=[],n=0){const a=this.elements;return e[n]=a[0],e[n+1]=a[1],e[n+2]=a[2],e[n+3]=a[3],e[n+4]=a[4],e[n+5]=a[5],e[n+6]=a[6],e[n+7]=a[7],e[n+8]=a[8],e[n+9]=a[9],e[n+10]=a[10],e[n+11]=a[11],e[n+12]=a[12],e[n+13]=a[13],e[n+14]=a[14],e[n+15]=a[15],e}};Gu.prototype.isMatrix4=!0;let dt=Gu;const Gr=new $,Pi=new dt,GE=new $(0,0,0),VE=new $(1,1,1),_s=new $,Zc=new $,di=new $,gv=new dt,_v=new ka;class Va{constructor(e=0,n=0,a=0,o=Va.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=n,this._z=a,this._order=o}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,n,a,o=this._order){return this._x=e,this._y=n,this._z=a,this._order=o,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,n=this._order,a=!0){const o=e.elements,c=o[0],u=o[4],h=o[8],p=o[1],d=o[5],g=o[9],_=o[2],v=o[6],x=o[10];switch(n){case"XYZ":this._y=Math.asin(Mt(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(-g,x),this._z=Math.atan2(-u,c)):(this._x=Math.atan2(v,d),this._z=0);break;case"YXZ":this._x=Math.asin(-Mt(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(h,x),this._z=Math.atan2(p,d)):(this._y=Math.atan2(-_,c),this._z=0);break;case"ZXY":this._x=Math.asin(Mt(v,-1,1)),Math.abs(v)<.9999999?(this._y=Math.atan2(-_,x),this._z=Math.atan2(-u,d)):(this._y=0,this._z=Math.atan2(p,c));break;case"ZYX":this._y=Math.asin(-Mt(_,-1,1)),Math.abs(_)<.9999999?(this._x=Math.atan2(v,x),this._z=Math.atan2(p,c)):(this._x=0,this._z=Math.atan2(-u,d));break;case"YZX":this._z=Math.asin(Mt(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-g,d),this._y=Math.atan2(-_,c)):(this._x=0,this._y=Math.atan2(h,x));break;case"XZY":this._z=Math.asin(-Mt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(v,d),this._y=Math.atan2(h,c)):(this._x=Math.atan2(-g,x),this._y=0);break;default:Ke("Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,a===!0&&this._onChangeCallback(),this}setFromQuaternion(e,n,a){return gv.makeRotationFromQuaternion(e),this.setFromRotationMatrix(gv,n,a)}setFromVector3(e,n=this._order){return this.set(e.x,e.y,e.z,n)}reorder(e){return _v.setFromEuler(this),this.setFromQuaternion(_v,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Va.DEFAULT_ORDER="XYZ";class Xx{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let kE=0;const vv=new $,Vr=new ka,wa=new dt,Qc=new $,fl=new $,XE=new $,WE=new ka,xv=new $(1,0,0),yv=new $(0,1,0),Sv=new $(0,0,1),Mv={type:"added"},qE={type:"removed"},kr={type:"childadded",child:null},fd={type:"childremoved",child:null};class en extends rr{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:kE++}),this.uuid=Hi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=en.DEFAULT_UP.clone();const e=new $,n=new Va,a=new ka,o=new $(1,1,1);function c(){a.setFromEuler(n,!1)}function u(){n.setFromQuaternion(a,void 0,!1)}n._onChange(c),a._onChange(u),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:a},scale:{configurable:!0,enumerable:!0,value:o},modelViewMatrix:{value:new dt},normalMatrix:{value:new lt}}),this.matrix=new dt,this.matrixWorld=new dt,this.matrixAutoUpdate=en.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=en.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Xx,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,n){this.quaternion.setFromAxisAngle(e,n)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,n){return Vr.setFromAxisAngle(e,n),this.quaternion.multiply(Vr),this}rotateOnWorldAxis(e,n){return Vr.setFromAxisAngle(e,n),this.quaternion.premultiply(Vr),this}rotateX(e){return this.rotateOnAxis(xv,e)}rotateY(e){return this.rotateOnAxis(yv,e)}rotateZ(e){return this.rotateOnAxis(Sv,e)}translateOnAxis(e,n){return vv.copy(e).applyQuaternion(this.quaternion),this.position.add(vv.multiplyScalar(n)),this}translateX(e){return this.translateOnAxis(xv,e)}translateY(e){return this.translateOnAxis(yv,e)}translateZ(e){return this.translateOnAxis(Sv,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(wa.copy(this.matrixWorld).invert())}lookAt(e,n,a){e.isVector3?Qc.copy(e):Qc.set(e,n,a);const o=this.parent;this.updateWorldMatrix(!0,!1),fl.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?wa.lookAt(fl,Qc,this.up):wa.lookAt(Qc,fl,this.up),this.quaternion.setFromRotationMatrix(wa),o&&(wa.extractRotation(o.matrixWorld),Vr.setFromRotationMatrix(wa),this.quaternion.premultiply(Vr.invert()))}add(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return e===this?(at("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Mv),kr.child=e,this.dispatchEvent(kr),kr.child=null):at("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.remove(arguments[a]);return this}const n=this.children.indexOf(e);return n!==-1&&(e.parent=null,this.children.splice(n,1),e.dispatchEvent(qE),fd.child=e,this.dispatchEvent(fd),fd.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),wa.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),wa.multiply(e.parent.matrixWorld)),e.applyMatrix4(wa),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Mv),kr.child=e,this.dispatchEvent(kr),kr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,n){if(this[e]===n)return this;for(let a=0,o=this.children.length;a<o;a++){const u=this.children[a].getObjectByProperty(e,n);if(u!==void 0)return u}}getObjectsByProperty(e,n,a=[]){this[e]===n&&a.push(this);const o=this.children;for(let c=0,u=o.length;c<u;c++)o[c].getObjectsByProperty(e,n,a);return a}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fl,e,XE),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fl,WE,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return e.set(n[8],n[9],n[10]).normalize()}raycast(){}traverse(e){e(this);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].traverseVisible(e)}traverseAncestors(e){const n=this.parent;n!==null&&(e(n),n.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const n=e.x,a=e.y,o=e.z,c=this.matrix.elements;c[12]+=n-c[0]*n-c[4]*a-c[8]*o,c[13]+=a-c[1]*n-c[5]*a-c[9]*o,c[14]+=o-c[2]*n-c[6]*a-c[10]*o}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const n=this.children;for(let a=0,o=n.length;a<o;a++)n[a].updateMatrixWorld(e)}updateWorldMatrix(e,n,a=!1){const o=this.parent;if(e===!0&&o!==null&&o.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||a)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,a=!0),n===!0){const c=this.children;for(let u=0,h=c.length;u<h;u++)c[u].updateWorldMatrix(!1,!0,a)}}toJSON(e){const n=e===void 0||typeof e=="string",a={};n&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},a.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const o={};o.uuid=this.uuid,o.type=this.type,this.name!==""&&(o.name=this.name),this.castShadow===!0&&(o.castShadow=!0),this.receiveShadow===!0&&(o.receiveShadow=!0),this.visible===!1&&(o.visible=!1),this.frustumCulled===!1&&(o.frustumCulled=!1),this.renderOrder!==0&&(o.renderOrder=this.renderOrder),this.static!==!1&&(o.static=this.static),Object.keys(this.userData).length>0&&(o.userData=this.userData),o.layers=this.layers.mask,o.matrix=this.matrix.toArray(),o.up=this.up.toArray(),this.pivot!==null&&(o.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(o.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(o.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(o.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(o.type="InstancedMesh",o.count=this.count,o.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(o.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(o.type="BatchedMesh",o.perObjectFrustumCulled=this.perObjectFrustumCulled,o.sortObjects=this.sortObjects,o.drawRanges=this._drawRanges,o.reservedRanges=this._reservedRanges,o.geometryInfo=this._geometryInfo.map(h=>({...h,boundingBox:h.boundingBox?h.boundingBox.toJSON():void 0,boundingSphere:h.boundingSphere?h.boundingSphere.toJSON():void 0})),o.instanceInfo=this._instanceInfo.map(h=>({...h})),o.availableInstanceIds=this._availableInstanceIds.slice(),o.availableGeometryIds=this._availableGeometryIds.slice(),o.nextIndexStart=this._nextIndexStart,o.nextVertexStart=this._nextVertexStart,o.geometryCount=this._geometryCount,o.maxInstanceCount=this._maxInstanceCount,o.maxVertexCount=this._maxVertexCount,o.maxIndexCount=this._maxIndexCount,o.geometryInitialized=this._geometryInitialized,o.matricesTexture=this._matricesTexture.toJSON(e),o.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(o.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(o.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(o.boundingBox=this.boundingBox.toJSON()));function c(h,p){return h[p.uuid]===void 0&&(h[p.uuid]=p.toJSON(e)),p.uuid}if(this.isScene)this.background&&(this.background.isColor?o.background=this.background.toJSON():this.background.isTexture&&(o.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(o.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){o.geometry=c(e.geometries,this.geometry);const h=this.geometry.parameters;if(h!==void 0&&h.shapes!==void 0){const p=h.shapes;if(Array.isArray(p))for(let d=0,g=p.length;d<g;d++){const _=p[d];c(e.shapes,_)}else c(e.shapes,p)}}if(this.isSkinnedMesh&&(o.bindMode=this.bindMode,o.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(e.skeletons,this.skeleton),o.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const h=[];for(let p=0,d=this.material.length;p<d;p++)h.push(c(e.materials,this.material[p]));o.material=h}else o.material=c(e.materials,this.material);if(this.children.length>0){o.children=[];for(let h=0;h<this.children.length;h++)o.children.push(this.children[h].toJSON(e).object)}if(this.animations.length>0){o.animations=[];for(let h=0;h<this.animations.length;h++){const p=this.animations[h];o.animations.push(c(e.animations,p))}}if(n){const h=u(e.geometries),p=u(e.materials),d=u(e.textures),g=u(e.images),_=u(e.shapes),v=u(e.skeletons),x=u(e.animations),E=u(e.nodes);h.length>0&&(a.geometries=h),p.length>0&&(a.materials=p),d.length>0&&(a.textures=d),g.length>0&&(a.images=g),_.length>0&&(a.shapes=_),v.length>0&&(a.skeletons=v),x.length>0&&(a.animations=x),E.length>0&&(a.nodes=E)}return a.object=o,a;function u(h){const p=[];for(const d in h){const g=h[d];delete g.metadata,p.push(g)}return p}}clone(e){return new this.constructor().copy(this,e)}copy(e,n=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),n===!0)for(let a=0;a<e.children.length;a++){const o=e.children[a];this.add(o.clone())}return this}}en.DEFAULT_UP=new $(0,1,0);en.DEFAULT_MATRIX_AUTO_UPDATE=!0;en.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class As extends en{constructor(){super(),this.isGroup=!0,this.type="Group"}}const YE={type:"move"};class hd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new As,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new As,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new $,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new $),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new As,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new $,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new $,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const n=this._hand;if(n)for(const a of e.hand.values())this._getHandJoint(n,a)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,n,a){let o=null,c=null,u=null;const h=this._targetRay,p=this._grip,d=this._hand;if(e&&n.session.visibilityState!=="visible-blurred"){if(d&&e.hand){u=!0;for(const C of e.hand.values()){const M=n.getJointPose(C,a),S=this._getHandJoint(d,C);M!==null&&(S.matrix.fromArray(M.transform.matrix),S.matrix.decompose(S.position,S.rotation,S.scale),S.matrixWorldNeedsUpdate=!0,S.jointRadius=M.radius),S.visible=M!==null}const g=d.joints["index-finger-tip"],_=d.joints["thumb-tip"],v=g.position.distanceTo(_.position),x=.02,E=.005;d.inputState.pinching&&v>x+E?(d.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!d.inputState.pinching&&v<=x-E&&(d.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else p!==null&&e.gripSpace&&(c=n.getPose(e.gripSpace,a),c!==null&&(p.matrix.fromArray(c.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,c.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(c.linearVelocity)):p.hasLinearVelocity=!1,c.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(c.angularVelocity)):p.hasAngularVelocity=!1,p.eventsEnabled&&p.dispatchEvent({type:"gripUpdated",data:e,target:this})));h!==null&&(o=n.getPose(e.targetRaySpace,a),o===null&&c!==null&&(o=c),o!==null&&(h.matrix.fromArray(o.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,o.linearVelocity?(h.hasLinearVelocity=!0,h.linearVelocity.copy(o.linearVelocity)):h.hasLinearVelocity=!1,o.angularVelocity?(h.hasAngularVelocity=!0,h.angularVelocity.copy(o.angularVelocity)):h.hasAngularVelocity=!1,this.dispatchEvent(YE)))}return h!==null&&(h.visible=o!==null),p!==null&&(p.visible=c!==null),d!==null&&(d.visible=u!==null),this}_getHandJoint(e,n){if(e.joints[n.jointName]===void 0){const a=new As;a.matrixAutoUpdate=!1,a.visible=!1,e.joints[n.jointName]=a,e.add(a)}return e.joints[n.jointName]}}const Wx={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},vs={h:0,s:0,l:0},Jc={h:0,s:0,l:0};function dd(r,e,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?r+(e-r)*6*n:n<1/2?e:n<2/3?r+(e-r)*6*(2/3-n):r}class st{constructor(e,n,a){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,n,a)}set(e,n,a){if(n===void 0&&a===void 0){const o=e;o&&o.isColor?this.copy(o):typeof o=="number"?this.setHex(o):typeof o=="string"&&this.setStyle(o)}else this.setRGB(e,n,a);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,n=Nn){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,St.colorSpaceToWorking(this,n),this}setRGB(e,n,a,o=St.workingColorSpace){return this.r=e,this.g=n,this.b=a,St.colorSpaceToWorking(this,o),this}setHSL(e,n,a,o=St.workingColorSpace){if(e=Jp(e,1),n=Mt(n,0,1),a=Mt(a,0,1),n===0)this.r=this.g=this.b=a;else{const c=a<=.5?a*(1+n):a+n-a*n,u=2*a-c;this.r=dd(u,c,e+1/3),this.g=dd(u,c,e),this.b=dd(u,c,e-1/3)}return St.colorSpaceToWorking(this,o),this}setStyle(e,n=Nn){function a(c){c!==void 0&&parseFloat(c)<1&&Ke("Color: Alpha component of "+e+" will be ignored.")}let o;if(o=/^(\w+)\(([^\)]*)\)/.exec(e)){let c;const u=o[1],h=o[2];switch(u){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,n);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,n);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(h))return a(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,n);break;default:Ke("Color: Unknown color model "+e)}}else if(o=/^\#([A-Fa-f\d]+)$/.exec(e)){const c=o[1],u=c.length;if(u===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,n);if(u===6)return this.setHex(parseInt(c,16),n);Ke("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,n);return this}setColorName(e,n=Nn){const a=Wx[e.toLowerCase()];return a!==void 0?this.setHex(a,n):Ke("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Fa(e.r),this.g=Fa(e.g),this.b=Fa(e.b),this}copyLinearToSRGB(e){return this.r=ao(e.r),this.g=ao(e.g),this.b=ao(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Nn){return St.workingToColorSpace(Vn.copy(this),e),Math.round(Mt(Vn.r*255,0,255))*65536+Math.round(Mt(Vn.g*255,0,255))*256+Math.round(Mt(Vn.b*255,0,255))}getHexString(e=Nn){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,n=St.workingColorSpace){St.workingToColorSpace(Vn.copy(this),n);const a=Vn.r,o=Vn.g,c=Vn.b,u=Math.max(a,o,c),h=Math.min(a,o,c);let p,d;const g=(h+u)/2;if(h===u)p=0,d=0;else{const _=u-h;switch(d=g<=.5?_/(u+h):_/(2-u-h),u){case a:p=(o-c)/_+(o<c?6:0);break;case o:p=(c-a)/_+2;break;case c:p=(a-o)/_+4;break}p/=6}return e.h=p,e.s=d,e.l=g,e}getRGB(e,n=St.workingColorSpace){return St.workingToColorSpace(Vn.copy(this),n),e.r=Vn.r,e.g=Vn.g,e.b=Vn.b,e}getStyle(e=Nn){St.workingToColorSpace(Vn.copy(this),e);const n=Vn.r,a=Vn.g,o=Vn.b;return e!==Nn?`color(${e} ${n.toFixed(3)} ${a.toFixed(3)} ${o.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(a*255)},${Math.round(o*255)})`}offsetHSL(e,n,a){return this.getHSL(vs),this.setHSL(vs.h+e,vs.s+n,vs.l+a)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,n){return this.r=e.r+n.r,this.g=e.g+n.g,this.b=e.b+n.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,n){return this.r+=(e.r-this.r)*n,this.g+=(e.g-this.g)*n,this.b+=(e.b-this.b)*n,this}lerpColors(e,n,a){return this.r=e.r+(n.r-e.r)*a,this.g=e.g+(n.g-e.g)*a,this.b=e.b+(n.b-e.b)*a,this}lerpHSL(e,n){this.getHSL(vs),e.getHSL(Jc);const a=Al(vs.h,Jc.h,n),o=Al(vs.s,Jc.s,n),c=Al(vs.l,Jc.l,n);return this.setHSL(a,o,c),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const n=this.r,a=this.g,o=this.b,c=e.elements;return this.r=c[0]*n+c[3]*a+c[6]*o,this.g=c[1]*n+c[4]*a+c[7]*o,this.b=c[2]*n+c[5]*a+c[8]*o,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,n=0){return this.r=e[n],this.g=e[n+1],this.b=e[n+2],this}toArray(e=[],n=0){return e[n]=this.r,e[n+1]=this.g,e[n+2]=this.b,e}fromBufferAttribute(e,n){return this.r=e.getX(n),this.g=e.getY(n),this.b=e.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Vn=new st;st.NAMES=Wx;class qx extends en{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Va,this.environmentIntensity=1,this.environmentRotation=new Va,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,n){return super.copy(e,n),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const n=super.toJSON(e);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(n.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(n.object.backgroundIntensity=this.backgroundIntensity),n.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(n.object.environmentIntensity=this.environmentIntensity),n.object.environmentRotation=this.environmentRotation.toArray(),n}}const Ii=new $,Da=new $,pd=new $,La=new $,Xr=new $,Wr=new $,Ev=new $,md=new $,gd=new $,_d=new $,vd=new Yt,xd=new Yt,yd=new Yt;class zi{constructor(e=new $,n=new $,a=new $){this.a=e,this.b=n,this.c=a}static getNormal(e,n,a,o){o.subVectors(a,n),Ii.subVectors(e,n),o.cross(Ii);const c=o.lengthSq();return c>0?o.multiplyScalar(1/Math.sqrt(c)):o.set(0,0,0)}static getBarycoord(e,n,a,o,c){Ii.subVectors(o,n),Da.subVectors(a,n),pd.subVectors(e,n);const u=Ii.dot(Ii),h=Ii.dot(Da),p=Ii.dot(pd),d=Da.dot(Da),g=Da.dot(pd),_=u*d-h*h;if(_===0)return c.set(0,0,0),null;const v=1/_,x=(d*p-h*g)*v,E=(u*g-h*p)*v;return c.set(1-x-E,E,x)}static containsPoint(e,n,a,o){return this.getBarycoord(e,n,a,o,La)===null?!1:La.x>=0&&La.y>=0&&La.x+La.y<=1}static getInterpolation(e,n,a,o,c,u,h,p){return this.getBarycoord(e,n,a,o,La)===null?(p.x=0,p.y=0,"z"in p&&(p.z=0),"w"in p&&(p.w=0),null):(p.setScalar(0),p.addScaledVector(c,La.x),p.addScaledVector(u,La.y),p.addScaledVector(h,La.z),p)}static getInterpolatedAttribute(e,n,a,o,c,u){return vd.setScalar(0),xd.setScalar(0),yd.setScalar(0),vd.fromBufferAttribute(e,n),xd.fromBufferAttribute(e,a),yd.fromBufferAttribute(e,o),u.setScalar(0),u.addScaledVector(vd,c.x),u.addScaledVector(xd,c.y),u.addScaledVector(yd,c.z),u}static isFrontFacing(e,n,a,o){return Ii.subVectors(a,n),Da.subVectors(e,n),Ii.cross(Da).dot(o)<0}set(e,n,a){return this.a.copy(e),this.b.copy(n),this.c.copy(a),this}setFromPointsAndIndices(e,n,a,o){return this.a.copy(e[n]),this.b.copy(e[a]),this.c.copy(e[o]),this}setFromAttributeAndIndices(e,n,a,o){return this.a.fromBufferAttribute(e,n),this.b.fromBufferAttribute(e,a),this.c.fromBufferAttribute(e,o),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Ii.subVectors(this.c,this.b),Da.subVectors(this.a,this.b),Ii.cross(Da).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return zi.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,n){return zi.getBarycoord(e,this.a,this.b,this.c,n)}getInterpolation(e,n,a,o,c){return zi.getInterpolation(e,this.a,this.b,this.c,n,a,o,c)}containsPoint(e){return zi.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return zi.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,n){const a=this.a,o=this.b,c=this.c;let u,h;Xr.subVectors(o,a),Wr.subVectors(c,a),md.subVectors(e,a);const p=Xr.dot(md),d=Wr.dot(md);if(p<=0&&d<=0)return n.copy(a);gd.subVectors(e,o);const g=Xr.dot(gd),_=Wr.dot(gd);if(g>=0&&_<=g)return n.copy(o);const v=p*_-g*d;if(v<=0&&p>=0&&g<=0)return u=p/(p-g),n.copy(a).addScaledVector(Xr,u);_d.subVectors(e,c);const x=Xr.dot(_d),E=Wr.dot(_d);if(E>=0&&x<=E)return n.copy(c);const C=x*d-p*E;if(C<=0&&d>=0&&E<=0)return h=d/(d-E),n.copy(a).addScaledVector(Wr,h);const M=g*E-x*_;if(M<=0&&_-g>=0&&x-E>=0)return Ev.subVectors(c,o),h=(_-g)/(_-g+(x-E)),n.copy(o).addScaledVector(Ev,h);const S=1/(M+C+v);return u=C*S,h=v*S,n.copy(a).addScaledVector(Xr,u).addScaledVector(Wr,h)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class ki{constructor(e=new $(1/0,1/0,1/0),n=new $(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=n}set(e,n){return this.min.copy(e),this.max.copy(n),this}setFromArray(e){this.makeEmpty();for(let n=0,a=e.length;n<a;n+=3)this.expandByPoint(Bi.fromArray(e,n));return this}setFromBufferAttribute(e){this.makeEmpty();for(let n=0,a=e.count;n<a;n++)this.expandByPoint(Bi.fromBufferAttribute(e,n));return this}setFromPoints(e){this.makeEmpty();for(let n=0,a=e.length;n<a;n++)this.expandByPoint(e[n]);return this}setFromCenterAndSize(e,n){const a=Bi.copy(n).multiplyScalar(.5);return this.min.copy(e).sub(a),this.max.copy(e).add(a),this}setFromObject(e,n=!1){return this.makeEmpty(),this.expandByObject(e,n)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,n=!1){e.updateWorldMatrix(!1,!1);const a=e.geometry;if(a!==void 0){const c=a.getAttribute("position");if(n===!0&&c!==void 0&&e.isInstancedMesh!==!0)for(let u=0,h=c.count;u<h;u++)e.isMesh===!0?e.getVertexPosition(u,Bi):Bi.fromBufferAttribute(c,u),Bi.applyMatrix4(e.matrixWorld),this.expandByPoint(Bi);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),jc.copy(e.boundingBox)):(a.boundingBox===null&&a.computeBoundingBox(),jc.copy(a.boundingBox)),jc.applyMatrix4(e.matrixWorld),this.union(jc)}const o=e.children;for(let c=0,u=o.length;c<u;c++)this.expandByObject(o[c],n);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,n){return n.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Bi),Bi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let n,a;return e.normal.x>0?(n=e.normal.x*this.min.x,a=e.normal.x*this.max.x):(n=e.normal.x*this.max.x,a=e.normal.x*this.min.x),e.normal.y>0?(n+=e.normal.y*this.min.y,a+=e.normal.y*this.max.y):(n+=e.normal.y*this.max.y,a+=e.normal.y*this.min.y),e.normal.z>0?(n+=e.normal.z*this.min.z,a+=e.normal.z*this.max.z):(n+=e.normal.z*this.max.z,a+=e.normal.z*this.min.z),n<=-e.constant&&a>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(hl),$c.subVectors(this.max,hl),qr.subVectors(e.a,hl),Yr.subVectors(e.b,hl),Kr.subVectors(e.c,hl),xs.subVectors(Yr,qr),ys.subVectors(Kr,Yr),Ks.subVectors(qr,Kr);let n=[0,-xs.z,xs.y,0,-ys.z,ys.y,0,-Ks.z,Ks.y,xs.z,0,-xs.x,ys.z,0,-ys.x,Ks.z,0,-Ks.x,-xs.y,xs.x,0,-ys.y,ys.x,0,-Ks.y,Ks.x,0];return!Sd(n,qr,Yr,Kr,$c)||(n=[1,0,0,0,1,0,0,0,1],!Sd(n,qr,Yr,Kr,$c))?!1:(eu.crossVectors(xs,ys),n=[eu.x,eu.y,eu.z],Sd(n,qr,Yr,Kr,$c))}clampPoint(e,n){return n.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Bi).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Bi).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Na[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Na[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Na[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Na[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Na[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Na[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Na[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Na[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Na),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Na=[new $,new $,new $,new $,new $,new $,new $,new $],Bi=new $,jc=new ki,qr=new $,Yr=new $,Kr=new $,xs=new $,ys=new $,Ks=new $,hl=new $,$c=new $,eu=new $,Zs=new $;function Sd(r,e,n,a,o){for(let c=0,u=r.length-3;c<=u;c+=3){Zs.fromArray(r,c);const h=o.x*Math.abs(Zs.x)+o.y*Math.abs(Zs.y)+o.z*Math.abs(Zs.z),p=e.dot(Zs),d=n.dot(Zs),g=a.dot(Zs);if(Math.max(-Math.max(p,d,g),Math.min(p,d,g))>h)return!1}return!0}const Mn=new $,tu=new gt;let KE=0;class Yn extends rr{constructor(e,n,a=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:KE++}),this.name="",this.array=e,this.itemSize=n,this.count=e!==void 0?e.length/n:0,this.normalized=a,this.usage=wp,this.updateRanges=[],this.gpuType=Ri,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,n,a){e*=this.itemSize,a*=n.itemSize;for(let o=0,c=this.itemSize;o<c;o++)this.array[e+o]=n.array[a+o];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let n=0,a=this.count;n<a;n++)tu.fromBufferAttribute(this,n),tu.applyMatrix3(e),this.setXY(n,tu.x,tu.y);else if(this.itemSize===3)for(let n=0,a=this.count;n<a;n++)Mn.fromBufferAttribute(this,n),Mn.applyMatrix3(e),this.setXYZ(n,Mn.x,Mn.y,Mn.z);return this}applyMatrix4(e){for(let n=0,a=this.count;n<a;n++)Mn.fromBufferAttribute(this,n),Mn.applyMatrix4(e),this.setXYZ(n,Mn.x,Mn.y,Mn.z);return this}applyNormalMatrix(e){for(let n=0,a=this.count;n<a;n++)Mn.fromBufferAttribute(this,n),Mn.applyNormalMatrix(e),this.setXYZ(n,Mn.x,Mn.y,Mn.z);return this}transformDirection(e){for(let n=0,a=this.count;n<a;n++)Mn.fromBufferAttribute(this,n),Mn.transformDirection(e),this.setXYZ(n,Mn.x,Mn.y,Mn.z);return this}set(e,n=0){return this.array.set(e,n),this}getComponent(e,n){let a=this.array[e*this.itemSize+n];return this.normalized&&(a=Fi(a,this.array)),a}setComponent(e,n,a){return this.normalized&&(a=Gt(a,this.array)),this.array[e*this.itemSize+n]=a,this}getX(e){let n=this.array[e*this.itemSize];return this.normalized&&(n=Fi(n,this.array)),n}setX(e,n){return this.normalized&&(n=Gt(n,this.array)),this.array[e*this.itemSize]=n,this}getY(e){let n=this.array[e*this.itemSize+1];return this.normalized&&(n=Fi(n,this.array)),n}setY(e,n){return this.normalized&&(n=Gt(n,this.array)),this.array[e*this.itemSize+1]=n,this}getZ(e){let n=this.array[e*this.itemSize+2];return this.normalized&&(n=Fi(n,this.array)),n}setZ(e,n){return this.normalized&&(n=Gt(n,this.array)),this.array[e*this.itemSize+2]=n,this}getW(e){let n=this.array[e*this.itemSize+3];return this.normalized&&(n=Fi(n,this.array)),n}setW(e,n){return this.normalized&&(n=Gt(n,this.array)),this.array[e*this.itemSize+3]=n,this}setXY(e,n,a){return e*=this.itemSize,this.normalized&&(n=Gt(n,this.array),a=Gt(a,this.array)),this.array[e+0]=n,this.array[e+1]=a,this}setXYZ(e,n,a,o){return e*=this.itemSize,this.normalized&&(n=Gt(n,this.array),a=Gt(a,this.array),o=Gt(o,this.array)),this.array[e+0]=n,this.array[e+1]=a,this.array[e+2]=o,this}setXYZW(e,n,a,o,c){return e*=this.itemSize,this.normalized&&(n=Gt(n,this.array),a=Gt(a,this.array),o=Gt(o,this.array),c=Gt(c,this.array)),this.array[e+0]=n,this.array[e+1]=a,this.array[e+2]=o,this.array[e+3]=c,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==wp&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class Yx extends Yn{constructor(e,n,a){super(new Uint16Array(e),n,a)}}class Kx extends Yn{constructor(e,n,a){super(new Uint32Array(e),n,a)}}class Gi extends Yn{constructor(e,n,a){super(new Float32Array(e),n,a)}}const ZE=new ki,dl=new $,Md=new $;class la{constructor(e=new $,n=-1){this.isSphere=!0,this.center=e,this.radius=n}set(e,n){return this.center.copy(e),this.radius=n,this}setFromPoints(e,n){const a=this.center;n!==void 0?a.copy(n):ZE.setFromPoints(e).getCenter(a);let o=0;for(let c=0,u=e.length;c<u;c++)o=Math.max(o,a.distanceToSquared(e[c]));return this.radius=Math.sqrt(o),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const n=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=n*n}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,n){const a=this.center.distanceToSquared(e);return n.copy(e),a>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;dl.subVectors(e,this.center);const n=dl.lengthSq();if(n>this.radius*this.radius){const a=Math.sqrt(n),o=(a-this.radius)*.5;this.center.addScaledVector(dl,o/a),this.radius+=o}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Md.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(dl.copy(e.center).add(Md)),this.expandByPoint(dl.copy(e.center).sub(Md))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let QE=0;const Ti=new dt,Ed=new en,Zr=new $,pi=new ki,pl=new ki,Ln=new $;class wi extends rr{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:QE++}),this.uuid=Hi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(dE(e)?Kx:Yx)(e,1):this.index=e,this}setIndirect(e,n=0){return this.indirect=e,this.indirectOffset=n,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,n){return this.attributes[e]=n,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,n,a=0){this.groups.push({start:e,count:n,materialIndex:a})}clearGroups(){this.groups=[]}setDrawRange(e,n){this.drawRange.start=e,this.drawRange.count=n}applyMatrix4(e){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(e),n.needsUpdate=!0);const a=this.attributes.normal;if(a!==void 0){const c=new lt().getNormalMatrix(e);a.applyNormalMatrix(c),a.needsUpdate=!0}const o=this.attributes.tangent;return o!==void 0&&(o.transformDirection(e),o.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Ti.makeRotationFromQuaternion(e),this.applyMatrix4(Ti),this}rotateX(e){return Ti.makeRotationX(e),this.applyMatrix4(Ti),this}rotateY(e){return Ti.makeRotationY(e),this.applyMatrix4(Ti),this}rotateZ(e){return Ti.makeRotationZ(e),this.applyMatrix4(Ti),this}translate(e,n,a){return Ti.makeTranslation(e,n,a),this.applyMatrix4(Ti),this}scale(e,n,a){return Ti.makeScale(e,n,a),this.applyMatrix4(Ti),this}lookAt(e){return Ed.lookAt(e),Ed.updateMatrix(),this.applyMatrix4(Ed.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Zr).negate(),this.translate(Zr.x,Zr.y,Zr.z),this}setFromPoints(e){const n=this.getAttribute("position");if(n===void 0){const a=[];for(let o=0,c=e.length;o<c;o++){const u=e[o];a.push(u.x,u.y,u.z||0)}this.setAttribute("position",new Gi(a,3))}else{const a=Math.min(e.length,n.count);for(let o=0;o<a;o++){const c=e[o];n.setXYZ(o,c.x,c.y,c.z||0)}e.length>n.count&&Ke("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ki);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){at("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new $(-1/0,-1/0,-1/0),new $(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),n)for(let a=0,o=n.length;a<o;a++){const c=n[a];pi.setFromBufferAttribute(c),this.morphTargetsRelative?(Ln.addVectors(this.boundingBox.min,pi.min),this.boundingBox.expandByPoint(Ln),Ln.addVectors(this.boundingBox.max,pi.max),this.boundingBox.expandByPoint(Ln)):(this.boundingBox.expandByPoint(pi.min),this.boundingBox.expandByPoint(pi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&at('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new la);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){at("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new $,1/0);return}if(e){const a=this.boundingSphere.center;if(pi.setFromBufferAttribute(e),n)for(let c=0,u=n.length;c<u;c++){const h=n[c];pl.setFromBufferAttribute(h),this.morphTargetsRelative?(Ln.addVectors(pi.min,pl.min),pi.expandByPoint(Ln),Ln.addVectors(pi.max,pl.max),pi.expandByPoint(Ln)):(pi.expandByPoint(pl.min),pi.expandByPoint(pl.max))}pi.getCenter(a);let o=0;for(let c=0,u=e.count;c<u;c++)Ln.fromBufferAttribute(e,c),o=Math.max(o,a.distanceToSquared(Ln));if(n)for(let c=0,u=n.length;c<u;c++){const h=n[c],p=this.morphTargetsRelative;for(let d=0,g=h.count;d<g;d++)Ln.fromBufferAttribute(h,d),p&&(Zr.fromBufferAttribute(e,d),Ln.add(Zr)),o=Math.max(o,a.distanceToSquared(Ln))}this.boundingSphere.radius=Math.sqrt(o),isNaN(this.boundingSphere.radius)&&at('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,n=this.attributes;if(e===null||n.position===void 0||n.normal===void 0||n.uv===void 0){at("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const a=n.position,o=n.normal,c=n.uv;let u=this.getAttribute("tangent");(u===void 0||u.count!==a.count)&&(u=new Yn(new Float32Array(4*a.count),4),this.setAttribute("tangent",u));const h=[],p=[];for(let T=0;T<a.count;T++)h[T]=new $,p[T]=new $;const d=new $,g=new $,_=new $,v=new gt,x=new gt,E=new gt,C=new $,M=new $;function S(T,O,X){d.fromBufferAttribute(a,T),g.fromBufferAttribute(a,O),_.fromBufferAttribute(a,X),v.fromBufferAttribute(c,T),x.fromBufferAttribute(c,O),E.fromBufferAttribute(c,X),g.sub(d),_.sub(d),x.sub(v),E.sub(v);const G=1/(x.x*E.y-E.x*x.y);isFinite(G)&&(C.copy(g).multiplyScalar(E.y).addScaledVector(_,-x.y).multiplyScalar(G),M.copy(_).multiplyScalar(x.x).addScaledVector(g,-E.x).multiplyScalar(G),h[T].add(C),h[O].add(C),h[X].add(C),p[T].add(M),p[O].add(M),p[X].add(M))}let B=this.groups;B.length===0&&(B=[{start:0,count:e.count}]);for(let T=0,O=B.length;T<O;++T){const X=B[T],G=X.start,Z=X.count;for(let ce=G,ge=G+Z;ce<ge;ce+=3)S(e.getX(ce+0),e.getX(ce+1),e.getX(ce+2))}const F=new $,w=new $,P=new $,U=new $;function N(T){P.fromBufferAttribute(o,T),U.copy(P);const O=h[T];F.copy(O),F.sub(P.multiplyScalar(P.dot(O))).normalize(),w.crossVectors(U,O);const G=w.dot(p[T])<0?-1:1;u.setXYZW(T,F.x,F.y,F.z,G)}for(let T=0,O=B.length;T<O;++T){const X=B[T],G=X.start,Z=X.count;for(let ce=G,ge=G+Z;ce<ge;ce+=3)N(e.getX(ce+0)),N(e.getX(ce+1)),N(e.getX(ce+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,n=this.getAttribute("position");if(n!==void 0){let a=this.getAttribute("normal");if(a===void 0||a.count!==n.count)a=new Yn(new Float32Array(n.count*3),3),this.setAttribute("normal",a);else for(let v=0,x=a.count;v<x;v++)a.setXYZ(v,0,0,0);const o=new $,c=new $,u=new $,h=new $,p=new $,d=new $,g=new $,_=new $;if(e)for(let v=0,x=e.count;v<x;v+=3){const E=e.getX(v+0),C=e.getX(v+1),M=e.getX(v+2);o.fromBufferAttribute(n,E),c.fromBufferAttribute(n,C),u.fromBufferAttribute(n,M),g.subVectors(u,c),_.subVectors(o,c),g.cross(_),h.fromBufferAttribute(a,E),p.fromBufferAttribute(a,C),d.fromBufferAttribute(a,M),h.add(g),p.add(g),d.add(g),a.setXYZ(E,h.x,h.y,h.z),a.setXYZ(C,p.x,p.y,p.z),a.setXYZ(M,d.x,d.y,d.z)}else for(let v=0,x=n.count;v<x;v+=3)o.fromBufferAttribute(n,v+0),c.fromBufferAttribute(n,v+1),u.fromBufferAttribute(n,v+2),g.subVectors(u,c),_.subVectors(o,c),g.cross(_),a.setXYZ(v+0,g.x,g.y,g.z),a.setXYZ(v+1,g.x,g.y,g.z),a.setXYZ(v+2,g.x,g.y,g.z);this.normalizeNormals(),a.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let n=0,a=e.count;n<a;n++)Ln.fromBufferAttribute(e,n),Ln.normalize(),e.setXYZ(n,Ln.x,Ln.y,Ln.z)}toNonIndexed(){function e(h,p){const d=h.array,g=h.itemSize,_=h.normalized,v=new d.constructor(p.length*g);let x=0,E=0;for(let C=0,M=p.length;C<M;C++){h.isInterleavedBufferAttribute?x=p[C]*h.data.stride+h.offset:x=p[C]*g;for(let S=0;S<g;S++)v[E++]=d[x++]}return new Yn(v,g,_)}if(this.index===null)return Ke("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new wi,a=this.index.array,o=this.attributes;for(const h in o){const p=o[h],d=e(p,a);n.setAttribute(h,d)}const c=this.morphAttributes;for(const h in c){const p=[],d=c[h];for(let g=0,_=d.length;g<_;g++){const v=d[g],x=e(v,a);p.push(x)}n.morphAttributes[h]=p}n.morphTargetsRelative=this.morphTargetsRelative;const u=this.groups;for(let h=0,p=u.length;h<p;h++){const d=u[h];n.addGroup(d.start,d.count,d.materialIndex)}return n}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const p=this.parameters;for(const d in p)p[d]!==void 0&&(e[d]=p[d]);return e}e.data={attributes:{}};const n=this.index;n!==null&&(e.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const a=this.attributes;for(const p in a){const d=a[p];e.data.attributes[p]=d.toJSON(e.data)}const o={};let c=!1;for(const p in this.morphAttributes){const d=this.morphAttributes[p],g=[];for(let _=0,v=d.length;_<v;_++){const x=d[_];g.push(x.toJSON(e.data))}g.length>0&&(o[p]=g,c=!0)}c&&(e.data.morphAttributes=o,e.data.morphTargetsRelative=this.morphTargetsRelative);const u=this.groups;u.length>0&&(e.data.groups=JSON.parse(JSON.stringify(u)));const h=this.boundingSphere;return h!==null&&(e.data.boundingSphere=h.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=e.name;const a=e.index;a!==null&&this.setIndex(a.clone());const o=e.attributes;for(const d in o){const g=o[d];this.setAttribute(d,g.clone(n))}const c=e.morphAttributes;for(const d in c){const g=[],_=c[d];for(let v=0,x=_.length;v<x;v++)g.push(_[v].clone(n));this.morphAttributes[d]=g}this.morphTargetsRelative=e.morphTargetsRelative;const u=e.groups;for(let d=0,g=u.length;d<g;d++){const _=u[d];this.addGroup(_.start,_.count,_.materialIndex)}const h=e.boundingBox;h!==null&&(this.boundingBox=h.clone());const p=e.boundingSphere;return p!==null&&(this.boundingSphere=p.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class JE{constructor(e,n){this.isInterleavedBuffer=!0,this.array=e,this.stride=n,this.count=e!==void 0?e.length/n:0,this.usage=wp,this.updateRanges=[],this.version=0,this.uuid=Hi()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,n,a){e*=this.stride,a*=n.stride;for(let o=0,c=this.stride;o<c;o++)this.array[e+o]=n.array[a+o];return this}set(e,n=0){return this.array.set(e,n),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Hi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const n=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),a=new this.constructor(n,this.stride);return a.setUsage(this.usage),a}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Hi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Xn=new $;class $p{constructor(e,n,a,o=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=n,this.offset=a,this.normalized=o}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let n=0,a=this.data.count;n<a;n++)Xn.fromBufferAttribute(this,n),Xn.applyMatrix4(e),this.setXYZ(n,Xn.x,Xn.y,Xn.z);return this}applyNormalMatrix(e){for(let n=0,a=this.count;n<a;n++)Xn.fromBufferAttribute(this,n),Xn.applyNormalMatrix(e),this.setXYZ(n,Xn.x,Xn.y,Xn.z);return this}transformDirection(e){for(let n=0,a=this.count;n<a;n++)Xn.fromBufferAttribute(this,n),Xn.transformDirection(e),this.setXYZ(n,Xn.x,Xn.y,Xn.z);return this}getComponent(e,n){let a=this.array[e*this.data.stride+this.offset+n];return this.normalized&&(a=Fi(a,this.array)),a}setComponent(e,n,a){return this.normalized&&(a=Gt(a,this.array)),this.data.array[e*this.data.stride+this.offset+n]=a,this}setX(e,n){return this.normalized&&(n=Gt(n,this.array)),this.data.array[e*this.data.stride+this.offset]=n,this}setY(e,n){return this.normalized&&(n=Gt(n,this.array)),this.data.array[e*this.data.stride+this.offset+1]=n,this}setZ(e,n){return this.normalized&&(n=Gt(n,this.array)),this.data.array[e*this.data.stride+this.offset+2]=n,this}setW(e,n){return this.normalized&&(n=Gt(n,this.array)),this.data.array[e*this.data.stride+this.offset+3]=n,this}getX(e){let n=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(n=Fi(n,this.array)),n}getY(e){let n=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(n=Fi(n,this.array)),n}getZ(e){let n=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(n=Fi(n,this.array)),n}getW(e){let n=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(n=Fi(n,this.array)),n}setXY(e,n,a){return e=e*this.data.stride+this.offset,this.normalized&&(n=Gt(n,this.array),a=Gt(a,this.array)),this.data.array[e+0]=n,this.data.array[e+1]=a,this}setXYZ(e,n,a,o){return e=e*this.data.stride+this.offset,this.normalized&&(n=Gt(n,this.array),a=Gt(a,this.array),o=Gt(o,this.array)),this.data.array[e+0]=n,this.data.array[e+1]=a,this.data.array[e+2]=o,this}setXYZW(e,n,a,o,c){return e=e*this.data.stride+this.offset,this.normalized&&(n=Gt(n,this.array),a=Gt(a,this.array),o=Gt(o,this.array),c=Gt(c,this.array)),this.data.array[e+0]=n,this.data.array[e+1]=a,this.data.array[e+2]=o,this.data.array[e+3]=c,this}clone(e){if(e===void 0){Bu("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const n=[];for(let a=0;a<this.count;a++){const o=a*this.data.stride+this.offset;for(let c=0;c<this.itemSize;c++)n.push(this.data.array[o+c])}return new Yn(new this.array.constructor(n),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new $p(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){Bu("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const n=[];for(let a=0;a<this.count;a++){const o=a*this.data.stride+this.offset;for(let c=0;c<this.itemSize;c++)n.push(this.data.array[o+c])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:n,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}let jE=0;class Vi extends rr{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:jE++}),this.uuid=Hi(),this.name="",this.type="Material",this.blending=no,this.side=za,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=kd,this.blendDst=Xd,this.blendEquation=er,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new st(0,0,0),this.blendAlpha=0,this.depthFunc=ro,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=cv,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=zr,this.stencilZFail=zr,this.stencilZPass=zr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const n in e){const a=e[n];if(a===void 0){Ke(`Material: parameter '${n}' has value of undefined.`);continue}const o=this[n];if(o===void 0){Ke(`Material: '${n}' is not a property of THREE.${this.type}.`);continue}o&&o.isColor?o.set(a):o&&o.isVector2&&a&&a.isVector2||o&&o.isEuler&&a&&a.isEuler||o&&o.isVector3&&a&&a.isVector3?o.copy(a):this[n]=a}}toJSON(e){const n=e===void 0||typeof e=="string";n&&(e={textures:{},images:{}});const a={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.color&&this.color.isColor&&(a.color=this.color.getHex()),this.roughness!==void 0&&(a.roughness=this.roughness),this.metalness!==void 0&&(a.metalness=this.metalness),this.sheen!==void 0&&(a.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(a.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(a.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(a.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(a.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(a.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(a.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(a.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(a.shininess=this.shininess),this.clearcoat!==void 0&&(a.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(a.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(a.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(a.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(a.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,a.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(a.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(a.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(a.dispersion=this.dispersion),this.iridescence!==void 0&&(a.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(a.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(a.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(a.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(a.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(a.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(a.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(a.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(a.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(a.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(a.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(a.lightMap=this.lightMap.toJSON(e).uuid,a.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(a.aoMap=this.aoMap.toJSON(e).uuid,a.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(a.bumpMap=this.bumpMap.toJSON(e).uuid,a.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(a.normalMap=this.normalMap.toJSON(e).uuid,a.normalMapType=this.normalMapType,a.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(a.displacementMap=this.displacementMap.toJSON(e).uuid,a.displacementScale=this.displacementScale,a.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(a.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(a.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(a.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(a.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(a.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(a.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(a.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(a.combine=this.combine)),this.envMapRotation!==void 0&&(a.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(a.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(a.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(a.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(a.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(a.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(a.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(a.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(a.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(a.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(a.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(a.size=this.size),this.shadowSide!==null&&(a.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(a.sizeAttenuation=this.sizeAttenuation),this.blending!==no&&(a.blending=this.blending),this.side!==za&&(a.side=this.side),this.vertexColors===!0&&(a.vertexColors=!0),this.opacity<1&&(a.opacity=this.opacity),this.transparent===!0&&(a.transparent=!0),this.blendSrc!==kd&&(a.blendSrc=this.blendSrc),this.blendDst!==Xd&&(a.blendDst=this.blendDst),this.blendEquation!==er&&(a.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(a.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(a.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(a.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(a.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(a.blendAlpha=this.blendAlpha),this.depthFunc!==ro&&(a.depthFunc=this.depthFunc),this.depthTest===!1&&(a.depthTest=this.depthTest),this.depthWrite===!1&&(a.depthWrite=this.depthWrite),this.colorWrite===!1&&(a.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(a.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==cv&&(a.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(a.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(a.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==zr&&(a.stencilFail=this.stencilFail),this.stencilZFail!==zr&&(a.stencilZFail=this.stencilZFail),this.stencilZPass!==zr&&(a.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(a.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(a.rotation=this.rotation),this.polygonOffset===!0&&(a.polygonOffset=!0),this.polygonOffsetFactor!==0&&(a.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(a.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(a.linewidth=this.linewidth),this.dashSize!==void 0&&(a.dashSize=this.dashSize),this.gapSize!==void 0&&(a.gapSize=this.gapSize),this.scale!==void 0&&(a.scale=this.scale),this.dithering===!0&&(a.dithering=!0),this.alphaTest>0&&(a.alphaTest=this.alphaTest),this.alphaHash===!0&&(a.alphaHash=!0),this.alphaToCoverage===!0&&(a.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(a.premultipliedAlpha=!0),this.forceSinglePass===!0&&(a.forceSinglePass=!0),this.allowOverride===!1&&(a.allowOverride=!1),this.wireframe===!0&&(a.wireframe=!0),this.wireframeLinewidth>1&&(a.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(a.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(a.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(a.flatShading=!0),this.visible===!1&&(a.visible=!1),this.toneMapped===!1&&(a.toneMapped=!1),this.fog===!1&&(a.fog=!1),Object.keys(this.userData).length>0&&(a.userData=this.userData);function o(c){const u=[];for(const h in c){const p=c[h];delete p.metadata,u.push(p)}return u}if(n){const c=o(e.textures),u=o(e.images);c.length>0&&(a.textures=c),u.length>0&&(a.images=u)}return a}fromJSON(e,n){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new st().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=n[e.map]||null),e.matcap!==void 0&&(this.matcap=n[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=n[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=n[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=n[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let a=e.normalScale;Array.isArray(a)===!1&&(a=[a,a]),this.normalScale=new gt().fromArray(a)}return e.displacementMap!==void 0&&(this.displacementMap=n[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=n[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=n[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=n[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=n[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=n[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=n[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=n[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=n[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=n[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=n[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=n[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=n[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=n[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new gt().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=n[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=n[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=n[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=n[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=n[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=n[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=n[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const n=e.clippingPlanes;let a=null;if(n!==null){const o=n.length;a=new Array(o);for(let c=0;c!==o;++c)a[c]=n[c].clone()}return this.clippingPlanes=a,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Ua=new $,bd=new $,nu=new $,Ss=new $,Td=new $,iu=new $,Ad=new $;class ku{constructor(e=new $,n=new $(0,0,-1)){this.origin=e,this.direction=n}set(e,n){return this.origin.copy(e),this.direction.copy(n),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,n){return n.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Ua)),this}closestPointToPoint(e,n){n.subVectors(e,this.origin);const a=n.dot(this.direction);return a<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,a)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const n=Ua.subVectors(e,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(e):(Ua.copy(this.origin).addScaledVector(this.direction,n),Ua.distanceToSquared(e))}distanceSqToSegment(e,n,a,o){bd.copy(e).add(n).multiplyScalar(.5),nu.copy(n).sub(e).normalize(),Ss.copy(this.origin).sub(bd);const c=e.distanceTo(n)*.5,u=-this.direction.dot(nu),h=Ss.dot(this.direction),p=-Ss.dot(nu),d=Ss.lengthSq(),g=Math.abs(1-u*u);let _,v,x,E;if(g>0)if(_=u*p-h,v=u*h-p,E=c*g,_>=0)if(v>=-E)if(v<=E){const C=1/g;_*=C,v*=C,x=_*(_+u*v+2*h)+v*(u*_+v+2*p)+d}else v=c,_=Math.max(0,-(u*v+h)),x=-_*_+v*(v+2*p)+d;else v=-c,_=Math.max(0,-(u*v+h)),x=-_*_+v*(v+2*p)+d;else v<=-E?(_=Math.max(0,-(-u*c+h)),v=_>0?-c:Math.min(Math.max(-c,-p),c),x=-_*_+v*(v+2*p)+d):v<=E?(_=0,v=Math.min(Math.max(-c,-p),c),x=v*(v+2*p)+d):(_=Math.max(0,-(u*c+h)),v=_>0?c:Math.min(Math.max(-c,-p),c),x=-_*_+v*(v+2*p)+d);else v=u>0?-c:c,_=Math.max(0,-(u*v+h)),x=-_*_+v*(v+2*p)+d;return a&&a.copy(this.origin).addScaledVector(this.direction,_),o&&o.copy(bd).addScaledVector(nu,v),x}intersectSphere(e,n){Ua.subVectors(e.center,this.origin);const a=Ua.dot(this.direction),o=Ua.dot(Ua)-a*a,c=e.radius*e.radius;if(o>c)return null;const u=Math.sqrt(c-o),h=a-u,p=a+u;return p<0?null:h<0?this.at(p,n):this.at(h,n)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const n=e.normal.dot(this.direction);if(n===0)return e.distanceToPoint(this.origin)===0?0:null;const a=-(this.origin.dot(e.normal)+e.constant)/n;return a>=0?a:null}intersectPlane(e,n){const a=this.distanceToPlane(e);return a===null?null:this.at(a,n)}intersectsPlane(e){const n=e.distanceToPoint(this.origin);return n===0||e.normal.dot(this.direction)*n<0}intersectBox(e,n){let a,o,c,u,h,p;const d=1/this.direction.x,g=1/this.direction.y,_=1/this.direction.z,v=this.origin;return d>=0?(a=(e.min.x-v.x)*d,o=(e.max.x-v.x)*d):(a=(e.max.x-v.x)*d,o=(e.min.x-v.x)*d),g>=0?(c=(e.min.y-v.y)*g,u=(e.max.y-v.y)*g):(c=(e.max.y-v.y)*g,u=(e.min.y-v.y)*g),a>u||c>o||((c>a||isNaN(a))&&(a=c),(u<o||isNaN(o))&&(o=u),_>=0?(h=(e.min.z-v.z)*_,p=(e.max.z-v.z)*_):(h=(e.max.z-v.z)*_,p=(e.min.z-v.z)*_),a>p||h>o)||((h>a||a!==a)&&(a=h),(p<o||o!==o)&&(o=p),o<0)?null:this.at(a>=0?a:o,n)}intersectsBox(e){return this.intersectBox(e,Ua)!==null}intersectTriangle(e,n,a,o,c){Td.subVectors(n,e),iu.subVectors(a,e),Ad.crossVectors(Td,iu);let u=this.direction.dot(Ad),h;if(u>0){if(o)return null;h=1}else if(u<0)h=-1,u=-u;else return null;Ss.subVectors(this.origin,e);const p=h*this.direction.dot(iu.crossVectors(Ss,iu));if(p<0)return null;const d=h*this.direction.dot(Td.cross(Ss));if(d<0||p+d>u)return null;const g=-h*Ss.dot(Ad);return g<0?null:this.at(g/u,c)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class ir extends Vi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new st(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Va,this.combine=Hp,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const bv=new dt,Qs=new ku,au=new la,Tv=new $,su=new $,ru=new $,ou=new $,Rd=new $,lu=new $,Av=new $,cu=new $;class En extends en{constructor(e=new wi,n=new ir){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}getVertexPosition(e,n){const a=this.geometry,o=a.attributes.position,c=a.morphAttributes.position,u=a.morphTargetsRelative;n.fromBufferAttribute(o,e);const h=this.morphTargetInfluences;if(c&&h){lu.set(0,0,0);for(let p=0,d=c.length;p<d;p++){const g=h[p],_=c[p];g!==0&&(Rd.fromBufferAttribute(_,e),u?lu.addScaledVector(Rd,g):lu.addScaledVector(Rd.sub(n),g))}n.add(lu)}return n}raycast(e,n){const a=this.geometry,o=this.material,c=this.matrixWorld;o!==void 0&&(a.boundingSphere===null&&a.computeBoundingSphere(),au.copy(a.boundingSphere),au.applyMatrix4(c),Qs.copy(e.ray).recast(e.near),!(au.containsPoint(Qs.origin)===!1&&(Qs.intersectSphere(au,Tv)===null||Qs.origin.distanceToSquared(Tv)>(e.far-e.near)**2))&&(bv.copy(c).invert(),Qs.copy(e.ray).applyMatrix4(bv),!(a.boundingBox!==null&&Qs.intersectsBox(a.boundingBox)===!1)&&this._computeIntersections(e,n,Qs)))}_computeIntersections(e,n,a){let o;const c=this.geometry,u=this.material,h=c.index,p=c.attributes.position,d=c.attributes.uv,g=c.attributes.uv1,_=c.attributes.normal,v=c.groups,x=c.drawRange;if(h!==null)if(Array.isArray(u))for(let E=0,C=v.length;E<C;E++){const M=v[E],S=u[M.materialIndex],B=Math.max(M.start,x.start),F=Math.min(h.count,Math.min(M.start+M.count,x.start+x.count));for(let w=B,P=F;w<P;w+=3){const U=h.getX(w),N=h.getX(w+1),T=h.getX(w+2);o=uu(this,S,e,a,d,g,_,U,N,T),o&&(o.faceIndex=Math.floor(w/3),o.face.materialIndex=M.materialIndex,n.push(o))}}else{const E=Math.max(0,x.start),C=Math.min(h.count,x.start+x.count);for(let M=E,S=C;M<S;M+=3){const B=h.getX(M),F=h.getX(M+1),w=h.getX(M+2);o=uu(this,u,e,a,d,g,_,B,F,w),o&&(o.faceIndex=Math.floor(M/3),n.push(o))}}else if(p!==void 0)if(Array.isArray(u))for(let E=0,C=v.length;E<C;E++){const M=v[E],S=u[M.materialIndex],B=Math.max(M.start,x.start),F=Math.min(p.count,Math.min(M.start+M.count,x.start+x.count));for(let w=B,P=F;w<P;w+=3){const U=w,N=w+1,T=w+2;o=uu(this,S,e,a,d,g,_,U,N,T),o&&(o.faceIndex=Math.floor(w/3),o.face.materialIndex=M.materialIndex,n.push(o))}}else{const E=Math.max(0,x.start),C=Math.min(p.count,x.start+x.count);for(let M=E,S=C;M<S;M+=3){const B=M,F=M+1,w=M+2;o=uu(this,u,e,a,d,g,_,B,F,w),o&&(o.faceIndex=Math.floor(M/3),n.push(o))}}}}function $E(r,e,n,a,o,c,u,h){let p;if(e.side===qn?p=a.intersectTriangle(u,c,o,!0,h):p=a.intersectTriangle(o,c,u,e.side===za,h),p===null)return null;cu.copy(h),cu.applyMatrix4(r.matrixWorld);const d=n.ray.origin.distanceTo(cu);return d<n.near||d>n.far?null:{distance:d,point:cu.clone(),object:r}}function uu(r,e,n,a,o,c,u,h,p,d){r.getVertexPosition(h,su),r.getVertexPosition(p,ru),r.getVertexPosition(d,ou);const g=$E(r,e,n,a,su,ru,ou,Av);if(g){const _=new $;zi.getBarycoord(Av,su,ru,ou,_),o&&(g.uv=zi.getInterpolatedAttribute(o,h,p,d,_,new gt)),c&&(g.uv1=zi.getInterpolatedAttribute(c,h,p,d,_,new gt)),u&&(g.normal=zi.getInterpolatedAttribute(u,h,p,d,_,new $),g.normal.dot(a.direction)>0&&g.normal.multiplyScalar(-1));const v={a:h,b:p,c:d,normal:new $,materialIndex:0};zi.getNormal(su,ru,ou,v.normal),g.face=v,g.barycoord=_}return g}const ml=new Yt,Rv=new Yt,Cv=new Yt,eb=new Yt,wv=new dt,fu=new $,Cd=new la,Dv=new dt,wd=new ku;class tb extends En{constructor(e,n){super(e,n),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=av,this.bindMatrix=new dt,this.bindMatrixInverse=new dt,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new ki),this.boundingBox.makeEmpty();const n=e.getAttribute("position");for(let a=0;a<n.count;a++)this.getVertexPosition(a,fu),this.boundingBox.expandByPoint(fu)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new la),this.boundingSphere.makeEmpty();const n=e.getAttribute("position");for(let a=0;a<n.count;a++)this.getVertexPosition(a,fu),this.boundingSphere.expandByPoint(fu)}copy(e,n){return super.copy(e,n),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,n){const a=this.material,o=this.matrixWorld;a!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Cd.copy(this.boundingSphere),Cd.applyMatrix4(o),e.ray.intersectsSphere(Cd)!==!1&&(Dv.copy(o).invert(),wd.copy(e.ray).applyMatrix4(Dv),!(this.boundingBox!==null&&wd.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,n,wd)))}getVertexPosition(e,n){return super.getVertexPosition(e,n),this.applyBoneTransform(e,n),n}bind(e,n){this.skeleton=e,n===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),n=this.matrixWorld),this.bindMatrix.copy(n),this.bindMatrixInverse.copy(n).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new Yt,n=this.geometry.attributes.skinWeight;for(let a=0,o=n.count;a<o;a++){e.fromBufferAttribute(n,a);const c=1/e.manhattanLength();c!==1/0?e.multiplyScalar(c):e.set(1,0,0,0),n.setXYZW(a,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===av?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===nE?this.bindMatrixInverse.copy(this.bindMatrix).invert():Ke("SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,n){const a=this.skeleton,o=this.geometry;Rv.fromBufferAttribute(o.attributes.skinIndex,e),Cv.fromBufferAttribute(o.attributes.skinWeight,e),n.isVector4?(ml.copy(n),n.set(0,0,0,0)):(ml.set(...n,1),n.set(0,0,0)),ml.applyMatrix4(this.bindMatrix);for(let c=0;c<4;c++){const u=Cv.getComponent(c);if(u!==0){const h=Rv.getComponent(c);wv.multiplyMatrices(a.bones[h].matrixWorld,a.boneInverses[h]),n.addScaledVector(eb.copy(ml).applyMatrix4(wv),u)}}return n.isVector4&&(n.w=ml.w),n.applyMatrix4(this.bindMatrixInverse)}}class Zx extends en{constructor(){super(),this.isBone=!0,this.type="Bone"}}class em extends Un{constructor(e=null,n=1,a=1,o,c,u,h,p,d=An,g=An,_,v){super(null,u,h,p,d,g,o,c,_,v),this.isDataTexture=!0,this.image={data:e,width:n,height:a},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Lv=new dt,nb=new dt;class tm{constructor(e=[],n=[]){this.uuid=Hi(),this.bones=e.slice(0),this.boneInverses=n,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,n=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),n.length===0)this.calculateInverses();else if(e.length!==n.length){Ke("Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let a=0,o=this.bones.length;a<o;a++)this.boneInverses.push(new dt)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,n=this.bones.length;e<n;e++){const a=new dt;this.bones[e]&&a.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(a)}}pose(){for(let e=0,n=this.bones.length;e<n;e++){const a=this.bones[e];a&&a.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,n=this.bones.length;e<n;e++){const a=this.bones[e];a&&(a.parent&&a.parent.isBone?(a.matrix.copy(a.parent.matrixWorld).invert(),a.matrix.multiply(a.matrixWorld)):a.matrix.copy(a.matrixWorld),a.matrix.decompose(a.position,a.quaternion,a.scale))}}update(){const e=this.bones,n=this.boneInverses,a=this.boneMatrices,o=this.boneTexture;for(let c=0,u=e.length;c<u;c++){const h=e[c]?e[c].matrixWorld:nb;Lv.multiplyMatrices(h,n[c]),Lv.toArray(a,c*16)}o!==null&&(o.needsUpdate=!0)}clone(){return new tm(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const n=new Float32Array(e*e*4);n.set(this.boneMatrices);const a=new em(n,e,e,Ci,Ri);return a.needsUpdate=!0,this.boneMatrices=n,this.boneTexture=a,this}getBoneByName(e){for(let n=0,a=this.bones.length;n<a;n++){const o=this.bones[n];if(o.name===e)return o}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,n){this.uuid=e.uuid;for(let a=0,o=e.bones.length;a<o;a++){const c=e.bones[a];let u=n[c];u===void 0&&(Ke("Skeleton: No bone found with UUID:",c),u=new Zx),this.bones.push(u),this.boneInverses.push(new dt().fromArray(e.boneInverses[a]))}return this.init(),this}toJSON(){const e={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const n=this.bones,a=this.boneInverses;for(let o=0,c=n.length;o<c;o++){const u=n[o];e.bones.push(u.uuid);const h=a[o];e.boneInverses.push(h.toArray())}return e}}class Dp extends Yn{constructor(e,n,a,o=1){super(e,n,a),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=o}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Qr=new dt,Nv=new dt,hu=[],Uv=new ki,ib=new dt,gl=new En,_l=new la;class Qx extends En{constructor(e,n,a){super(e,n),this.isInstancedMesh=!0,this.instanceMatrix=new Dp(new Float32Array(a*16),16),this.instanceColor=null,this.morphTexture=null,this.count=a,this.boundingBox=null,this.boundingSphere=null;for(let o=0;o<a;o++)this.setMatrixAt(o,ib)}computeBoundingBox(){const e=this.geometry,n=this.count;this.boundingBox===null&&(this.boundingBox=new ki),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let a=0;a<n;a++)this.getMatrixAt(a,Qr),Uv.copy(e.boundingBox).applyMatrix4(Qr),this.boundingBox.union(Uv)}computeBoundingSphere(){const e=this.geometry,n=this.count;this.boundingSphere===null&&(this.boundingSphere=new la),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let a=0;a<n;a++)this.getMatrixAt(a,Qr),_l.copy(e.boundingSphere).applyMatrix4(Qr),this.boundingSphere.union(_l)}copy(e,n){return super.copy(e,n),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,n){return this.instanceColor===null?n.setRGB(1,1,1):n.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,n){return n.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,n){const a=n.morphTargetInfluences,o=this.morphTexture.source.data.data,c=a.length+1,u=e*c+1;for(let h=0;h<a.length;h++)a[h]=o[u+h]}raycast(e,n){const a=this.matrixWorld,o=this.count;if(gl.geometry=this.geometry,gl.material=this.material,gl.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),_l.copy(this.boundingSphere),_l.applyMatrix4(a),e.ray.intersectsSphere(_l)!==!1))for(let c=0;c<o;c++){this.getMatrixAt(c,Qr),Nv.multiplyMatrices(a,Qr),gl.matrixWorld=Nv,gl.raycast(e,hu);for(let u=0,h=hu.length;u<h;u++){const p=hu[u];p.instanceId=c,p.object=this,n.push(p)}hu.length=0}}setColorAt(e,n){return this.instanceColor===null&&(this.instanceColor=new Dp(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),n.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,n){return n.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,n){const a=n.morphTargetInfluences,o=a.length+1;this.morphTexture===null&&(this.morphTexture=new em(new Float32Array(o*this.count),o,this.count,Wp,Ri));const c=this.morphTexture.source.data.data;let u=0;for(let d=0;d<a.length;d++)u+=a[d];const h=this.geometry.morphTargetsRelative?1:1-u,p=o*e;return c[p]=h,c.set(a,p+1),this}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Dd=new $,ab=new $,sb=new lt;class $s{constructor(e=new $(1,0,0),n=0){this.isPlane=!0,this.normal=e,this.constant=n}set(e,n){return this.normal.copy(e),this.constant=n,this}setComponents(e,n,a,o){return this.normal.set(e,n,a),this.constant=o,this}setFromNormalAndCoplanarPoint(e,n){return this.normal.copy(e),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(e,n,a){const o=Dd.subVectors(a,n).cross(ab.subVectors(e,n)).normalize();return this.setFromNormalAndCoplanarPoint(o,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,n){return n.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,n,a=!0){const o=e.delta(Dd),c=this.normal.dot(o);if(c===0)return this.distanceToPoint(e.start)===0?n.copy(e.start):null;const u=-(e.start.dot(this.normal)+this.constant)/c;return a===!0&&(u<0||u>1)?null:n.copy(e.start).addScaledVector(o,u)}intersectsLine(e){const n=this.distanceToPoint(e.start),a=this.distanceToPoint(e.end);return n<0&&a>0||a<0&&n>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,n){const a=n||sb.getNormalMatrix(e),o=this.coplanarPoint(Dd).applyMatrix4(e),c=this.normal.applyMatrix3(a).normalize();return this.constant=-o.dot(c),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Js=new la,rb=new gt(.5,.5),du=new $;class nm{constructor(e=new $s,n=new $s,a=new $s,o=new $s,c=new $s,u=new $s){this.planes=[e,n,a,o,c,u]}set(e,n,a,o,c,u){const h=this.planes;return h[0].copy(e),h[1].copy(n),h[2].copy(a),h[3].copy(o),h[4].copy(c),h[5].copy(u),this}copy(e){const n=this.planes;for(let a=0;a<6;a++)n[a].copy(e.planes[a]);return this}setFromProjectionMatrix(e,n=ia,a=!1){const o=this.planes,c=e.elements,u=c[0],h=c[1],p=c[2],d=c[3],g=c[4],_=c[5],v=c[6],x=c[7],E=c[8],C=c[9],M=c[10],S=c[11],B=c[12],F=c[13],w=c[14],P=c[15];if(o[0].setComponents(d-u,x-g,S-E,P-B).normalize(),o[1].setComponents(d+u,x+g,S+E,P+B).normalize(),o[2].setComponents(d+h,x+_,S+C,P+F).normalize(),o[3].setComponents(d-h,x-_,S-C,P-F).normalize(),a)o[4].setComponents(p,v,M,w).normalize(),o[5].setComponents(d-p,x-v,S-M,P-w).normalize();else if(o[4].setComponents(d-p,x-v,S-M,P-w).normalize(),n===ia)o[5].setComponents(d+p,x+v,S+M,P+w).normalize();else if(n===Nl)o[5].setComponents(p,v,M,w).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Js.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const n=e.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),Js.copy(n.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Js)}intersectsSprite(e){Js.center.set(0,0,0);const n=rb.distanceTo(e.center);return Js.radius=.7071067811865476+n,Js.applyMatrix4(e.matrixWorld),this.intersectsSphere(Js)}intersectsSphere(e){const n=this.planes,a=e.center,o=-e.radius;for(let c=0;c<6;c++)if(n[c].distanceToPoint(a)<o)return!1;return!0}intersectsBox(e){const n=this.planes;for(let a=0;a<6;a++){const o=n[a];if(du.x=o.normal.x>0?e.max.x:e.min.x,du.y=o.normal.y>0?e.max.y:e.min.y,du.z=o.normal.z>0?e.max.z:e.min.z,o.distanceToPoint(du)<0)return!1}return!0}containsPoint(e){const n=this.planes;for(let a=0;a<6;a++)if(n[a].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Jx extends Vi{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new st(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Fu=new $,zu=new $,Ov=new dt,vl=new ku,pu=new la,Ld=new $,Pv=new $;class im extends en{constructor(e=new wi,n=new Jx){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const n=e.attributes.position,a=[0];for(let o=1,c=n.count;o<c;o++)Fu.fromBufferAttribute(n,o-1),zu.fromBufferAttribute(n,o),a[o]=a[o-1],a[o]+=Fu.distanceTo(zu);e.setAttribute("lineDistance",new Gi(a,1))}else Ke("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,n){const a=this.geometry,o=this.matrixWorld,c=e.params.Line.threshold,u=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),pu.copy(a.boundingSphere),pu.applyMatrix4(o),pu.radius+=c,e.ray.intersectsSphere(pu)===!1)return;Ov.copy(o).invert(),vl.copy(e.ray).applyMatrix4(Ov);const h=c/((this.scale.x+this.scale.y+this.scale.z)/3),p=h*h,d=this.isLineSegments?2:1,g=a.index,v=a.attributes.position;if(g!==null){const x=Math.max(0,u.start),E=Math.min(g.count,u.start+u.count);for(let C=x,M=E-1;C<M;C+=d){const S=g.getX(C),B=g.getX(C+1),F=mu(this,e,vl,p,S,B,C);F&&n.push(F)}if(this.isLineLoop){const C=g.getX(E-1),M=g.getX(x),S=mu(this,e,vl,p,C,M,E-1);S&&n.push(S)}}else{const x=Math.max(0,u.start),E=Math.min(v.count,u.start+u.count);for(let C=x,M=E-1;C<M;C+=d){const S=mu(this,e,vl,p,C,C+1,C);S&&n.push(S)}if(this.isLineLoop){const C=mu(this,e,vl,p,E-1,x,E-1);C&&n.push(C)}}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}}function mu(r,e,n,a,o,c,u){const h=r.geometry.attributes.position;if(Fu.fromBufferAttribute(h,o),zu.fromBufferAttribute(h,c),n.distanceSqToSegment(Fu,zu,Ld,Pv)>a)return;Ld.applyMatrix4(r.matrixWorld);const d=e.ray.origin.distanceTo(Ld);if(!(d<e.near||d>e.far))return{distance:d,point:Pv.clone().applyMatrix4(r.matrixWorld),index:u,face:null,faceIndex:null,barycoord:null,object:r}}const Iv=new $,Bv=new $;class ob extends im{constructor(e,n){super(e,n),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const n=e.attributes.position,a=[];for(let o=0,c=n.count;o<c;o+=2)Iv.fromBufferAttribute(n,o),Bv.fromBufferAttribute(n,o+1),a[o]=o===0?0:a[o-1],a[o+1]=a[o]+Iv.distanceTo(Bv);e.setAttribute("lineDistance",new Gi(a,1))}else Ke("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class lb extends im{constructor(e,n){super(e,n),this.isLineLoop=!0,this.type="LineLoop"}}class jx extends Vi{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new st(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Fv=new dt,Lp=new ku,gu=new la,_u=new $;class cb extends en{constructor(e=new wi,n=new jx){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,n){const a=this.geometry,o=this.matrixWorld,c=e.params.Points.threshold,u=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),gu.copy(a.boundingSphere),gu.applyMatrix4(o),gu.radius+=c,e.ray.intersectsSphere(gu)===!1)return;Fv.copy(o).invert(),Lp.copy(e.ray).applyMatrix4(Fv);const h=c/((this.scale.x+this.scale.y+this.scale.z)/3),p=h*h,d=a.index,_=a.attributes.position;if(d!==null){const v=Math.max(0,u.start),x=Math.min(d.count,u.start+u.count);for(let E=v,C=x;E<C;E++){const M=d.getX(E);_u.fromBufferAttribute(_,M),zv(_u,M,p,o,e,n,this)}}else{const v=Math.max(0,u.start),x=Math.min(_.count,u.start+u.count);for(let E=v,C=x;E<C;E++)_u.fromBufferAttribute(_,E),zv(_u,E,p,o,e,n,this)}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const o=n[a[0]];if(o!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,u=o.length;c<u;c++){const h=o[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[h]=c}}}}}function zv(r,e,n,a,o,c,u){const h=Lp.distanceSqToPoint(r);if(h<n){const p=new $;Lp.closestPointToPoint(r,p),p.applyMatrix4(a);const d=o.ray.origin.distanceTo(p);if(d<o.near||d>o.far)return;c.push({distance:d,distanceToRay:Math.sqrt(h),point:p,index:e,face:null,faceIndex:null,barycoord:null,object:u})}}class $x extends Un{constructor(e=[],n=ar,a,o,c,u,h,p,d,g){super(e,n,a,o,c,u,h,p,d,g),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class uo extends Un{constructor(e,n,a=ra,o,c,u,h=An,p=An,d,g=Ga,_=1){if(g!==Ga&&g!==nr)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const v={width:e,height:n,depth:_};super(v,o,c,u,h,p,g,a,d),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new jp(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const n=super.toJSON(e);return this.compareFunction!==null&&(n.compareFunction=this.compareFunction),n}}class ub extends uo{constructor(e,n=ra,a=ar,o,c,u=An,h=An,p,d=Ga){const g={width:e,height:e,depth:1},_=[g,g,g,g,g,g];super(e,e,n,a,o,c,u,h,p,d),this.image=_,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class ey extends Un{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class ho extends wi{constructor(e=1,n=1,a=1,o=1,c=1,u=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:n,depth:a,widthSegments:o,heightSegments:c,depthSegments:u};const h=this;o=Math.floor(o),c=Math.floor(c),u=Math.floor(u);const p=[],d=[],g=[],_=[];let v=0,x=0;E("z","y","x",-1,-1,a,n,e,u,c,0),E("z","y","x",1,-1,a,n,-e,u,c,1),E("x","z","y",1,1,e,a,n,o,u,2),E("x","z","y",1,-1,e,a,-n,o,u,3),E("x","y","z",1,-1,e,n,a,o,c,4),E("x","y","z",-1,-1,e,n,-a,o,c,5),this.setIndex(p),this.setAttribute("position",new Gi(d,3)),this.setAttribute("normal",new Gi(g,3)),this.setAttribute("uv",new Gi(_,2));function E(C,M,S,B,F,w,P,U,N,T,O){const X=w/N,G=P/T,Z=w/2,ce=P/2,ge=U/2,j=N+1,I=T+1;let z=0,Q=0;const de=new $;for(let ve=0;ve<I;ve++){const D=ve*G-ce;for(let Y=0;Y<j;Y++){const Ee=Y*X-Z;de[C]=Ee*B,de[M]=D*F,de[S]=ge,d.push(de.x,de.y,de.z),de[C]=0,de[M]=0,de[S]=U>0?1:-1,g.push(de.x,de.y,de.z),_.push(Y/N),_.push(1-ve/T),z+=1}}for(let ve=0;ve<T;ve++)for(let D=0;D<N;D++){const Y=v+D+j*ve,Ee=v+D+j*(ve+1),Re=v+(D+1)+j*(ve+1),Pe=v+(D+1)+j*ve;p.push(Y,Ee,Pe),p.push(Ee,Re,Pe),Q+=6}h.addGroup(x,Q,O),x+=Q,v+=z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ho(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Xu extends wi{constructor(e=1,n=1,a=1,o=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:n,widthSegments:a,heightSegments:o};const c=e/2,u=n/2,h=Math.floor(a),p=Math.floor(o),d=h+1,g=p+1,_=e/h,v=n/p,x=[],E=[],C=[],M=[];for(let S=0;S<g;S++){const B=S*v-u;for(let F=0;F<d;F++){const w=F*_-c;E.push(w,-B,0),C.push(0,0,1),M.push(F/h),M.push(1-S/p)}}for(let S=0;S<p;S++)for(let B=0;B<h;B++){const F=B+d*S,w=B+d*(S+1),P=B+1+d*(S+1),U=B+1+d*S;x.push(F,w,U),x.push(w,P,U)}this.setIndex(x),this.setAttribute("position",new Gi(E,3)),this.setAttribute("normal",new Gi(C,3)),this.setAttribute("uv",new Gi(M,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Xu(e.width,e.height,e.widthSegments,e.heightSegments)}}function fo(r){const e={};for(const n in r){e[n]={};for(const a in r[n]){const o=r[n][a];if(Hv(o))o.isRenderTargetTexture?(Ke("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[n][a]=null):e[n][a]=o.clone();else if(Array.isArray(o))if(Hv(o[0])){const c=[];for(let u=0,h=o.length;u<h;u++)c[u]=o[u].clone();e[n][a]=c}else e[n][a]=o.slice();else e[n][a]=o}}return e}function Wn(r){const e={};for(let n=0;n<r.length;n++){const a=fo(r[n]);for(const o in a)e[o]=a[o]}return e}function Hv(r){return r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)}function fb(r){const e=[];for(let n=0;n<r.length;n++)e.push(r[n].clone());return e}function ty(r){const e=r.getRenderTarget();return e===null?r.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:St.workingColorSpace}const hb={clone:fo,merge:Wn};var db=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,pb=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class oa extends Vi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=db,this.fragmentShader=pb,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=fo(e.uniforms),this.uniformsGroups=fb(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const n=super.toJSON(e);n.glslVersion=this.glslVersion,n.uniforms={};for(const o in this.uniforms){const u=this.uniforms[o].value;u&&u.isTexture?n.uniforms[o]={type:"t",value:u.toJSON(e).uuid}:u&&u.isColor?n.uniforms[o]={type:"c",value:u.getHex()}:u&&u.isVector2?n.uniforms[o]={type:"v2",value:u.toArray()}:u&&u.isVector3?n.uniforms[o]={type:"v3",value:u.toArray()}:u&&u.isVector4?n.uniforms[o]={type:"v4",value:u.toArray()}:u&&u.isMatrix3?n.uniforms[o]={type:"m3",value:u.toArray()}:u&&u.isMatrix4?n.uniforms[o]={type:"m4",value:u.toArray()}:n.uniforms[o]={value:u}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const a={};for(const o in this.extensions)this.extensions[o]===!0&&(a[o]=!0);return Object.keys(a).length>0&&(n.extensions=a),n}fromJSON(e,n){if(super.fromJSON(e,n),e.uniforms!==void 0)for(const a in e.uniforms){const o=e.uniforms[a];switch(this.uniforms[a]={},o.type){case"t":this.uniforms[a].value=n[o.value]||null;break;case"c":this.uniforms[a].value=new st().setHex(o.value);break;case"v2":this.uniforms[a].value=new gt().fromArray(o.value);break;case"v3":this.uniforms[a].value=new $().fromArray(o.value);break;case"v4":this.uniforms[a].value=new Yt().fromArray(o.value);break;case"m3":this.uniforms[a].value=new lt().fromArray(o.value);break;case"m4":this.uniforms[a].value=new dt().fromArray(o.value);break;default:this.uniforms[a].value=o.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const a in e.extensions)this.extensions[a]=e.extensions[a];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class mb extends oa{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Ol extends Vi{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new st(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new st(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Pu,this.normalScale=new gt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Va,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class ca extends Ol{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new gt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Mt(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(n){this.ior=(1+.4*n)/(1-.4*n)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new st(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new st(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new st(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class gb extends Vi{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new st(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new st(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Pu,this.normalScale=new gt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Va,this.combine=Hp,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class _b extends Vi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=sE,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class vb extends Vi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function vu(r,e){return!r||r.constructor===e?r:typeof e.BYTES_PER_ELEMENT=="number"?new e(r):Array.prototype.slice.call(r)}function xb(r){function e(o,c){return r[o]-r[c]}const n=r.length,a=new Array(n);for(let o=0;o!==n;++o)a[o]=o;return a.sort(e),a}function Gv(r,e,n){const a=r.length,o=new r.constructor(a);for(let c=0,u=0;u!==a;++c){const h=n[c]*e;for(let p=0;p!==e;++p)o[u++]=r[h+p]}return o}function yb(r,e,n,a){let o=1,c=r[0];for(;c!==void 0&&c[a]===void 0;)c=r[o++];if(c===void 0)return;let u=c[a];if(u!==void 0)if(Array.isArray(u))do u=c[a],u!==void 0&&(e.push(c.time),n.push(...u)),c=r[o++];while(c!==void 0);else if(u.toArray!==void 0)do u=c[a],u!==void 0&&(e.push(c.time),u.toArray(n,n.length)),c=r[o++];while(c!==void 0);else do u=c[a],u!==void 0&&(e.push(c.time),n.push(u)),c=r[o++];while(c!==void 0)}class po{constructor(e,n,a,o){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=o!==void 0?o:new n.constructor(a),this.sampleValues=n,this.valueSize=a,this.settings=null,this.DefaultSettings_={}}evaluate(e){const n=this.parameterPositions;let a=this._cachedIndex,o=n[a],c=n[a-1];e:{t:{let u;n:{i:if(!(e<o)){for(let h=a+2;;){if(o===void 0){if(e<c)break i;return a=n.length,this._cachedIndex=a,this.copySampleValue_(a-1)}if(a===h)break;if(c=o,o=n[++a],e<o)break t}u=n.length;break n}if(!(e>=c)){const h=n[1];e<h&&(a=2,c=h);for(let p=a-2;;){if(c===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(a===p)break;if(o=c,c=n[--a-1],e>=c)break t}u=a,a=0;break n}break e}for(;a<u;){const h=a+u>>>1;e<n[h]?u=h:a=h+1}if(o=n[a],c=n[a-1],c===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(o===void 0)return a=n.length,this._cachedIndex=a,this.copySampleValue_(a-1)}this._cachedIndex=a,this.intervalChanged_(a,c,o)}return this.interpolate_(a,c,e,o)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const n=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o;for(let u=0;u!==o;++u)n[u]=a[c+u];return n}interpolate_(){throw new Error("THREE.Interpolant: Call to abstract method.")}intervalChanged_(){}}class Sb extends po{constructor(e,n,a,o){super(e,n,a,o),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:rv,endingEnd:rv}}intervalChanged_(e,n,a){const o=this.parameterPositions;let c=e-2,u=e+1,h=o[c],p=o[u];if(h===void 0)switch(this.getSettings_().endingStart){case ov:c=e,h=2*n-a;break;case lv:c=o.length-2,h=n+o[c]-o[c+1];break;default:c=e,h=a}if(p===void 0)switch(this.getSettings_().endingEnd){case ov:u=e,p=2*a-n;break;case lv:u=1,p=a+o[1]-o[0];break;default:u=e-1,p=n}const d=(a-n)*.5,g=this.valueSize;this._weightPrev=d/(n-h),this._weightNext=d/(p-a),this._offsetPrev=c*g,this._offsetNext=u*g}interpolate_(e,n,a,o){const c=this.resultBuffer,u=this.sampleValues,h=this.valueSize,p=e*h,d=p-h,g=this._offsetPrev,_=this._offsetNext,v=this._weightPrev,x=this._weightNext,E=(a-n)/(o-n),C=E*E,M=C*E,S=-v*M+2*v*C-v*E,B=(1+v)*M+(-1.5-2*v)*C+(-.5+v)*E+1,F=(-1-x)*M+(1.5+x)*C+.5*E,w=x*M-x*C;for(let P=0;P!==h;++P)c[P]=S*u[g+P]+B*u[d+P]+F*u[p+P]+w*u[_+P];return c}}class Mb extends po{constructor(e,n,a,o){super(e,n,a,o)}interpolate_(e,n,a,o){const c=this.resultBuffer,u=this.sampleValues,h=this.valueSize,p=e*h,d=p-h,g=(a-n)/(o-n),_=1-g;for(let v=0;v!==h;++v)c[v]=u[d+v]*_+u[p+v]*g;return c}}class Eb extends po{constructor(e,n,a,o){super(e,n,a,o)}interpolate_(e){return this.copySampleValue_(e-1)}}class bb extends po{interpolate_(e,n,a,o){const c=this.resultBuffer,u=this.sampleValues,h=this.valueSize,p=e*h,d=p-h,g=this.inTangents,_=this.outTangents;if(!g||!_){const E=(a-n)/(o-n),C=1-E;for(let M=0;M!==h;++M)c[M]=u[d+M]*C+u[p+M]*E;return c}const v=h*2,x=e-1;for(let E=0;E!==h;++E){const C=u[d+E],M=u[p+E],S=x*v+E*2,B=_[S],F=_[S+1],w=e*v+E*2,P=g[w],U=g[w+1];let N=(a-n)/(o-n),T,O,X,G,Z;for(let ce=0;ce<8;ce++){T=N*N,O=T*N,X=1-N,G=X*X,Z=G*X;const j=Z*n+3*G*N*B+3*X*T*P+O*o-a;if(Math.abs(j)<1e-10)break;const I=3*G*(B-n)+6*X*N*(P-B)+3*T*(o-P);if(Math.abs(I)<1e-10)break;N=N-j/I,N=Math.max(0,Math.min(1,N))}c[E]=Z*C+3*G*N*F+3*X*T*U+O*M}return c}}class Xi{constructor(e,n,a,o){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(n===void 0||n.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=vu(n,this.TimeBufferType),this.values=vu(a,this.ValueBufferType),this.setInterpolation(o||this.DefaultInterpolation)}static toJSON(e){const n=e.constructor;let a;if(n.toJSON!==this.toJSON)a=n.toJSON(e);else{a={name:e.name,times:vu(e.times,Array),values:vu(e.values,Array)};const o=e.getInterpolation();o!==e.DefaultInterpolation&&(a.interpolation=o)}return a.type=e.ValueTypeName,a}InterpolantFactoryMethodDiscrete(e){return new Eb(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Mb(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Sb(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){const n=new bb(this.times,this.values,this.getValueSize(),e);return this.settings&&(n.inTangents=this.settings.inTangents,n.outTangents=this.settings.outTangents),n}setInterpolation(e){let n;switch(e){case Dl:n=this.InterpolantFactoryMethodDiscrete;break;case Ll:n=this.InterpolantFactoryMethodLinear;break;case rd:n=this.InterpolantFactoryMethodSmooth;break;case sv:n=this.InterpolantFactoryMethodBezier;break}if(n===void 0){const a="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(a);return Ke("KeyframeTrack:",a),this}return this.createInterpolant=n,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Dl;case this.InterpolantFactoryMethodLinear:return Ll;case this.InterpolantFactoryMethodSmooth:return rd;case this.InterpolantFactoryMethodBezier:return sv}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const n=this.times;for(let a=0,o=n.length;a!==o;++a)n[a]+=e}return this}scale(e){if(e!==1){const n=this.times;for(let a=0,o=n.length;a!==o;++a)n[a]*=e}return this}trim(e,n){const a=this.times,o=a.length;let c=0,u=o-1;for(;c!==o&&a[c]<e;)++c;for(;u!==-1&&a[u]>n;)--u;if(++u,c!==0||u!==o){c>=u&&(u=Math.max(u,1),c=u-1);const h=this.getValueSize();this.times=a.slice(c,u),this.values=this.values.slice(c*h,u*h)}return this}validate(){let e=!0;const n=this.getValueSize();n-Math.floor(n)!==0&&(at("KeyframeTrack: Invalid value size in track.",this),e=!1);const a=this.times,o=this.values,c=a.length;c===0&&(at("KeyframeTrack: Track is empty.",this),e=!1);let u=null;for(let h=0;h!==c;h++){const p=a[h];if(typeof p=="number"&&isNaN(p)){at("KeyframeTrack: Time is not a valid number.",this,h,p),e=!1;break}if(u!==null&&u>p){at("KeyframeTrack: Out of order keys.",this,h,p,u),e=!1;break}u=p}if(o!==void 0&&pE(o))for(let h=0,p=o.length;h!==p;++h){const d=o[h];if(isNaN(d)){at("KeyframeTrack: Value is not a valid number.",this,h,d),e=!1;break}}return e}optimize(){const e=this.times.slice(),n=this.values.slice(),a=this.getValueSize(),o=this.getInterpolation()===rd,c=e.length-1;let u=1;for(let h=1;h<c;++h){let p=!1;const d=e[h],g=e[h+1];if(d!==g&&(h!==1||d!==e[0]))if(o)p=!0;else{const _=h*a,v=_-a,x=_+a;for(let E=0;E!==a;++E){const C=n[_+E];if(C!==n[v+E]||C!==n[x+E]){p=!0;break}}}if(p){if(h!==u){e[u]=e[h];const _=h*a,v=u*a;for(let x=0;x!==a;++x)n[v+x]=n[_+x]}++u}}if(c>0){e[u]=e[c];for(let h=c*a,p=u*a,d=0;d!==a;++d)n[p+d]=n[h+d];++u}return u!==e.length?(this.times=e.slice(0,u),this.values=n.slice(0,u*a)):(this.times=e,this.values=n),this}clone(){const e=this.times.slice(),n=this.values.slice(),a=this.constructor,o=new a(this.name,e,n);return o.createInterpolant=this.createInterpolant,o}}Xi.prototype.ValueTypeName="";Xi.prototype.TimeBufferType=Float32Array;Xi.prototype.ValueBufferType=Float32Array;Xi.prototype.DefaultInterpolation=Ll;class mo extends Xi{constructor(e,n,a){super(e,n,a)}}mo.prototype.ValueTypeName="bool";mo.prototype.ValueBufferType=Array;mo.prototype.DefaultInterpolation=Dl;mo.prototype.InterpolantFactoryMethodLinear=void 0;mo.prototype.InterpolantFactoryMethodSmooth=void 0;class ny extends Xi{constructor(e,n,a,o){super(e,n,a,o)}}ny.prototype.ValueTypeName="color";class Pl extends Xi{constructor(e,n,a,o){super(e,n,a,o)}}Pl.prototype.ValueTypeName="number";class Tb extends po{constructor(e,n,a,o){super(e,n,a,o)}interpolate_(e,n,a,o){const c=this.resultBuffer,u=this.sampleValues,h=this.valueSize,p=(a-n)/(o-n);let d=e*h;for(let g=d+h;d!==g;d+=4)ka.slerpFlat(c,0,u,d-h,u,d,p);return c}}class Il extends Xi{constructor(e,n,a,o){super(e,n,a,o)}InterpolantFactoryMethodLinear(e){return new Tb(this.times,this.values,this.getValueSize(),e)}}Il.prototype.ValueTypeName="quaternion";Il.prototype.InterpolantFactoryMethodSmooth=void 0;class go extends Xi{constructor(e,n,a){super(e,n,a)}}go.prototype.ValueTypeName="string";go.prototype.ValueBufferType=Array;go.prototype.DefaultInterpolation=Dl;go.prototype.InterpolantFactoryMethodLinear=void 0;go.prototype.InterpolantFactoryMethodSmooth=void 0;class Hu extends Xi{constructor(e,n,a,o){super(e,n,a,o)}}Hu.prototype.ValueTypeName="vector";class Ab{constructor(e="",n=-1,a=[],o=iE){this.name=e,this.tracks=a,this.duration=n,this.blendMode=o,this.uuid=Hi(),this.userData={},this.duration<0&&this.resetDuration()}static parse(e){const n=[],a=e.tracks,o=1/(e.fps||1);for(let u=0,h=a.length;u!==h;++u)n.push(Cb(a[u]).scale(o));const c=new this(e.name,e.duration,n,e.blendMode);return c.uuid=e.uuid,c.userData=JSON.parse(e.userData||"{}"),c}static toJSON(e){const n=[],a=e.tracks,o={name:e.name,duration:e.duration,tracks:n,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let c=0,u=a.length;c!==u;++c)n.push(Xi.toJSON(a[c]));return o}static CreateFromMorphTargetSequence(e,n,a,o){const c=n.length,u=[];for(let h=0;h<c;h++){let p=[],d=[];p.push((h+c-1)%c,h,(h+1)%c),d.push(0,1,0);const g=xb(p);p=Gv(p,1,g),d=Gv(d,1,g),!o&&p[0]===0&&(p.push(c),d.push(d[0])),u.push(new Pl(".morphTargetInfluences["+n[h].name+"]",p,d).scale(1/a))}return new this(e,-1,u)}static findByName(e,n){let a=e;if(!Array.isArray(e)){const o=e;a=o.geometry&&o.geometry.animations||o.animations}for(let o=0;o<a.length;o++)if(a[o].name===n)return a[o];return null}static CreateClipsFromMorphTargetSequences(e,n,a){const o={},c=/^([\w-]*?)([\d]+)$/;for(let h=0,p=e.length;h<p;h++){const d=e[h],g=d.name.match(c);if(g&&g.length>1){const _=g[1];let v=o[_];v||(o[_]=v=[]),v.push(d)}}const u=[];for(const h in o)u.push(this.CreateFromMorphTargetSequence(h,o[h],n,a));return u}resetDuration(){const e=this.tracks;let n=0;for(let a=0,o=e.length;a!==o;++a){const c=this.tracks[a];n=Math.max(n,c.times[c.times.length-1])}return this.duration=n,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let n=0;n<this.tracks.length;n++)e=e&&this.tracks[n].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let a=0;a<this.tracks.length;a++)e.push(this.tracks[a].clone());const n=new this.constructor(this.name,this.duration,e,this.blendMode);return n.userData=JSON.parse(JSON.stringify(this.userData)),n}toJSON(){return this.constructor.toJSON(this)}}function Rb(r){switch(r.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Pl;case"vector":case"vector2":case"vector3":case"vector4":return Hu;case"color":return ny;case"quaternion":return Il;case"bool":case"boolean":return mo;case"string":return go}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+r)}function Cb(r){if(r.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=Rb(r.type);if(r.times===void 0){const n=[],a=[];yb(r.keys,n,a,"value"),r.times=n,r.values=a}return e.parse!==void 0?e.parse(r):new e(r.name,r.times,r.values,r.interpolation)}const Ia={enabled:!1,files:{},add:function(r,e){this.enabled!==!1&&(Vv(r)||(this.files[r]=e))},get:function(r){if(this.enabled!==!1&&!Vv(r))return this.files[r]},remove:function(r){delete this.files[r]},clear:function(){this.files={}}};function Vv(r){try{const e=r.slice(r.indexOf(":")+1);return new URL(e).protocol==="blob:"}catch{return!1}}class wb{constructor(e,n,a){const o=this;let c=!1,u=0,h=0,p;const d=[];this.onStart=void 0,this.onLoad=e,this.onProgress=n,this.onError=a,this._abortController=null,this.itemStart=function(g){h++,c===!1&&o.onStart!==void 0&&o.onStart(g,u,h),c=!0},this.itemEnd=function(g){u++,o.onProgress!==void 0&&o.onProgress(g,u,h),u===h&&(c=!1,o.onLoad!==void 0&&o.onLoad())},this.itemError=function(g){o.onError!==void 0&&o.onError(g)},this.resolveURL=function(g){return g=g.normalize("NFC"),p?p(g):g},this.setURLModifier=function(g){return p=g,this},this.addHandler=function(g,_){return d.push(g,_),this},this.removeHandler=function(g){const _=d.indexOf(g);return _!==-1&&d.splice(_,2),this},this.getHandler=function(g){for(let _=0,v=d.length;_<v;_+=2){const x=d[_],E=d[_+1];if(x.global&&(x.lastIndex=0),x.test(g))return E}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}}const Db=new wb;class _o{constructor(e){this.manager=e!==void 0?e:Db,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(e,n){const a=this;return new Promise(function(o,c){a.load(e,o,n,c)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}_o.DEFAULT_MATERIAL_NAME="__DEFAULT";const Oa={};class Lb extends Error{constructor(e,n){super(e),this.response=n}}class iy extends _o{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,n,a,o){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const c=Ia.get(`file:${e}`);if(c!==void 0){this.manager.itemStart(e),setTimeout(()=>{n&&n(c),this.manager.itemEnd(e)},0);return}if(Oa[e]!==void 0){Oa[e].push({onLoad:n,onProgress:a,onError:o});return}Oa[e]=[],Oa[e].push({onLoad:n,onProgress:a,onError:o});const u=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),h=this.mimeType,p=this.responseType;fetch(u).then(d=>{if(d.status===200||d.status===0){if(d.status===0&&Ke("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||d.body===void 0||d.body.getReader===void 0)return d;const g=Oa[e],_=d.body.getReader(),v=d.headers.get("X-File-Size")||d.headers.get("Content-Length"),x=v?parseInt(v):0,E=x!==0;let C=0;const M=new ReadableStream({start(S){B();function B(){_.read().then(({done:F,value:w})=>{if(F)S.close();else{C+=w.byteLength;const P=new ProgressEvent("progress",{lengthComputable:E,loaded:C,total:x});for(let U=0,N=g.length;U<N;U++){const T=g[U];T.onProgress&&T.onProgress(P)}S.enqueue(w),B()}},F=>{S.error(F)})}}});return new Response(M)}else throw new Lb(`fetch for "${d.url}" responded with ${d.status}: ${d.statusText}`,d)}).then(d=>{switch(p){case"arraybuffer":return d.arrayBuffer();case"blob":return d.blob();case"document":return d.text().then(g=>new DOMParser().parseFromString(g,h));case"json":return d.json();default:if(h==="")return d.text();{const _=/charset="?([^;"\s]*)"?/i.exec(h),v=_&&_[1]?_[1].toLowerCase():void 0,x=new TextDecoder(v);return d.arrayBuffer().then(E=>x.decode(E))}}}).then(d=>{Ia.add(`file:${e}`,d);const g=Oa[e];delete Oa[e];for(let _=0,v=g.length;_<v;_++){const x=g[_];x.onLoad&&x.onLoad(d)}}).catch(d=>{const g=Oa[e];if(g===void 0)throw this.manager.itemError(e),d;delete Oa[e];for(let _=0,v=g.length;_<v;_++){const x=g[_];x.onError&&x.onError(d)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}const Jr=new WeakMap;class Nb extends _o{constructor(e){super(e)}load(e,n,a,o){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const c=this,u=Ia.get(`image:${e}`);if(u!==void 0){if(u.complete===!0)c.manager.itemStart(e),setTimeout(function(){n&&n(u),c.manager.itemEnd(e)},0);else{let _=Jr.get(u);_===void 0&&(_=[],Jr.set(u,_)),_.push({onLoad:n,onError:o})}return u}const h=Ul("img");function p(){g(),n&&n(this);const _=Jr.get(this)||[];for(let v=0;v<_.length;v++){const x=_[v];x.onLoad&&x.onLoad(this)}Jr.delete(this),c.manager.itemEnd(e)}function d(_){g(),o&&o(_),Ia.remove(`image:${e}`);const v=Jr.get(this)||[];for(let x=0;x<v.length;x++){const E=v[x];E.onError&&E.onError(_)}Jr.delete(this),c.manager.itemError(e),c.manager.itemEnd(e)}function g(){h.removeEventListener("load",p,!1),h.removeEventListener("error",d,!1)}return h.addEventListener("load",p,!1),h.addEventListener("error",d,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(h.crossOrigin=this.crossOrigin),Ia.add(`image:${e}`,h),c.manager.itemStart(e),h.src=e,h}}class Ub extends _o{constructor(e){super(e)}load(e,n,a,o){const c=new Un,u=new Nb(this.manager);return u.setCrossOrigin(this.crossOrigin),u.setPath(this.path),u.load(e,function(h){c.image=h,c.needsUpdate=!0,n!==void 0&&n(c)},a,o),c}}class Wu extends en{constructor(e,n=1){super(),this.isLight=!0,this.type="Light",this.color=new st(e),this.intensity=n}dispose(){this.dispatchEvent({type:"dispose"})}copy(e,n){return super.copy(e,n),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const n=super.toJSON(e);return n.object.color=this.color.getHex(),n.object.intensity=this.intensity,n}}class Ob extends Wu{constructor(e,n,a){super(e,a),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(en.DEFAULT_UP),this.updateMatrix(),this.groundColor=new st(n)}copy(e,n){return super.copy(e,n),this.groundColor.copy(e.groundColor),this}toJSON(e){const n=super.toJSON(e);return n.object.groundColor=this.groundColor.getHex(),n}}const Nd=new dt,kv=new $,Xv=new $;class am{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new gt(512,512),this.mapType=mi,this.map=null,this.mapPass=null,this.matrix=new dt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new nm,this._frameExtents=new gt(1,1),this._viewportCount=1,this._viewports=[new Yt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const n=this.camera,a=this.matrix;kv.setFromMatrixPosition(e.matrixWorld),n.position.copy(kv),Xv.setFromMatrixPosition(e.target.matrixWorld),n.lookAt(Xv),n.updateMatrixWorld(),Nd.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Nd,n.coordinateSystem,n.reversedDepth),n.coordinateSystem===Nl||n.reversedDepth?a.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):a.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),a.multiply(Nd)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const xu=new $,yu=new ka,Ji=new $;class ay extends en{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new dt,this.projectionMatrix=new dt,this.projectionMatrixInverse=new dt,this.coordinateSystem=ia,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,n){return super.copy(e,n),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(xu,yu,Ji),Ji.x===1&&Ji.y===1&&Ji.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(xu,yu,Ji.set(1,1,1)).invert()}updateWorldMatrix(e,n,a=!1){super.updateWorldMatrix(e,n,a),this.matrixWorld.decompose(xu,yu,Ji),Ji.x===1&&Ji.y===1&&Ji.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(xu,yu,Ji.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Ms=new $,Wv=new gt,qv=new gt;class ti extends ay{constructor(e=50,n=1,a=.1,o=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=a,this.far=o,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const n=.5*this.getFilmHeight()/e;this.fov=co*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Tl*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return co*2*Math.atan(Math.tan(Tl*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,n,a){Ms.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Ms.x,Ms.y).multiplyScalar(-e/Ms.z),Ms.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(Ms.x,Ms.y).multiplyScalar(-e/Ms.z)}getViewSize(e,n){return this.getViewBounds(e,Wv,qv),n.subVectors(qv,Wv)}setViewOffset(e,n,a,o,c,u){this.aspect=e/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=o,this.view.width=c,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let n=e*Math.tan(Tl*.5*this.fov)/this.zoom,a=2*n,o=this.aspect*a,c=-.5*o;const u=this.view;if(this.view!==null&&this.view.enabled){const p=u.fullWidth,d=u.fullHeight;c+=u.offsetX*o/p,n-=u.offsetY*a/d,o*=u.width/p,a*=u.height/d}const h=this.filmOffset;h!==0&&(c+=e*h/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+o,n,n-a,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}class Pb extends am{constructor(){super(new ti(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){const n=this.camera,a=co*2*e.angle*this.focus,o=this.mapSize.width/this.mapSize.height*this.aspect,c=e.distance||n.far;(a!==n.fov||o!==n.aspect||c!==n.far)&&(n.fov=a,n.aspect=o,n.far=c,n.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class Ib extends Wu{constructor(e,n,a=0,o=Math.PI/3,c=0,u=2){super(e,n),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(en.DEFAULT_UP),this.updateMatrix(),this.target=new en,this.distance=a,this.angle=o,this.penumbra=c,this.decay=u,this.map=null,this.shadow=new Pb}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){super.dispose(),this.shadow.dispose()}copy(e,n){return super.copy(e,n),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.map=e.map,this.shadow=e.shadow.clone(),this}toJSON(e){const n=super.toJSON(e);return n.object.distance=this.distance,n.object.angle=this.angle,n.object.decay=this.decay,n.object.penumbra=this.penumbra,n.object.target=this.target.uuid,this.map&&this.map.isTexture&&(n.object.map=this.map.toJSON(e).uuid),n.object.shadow=this.shadow.toJSON(),n}}class Bb extends am{constructor(){super(new ti(90,1,.5,500)),this.isPointLightShadow=!0}}class sy extends Wu{constructor(e,n,a=0,o=2){super(e,n),this.isPointLight=!0,this.type="PointLight",this.distance=a,this.decay=o,this.shadow=new Bb}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,n){return super.copy(e,n),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){const n=super.toJSON(e);return n.object.distance=this.distance,n.object.decay=this.decay,n.object.shadow=this.shadow.toJSON(),n}}class Bl extends ay{constructor(e=-1,n=1,a=1,o=-1,c=.1,u=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=n,this.top=a,this.bottom=o,this.near=c,this.far=u,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,n,a,o,c,u){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=o,this.view.width=c,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),a=(this.right+this.left)/2,o=(this.top+this.bottom)/2;let c=a-e,u=a+e,h=o+n,p=o-n;if(this.view!==null&&this.view.enabled){const d=(this.right-this.left)/this.view.fullWidth/this.zoom,g=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=d*this.view.offsetX,u=c+d*this.view.width,h-=g*this.view.offsetY,p=h-g*this.view.height}this.projectionMatrix.makeOrthographic(c,u,h,p,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}class Fb extends am{constructor(){super(new Bl(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Du extends Wu{constructor(e,n){super(e,n),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(en.DEFAULT_UP),this.updateMatrix(),this.target=new en,this.shadow=new Fb}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const n=super.toJSON(e);return n.object.shadow=this.shadow.toJSON(),n.object.target=this.target.uuid,n}}class Rl{static extractUrlBase(e){const n=e.lastIndexOf("/");return n===-1?"./":e.slice(0,n+1)}static resolveURL(e,n){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(n)&&/^\//.test(e)&&(n=n.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:n+e)}}const Ud=new WeakMap;class zb extends _o{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&Ke("ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&Ke("ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,n,a,o){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const c=this,u=Ia.get(`image-bitmap:${e}`);if(u!==void 0){if(c.manager.itemStart(e),u.then){u.then(d=>{Ud.has(u)===!0?(o&&o(Ud.get(u)),c.manager.itemError(e),c.manager.itemEnd(e)):(n&&n(d),c.manager.itemEnd(e))});return}setTimeout(function(){n&&n(u),c.manager.itemEnd(e)},0);return}const h={};h.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",h.headers=this.requestHeader,h.signal=typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;const p=fetch(e,h).then(function(d){return d.blob()}).then(function(d){return createImageBitmap(d,Object.assign(c.options,{colorSpaceConversion:"none"}))}).then(function(d){Ia.add(`image-bitmap:${e}`,d),n&&n(d),c.manager.itemEnd(e)}).catch(function(d){o&&o(d),Ud.set(p,d),Ia.remove(`image-bitmap:${e}`),c.manager.itemError(e),c.manager.itemEnd(e)});Ia.add(`image-bitmap:${e}`,p),c.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}const jr=-90,$r=1;class Hb extends en{constructor(e,n,a){super(),this.type="CubeCamera",this.renderTarget=a,this.coordinateSystem=null,this.activeMipmapLevel=0;const o=new ti(jr,$r,e,n);o.layers=this.layers,this.add(o);const c=new ti(jr,$r,e,n);c.layers=this.layers,this.add(c);const u=new ti(jr,$r,e,n);u.layers=this.layers,this.add(u);const h=new ti(jr,$r,e,n);h.layers=this.layers,this.add(h);const p=new ti(jr,$r,e,n);p.layers=this.layers,this.add(p);const d=new ti(jr,$r,e,n);d.layers=this.layers,this.add(d)}updateCoordinateSystem(){const e=this.coordinateSystem,n=this.children.concat(),[a,o,c,u,h,p]=n;for(const d of n)this.remove(d);if(e===ia)a.up.set(0,1,0),a.lookAt(1,0,0),o.up.set(0,1,0),o.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),u.up.set(0,0,1),u.lookAt(0,-1,0),h.up.set(0,1,0),h.lookAt(0,0,1),p.up.set(0,1,0),p.lookAt(0,0,-1);else if(e===Nl)a.up.set(0,-1,0),a.lookAt(-1,0,0),o.up.set(0,-1,0),o.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),u.up.set(0,0,-1),u.lookAt(0,-1,0),h.up.set(0,-1,0),h.lookAt(0,0,1),p.up.set(0,-1,0),p.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const d of n)this.add(d),d.updateMatrixWorld()}update(e,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:a,activeMipmapLevel:o}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[c,u,h,p,d,g]=this.children,_=e.getRenderTarget(),v=e.getActiveCubeFace(),x=e.getActiveMipmapLevel(),E=e.xr.enabled;e.xr.enabled=!1;const C=a.texture.generateMipmaps;a.texture.generateMipmaps=!1;let M=!1;e.isWebGLRenderer===!0?M=e.state.buffers.depth.getReversed():M=e.reversedDepthBuffer,e.setRenderTarget(a,0,o),M&&e.autoClear===!1&&e.clearDepth(),e.render(n,c),e.setRenderTarget(a,1,o),M&&e.autoClear===!1&&e.clearDepth(),e.render(n,u),e.setRenderTarget(a,2,o),M&&e.autoClear===!1&&e.clearDepth(),e.render(n,h),e.setRenderTarget(a,3,o),M&&e.autoClear===!1&&e.clearDepth(),e.render(n,p),e.setRenderTarget(a,4,o),M&&e.autoClear===!1&&e.clearDepth(),e.render(n,d),a.texture.generateMipmaps=C,e.setRenderTarget(a,5,o),M&&e.autoClear===!1&&e.clearDepth(),e.render(n,g),e.setRenderTarget(_,v,x),e.xr.enabled=E,a.texture.needsPMREMUpdate=!0}}class Gb extends ti{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const sm="\\[\\]\\.:\\/",Vb=new RegExp("["+sm+"]","g"),rm="[^"+sm+"]",kb="[^"+sm.replace("\\.","")+"]",Xb=/((?:WC+[\/:])*)/.source.replace("WC",rm),Wb=/(WCOD+)?/.source.replace("WCOD",kb),qb=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",rm),Yb=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",rm),Kb=new RegExp("^"+Xb+Wb+qb+Yb+"$"),Zb=["material","materials","bones","map"];class Qb{constructor(e,n,a){const o=a||Vt.parseTrackName(n);this._targetGroup=e,this._bindings=e.subscribe_(n,o)}getValue(e,n){this.bind();const a=this._targetGroup.nCachedObjects_,o=this._bindings[a];o!==void 0&&o.getValue(e,n)}setValue(e,n){const a=this._bindings;for(let o=this._targetGroup.nCachedObjects_,c=a.length;o!==c;++o)a[o].setValue(e,n)}bind(){const e=this._bindings;for(let n=this._targetGroup.nCachedObjects_,a=e.length;n!==a;++n)e[n].bind()}unbind(){const e=this._bindings;for(let n=this._targetGroup.nCachedObjects_,a=e.length;n!==a;++n)e[n].unbind()}}class Vt{constructor(e,n,a){this.path=n,this.parsedPath=a||Vt.parseTrackName(n),this.node=Vt.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,n,a){return e&&e.isAnimationObjectGroup?new Vt.Composite(e,n,a):new Vt(e,n,a)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Vb,"")}static parseTrackName(e){const n=Kb.exec(e);if(n===null)throw new Error("THREE.PropertyBinding: Cannot parse trackName: "+e);const a={nodeName:n[2],objectName:n[3],objectIndex:n[4],propertyName:n[5],propertyIndex:n[6]},o=a.nodeName&&a.nodeName.lastIndexOf(".");if(o!==void 0&&o!==-1){const c=a.nodeName.substring(o+1);Zb.indexOf(c)!==-1&&(a.nodeName=a.nodeName.substring(0,o),a.objectName=c)}if(a.propertyName===null||a.propertyName.length===0)throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: "+e);return a}static findNode(e,n){if(n===void 0||n===""||n==="."||n===-1||n===e.name||n===e.uuid)return e;if(e.skeleton){const a=e.skeleton.getBoneByName(n);if(a!==void 0)return a}if(e.children){const a=function(c){for(let u=0;u<c.length;u++){const h=c[u];if(h.name===n||h.uuid===n)return h;const p=a(h.children);if(p)return p}return null},o=a(e.children);if(o)return o}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,n){e[n]=this.targetObject[this.propertyName]}_getValue_array(e,n){const a=this.resolvedProperty;for(let o=0,c=a.length;o!==c;++o)e[n++]=a[o]}_getValue_arrayElement(e,n){e[n]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,n){this.resolvedProperty.toArray(e,n)}_setValue_direct(e,n){this.targetObject[this.propertyName]=e[n]}_setValue_direct_setNeedsUpdate(e,n){this.targetObject[this.propertyName]=e[n],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,n){this.targetObject[this.propertyName]=e[n],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,n){const a=this.resolvedProperty;for(let o=0,c=a.length;o!==c;++o)a[o]=e[n++]}_setValue_array_setNeedsUpdate(e,n){const a=this.resolvedProperty;for(let o=0,c=a.length;o!==c;++o)a[o]=e[n++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,n){const a=this.resolvedProperty;for(let o=0,c=a.length;o!==c;++o)a[o]=e[n++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,n){this.resolvedProperty[this.propertyIndex]=e[n]}_setValue_arrayElement_setNeedsUpdate(e,n){this.resolvedProperty[this.propertyIndex]=e[n],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,n){this.resolvedProperty[this.propertyIndex]=e[n],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,n){this.resolvedProperty.fromArray(e,n)}_setValue_fromArray_setNeedsUpdate(e,n){this.resolvedProperty.fromArray(e,n),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,n){this.resolvedProperty.fromArray(e,n),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,n){this.bind(),this.getValue(e,n)}_setValue_unbound(e,n){this.bind(),this.setValue(e,n)}bind(){let e=this.node;const n=this.parsedPath,a=n.objectName,o=n.propertyName;let c=n.propertyIndex;if(e||(e=Vt.findNode(this.rootNode,n.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){Ke("PropertyBinding: No target node found for track: "+this.path+".");return}if(a){let d=n.objectIndex;switch(a){case"materials":if(!e.material){at("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){at("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){at("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let g=0;g<e.length;g++)if(e[g].name===d){d=g;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){at("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){at("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[a]===void 0){at("PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[a]}if(d!==void 0){if(e[d]===void 0){at("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[d]}}const u=e[o];if(u===void 0){const d=n.nodeName;at("PropertyBinding: Trying to update property for track: "+d+"."+o+" but it wasn't found.",e);return}let h=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?h=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(h=this.Versioning.MatrixWorldNeedsUpdate);let p=this.BindingType.Direct;if(c!==void 0){if(o==="morphTargetInfluences"){if(!e.geometry){at("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){at("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[c]!==void 0&&(c=e.morphTargetDictionary[c])}p=this.BindingType.ArrayElement,this.resolvedProperty=u,this.propertyIndex=c}else u.fromArray!==void 0&&u.toArray!==void 0?(p=this.BindingType.HasFromToArray,this.resolvedProperty=u):Array.isArray(u)?(p=this.BindingType.EntireArray,this.resolvedProperty=u):this.propertyName=o;this.getValue=this.GetterByBindingType[p],this.setValue=this.SetterByBindingTypeAndVersioning[p][h]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}Vt.Composite=Qb;Vt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Vt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Vt.prototype.GetterByBindingType=[Vt.prototype._getValue_direct,Vt.prototype._getValue_array,Vt.prototype._getValue_arrayElement,Vt.prototype._getValue_toArray];Vt.prototype.SetterByBindingTypeAndVersioning=[[Vt.prototype._setValue_direct,Vt.prototype._setValue_direct_setNeedsUpdate,Vt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Vt.prototype._setValue_array,Vt.prototype._setValue_array_setNeedsUpdate,Vt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Vt.prototype._setValue_arrayElement,Vt.prototype._setValue_arrayElement_setNeedsUpdate,Vt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Vt.prototype._setValue_fromArray,Vt.prototype._setValue_fromArray_setNeedsUpdate,Vt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];const fm=class fm{constructor(e,n,a,o){this.elements=[1,0,0,1],e!==void 0&&this.set(e,n,a,o)}identity(){return this.set(1,0,0,1),this}fromArray(e,n=0){for(let a=0;a<4;a++)this.elements[a]=e[a+n];return this}set(e,n,a,o){const c=this.elements;return c[0]=e,c[2]=n,c[1]=a,c[3]=o,this}};fm.prototype.isMatrix2=!0;let Yv=fm;function Kv(r,e,n,a){const o=Jb(a);switch(n){case zx:return r*e;case Wp:return r*e/o.components*o.byteLength;case qp:return r*e/o.components*o.byteLength;case sr:return r*e*2/o.components*o.byteLength;case Yp:return r*e*2/o.components*o.byteLength;case Hx:return r*e*3/o.components*o.byteLength;case Ci:return r*e*4/o.components*o.byteLength;case Kp:return r*e*4/o.components*o.byteLength;case Au:case Ru:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case Cu:case wu:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case $d:case tp:return Math.max(r,16)*Math.max(e,8)/4;case jd:case ep:return Math.max(r,8)*Math.max(e,8)/2;case np:case ip:case sp:case rp:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case ap:case Uu:case op:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case lp:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case cp:return Math.floor((r+4)/5)*Math.floor((e+3)/4)*16;case up:return Math.floor((r+4)/5)*Math.floor((e+4)/5)*16;case fp:return Math.floor((r+5)/6)*Math.floor((e+4)/5)*16;case hp:return Math.floor((r+5)/6)*Math.floor((e+5)/6)*16;case dp:return Math.floor((r+7)/8)*Math.floor((e+4)/5)*16;case pp:return Math.floor((r+7)/8)*Math.floor((e+5)/6)*16;case mp:return Math.floor((r+7)/8)*Math.floor((e+7)/8)*16;case gp:return Math.floor((r+9)/10)*Math.floor((e+4)/5)*16;case _p:return Math.floor((r+9)/10)*Math.floor((e+5)/6)*16;case vp:return Math.floor((r+9)/10)*Math.floor((e+7)/8)*16;case xp:return Math.floor((r+9)/10)*Math.floor((e+9)/10)*16;case yp:return Math.floor((r+11)/12)*Math.floor((e+9)/10)*16;case Sp:return Math.floor((r+11)/12)*Math.floor((e+11)/12)*16;case Mp:case Ep:case bp:return Math.ceil(r/4)*Math.ceil(e/4)*16;case Tp:case Ap:return Math.ceil(r/4)*Math.ceil(e/4)*8;case Ou:case Rp:return Math.ceil(r/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function Jb(r){switch(r){case mi:case Px:return{byteLength:1,components:1};case Cl:case Ix:case Ha:return{byteLength:2,components:1};case kp:case Xp:return{byteLength:2,components:4};case ra:case Vp:case Ri:return{byteLength:4,components:1};case Bx:case Fx:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:zp}}));typeof window<"u"&&(window.__THREE__?Ke("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=zp);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function ry(){let r=null,e=!1,n=null,a=null;function o(c,u){n(c,u),a=r.requestAnimationFrame(o)}return{start:function(){e!==!0&&n!==null&&r!==null&&(a=r.requestAnimationFrame(o),e=!0)},stop:function(){r!==null&&r.cancelAnimationFrame(a),e=!1},setAnimationLoop:function(c){n=c},setContext:function(c){r=c}}}function jb(r){const e=new WeakMap;function n(h,p){const d=h.array,g=h.usage,_=d.byteLength,v=r.createBuffer();r.bindBuffer(p,v),r.bufferData(p,d,g),h.onUploadCallback();let x;if(d instanceof Float32Array)x=r.FLOAT;else if(typeof Float16Array<"u"&&d instanceof Float16Array)x=r.HALF_FLOAT;else if(d instanceof Uint16Array)h.isFloat16BufferAttribute?x=r.HALF_FLOAT:x=r.UNSIGNED_SHORT;else if(d instanceof Int16Array)x=r.SHORT;else if(d instanceof Uint32Array)x=r.UNSIGNED_INT;else if(d instanceof Int32Array)x=r.INT;else if(d instanceof Int8Array)x=r.BYTE;else if(d instanceof Uint8Array)x=r.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)x=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:v,type:x,bytesPerElement:d.BYTES_PER_ELEMENT,version:h.version,size:_}}function a(h,p,d){const g=p.array,_=p.updateRanges;if(r.bindBuffer(d,h),_.length===0)r.bufferSubData(d,0,g);else{_.sort((x,E)=>x.start-E.start);let v=0;for(let x=1;x<_.length;x++){const E=_[v],C=_[x];C.start<=E.start+E.count+1?E.count=Math.max(E.count,C.start+C.count-E.start):(++v,_[v]=C)}_.length=v+1;for(let x=0,E=_.length;x<E;x++){const C=_[x];r.bufferSubData(d,C.start*g.BYTES_PER_ELEMENT,g,C.start,C.count)}p.clearUpdateRanges()}p.onUploadCallback()}function o(h){return h.isInterleavedBufferAttribute&&(h=h.data),e.get(h)}function c(h){h.isInterleavedBufferAttribute&&(h=h.data);const p=e.get(h);p&&(r.deleteBuffer(p.buffer),e.delete(h))}function u(h,p){if(h.isInterleavedBufferAttribute&&(h=h.data),h.isGLBufferAttribute){const g=e.get(h);(!g||g.version<h.version)&&e.set(h,{buffer:h.buffer,type:h.type,bytesPerElement:h.elementSize,version:h.version});return}const d=e.get(h);if(d===void 0)e.set(h,n(h,p));else if(d.version<h.version){if(d.size!==h.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");a(d.buffer,h,p),d.version=h.version}}return{get:o,remove:c,update:u}}var $b=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,eT=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,tT=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,nT=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,iT=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,aT=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,sT=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,rT=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,oT=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,lT=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,cT=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,uT=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,fT=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,hT=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,dT=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,pT=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,mT=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,gT=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,_T=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,vT=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,xT=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,yT=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,ST=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,MT=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,ET=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,bT=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,TT=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,AT=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,RT=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,CT=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,wT="gl_FragColor = linearToOutputTexel( gl_FragColor );",DT=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,LT=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,NT=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,UT=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,OT=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,PT=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,IT=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,BT=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,FT=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,zT=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,HT=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,GT=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,VT=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,kT=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,XT=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,WT=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,qT=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,YT=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,KT=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,ZT=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,QT=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,JT=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,jT=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,$T=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,e1=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,t1=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,n1=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,i1=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,a1=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,s1=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,r1=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,o1=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,l1=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,c1=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,u1=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,f1=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,h1=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,d1=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,p1=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,m1=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,g1=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,_1=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,v1=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,x1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,y1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,S1=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,M1=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,E1=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,b1=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,T1=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,A1=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,R1=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,C1=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,w1=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,D1=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,L1=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,N1=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,U1=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,O1=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,P1=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,I1=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,B1=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,F1=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,z1=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,H1=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,G1=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,V1=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,k1=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,X1=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,W1=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,q1=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Y1=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,K1=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Z1=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Q1=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,J1=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,j1=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const $1=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,eA=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,tA=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,nA=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,iA=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,aA=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,sA=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,rA=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,oA=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,lA=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,cA=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,uA=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,fA=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,hA=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,dA=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,pA=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,mA=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,gA=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_A=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,vA=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xA=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,yA=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,SA=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,MA=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,EA=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,bA=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,TA=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,AA=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,RA=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,CA=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,wA=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,DA=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,LA=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,NA=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ht={alphahash_fragment:$b,alphahash_pars_fragment:eT,alphamap_fragment:tT,alphamap_pars_fragment:nT,alphatest_fragment:iT,alphatest_pars_fragment:aT,aomap_fragment:sT,aomap_pars_fragment:rT,batching_pars_vertex:oT,batching_vertex:lT,begin_vertex:cT,beginnormal_vertex:uT,bsdfs:fT,iridescence_fragment:hT,bumpmap_pars_fragment:dT,clipping_planes_fragment:pT,clipping_planes_pars_fragment:mT,clipping_planes_pars_vertex:gT,clipping_planes_vertex:_T,color_fragment:vT,color_pars_fragment:xT,color_pars_vertex:yT,color_vertex:ST,common:MT,cube_uv_reflection_fragment:ET,defaultnormal_vertex:bT,displacementmap_pars_vertex:TT,displacementmap_vertex:AT,emissivemap_fragment:RT,emissivemap_pars_fragment:CT,colorspace_fragment:wT,colorspace_pars_fragment:DT,envmap_fragment:LT,envmap_common_pars_fragment:NT,envmap_pars_fragment:UT,envmap_pars_vertex:OT,envmap_physical_pars_fragment:WT,envmap_vertex:PT,fog_vertex:IT,fog_pars_vertex:BT,fog_fragment:FT,fog_pars_fragment:zT,gradientmap_pars_fragment:HT,lightmap_pars_fragment:GT,lights_lambert_fragment:VT,lights_lambert_pars_fragment:kT,lights_pars_begin:XT,lights_toon_fragment:qT,lights_toon_pars_fragment:YT,lights_phong_fragment:KT,lights_phong_pars_fragment:ZT,lights_physical_fragment:QT,lights_physical_pars_fragment:JT,lights_fragment_begin:jT,lights_fragment_maps:$T,lights_fragment_end:e1,lightprobes_pars_fragment:t1,logdepthbuf_fragment:n1,logdepthbuf_pars_fragment:i1,logdepthbuf_pars_vertex:a1,logdepthbuf_vertex:s1,map_fragment:r1,map_pars_fragment:o1,map_particle_fragment:l1,map_particle_pars_fragment:c1,metalnessmap_fragment:u1,metalnessmap_pars_fragment:f1,morphinstance_vertex:h1,morphcolor_vertex:d1,morphnormal_vertex:p1,morphtarget_pars_vertex:m1,morphtarget_vertex:g1,normal_fragment_begin:_1,normal_fragment_maps:v1,normal_pars_fragment:x1,normal_pars_vertex:y1,normal_vertex:S1,normalmap_pars_fragment:M1,clearcoat_normal_fragment_begin:E1,clearcoat_normal_fragment_maps:b1,clearcoat_pars_fragment:T1,iridescence_pars_fragment:A1,opaque_fragment:R1,packing:C1,premultiplied_alpha_fragment:w1,project_vertex:D1,dithering_fragment:L1,dithering_pars_fragment:N1,roughnessmap_fragment:U1,roughnessmap_pars_fragment:O1,shadowmap_pars_fragment:P1,shadowmap_pars_vertex:I1,shadowmap_vertex:B1,shadowmask_pars_fragment:F1,skinbase_vertex:z1,skinning_pars_vertex:H1,skinning_vertex:G1,skinnormal_vertex:V1,specularmap_fragment:k1,specularmap_pars_fragment:X1,tonemapping_fragment:W1,tonemapping_pars_fragment:q1,transmission_fragment:Y1,transmission_pars_fragment:K1,uv_pars_fragment:Z1,uv_pars_vertex:Q1,uv_vertex:J1,worldpos_vertex:j1,background_vert:$1,background_frag:eA,backgroundCube_vert:tA,backgroundCube_frag:nA,cube_vert:iA,cube_frag:aA,depth_vert:sA,depth_frag:rA,distance_vert:oA,distance_frag:lA,equirect_vert:cA,equirect_frag:uA,linedashed_vert:fA,linedashed_frag:hA,meshbasic_vert:dA,meshbasic_frag:pA,meshlambert_vert:mA,meshlambert_frag:gA,meshmatcap_vert:_A,meshmatcap_frag:vA,meshnormal_vert:xA,meshnormal_frag:yA,meshphong_vert:SA,meshphong_frag:MA,meshphysical_vert:EA,meshphysical_frag:bA,meshtoon_vert:TA,meshtoon_frag:AA,points_vert:RA,points_frag:CA,shadow_vert:wA,shadow_frag:DA,sprite_vert:LA,sprite_frag:NA},Oe={common:{diffuse:{value:new st(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new lt},alphaMap:{value:null},alphaMapTransform:{value:new lt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new lt}},envmap:{envMap:{value:null},envMapRotation:{value:new lt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new lt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new lt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new lt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new lt},normalScale:{value:new gt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new lt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new lt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new lt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new lt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new st(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new $},probesMax:{value:new $},probesResolution:{value:new $}},points:{diffuse:{value:new st(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new lt},alphaTest:{value:0},uvTransform:{value:new lt}},sprite:{diffuse:{value:new st(16777215)},opacity:{value:1},center:{value:new gt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new lt},alphaMap:{value:null},alphaMapTransform:{value:new lt},alphaTest:{value:0}}},ea={basic:{uniforms:Wn([Oe.common,Oe.specularmap,Oe.envmap,Oe.aomap,Oe.lightmap,Oe.fog]),vertexShader:ht.meshbasic_vert,fragmentShader:ht.meshbasic_frag},lambert:{uniforms:Wn([Oe.common,Oe.specularmap,Oe.envmap,Oe.aomap,Oe.lightmap,Oe.emissivemap,Oe.bumpmap,Oe.normalmap,Oe.displacementmap,Oe.fog,Oe.lights,{emissive:{value:new st(0)},envMapIntensity:{value:1}}]),vertexShader:ht.meshlambert_vert,fragmentShader:ht.meshlambert_frag},phong:{uniforms:Wn([Oe.common,Oe.specularmap,Oe.envmap,Oe.aomap,Oe.lightmap,Oe.emissivemap,Oe.bumpmap,Oe.normalmap,Oe.displacementmap,Oe.fog,Oe.lights,{emissive:{value:new st(0)},specular:{value:new st(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ht.meshphong_vert,fragmentShader:ht.meshphong_frag},standard:{uniforms:Wn([Oe.common,Oe.envmap,Oe.aomap,Oe.lightmap,Oe.emissivemap,Oe.bumpmap,Oe.normalmap,Oe.displacementmap,Oe.roughnessmap,Oe.metalnessmap,Oe.fog,Oe.lights,{emissive:{value:new st(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ht.meshphysical_vert,fragmentShader:ht.meshphysical_frag},toon:{uniforms:Wn([Oe.common,Oe.aomap,Oe.lightmap,Oe.emissivemap,Oe.bumpmap,Oe.normalmap,Oe.displacementmap,Oe.gradientmap,Oe.fog,Oe.lights,{emissive:{value:new st(0)}}]),vertexShader:ht.meshtoon_vert,fragmentShader:ht.meshtoon_frag},matcap:{uniforms:Wn([Oe.common,Oe.bumpmap,Oe.normalmap,Oe.displacementmap,Oe.fog,{matcap:{value:null}}]),vertexShader:ht.meshmatcap_vert,fragmentShader:ht.meshmatcap_frag},points:{uniforms:Wn([Oe.points,Oe.fog]),vertexShader:ht.points_vert,fragmentShader:ht.points_frag},dashed:{uniforms:Wn([Oe.common,Oe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ht.linedashed_vert,fragmentShader:ht.linedashed_frag},depth:{uniforms:Wn([Oe.common,Oe.displacementmap]),vertexShader:ht.depth_vert,fragmentShader:ht.depth_frag},normal:{uniforms:Wn([Oe.common,Oe.bumpmap,Oe.normalmap,Oe.displacementmap,{opacity:{value:1}}]),vertexShader:ht.meshnormal_vert,fragmentShader:ht.meshnormal_frag},sprite:{uniforms:Wn([Oe.sprite,Oe.fog]),vertexShader:ht.sprite_vert,fragmentShader:ht.sprite_frag},background:{uniforms:{uvTransform:{value:new lt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ht.background_vert,fragmentShader:ht.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new lt}},vertexShader:ht.backgroundCube_vert,fragmentShader:ht.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ht.cube_vert,fragmentShader:ht.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ht.equirect_vert,fragmentShader:ht.equirect_frag},distance:{uniforms:Wn([Oe.common,Oe.displacementmap,{referencePosition:{value:new $},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ht.distance_vert,fragmentShader:ht.distance_frag},shadow:{uniforms:Wn([Oe.lights,Oe.fog,{color:{value:new st(0)},opacity:{value:1}}]),vertexShader:ht.shadow_vert,fragmentShader:ht.shadow_frag}};ea.physical={uniforms:Wn([ea.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new lt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new lt},clearcoatNormalScale:{value:new gt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new lt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new lt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new lt},sheen:{value:0},sheenColor:{value:new st(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new lt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new lt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new lt},transmissionSamplerSize:{value:new gt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new lt},attenuationDistance:{value:0},attenuationColor:{value:new st(0)},specularColor:{value:new st(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new lt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new lt},anisotropyVector:{value:new gt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new lt}}]),vertexShader:ht.meshphysical_vert,fragmentShader:ht.meshphysical_frag};const Su={r:0,b:0,g:0},UA=new dt,oy=new lt;oy.set(-1,0,0,0,1,0,0,0,1);function OA(r,e,n,a,o,c){const u=new st(0);let h=o===!0?0:1,p,d,g=null,_=0,v=null;function x(B){let F=B.isScene===!0?B.background:null;if(F&&F.isTexture){const w=B.backgroundBlurriness>0;F=e.get(F,w)}return F}function E(B){let F=!1;const w=x(B);w===null?M(u,h):w&&w.isColor&&(M(w,1),F=!0);const P=r.xr.getEnvironmentBlendMode();P==="additive"?n.buffers.color.setClear(0,0,0,1,c):P==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,c),(r.autoClear||F)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function C(B,F){const w=x(F);w&&(w.isCubeTexture||w.mapping===Vu)?(d===void 0&&(d=new En(new ho(1,1,1),new oa({name:"BackgroundCubeMaterial",uniforms:fo(ea.backgroundCube.uniforms),vertexShader:ea.backgroundCube.vertexShader,fragmentShader:ea.backgroundCube.fragmentShader,side:qn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(P,U,N){this.matrixWorld.copyPosition(N.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(d)),d.material.uniforms.envMap.value=w,d.material.uniforms.backgroundBlurriness.value=F.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=F.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(UA.makeRotationFromEuler(F.backgroundRotation)).transpose(),w.isCubeTexture&&w.isRenderTargetTexture===!1&&d.material.uniforms.backgroundRotation.value.premultiply(oy),d.material.toneMapped=St.getTransfer(w.colorSpace)!==Ht,(g!==w||_!==w.version||v!==r.toneMapping)&&(d.material.needsUpdate=!0,g=w,_=w.version,v=r.toneMapping),d.layers.enableAll(),B.unshift(d,d.geometry,d.material,0,0,null)):w&&w.isTexture&&(p===void 0&&(p=new En(new Xu(2,2),new oa({name:"BackgroundMaterial",uniforms:fo(ea.background.uniforms),vertexShader:ea.background.vertexShader,fragmentShader:ea.background.fragmentShader,side:za,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),Object.defineProperty(p.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(p)),p.material.uniforms.t2D.value=w,p.material.uniforms.backgroundIntensity.value=F.backgroundIntensity,p.material.toneMapped=St.getTransfer(w.colorSpace)!==Ht,w.matrixAutoUpdate===!0&&w.updateMatrix(),p.material.uniforms.uvTransform.value.copy(w.matrix),(g!==w||_!==w.version||v!==r.toneMapping)&&(p.material.needsUpdate=!0,g=w,_=w.version,v=r.toneMapping),p.layers.enableAll(),B.unshift(p,p.geometry,p.material,0,0,null))}function M(B,F){B.getRGB(Su,ty(r)),n.buffers.color.setClear(Su.r,Su.g,Su.b,F,c)}function S(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0)}return{getClearColor:function(){return u},setClearColor:function(B,F=1){u.set(B),h=F,M(u,h)},getClearAlpha:function(){return h},setClearAlpha:function(B){h=B,M(u,h)},render:E,addToRenderList:C,dispose:S}}function PA(r,e){const n=r.getParameter(r.MAX_VERTEX_ATTRIBS),a={},o=v(null);let c=o,u=!1;function h(G,Z,ce,ge,j){let I=!1;const z=_(G,ge,ce,Z);c!==z&&(c=z,d(c.object)),I=x(G,ge,ce,j),I&&E(G,ge,ce,j),j!==null&&e.update(j,r.ELEMENT_ARRAY_BUFFER),(I||u)&&(u=!1,w(G,Z,ce,ge),j!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,e.get(j).buffer))}function p(){return r.createVertexArray()}function d(G){return r.bindVertexArray(G)}function g(G){return r.deleteVertexArray(G)}function _(G,Z,ce,ge){const j=ge.wireframe===!0;let I=a[Z.id];I===void 0&&(I={},a[Z.id]=I);const z=G.isInstancedMesh===!0?G.id:0;let Q=I[z];Q===void 0&&(Q={},I[z]=Q);let de=Q[ce.id];de===void 0&&(de={},Q[ce.id]=de);let ve=de[j];return ve===void 0&&(ve=v(p()),de[j]=ve),ve}function v(G){const Z=[],ce=[],ge=[];for(let j=0;j<n;j++)Z[j]=0,ce[j]=0,ge[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:Z,enabledAttributes:ce,attributeDivisors:ge,object:G,attributes:{},index:null}}function x(G,Z,ce,ge){const j=c.attributes,I=Z.attributes;let z=0;const Q=ce.getAttributes();for(const de in Q)if(Q[de].location>=0){const D=j[de];let Y=I[de];if(Y===void 0&&(de==="instanceMatrix"&&G.instanceMatrix&&(Y=G.instanceMatrix),de==="instanceColor"&&G.instanceColor&&(Y=G.instanceColor)),D===void 0||D.attribute!==Y||Y&&D.data!==Y.data)return!0;z++}return c.attributesNum!==z||c.index!==ge}function E(G,Z,ce,ge){const j={},I=Z.attributes;let z=0;const Q=ce.getAttributes();for(const de in Q)if(Q[de].location>=0){let D=I[de];D===void 0&&(de==="instanceMatrix"&&G.instanceMatrix&&(D=G.instanceMatrix),de==="instanceColor"&&G.instanceColor&&(D=G.instanceColor));const Y={};Y.attribute=D,D&&D.data&&(Y.data=D.data),j[de]=Y,z++}c.attributes=j,c.attributesNum=z,c.index=ge}function C(){const G=c.newAttributes;for(let Z=0,ce=G.length;Z<ce;Z++)G[Z]=0}function M(G){S(G,0)}function S(G,Z){const ce=c.newAttributes,ge=c.enabledAttributes,j=c.attributeDivisors;ce[G]=1,ge[G]===0&&(r.enableVertexAttribArray(G),ge[G]=1),j[G]!==Z&&(r.vertexAttribDivisor(G,Z),j[G]=Z)}function B(){const G=c.newAttributes,Z=c.enabledAttributes;for(let ce=0,ge=Z.length;ce<ge;ce++)Z[ce]!==G[ce]&&(r.disableVertexAttribArray(ce),Z[ce]=0)}function F(G,Z,ce,ge,j,I,z){z===!0?r.vertexAttribIPointer(G,Z,ce,j,I):r.vertexAttribPointer(G,Z,ce,ge,j,I)}function w(G,Z,ce,ge){C();const j=ge.attributes,I=ce.getAttributes(),z=Z.defaultAttributeValues;for(const Q in I){const de=I[Q];if(de.location>=0){let ve=j[Q];if(ve===void 0&&(Q==="instanceMatrix"&&G.instanceMatrix&&(ve=G.instanceMatrix),Q==="instanceColor"&&G.instanceColor&&(ve=G.instanceColor)),ve!==void 0){const D=ve.normalized,Y=ve.itemSize,Ee=e.get(ve);if(Ee===void 0)continue;const Re=Ee.buffer,Pe=Ee.type,ae=Ee.bytesPerElement,ye=Pe===r.INT||Pe===r.UNSIGNED_INT||ve.gpuType===Vp;if(ve.isInterleavedBufferAttribute){const Me=ve.data,ze=Me.stride,it=ve.offset;if(Me.isInstancedInterleavedBuffer){for(let je=0;je<de.locationSize;je++)S(de.location+je,Me.meshPerAttribute);G.isInstancedMesh!==!0&&ge._maxInstanceCount===void 0&&(ge._maxInstanceCount=Me.meshPerAttribute*Me.count)}else for(let je=0;je<de.locationSize;je++)M(de.location+je);r.bindBuffer(r.ARRAY_BUFFER,Re);for(let je=0;je<de.locationSize;je++)F(de.location+je,Y/de.locationSize,Pe,D,ze*ae,(it+Y/de.locationSize*je)*ae,ye)}else{if(ve.isInstancedBufferAttribute){for(let Me=0;Me<de.locationSize;Me++)S(de.location+Me,ve.meshPerAttribute);G.isInstancedMesh!==!0&&ge._maxInstanceCount===void 0&&(ge._maxInstanceCount=ve.meshPerAttribute*ve.count)}else for(let Me=0;Me<de.locationSize;Me++)M(de.location+Me);r.bindBuffer(r.ARRAY_BUFFER,Re);for(let Me=0;Me<de.locationSize;Me++)F(de.location+Me,Y/de.locationSize,Pe,D,Y*ae,Y/de.locationSize*Me*ae,ye)}}else if(z!==void 0){const D=z[Q];if(D!==void 0)switch(D.length){case 2:r.vertexAttrib2fv(de.location,D);break;case 3:r.vertexAttrib3fv(de.location,D);break;case 4:r.vertexAttrib4fv(de.location,D);break;default:r.vertexAttrib1fv(de.location,D)}}}}B()}function P(){O();for(const G in a){const Z=a[G];for(const ce in Z){const ge=Z[ce];for(const j in ge){const I=ge[j];for(const z in I)g(I[z].object),delete I[z];delete ge[j]}}delete a[G]}}function U(G){if(a[G.id]===void 0)return;const Z=a[G.id];for(const ce in Z){const ge=Z[ce];for(const j in ge){const I=ge[j];for(const z in I)g(I[z].object),delete I[z];delete ge[j]}}delete a[G.id]}function N(G){for(const Z in a){const ce=a[Z];for(const ge in ce){const j=ce[ge];if(j[G.id]===void 0)continue;const I=j[G.id];for(const z in I)g(I[z].object),delete I[z];delete j[G.id]}}}function T(G){for(const Z in a){const ce=a[Z],ge=G.isInstancedMesh===!0?G.id:0,j=ce[ge];if(j!==void 0){for(const I in j){const z=j[I];for(const Q in z)g(z[Q].object),delete z[Q];delete j[I]}delete ce[ge],Object.keys(ce).length===0&&delete a[Z]}}}function O(){X(),u=!0,c!==o&&(c=o,d(c.object))}function X(){o.geometry=null,o.program=null,o.wireframe=!1}return{setup:h,reset:O,resetDefaultState:X,dispose:P,releaseStatesOfGeometry:U,releaseStatesOfObject:T,releaseStatesOfProgram:N,initAttributes:C,enableAttribute:M,disableUnusedAttributes:B}}function IA(r,e,n){let a;function o(p){a=p}function c(p,d){r.drawArrays(a,p,d),n.update(d,a,1)}function u(p,d,g){g!==0&&(r.drawArraysInstanced(a,p,d,g),n.update(d,a,g))}function h(p,d,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(a,p,0,d,0,g);let v=0;for(let x=0;x<g;x++)v+=d[x];n.update(v,a,1)}this.setMode=o,this.render=c,this.renderInstances=u,this.renderMultiDraw=h}function BA(r,e,n,a){let o;function c(){if(o!==void 0)return o;if(e.has("EXT_texture_filter_anisotropic")===!0){const N=e.get("EXT_texture_filter_anisotropic");o=r.getParameter(N.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else o=0;return o}function u(N){return!(N!==Ci&&a.convert(N)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function h(N){const T=N===Ha&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(N!==mi&&a.convert(N)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&N!==Ri&&!T)}function p(N){if(N==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";N="mediump"}return N==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let d=n.precision!==void 0?n.precision:"highp";const g=p(d);g!==d&&(Ke("WebGLRenderer:",d,"not supported, using",g,"instead."),d=g);const _=n.logarithmicDepthBuffer===!0,v=n.reversedDepthBuffer===!0&&e.has("EXT_clip_control");n.reversedDepthBuffer===!0&&v===!1&&Ke("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const x=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),E=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),C=r.getParameter(r.MAX_TEXTURE_SIZE),M=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),S=r.getParameter(r.MAX_VERTEX_ATTRIBS),B=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),F=r.getParameter(r.MAX_VARYING_VECTORS),w=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),P=r.getParameter(r.MAX_SAMPLES),U=r.getParameter(r.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:p,textureFormatReadable:u,textureTypeReadable:h,precision:d,logarithmicDepthBuffer:_,reversedDepthBuffer:v,maxTextures:x,maxVertexTextures:E,maxTextureSize:C,maxCubemapSize:M,maxAttributes:S,maxVertexUniforms:B,maxVaryings:F,maxFragmentUniforms:w,maxSamples:P,samples:U}}function FA(r){const e=this;let n=null,a=0,o=!1,c=!1;const u=new $s,h=new lt,p={value:null,needsUpdate:!1};this.uniform=p,this.numPlanes=0,this.numIntersection=0,this.init=function(_,v){const x=_.length!==0||v||a!==0||o;return o=v,a=_.length,x},this.beginShadows=function(){c=!0,g(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(_,v){n=g(_,v,0)},this.setState=function(_,v,x){const E=_.clippingPlanes,C=_.clipIntersection,M=_.clipShadows,S=r.get(_);if(!o||E===null||E.length===0||c&&!M)c?g(null):d();else{const B=c?0:a,F=B*4;let w=S.clippingState||null;p.value=w,w=g(E,v,F,x);for(let P=0;P!==F;++P)w[P]=n[P];S.clippingState=w,this.numIntersection=C?this.numPlanes:0,this.numPlanes+=B}};function d(){p.value!==n&&(p.value=n,p.needsUpdate=a>0),e.numPlanes=a,e.numIntersection=0}function g(_,v,x,E){const C=_!==null?_.length:0;let M=null;if(C!==0){if(M=p.value,E!==!0||M===null){const S=x+C*4,B=v.matrixWorldInverse;h.getNormalMatrix(B),(M===null||M.length<S)&&(M=new Float32Array(S));for(let F=0,w=x;F!==C;++F,w+=4)u.copy(_[F]).applyMatrix4(B,h),u.normal.toArray(M,w),M[w+3]=u.constant}p.value=M,p.needsUpdate=!0}return e.numPlanes=C,e.numIntersection=0,M}}const Rs=4,Zv=[.125,.215,.35,.446,.526,.582],tr=20,zA=256,xl=new Bl,Qv=new st;let Od=null,Pd=0,Id=0,Bd=!1;const HA=new $;class Np{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,n=0,a=.1,o=100,c={}){const{size:u=256,position:h=HA}=c;Od=this._renderer.getRenderTarget(),Pd=this._renderer.getActiveCubeFace(),Id=this._renderer.getActiveMipmapLevel(),Bd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(u);const p=this._allocateTargets();return p.depthBuffer=!0,this._sceneToCubeUV(e,a,o,p,h),n>0&&this._blur(p,0,0,n),this._applyPMREM(p),this._cleanup(p),p}fromEquirectangular(e,n=null){return this._fromTexture(e,n)}fromCubemap(e,n=null){return this._fromTexture(e,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=$v(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=jv(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Od,Pd,Id),this._renderer.xr.enabled=Bd,e.scissorTest=!1,eo(e,0,0,e.width,e.height)}_fromTexture(e,n){e.mapping===ar||e.mapping===oo?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Od=this._renderer.getRenderTarget(),Pd=this._renderer.getActiveCubeFace(),Id=this._renderer.getActiveMipmapLevel(),Bd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const a=n||this._allocateTargets();return this._textureToCubeUV(e,a),this._applyPMREM(a),this._cleanup(a),a}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,a={magFilter:Rn,minFilter:Rn,generateMipmaps:!1,type:Ha,format:Ci,colorSpace:gi,depthBuffer:!1},o=Jv(e,n,a);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Jv(e,n,a);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=GA(c)),this._blurMaterial=kA(c,e,n),this._ggxMaterial=VA(c,e,n)}return o}_compileMaterial(e){const n=new En(new wi,e);this._renderer.compile(n,xl)}_sceneToCubeUV(e,n,a,o,c){const p=new ti(90,1,n,a),d=[1,-1,1,1,1,1],g=[1,1,1,-1,-1,-1],_=this._renderer,v=_.autoClear,x=_.toneMapping;_.getClearColor(Qv),_.toneMapping=aa,_.autoClear=!1,_.state.buffers.depth.getReversed()&&(_.setRenderTarget(o),_.clearDepth(),_.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new En(new ho,new ir({name:"PMREM.Background",side:qn,depthWrite:!1,depthTest:!1})));const C=this._backgroundBox,M=C.material;let S=!1;const B=e.background;B?B.isColor&&(M.color.copy(B),e.background=null,S=!0):(M.color.copy(Qv),S=!0);for(let F=0;F<6;F++){const w=F%3;w===0?(p.up.set(0,d[F],0),p.position.set(c.x,c.y,c.z),p.lookAt(c.x+g[F],c.y,c.z)):w===1?(p.up.set(0,0,d[F]),p.position.set(c.x,c.y,c.z),p.lookAt(c.x,c.y+g[F],c.z)):(p.up.set(0,d[F],0),p.position.set(c.x,c.y,c.z),p.lookAt(c.x,c.y,c.z+g[F]));const P=this._cubeSize;eo(o,w*P,F>2?P:0,P,P),_.setRenderTarget(o),S&&_.render(C,p),_.render(e,p)}_.toneMapping=x,_.autoClear=v,e.background=B}_textureToCubeUV(e,n){const a=this._renderer,o=e.mapping===ar||e.mapping===oo;o?(this._cubemapMaterial===null&&(this._cubemapMaterial=$v()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=jv());const c=o?this._cubemapMaterial:this._equirectMaterial,u=this._lodMeshes[0];u.material=c;const h=c.uniforms;h.envMap.value=e;const p=this._cubeSize;eo(n,0,0,3*p,2*p),a.setRenderTarget(n),a.render(u,xl)}_applyPMREM(e){const n=this._renderer,a=n.autoClear;n.autoClear=!1;const o=this._lodMeshes.length;for(let c=1;c<o;c++)this._applyGGXFilter(e,c-1,c);n.autoClear=a}_applyGGXFilter(e,n,a){const o=this._renderer,c=this._pingPongRenderTarget,u=this._ggxMaterial,h=this._lodMeshes[a];h.material=u;const p=u.uniforms,d=a/(this._lodMeshes.length-1),g=n/(this._lodMeshes.length-1),_=Math.sqrt(d*d-g*g),v=0+d*1.25,x=_*v,{_lodMax:E}=this,C=this._sizeLods[a],M=3*C*(a>E-Rs?a-E+Rs:0),S=4*(this._cubeSize-C);p.envMap.value=e.texture,p.roughness.value=x,p.mipInt.value=E-n,eo(c,M,S,3*C,2*C),o.setRenderTarget(c),o.render(h,xl),p.envMap.value=c.texture,p.roughness.value=0,p.mipInt.value=E-a,eo(e,M,S,3*C,2*C),o.setRenderTarget(e),o.render(h,xl)}_blur(e,n,a,o,c){const u=this._pingPongRenderTarget;this._halfBlur(e,u,n,a,o,"latitudinal",c),this._halfBlur(u,e,a,a,o,"longitudinal",c)}_halfBlur(e,n,a,o,c,u,h){const p=this._renderer,d=this._blurMaterial;u!=="latitudinal"&&u!=="longitudinal"&&at("blur direction must be either latitudinal or longitudinal!");const g=3,_=this._lodMeshes[o];_.material=d;const v=d.uniforms,x=this._sizeLods[a]-1,E=isFinite(c)?Math.PI/(2*x):2*Math.PI/(2*tr-1),C=c/E,M=isFinite(c)?1+Math.floor(g*C):tr;M>tr&&Ke(`sigmaRadians, ${c}, is too large and will clip, as it requested ${M} samples when the maximum is set to ${tr}`);const S=[];let B=0;for(let N=0;N<tr;++N){const T=N/C,O=Math.exp(-T*T/2);S.push(O),N===0?B+=O:N<M&&(B+=2*O)}for(let N=0;N<S.length;N++)S[N]=S[N]/B;v.envMap.value=e.texture,v.samples.value=M,v.weights.value=S,v.latitudinal.value=u==="latitudinal",h&&(v.poleAxis.value=h);const{_lodMax:F}=this;v.dTheta.value=E,v.mipInt.value=F-a;const w=this._sizeLods[o],P=3*w*(o>F-Rs?o-F+Rs:0),U=4*(this._cubeSize-w);eo(n,P,U,3*w,2*w),p.setRenderTarget(n),p.render(_,xl)}}function GA(r){const e=[],n=[],a=[];let o=r;const c=r-Rs+1+Zv.length;for(let u=0;u<c;u++){const h=Math.pow(2,o);e.push(h);let p=1/h;u>r-Rs?p=Zv[u-r+Rs-1]:u===0&&(p=0),n.push(p);const d=1/(h-2),g=-d,_=1+d,v=[g,g,_,g,_,_,g,g,_,_,g,_],x=6,E=6,C=3,M=2,S=1,B=new Float32Array(C*E*x),F=new Float32Array(M*E*x),w=new Float32Array(S*E*x);for(let U=0;U<x;U++){const N=U%3*2/3-1,T=U>2?0:-1,O=[N,T,0,N+2/3,T,0,N+2/3,T+1,0,N,T,0,N+2/3,T+1,0,N,T+1,0];B.set(O,C*E*U),F.set(v,M*E*U);const X=[U,U,U,U,U,U];w.set(X,S*E*U)}const P=new wi;P.setAttribute("position",new Yn(B,C)),P.setAttribute("uv",new Yn(F,M)),P.setAttribute("faceIndex",new Yn(w,S)),a.push(new En(P,null)),o>Rs&&o--}return{lodMeshes:a,sizeLods:e,sigmas:n}}function Jv(r,e,n){const a=new sa(r,e,n);return a.texture.mapping=Vu,a.texture.name="PMREM.cubeUv",a.scissorTest=!0,a}function eo(r,e,n,a,o){r.viewport.set(e,n,a,o),r.scissor.set(e,n,a,o)}function VA(r,e,n){return new oa({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:zA,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:qu(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ba,depthTest:!1,depthWrite:!1})}function kA(r,e,n){const a=new Float32Array(tr),o=new $(0,1,0);return new oa({name:"SphericalGaussianBlur",defines:{n:tr,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:a},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:o}},vertexShader:qu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ba,depthTest:!1,depthWrite:!1})}function jv(){return new oa({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:qu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ba,depthTest:!1,depthWrite:!1})}function $v(){return new oa({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:qu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ba,depthTest:!1,depthWrite:!1})}function qu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class ly extends sa{constructor(e=1,n={}){super(e,e,n),this.isWebGLCubeRenderTarget=!0;const a={width:e,height:e,depth:1},o=[a,a,a,a,a,a];this.texture=new $x(o),this._setTextureOptions(n),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const a={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},o=new ho(5,5,5),c=new oa({name:"CubemapFromEquirect",uniforms:fo(a.uniforms),vertexShader:a.vertexShader,fragmentShader:a.fragmentShader,side:qn,blending:Ba});c.uniforms.tEquirect.value=n;const u=new En(o,c),h=n.minFilter;return n.minFilter===Pa&&(n.minFilter=Rn),new Hb(1,10,this).update(e,u),n.minFilter=h,u.geometry.dispose(),u.material.dispose(),this}clear(e,n=!0,a=!0,o=!0){const c=e.getRenderTarget();for(let u=0;u<6;u++)e.setRenderTarget(this,u),e.clear(n,a,o);e.setRenderTarget(c)}}function XA(r){let e=new WeakMap,n=new WeakMap,a=null;function o(v,x=!1){return v==null?null:x?u(v):c(v)}function c(v){if(v&&v.isTexture){const x=v.mapping;if(x===ad||x===sd)if(e.has(v)){const E=e.get(v).texture;return h(E,v.mapping)}else{const E=v.image;if(E&&E.height>0){const C=new ly(E.height);return C.fromEquirectangularTexture(r,v),e.set(v,C),v.addEventListener("dispose",d),h(C.texture,v.mapping)}else return null}}return v}function u(v){if(v&&v.isTexture){const x=v.mapping,E=x===ad||x===sd,C=x===ar||x===oo;if(E||C){let M=n.get(v);const S=M!==void 0?M.texture.pmremVersion:0;if(v.isRenderTargetTexture&&v.pmremVersion!==S)return a===null&&(a=new Np(r)),M=E?a.fromEquirectangular(v,M):a.fromCubemap(v,M),M.texture.pmremVersion=v.pmremVersion,n.set(v,M),M.texture;if(M!==void 0)return M.texture;{const B=v.image;return E&&B&&B.height>0||C&&B&&p(B)?(a===null&&(a=new Np(r)),M=E?a.fromEquirectangular(v):a.fromCubemap(v),M.texture.pmremVersion=v.pmremVersion,n.set(v,M),v.addEventListener("dispose",g),M.texture):null}}}return v}function h(v,x){return x===ad?v.mapping=ar:x===sd&&(v.mapping=oo),v}function p(v){let x=0;const E=6;for(let C=0;C<E;C++)v[C]!==void 0&&x++;return x===E}function d(v){const x=v.target;x.removeEventListener("dispose",d);const E=e.get(x);E!==void 0&&(e.delete(x),E.dispose())}function g(v){const x=v.target;x.removeEventListener("dispose",g);const E=n.get(x);E!==void 0&&(n.delete(x),E.dispose())}function _(){e=new WeakMap,n=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:o,dispose:_}}function WA(r){const e={};function n(a){if(e[a]!==void 0)return e[a];const o=r.getExtension(a);return e[a]=o,o}return{has:function(a){return n(a)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(a){const o=n(a);return o===null&&io("WebGLRenderer: "+a+" extension not supported."),o}}}function qA(r,e,n,a){const o={},c=new WeakMap;function u(_){const v=_.target;v.index!==null&&e.remove(v.index);for(const E in v.attributes)e.remove(v.attributes[E]);v.removeEventListener("dispose",u),delete o[v.id];const x=c.get(v);x&&(e.remove(x),c.delete(v)),a.releaseStatesOfGeometry(v),v.isInstancedBufferGeometry===!0&&delete v._maxInstanceCount,n.memory.geometries--}function h(_,v){return o[v.id]===!0||(v.addEventListener("dispose",u),o[v.id]=!0,n.memory.geometries++),v}function p(_){const v=_.attributes;for(const x in v)e.update(v[x],r.ARRAY_BUFFER)}function d(_){const v=[],x=_.index,E=_.attributes.position;let C=0;if(E===void 0)return;if(x!==null){const B=x.array;C=x.version;for(let F=0,w=B.length;F<w;F+=3){const P=B[F+0],U=B[F+1],N=B[F+2];v.push(P,U,U,N,N,P)}}else{const B=E.array;C=E.version;for(let F=0,w=B.length/3-1;F<w;F+=3){const P=F+0,U=F+1,N=F+2;v.push(P,U,U,N,N,P)}}const M=new(E.count>=65535?Kx:Yx)(v,1);M.version=C;const S=c.get(_);S&&e.remove(S),c.set(_,M)}function g(_){const v=c.get(_);if(v){const x=_.index;x!==null&&v.version<x.version&&d(_)}else d(_);return c.get(_)}return{get:h,update:p,getWireframeAttribute:g}}function YA(r,e,n){let a;function o(_){a=_}let c,u;function h(_){c=_.type,u=_.bytesPerElement}function p(_,v){r.drawElements(a,v,c,_*u),n.update(v,a,1)}function d(_,v,x){x!==0&&(r.drawElementsInstanced(a,v,c,_*u,x),n.update(v,a,x))}function g(_,v,x){if(x===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(a,v,0,c,_,0,x);let C=0;for(let M=0;M<x;M++)C+=v[M];n.update(C,a,1)}this.setMode=o,this.setIndex=h,this.render=p,this.renderInstances=d,this.renderMultiDraw=g}function KA(r){const e={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function a(c,u,h){switch(n.calls++,u){case r.TRIANGLES:n.triangles+=h*(c/3);break;case r.LINES:n.lines+=h*(c/2);break;case r.LINE_STRIP:n.lines+=h*(c-1);break;case r.LINE_LOOP:n.lines+=h*c;break;case r.POINTS:n.points+=h*c;break;default:at("WebGLInfo: Unknown draw mode:",u);break}}function o(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:e,render:n,programs:null,autoReset:!0,reset:o,update:a}}function ZA(r,e,n){const a=new WeakMap,o=new Yt;function c(u,h,p){const d=u.morphTargetInfluences,g=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,_=g!==void 0?g.length:0;let v=a.get(h);if(v===void 0||v.count!==_){let X=function(){T.dispose(),a.delete(h),h.removeEventListener("dispose",X)};var x=X;v!==void 0&&v.texture.dispose();const E=h.morphAttributes.position!==void 0,C=h.morphAttributes.normal!==void 0,M=h.morphAttributes.color!==void 0,S=h.morphAttributes.position||[],B=h.morphAttributes.normal||[],F=h.morphAttributes.color||[];let w=0;E===!0&&(w=1),C===!0&&(w=2),M===!0&&(w=3);let P=h.attributes.position.count*w,U=1;P>e.maxTextureSize&&(U=Math.ceil(P/e.maxTextureSize),P=e.maxTextureSize);const N=new Float32Array(P*U*4*_),T=new kx(N,P,U,_);T.type=Ri,T.needsUpdate=!0;const O=w*4;for(let G=0;G<_;G++){const Z=S[G],ce=B[G],ge=F[G],j=P*U*4*G;for(let I=0;I<Z.count;I++){const z=I*O;E===!0&&(o.fromBufferAttribute(Z,I),N[j+z+0]=o.x,N[j+z+1]=o.y,N[j+z+2]=o.z,N[j+z+3]=0),C===!0&&(o.fromBufferAttribute(ce,I),N[j+z+4]=o.x,N[j+z+5]=o.y,N[j+z+6]=o.z,N[j+z+7]=0),M===!0&&(o.fromBufferAttribute(ge,I),N[j+z+8]=o.x,N[j+z+9]=o.y,N[j+z+10]=o.z,N[j+z+11]=ge.itemSize===4?o.w:1)}}v={count:_,texture:T,size:new gt(P,U)},a.set(h,v),h.addEventListener("dispose",X)}if(u.isInstancedMesh===!0&&u.morphTexture!==null)p.getUniforms().setValue(r,"morphTexture",u.morphTexture,n);else{let E=0;for(let M=0;M<d.length;M++)E+=d[M];const C=h.morphTargetsRelative?1:1-E;p.getUniforms().setValue(r,"morphTargetBaseInfluence",C),p.getUniforms().setValue(r,"morphTargetInfluences",d)}p.getUniforms().setValue(r,"morphTargetsTexture",v.texture,n),p.getUniforms().setValue(r,"morphTargetsTextureSize",v.size)}return{update:c}}function QA(r,e,n,a,o){let c=new WeakMap;function u(d){const g=o.render.frame,_=d.geometry,v=e.get(d,_);if(c.get(v)!==g&&(e.update(v),c.set(v,g)),d.isInstancedMesh&&(d.hasEventListener("dispose",p)===!1&&d.addEventListener("dispose",p),c.get(d)!==g&&(n.update(d.instanceMatrix,r.ARRAY_BUFFER),d.instanceColor!==null&&n.update(d.instanceColor,r.ARRAY_BUFFER),c.set(d,g))),d.isSkinnedMesh){const x=d.skeleton;c.get(x)!==g&&(x.update(),c.set(x,g))}return v}function h(){c=new WeakMap}function p(d){const g=d.target;g.removeEventListener("dispose",p),a.releaseStatesOfObject(g),n.remove(g.instanceMatrix),g.instanceColor!==null&&n.remove(g.instanceColor)}return{update:u,dispose:h}}const JA={[Rx]:"LINEAR_TONE_MAPPING",[Cx]:"REINHARD_TONE_MAPPING",[wx]:"CINEON_TONE_MAPPING",[Gp]:"ACES_FILMIC_TONE_MAPPING",[Lx]:"AGX_TONE_MAPPING",[Nx]:"NEUTRAL_TONE_MAPPING",[Dx]:"CUSTOM_TONE_MAPPING"};function jA(r,e,n,a,o,c){const u=new sa(e,n,{type:r,depthBuffer:o,stencilBuffer:c,samples:a?4:0,depthTexture:o?new uo(e,n):void 0}),h=new sa(e,n,{type:Ha,depthBuffer:!1,stencilBuffer:!1}),p=new wi;p.setAttribute("position",new Gi([-1,3,0,-1,-1,0,3,-1,0],3)),p.setAttribute("uv",new Gi([0,2,0,0,2,0],2));const d=new mb({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),g=new En(p,d),_=new Bl(-1,1,1,-1,0,1);let v=null,x=null,E=!1,C,M=null,S=[],B=!1;this.setSize=function(F,w){u.setSize(F,w),h.setSize(F,w);for(let P=0;P<S.length;P++){const U=S[P];U.setSize&&U.setSize(F,w)}},this.setEffects=function(F){S=F,B=S.length>0&&S[0].isRenderPass===!0;const w=u.width,P=u.height;for(let U=0;U<S.length;U++){const N=S[U];N.setSize&&N.setSize(w,P)}},this.begin=function(F,w){if(E||F.toneMapping===aa&&S.length===0)return!1;if(M=w,w!==null){const P=w.width,U=w.height;(u.width!==P||u.height!==U)&&this.setSize(P,U)}return B===!1&&F.setRenderTarget(u),C=F.toneMapping,F.toneMapping=aa,!0},this.hasRenderPass=function(){return B},this.end=function(F,w){F.toneMapping=C,E=!0;let P=u,U=h;for(let N=0;N<S.length;N++){const T=S[N];if(T.enabled!==!1&&(T.render(F,U,P,w),T.needsSwap!==!1)){const O=P;P=U,U=O}}if(v!==F.outputColorSpace||x!==F.toneMapping){v=F.outputColorSpace,x=F.toneMapping,d.defines={},St.getTransfer(v)===Ht&&(d.defines.SRGB_TRANSFER="");const N=JA[x];N&&(d.defines[N]=""),d.needsUpdate=!0}d.uniforms.tDiffuse.value=P.texture,F.setRenderTarget(M),F.render(g,_),M=null,E=!1},this.isCompositing=function(){return E},this.dispose=function(){u.depthTexture&&u.depthTexture.dispose(),u.dispose(),h.dispose(),p.dispose(),d.dispose()}}const cy=new Un,Up=new uo(1,1),uy=new kx,fy=new HE,hy=new $x,ex=[],tx=[],nx=new Float32Array(16),ix=new Float32Array(9),ax=new Float32Array(4);function vo(r,e,n){const a=r[0];if(a<=0||a>0)return r;const o=e*n;let c=ex[o];if(c===void 0&&(c=new Float32Array(o),ex[o]=c),e!==0){a.toArray(c,0);for(let u=1,h=0;u!==e;++u)h+=n,r[u].toArray(c,h)}return c}function Cn(r,e){if(r.length!==e.length)return!1;for(let n=0,a=r.length;n<a;n++)if(r[n]!==e[n])return!1;return!0}function wn(r,e){for(let n=0,a=e.length;n<a;n++)r[n]=e[n]}function Yu(r,e){let n=tx[e];n===void 0&&(n=new Int32Array(e),tx[e]=n);for(let a=0;a!==e;++a)n[a]=r.allocateTextureUnit();return n}function $A(r,e){const n=this.cache;n[0]!==e&&(r.uniform1f(this.addr,e),n[0]=e)}function eR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(r.uniform2f(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Cn(n,e))return;r.uniform2fv(this.addr,e),wn(n,e)}}function tR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(r.uniform3f(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else if(e.r!==void 0)(n[0]!==e.r||n[1]!==e.g||n[2]!==e.b)&&(r.uniform3f(this.addr,e.r,e.g,e.b),n[0]=e.r,n[1]=e.g,n[2]=e.b);else{if(Cn(n,e))return;r.uniform3fv(this.addr,e),wn(n,e)}}function nR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Cn(n,e))return;r.uniform4fv(this.addr,e),wn(n,e)}}function iR(r,e){const n=this.cache,a=e.elements;if(a===void 0){if(Cn(n,e))return;r.uniformMatrix2fv(this.addr,!1,e),wn(n,e)}else{if(Cn(n,a))return;ax.set(a),r.uniformMatrix2fv(this.addr,!1,ax),wn(n,a)}}function aR(r,e){const n=this.cache,a=e.elements;if(a===void 0){if(Cn(n,e))return;r.uniformMatrix3fv(this.addr,!1,e),wn(n,e)}else{if(Cn(n,a))return;ix.set(a),r.uniformMatrix3fv(this.addr,!1,ix),wn(n,a)}}function sR(r,e){const n=this.cache,a=e.elements;if(a===void 0){if(Cn(n,e))return;r.uniformMatrix4fv(this.addr,!1,e),wn(n,e)}else{if(Cn(n,a))return;nx.set(a),r.uniformMatrix4fv(this.addr,!1,nx),wn(n,a)}}function rR(r,e){const n=this.cache;n[0]!==e&&(r.uniform1i(this.addr,e),n[0]=e)}function oR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(r.uniform2i(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Cn(n,e))return;r.uniform2iv(this.addr,e),wn(n,e)}}function lR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(r.uniform3i(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(Cn(n,e))return;r.uniform3iv(this.addr,e),wn(n,e)}}function cR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Cn(n,e))return;r.uniform4iv(this.addr,e),wn(n,e)}}function uR(r,e){const n=this.cache;n[0]!==e&&(r.uniform1ui(this.addr,e),n[0]=e)}function fR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(r.uniform2ui(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(Cn(n,e))return;r.uniform2uiv(this.addr,e),wn(n,e)}}function hR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(r.uniform3ui(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(Cn(n,e))return;r.uniform3uiv(this.addr,e),wn(n,e)}}function dR(r,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(Cn(n,e))return;r.uniform4uiv(this.addr,e),wn(n,e)}}function pR(r,e,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o);let c;this.type===r.SAMPLER_2D_SHADOW?(Up.compareFunction=n.isReversedDepthBuffer()?Qp:Zp,c=Up):c=cy,n.setTexture2D(e||c,o)}function mR(r,e,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o),n.setTexture3D(e||fy,o)}function gR(r,e,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o),n.setTextureCube(e||hy,o)}function _R(r,e,n){const a=this.cache,o=n.allocateTextureUnit();a[0]!==o&&(r.uniform1i(this.addr,o),a[0]=o),n.setTexture2DArray(e||uy,o)}function vR(r){switch(r){case 5126:return $A;case 35664:return eR;case 35665:return tR;case 35666:return nR;case 35674:return iR;case 35675:return aR;case 35676:return sR;case 5124:case 35670:return rR;case 35667:case 35671:return oR;case 35668:case 35672:return lR;case 35669:case 35673:return cR;case 5125:return uR;case 36294:return fR;case 36295:return hR;case 36296:return dR;case 35678:case 36198:case 36298:case 36306:case 35682:return pR;case 35679:case 36299:case 36307:return mR;case 35680:case 36300:case 36308:case 36293:return gR;case 36289:case 36303:case 36311:case 36292:return _R}}function xR(r,e){r.uniform1fv(this.addr,e)}function yR(r,e){const n=vo(e,this.size,2);r.uniform2fv(this.addr,n)}function SR(r,e){const n=vo(e,this.size,3);r.uniform3fv(this.addr,n)}function MR(r,e){const n=vo(e,this.size,4);r.uniform4fv(this.addr,n)}function ER(r,e){const n=vo(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,n)}function bR(r,e){const n=vo(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,n)}function TR(r,e){const n=vo(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,n)}function AR(r,e){r.uniform1iv(this.addr,e)}function RR(r,e){r.uniform2iv(this.addr,e)}function CR(r,e){r.uniform3iv(this.addr,e)}function wR(r,e){r.uniform4iv(this.addr,e)}function DR(r,e){r.uniform1uiv(this.addr,e)}function LR(r,e){r.uniform2uiv(this.addr,e)}function NR(r,e){r.uniform3uiv(this.addr,e)}function UR(r,e){r.uniform4uiv(this.addr,e)}function OR(r,e,n){const a=this.cache,o=e.length,c=Yu(n,o);Cn(a,c)||(r.uniform1iv(this.addr,c),wn(a,c));let u;this.type===r.SAMPLER_2D_SHADOW?u=Up:u=cy;for(let h=0;h!==o;++h)n.setTexture2D(e[h]||u,c[h])}function PR(r,e,n){const a=this.cache,o=e.length,c=Yu(n,o);Cn(a,c)||(r.uniform1iv(this.addr,c),wn(a,c));for(let u=0;u!==o;++u)n.setTexture3D(e[u]||fy,c[u])}function IR(r,e,n){const a=this.cache,o=e.length,c=Yu(n,o);Cn(a,c)||(r.uniform1iv(this.addr,c),wn(a,c));for(let u=0;u!==o;++u)n.setTextureCube(e[u]||hy,c[u])}function BR(r,e,n){const a=this.cache,o=e.length,c=Yu(n,o);Cn(a,c)||(r.uniform1iv(this.addr,c),wn(a,c));for(let u=0;u!==o;++u)n.setTexture2DArray(e[u]||uy,c[u])}function FR(r){switch(r){case 5126:return xR;case 35664:return yR;case 35665:return SR;case 35666:return MR;case 35674:return ER;case 35675:return bR;case 35676:return TR;case 5124:case 35670:return AR;case 35667:case 35671:return RR;case 35668:case 35672:return CR;case 35669:case 35673:return wR;case 5125:return DR;case 36294:return LR;case 36295:return NR;case 36296:return UR;case 35678:case 36198:case 36298:case 36306:case 35682:return OR;case 35679:case 36299:case 36307:return PR;case 35680:case 36300:case 36308:case 36293:return IR;case 36289:case 36303:case 36311:case 36292:return BR}}class zR{constructor(e,n,a){this.id=e,this.addr=a,this.cache=[],this.type=n.type,this.setValue=vR(n.type)}}class HR{constructor(e,n,a){this.id=e,this.addr=a,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=FR(n.type)}}class GR{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,n,a){const o=this.seq;for(let c=0,u=o.length;c!==u;++c){const h=o[c];h.setValue(e,n[h.id],a)}}}const Fd=/(\w+)(\])?(\[|\.)?/g;function sx(r,e){r.seq.push(e),r.map[e.id]=e}function VR(r,e,n){const a=r.name,o=a.length;for(Fd.lastIndex=0;;){const c=Fd.exec(a),u=Fd.lastIndex;let h=c[1];const p=c[2]==="]",d=c[3];if(p&&(h=h|0),d===void 0||d==="["&&u+2===o){sx(n,d===void 0?new zR(h,r,e):new HR(h,r,e));break}else{let _=n.map[h];_===void 0&&(_=new GR(h),sx(n,_)),n=_}}}class Lu{constructor(e,n){this.seq=[],this.map={};const a=e.getProgramParameter(n,e.ACTIVE_UNIFORMS);for(let u=0;u<a;++u){const h=e.getActiveUniform(n,u),p=e.getUniformLocation(n,h.name);VR(h,p,this)}const o=[],c=[];for(const u of this.seq)u.type===e.SAMPLER_2D_SHADOW||u.type===e.SAMPLER_CUBE_SHADOW||u.type===e.SAMPLER_2D_ARRAY_SHADOW?o.push(u):c.push(u);o.length>0&&(this.seq=o.concat(c))}setValue(e,n,a,o){const c=this.map[n];c!==void 0&&c.setValue(e,a,o)}setOptional(e,n,a){const o=n[a];o!==void 0&&this.setValue(e,a,o)}static upload(e,n,a,o){for(let c=0,u=n.length;c!==u;++c){const h=n[c],p=a[h.id];p.needsUpdate!==!1&&h.setValue(e,p.value,o)}}static seqWithValue(e,n){const a=[];for(let o=0,c=e.length;o!==c;++o){const u=e[o];u.id in n&&a.push(u)}return a}}function rx(r,e,n){const a=r.createShader(e);return r.shaderSource(a,n),r.compileShader(a),a}const kR=37297;let XR=0;function WR(r,e){const n=r.split(`
`),a=[],o=Math.max(e-6,0),c=Math.min(e+6,n.length);for(let u=o;u<c;u++){const h=u+1;a.push(`${h===e?">":" "} ${h}: ${n[u]}`)}return a.join(`
`)}const ox=new lt;function qR(r){St._getMatrix(ox,St.workingColorSpace,r);const e=`mat3( ${ox.elements.map(n=>n.toFixed(4))} )`;switch(St.getTransfer(r)){case Iu:return[e,"LinearTransferOETF"];case Ht:return[e,"sRGBTransferOETF"];default:return Ke("WebGLProgram: Unsupported color space: ",r),[e,"LinearTransferOETF"]}}function lx(r,e,n){const a=r.getShaderParameter(e,r.COMPILE_STATUS),c=(r.getShaderInfoLog(e)||"").trim();if(a&&c==="")return"";const u=/ERROR: 0:(\d+)/.exec(c);if(u){const h=parseInt(u[1]);return n.toUpperCase()+`

`+c+`

`+WR(r.getShaderSource(e),h)}else return c}function YR(r,e){const n=qR(e);return[`vec4 ${r}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}const KR={[Rx]:"Linear",[Cx]:"Reinhard",[wx]:"Cineon",[Gp]:"ACESFilmic",[Lx]:"AgX",[Nx]:"Neutral",[Dx]:"Custom"};function ZR(r,e){const n=KR[e];return n===void 0?(Ke("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+r+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+r+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const Mu=new $;function QR(){St.getLuminanceCoefficients(Mu);const r=Mu.x.toFixed(4),e=Mu.y.toFixed(4),n=Mu.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${e}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function JR(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(bl).join(`
`)}function jR(r){const e=[];for(const n in r){const a=r[n];a!==!1&&e.push("#define "+n+" "+a)}return e.join(`
`)}function $R(r,e){const n={},a=r.getProgramParameter(e,r.ACTIVE_ATTRIBUTES);for(let o=0;o<a;o++){const c=r.getActiveAttrib(e,o),u=c.name;let h=1;c.type===r.FLOAT_MAT2&&(h=2),c.type===r.FLOAT_MAT3&&(h=3),c.type===r.FLOAT_MAT4&&(h=4),n[u]={type:c.type,location:r.getAttribLocation(e,u),locationSize:h}}return n}function bl(r){return r!==""}function cx(r,e){const n=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function ux(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const eC=/^[ \t]*#include +<([\w\d./]+)>/gm;function Op(r){return r.replace(eC,nC)}const tC=new Map;function nC(r,e){let n=ht[e];if(n===void 0){const a=tC.get(e);if(a!==void 0)n=ht[a],Ke('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,a);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return Op(n)}const iC=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function fx(r){return r.replace(iC,aC)}function aC(r,e,n,a){let o="";for(let c=parseInt(e);c<parseInt(n);c++)o+=a.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return o}function hx(r){let e=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const sC={[bu]:"SHADOWMAP_TYPE_PCF",[Ml]:"SHADOWMAP_TYPE_VSM"};function rC(r){return sC[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const oC={[ar]:"ENVMAP_TYPE_CUBE",[oo]:"ENVMAP_TYPE_CUBE",[Vu]:"ENVMAP_TYPE_CUBE_UV"};function lC(r){return r.envMap===!1?"ENVMAP_TYPE_CUBE":oC[r.envMapMode]||"ENVMAP_TYPE_CUBE"}const cC={[oo]:"ENVMAP_MODE_REFRACTION"};function uC(r){return r.envMap===!1?"ENVMAP_MODE_REFLECTION":cC[r.envMapMode]||"ENVMAP_MODE_REFLECTION"}const fC={[Hp]:"ENVMAP_BLENDING_MULTIPLY",[eE]:"ENVMAP_BLENDING_MIX",[tE]:"ENVMAP_BLENDING_ADD"};function hC(r){return r.envMap===!1?"ENVMAP_BLENDING_NONE":fC[r.combine]||"ENVMAP_BLENDING_NONE"}function dC(r){const e=r.envMapCubeUVHeight;if(e===null)return null;const n=Math.log2(e)-2,a=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,n),112)),texelHeight:a,maxMip:n}}function pC(r,e,n,a){const o=r.getContext(),c=n.defines;let u=n.vertexShader,h=n.fragmentShader;const p=rC(n),d=lC(n),g=uC(n),_=hC(n),v=dC(n),x=JR(n),E=jR(c),C=o.createProgram();let M,S,B=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(M=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,E].filter(bl).join(`
`),M.length>0&&(M+=`
`),S=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,E].filter(bl).join(`
`),S.length>0&&(S+=`
`)):(M=[hx(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,E,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+g:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexNormals?"#define HAS_NORMAL":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(bl).join(`
`),S=[hx(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,E,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+d:"",n.envMap?"#define "+g:"",n.envMap?"#define "+_:"",v?"#define CUBEUV_TEXEL_WIDTH "+v.texelWidth:"",v?"#define CUBEUV_TEXEL_HEIGHT "+v.texelHeight:"",v?"#define CUBEUV_MAX_MIP "+v.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==aa?"#define TONE_MAPPING":"",n.toneMapping!==aa?ht.tonemapping_pars_fragment:"",n.toneMapping!==aa?ZR("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",ht.colorspace_pars_fragment,YR("linearToOutputTexel",n.outputColorSpace),QR(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(bl).join(`
`)),u=Op(u),u=cx(u,n),u=ux(u,n),h=Op(h),h=cx(h,n),h=ux(h,n),u=fx(u),h=fx(h),n.isRawShaderMaterial!==!0&&(B=`#version 300 es
`,M=[x,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+M,S=["#define varying in",n.glslVersion===uv?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===uv?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);const F=B+M+u,w=B+S+h,P=rx(o,o.VERTEX_SHADER,F),U=rx(o,o.FRAGMENT_SHADER,w);o.attachShader(C,P),o.attachShader(C,U),n.index0AttributeName!==void 0?o.bindAttribLocation(C,0,n.index0AttributeName):n.hasPositionAttribute===!0&&o.bindAttribLocation(C,0,"position"),o.linkProgram(C);function N(G){if(r.debug.checkShaderErrors){const Z=o.getProgramInfoLog(C)||"",ce=o.getShaderInfoLog(P)||"",ge=o.getShaderInfoLog(U)||"",j=Z.trim(),I=ce.trim(),z=ge.trim();let Q=!0,de=!0;if(o.getProgramParameter(C,o.LINK_STATUS)===!1)if(Q=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(o,C,P,U);else{const ve=lx(o,P,"vertex"),D=lx(o,U,"fragment");at("WebGLProgram: Shader Error "+o.getError()+" - VALIDATE_STATUS "+o.getProgramParameter(C,o.VALIDATE_STATUS)+`

Material Name: `+G.name+`
Material Type: `+G.type+`

Program Info Log: `+j+`
`+ve+`
`+D)}else j!==""?Ke("WebGLProgram: Program Info Log:",j):(I===""||z==="")&&(de=!1);de&&(G.diagnostics={runnable:Q,programLog:j,vertexShader:{log:I,prefix:M},fragmentShader:{log:z,prefix:S}})}o.deleteShader(P),o.deleteShader(U),T=new Lu(o,C),O=$R(o,C)}let T;this.getUniforms=function(){return T===void 0&&N(this),T};let O;this.getAttributes=function(){return O===void 0&&N(this),O};let X=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return X===!1&&(X=o.getProgramParameter(C,kR)),X},this.destroy=function(){a.releaseStatesOfProgram(this),o.deleteProgram(C),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=XR++,this.cacheKey=e,this.usedTimes=1,this.program=C,this.vertexShader=P,this.fragmentShader=U,this}let mC=0;class gC{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,n,a){const o=this._getShaderCacheForMaterial(e);return o.has(n)===!1&&(o.add(n),n.usedTimes++),o.has(a)===!1&&(o.add(a),a.usedTimes++),this}remove(e){const n=this.materialCache.get(e);for(const a of n)a.usedTimes--,a.usedTimes===0&&this.shaderCache.delete(a.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const n=this.materialCache;let a=n.get(e);return a===void 0&&(a=new Set,n.set(e,a)),a}_getShaderStage(e){const n=this.shaderCache;let a=n.get(e);return a===void 0&&(a=new _C(e),n.set(e,a)),a}}class _C{constructor(e){this.id=mC++,this.code=e,this.usedTimes=0}}function vC(r){return r===sr||r===Uu||r===Ou}function xC(r,e,n,a,o,c){const u=new Xx,h=new gC,p=new Set,d=[],g=new Map,_=a.logarithmicDepthBuffer;let v=a.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function E(T){return p.add(T),T===0?"uv":`uv${T}`}function C(T,O,X,G,Z,ce){const ge=G.fog,j=Z.geometry,I=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?G.environment:null,z=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,Q=e.get(T.envMap||I,z),de=Q&&Q.mapping===Vu?Q.image.height:null,ve=x[T.type];T.precision!==null&&(v=a.getMaxPrecision(T.precision),v!==T.precision&&Ke("WebGLProgram.getParameters:",T.precision,"not supported, using",v,"instead."));const D=j.morphAttributes.position||j.morphAttributes.normal||j.morphAttributes.color,Y=D!==void 0?D.length:0;let Ee=0;j.morphAttributes.position!==void 0&&(Ee=1),j.morphAttributes.normal!==void 0&&(Ee=2),j.morphAttributes.color!==void 0&&(Ee=3);let Re,Pe,ae,ye;if(ve){const Ge=ea[ve];Re=Ge.vertexShader,Pe=Ge.fragmentShader}else{Re=T.vertexShader,Pe=T.fragmentShader;const Ge=h.getVertexShaderStage(T),tn=h.getFragmentShaderStage(T);h.update(T,Ge,tn),ae=Ge.id,ye=tn.id}const Me=r.getRenderTarget(),ze=r.state.buffers.depth.getReversed(),it=Z.isInstancedMesh===!0,je=Z.isBatchedMesh===!0,Jt=!!T.map,pt=!!T.matcap,Tt=!!Q,At=!!T.aoMap,_t=!!T.lightMap,rn=!!T.bumpMap&&T.wireframe===!1,on=!!T.normalMap,ln=!!T.displacementMap,hn=!!T.emissiveMap,Qt=!!T.metalnessMap,cn=!!T.roughnessMap,q=T.anisotropy>0,kt=T.clearcoat>0,Lt=T.dispersion>0,L=T.iridescence>0,b=T.sheen>0,J=T.transmission>0,se=q&&!!T.anisotropyMap,fe=kt&&!!T.clearcoatMap,be=kt&&!!T.clearcoatNormalMap,we=kt&&!!T.clearcoatRoughnessMap,ue=L&&!!T.iridescenceMap,he=L&&!!T.iridescenceThicknessMap,Ae=b&&!!T.sheenColorMap,Be=b&&!!T.sheenRoughnessMap,Ne=!!T.specularMap,De=!!T.specularColorMap,Ze=!!T.specularIntensityMap,$e=J&&!!T.transmissionMap,rt=J&&!!T.thicknessMap,k=!!T.gradientMap,Te=!!T.alphaMap,me=T.alphaTest>0,Ce=!!T.alphaHash,Ie=!!T.extensions;let Se=aa;T.toneMapped&&(Me===null||Me.isXRRenderTarget===!0)&&(Se=r.toneMapping);const We={shaderID:ve,shaderType:T.type,shaderName:T.name,vertexShader:Re,fragmentShader:Pe,defines:T.defines,customVertexShaderID:ae,customFragmentShaderID:ye,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:v,batching:je,batchingColor:je&&Z._colorsTexture!==null,instancing:it,instancingColor:it&&Z.instanceColor!==null,instancingMorph:it&&Z.morphTexture!==null,outputColorSpace:Me===null?r.outputColorSpace:Me.isXRRenderTarget===!0?Me.texture.colorSpace:St.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:Jt,matcap:pt,envMap:Tt,envMapMode:Tt&&Q.mapping,envMapCubeUVHeight:de,aoMap:At,lightMap:_t,bumpMap:rn,normalMap:on,displacementMap:ln,emissiveMap:hn,normalMapObjectSpace:on&&T.normalMapType===rE,normalMapTangentSpace:on&&T.normalMapType===Pu,packedNormalMap:on&&T.normalMapType===Pu&&vC(T.normalMap.format),metalnessMap:Qt,roughnessMap:cn,anisotropy:q,anisotropyMap:se,clearcoat:kt,clearcoatMap:fe,clearcoatNormalMap:be,clearcoatRoughnessMap:we,dispersion:Lt,iridescence:L,iridescenceMap:ue,iridescenceThicknessMap:he,sheen:b,sheenColorMap:Ae,sheenRoughnessMap:Be,specularMap:Ne,specularColorMap:De,specularIntensityMap:Ze,transmission:J,transmissionMap:$e,thicknessMap:rt,gradientMap:k,opaque:T.transparent===!1&&T.blending===no&&T.alphaToCoverage===!1,alphaMap:Te,alphaTest:me,alphaHash:Ce,combine:T.combine,mapUv:Jt&&E(T.map.channel),aoMapUv:At&&E(T.aoMap.channel),lightMapUv:_t&&E(T.lightMap.channel),bumpMapUv:rn&&E(T.bumpMap.channel),normalMapUv:on&&E(T.normalMap.channel),displacementMapUv:ln&&E(T.displacementMap.channel),emissiveMapUv:hn&&E(T.emissiveMap.channel),metalnessMapUv:Qt&&E(T.metalnessMap.channel),roughnessMapUv:cn&&E(T.roughnessMap.channel),anisotropyMapUv:se&&E(T.anisotropyMap.channel),clearcoatMapUv:fe&&E(T.clearcoatMap.channel),clearcoatNormalMapUv:be&&E(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:we&&E(T.clearcoatRoughnessMap.channel),iridescenceMapUv:ue&&E(T.iridescenceMap.channel),iridescenceThicknessMapUv:he&&E(T.iridescenceThicknessMap.channel),sheenColorMapUv:Ae&&E(T.sheenColorMap.channel),sheenRoughnessMapUv:Be&&E(T.sheenRoughnessMap.channel),specularMapUv:Ne&&E(T.specularMap.channel),specularColorMapUv:De&&E(T.specularColorMap.channel),specularIntensityMapUv:Ze&&E(T.specularIntensityMap.channel),transmissionMapUv:$e&&E(T.transmissionMap.channel),thicknessMapUv:rt&&E(T.thicknessMap.channel),alphaMapUv:Te&&E(T.alphaMap.channel),vertexTangents:!!j.attributes.tangent&&(on||q),vertexNormals:!!j.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!j.attributes.color&&j.attributes.color.itemSize===4,pointsUvs:Z.isPoints===!0&&!!j.attributes.uv&&(Jt||Te),fog:!!ge,useFog:T.fog===!0,fogExp2:!!ge&&ge.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||j.attributes.normal===void 0&&on===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:_,reversedDepthBuffer:ze,skinning:Z.isSkinnedMesh===!0,hasPositionAttribute:j.attributes.position!==void 0,morphTargets:j.morphAttributes.position!==void 0,morphNormals:j.morphAttributes.normal!==void 0,morphColors:j.morphAttributes.color!==void 0,morphTargetsCount:Y,morphTextureStride:Ee,numDirLights:O.directional.length,numPointLights:O.point.length,numSpotLights:O.spot.length,numSpotLightMaps:O.spotLightMap.length,numRectAreaLights:O.rectArea.length,numHemiLights:O.hemi.length,numDirLightShadows:O.directionalShadowMap.length,numPointLightShadows:O.pointShadowMap.length,numSpotLightShadows:O.spotShadowMap.length,numSpotLightShadowsWithMaps:O.numSpotLightShadowsWithMaps,numLightProbes:O.numLightProbes,numLightProbeGrids:ce.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:T.dithering,shadowMapEnabled:r.shadowMap.enabled&&X.length>0,shadowMapType:r.shadowMap.type,toneMapping:Se,decodeVideoTexture:Jt&&T.map.isVideoTexture===!0&&St.getTransfer(T.map.colorSpace)===Ht,decodeVideoTextureEmissive:hn&&T.emissiveMap.isVideoTexture===!0&&St.getTransfer(T.emissiveMap.colorSpace)===Ht,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===ta,flipSided:T.side===qn,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:Ie&&T.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ie&&T.extensions.multiDraw===!0||je)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return We.vertexUv1s=p.has(1),We.vertexUv2s=p.has(2),We.vertexUv3s=p.has(3),p.clear(),We}function M(T){const O=[];if(T.shaderID?O.push(T.shaderID):(O.push(T.customVertexShaderID),O.push(T.customFragmentShaderID)),T.defines!==void 0)for(const X in T.defines)O.push(X),O.push(T.defines[X]);return T.isRawShaderMaterial===!1&&(S(O,T),B(O,T),O.push(r.outputColorSpace)),O.push(T.customProgramCacheKey),O.join()}function S(T,O){T.push(O.precision),T.push(O.outputColorSpace),T.push(O.envMapMode),T.push(O.envMapCubeUVHeight),T.push(O.mapUv),T.push(O.alphaMapUv),T.push(O.lightMapUv),T.push(O.aoMapUv),T.push(O.bumpMapUv),T.push(O.normalMapUv),T.push(O.displacementMapUv),T.push(O.emissiveMapUv),T.push(O.metalnessMapUv),T.push(O.roughnessMapUv),T.push(O.anisotropyMapUv),T.push(O.clearcoatMapUv),T.push(O.clearcoatNormalMapUv),T.push(O.clearcoatRoughnessMapUv),T.push(O.iridescenceMapUv),T.push(O.iridescenceThicknessMapUv),T.push(O.sheenColorMapUv),T.push(O.sheenRoughnessMapUv),T.push(O.specularMapUv),T.push(O.specularColorMapUv),T.push(O.specularIntensityMapUv),T.push(O.transmissionMapUv),T.push(O.thicknessMapUv),T.push(O.combine),T.push(O.fogExp2),T.push(O.sizeAttenuation),T.push(O.morphTargetsCount),T.push(O.morphAttributeCount),T.push(O.numDirLights),T.push(O.numPointLights),T.push(O.numSpotLights),T.push(O.numSpotLightMaps),T.push(O.numHemiLights),T.push(O.numRectAreaLights),T.push(O.numDirLightShadows),T.push(O.numPointLightShadows),T.push(O.numSpotLightShadows),T.push(O.numSpotLightShadowsWithMaps),T.push(O.numLightProbes),T.push(O.shadowMapType),T.push(O.toneMapping),T.push(O.numClippingPlanes),T.push(O.numClipIntersection),T.push(O.depthPacking)}function B(T,O){u.disableAll(),O.instancing&&u.enable(0),O.instancingColor&&u.enable(1),O.instancingMorph&&u.enable(2),O.matcap&&u.enable(3),O.envMap&&u.enable(4),O.normalMapObjectSpace&&u.enable(5),O.normalMapTangentSpace&&u.enable(6),O.clearcoat&&u.enable(7),O.iridescence&&u.enable(8),O.alphaTest&&u.enable(9),O.vertexColors&&u.enable(10),O.vertexAlphas&&u.enable(11),O.vertexUv1s&&u.enable(12),O.vertexUv2s&&u.enable(13),O.vertexUv3s&&u.enable(14),O.vertexTangents&&u.enable(15),O.anisotropy&&u.enable(16),O.alphaHash&&u.enable(17),O.batching&&u.enable(18),O.dispersion&&u.enable(19),O.batchingColor&&u.enable(20),O.gradientMap&&u.enable(21),O.packedNormalMap&&u.enable(22),O.vertexNormals&&u.enable(23),T.push(u.mask),u.disableAll(),O.fog&&u.enable(0),O.useFog&&u.enable(1),O.flatShading&&u.enable(2),O.logarithmicDepthBuffer&&u.enable(3),O.reversedDepthBuffer&&u.enable(4),O.skinning&&u.enable(5),O.morphTargets&&u.enable(6),O.morphNormals&&u.enable(7),O.morphColors&&u.enable(8),O.premultipliedAlpha&&u.enable(9),O.shadowMapEnabled&&u.enable(10),O.doubleSided&&u.enable(11),O.flipSided&&u.enable(12),O.useDepthPacking&&u.enable(13),O.dithering&&u.enable(14),O.transmission&&u.enable(15),O.sheen&&u.enable(16),O.opaque&&u.enable(17),O.pointsUvs&&u.enable(18),O.decodeVideoTexture&&u.enable(19),O.decodeVideoTextureEmissive&&u.enable(20),O.alphaToCoverage&&u.enable(21),O.numLightProbeGrids>0&&u.enable(22),O.hasPositionAttribute&&u.enable(23),T.push(u.mask)}function F(T){const O=x[T.type];let X;if(O){const G=ea[O];X=hb.clone(G.uniforms)}else X=T.uniforms;return X}function w(T,O){let X=g.get(O);return X!==void 0?++X.usedTimes:(X=new pC(r,O,T,o),d.push(X),g.set(O,X)),X}function P(T){if(--T.usedTimes===0){const O=d.indexOf(T);d[O]=d[d.length-1],d.pop(),g.delete(T.cacheKey),T.destroy()}}function U(T){h.remove(T)}function N(){h.dispose()}return{getParameters:C,getProgramCacheKey:M,getUniforms:F,acquireProgram:w,releaseProgram:P,releaseShaderCache:U,programs:d,dispose:N}}function yC(){let r=new WeakMap;function e(u){return r.has(u)}function n(u){let h=r.get(u);return h===void 0&&(h={},r.set(u,h)),h}function a(u){r.delete(u)}function o(u,h,p){r.get(u)[h]=p}function c(){r=new WeakMap}return{has:e,get:n,remove:a,update:o,dispose:c}}function SC(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.materialVariant!==e.materialVariant?r.materialVariant-e.materialVariant:r.z!==e.z?r.z-e.z:r.id-e.id}function dx(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function px(){const r=[];let e=0;const n=[],a=[],o=[];function c(){e=0,n.length=0,a.length=0,o.length=0}function u(v){let x=0;return v.isInstancedMesh&&(x+=2),v.isSkinnedMesh&&(x+=1),x}function h(v,x,E,C,M,S){let B=r[e];return B===void 0?(B={id:v.id,object:v,geometry:x,material:E,materialVariant:u(v),groupOrder:C,renderOrder:v.renderOrder,z:M,group:S},r[e]=B):(B.id=v.id,B.object=v,B.geometry=x,B.material=E,B.materialVariant=u(v),B.groupOrder=C,B.renderOrder=v.renderOrder,B.z=M,B.group=S),e++,B}function p(v,x,E,C,M,S){const B=h(v,x,E,C,M,S);E.transmission>0?a.push(B):E.transparent===!0?o.push(B):n.push(B)}function d(v,x,E,C,M,S){const B=h(v,x,E,C,M,S);E.transmission>0?a.unshift(B):E.transparent===!0?o.unshift(B):n.unshift(B)}function g(v,x,E){n.length>1&&n.sort(v||SC),a.length>1&&a.sort(x||dx),o.length>1&&o.sort(x||dx),E&&(n.reverse(),a.reverse(),o.reverse())}function _(){for(let v=e,x=r.length;v<x;v++){const E=r[v];if(E.id===null)break;E.id=null,E.object=null,E.geometry=null,E.material=null,E.group=null}}return{opaque:n,transmissive:a,transparent:o,init:c,push:p,unshift:d,finish:_,sort:g}}function MC(){let r=new WeakMap;function e(a,o){const c=r.get(a);let u;return c===void 0?(u=new px,r.set(a,[u])):o>=c.length?(u=new px,c.push(u)):u=c[o],u}function n(){r=new WeakMap}return{get:e,dispose:n}}function EC(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let n;switch(e.type){case"DirectionalLight":n={direction:new $,color:new st};break;case"SpotLight":n={position:new $,direction:new $,color:new st,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new $,color:new st,distance:0,decay:0};break;case"HemisphereLight":n={direction:new $,skyColor:new st,groundColor:new st};break;case"RectAreaLight":n={color:new st,position:new $,halfWidth:new $,halfHeight:new $};break}return r[e.id]=n,n}}}function bC(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let n;switch(e.type){case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new gt};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new gt};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new gt,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[e.id]=n,n}}}let TC=0;function AC(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function RC(r){const e=new EC,n=bC(),a={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)a.probe.push(new $);const o=new $,c=new dt,u=new dt;function h(d){let g=0,_=0,v=0;for(let O=0;O<9;O++)a.probe[O].set(0,0,0);let x=0,E=0,C=0,M=0,S=0,B=0,F=0,w=0,P=0,U=0,N=0;d.sort(AC);for(let O=0,X=d.length;O<X;O++){const G=d[O],Z=G.color,ce=G.intensity,ge=G.distance;let j=null;if(G.shadow&&G.shadow.map&&(G.shadow.map.texture.format===sr?j=G.shadow.map.texture:j=G.shadow.map.depthTexture||G.shadow.map.texture),G.isAmbientLight)g+=Z.r*ce,_+=Z.g*ce,v+=Z.b*ce;else if(G.isLightProbe){for(let I=0;I<9;I++)a.probe[I].addScaledVector(G.sh.coefficients[I],ce);N++}else if(G.isDirectionalLight){const I=e.get(G);if(I.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){const z=G.shadow,Q=n.get(G);Q.shadowIntensity=z.intensity,Q.shadowBias=z.bias,Q.shadowNormalBias=z.normalBias,Q.shadowRadius=z.radius,Q.shadowMapSize=z.mapSize,a.directionalShadow[x]=Q,a.directionalShadowMap[x]=j,a.directionalShadowMatrix[x]=G.shadow.matrix,B++}a.directional[x]=I,x++}else if(G.isSpotLight){const I=e.get(G);I.position.setFromMatrixPosition(G.matrixWorld),I.color.copy(Z).multiplyScalar(ce),I.distance=ge,I.coneCos=Math.cos(G.angle),I.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),I.decay=G.decay,a.spot[C]=I;const z=G.shadow;if(G.map&&(a.spotLightMap[P]=G.map,P++,z.updateMatrices(G),G.castShadow&&U++),a.spotLightMatrix[C]=z.matrix,G.castShadow){const Q=n.get(G);Q.shadowIntensity=z.intensity,Q.shadowBias=z.bias,Q.shadowNormalBias=z.normalBias,Q.shadowRadius=z.radius,Q.shadowMapSize=z.mapSize,a.spotShadow[C]=Q,a.spotShadowMap[C]=j,w++}C++}else if(G.isRectAreaLight){const I=e.get(G);I.color.copy(Z).multiplyScalar(ce),I.halfWidth.set(G.width*.5,0,0),I.halfHeight.set(0,G.height*.5,0),a.rectArea[M]=I,M++}else if(G.isPointLight){const I=e.get(G);if(I.color.copy(G.color).multiplyScalar(G.intensity),I.distance=G.distance,I.decay=G.decay,G.castShadow){const z=G.shadow,Q=n.get(G);Q.shadowIntensity=z.intensity,Q.shadowBias=z.bias,Q.shadowNormalBias=z.normalBias,Q.shadowRadius=z.radius,Q.shadowMapSize=z.mapSize,Q.shadowCameraNear=z.camera.near,Q.shadowCameraFar=z.camera.far,a.pointShadow[E]=Q,a.pointShadowMap[E]=j,a.pointShadowMatrix[E]=G.shadow.matrix,F++}a.point[E]=I,E++}else if(G.isHemisphereLight){const I=e.get(G);I.skyColor.copy(G.color).multiplyScalar(ce),I.groundColor.copy(G.groundColor).multiplyScalar(ce),a.hemi[S]=I,S++}}M>0&&(r.has("OES_texture_float_linear")===!0?(a.rectAreaLTC1=Oe.LTC_FLOAT_1,a.rectAreaLTC2=Oe.LTC_FLOAT_2):(a.rectAreaLTC1=Oe.LTC_HALF_1,a.rectAreaLTC2=Oe.LTC_HALF_2)),a.ambient[0]=g,a.ambient[1]=_,a.ambient[2]=v;const T=a.hash;(T.directionalLength!==x||T.pointLength!==E||T.spotLength!==C||T.rectAreaLength!==M||T.hemiLength!==S||T.numDirectionalShadows!==B||T.numPointShadows!==F||T.numSpotShadows!==w||T.numSpotMaps!==P||T.numLightProbes!==N)&&(a.directional.length=x,a.spot.length=C,a.rectArea.length=M,a.point.length=E,a.hemi.length=S,a.directionalShadow.length=B,a.directionalShadowMap.length=B,a.pointShadow.length=F,a.pointShadowMap.length=F,a.spotShadow.length=w,a.spotShadowMap.length=w,a.directionalShadowMatrix.length=B,a.pointShadowMatrix.length=F,a.spotLightMatrix.length=w+P-U,a.spotLightMap.length=P,a.numSpotLightShadowsWithMaps=U,a.numLightProbes=N,T.directionalLength=x,T.pointLength=E,T.spotLength=C,T.rectAreaLength=M,T.hemiLength=S,T.numDirectionalShadows=B,T.numPointShadows=F,T.numSpotShadows=w,T.numSpotMaps=P,T.numLightProbes=N,a.version=TC++)}function p(d,g){let _=0,v=0,x=0,E=0,C=0;const M=g.matrixWorldInverse;for(let S=0,B=d.length;S<B;S++){const F=d[S];if(F.isDirectionalLight){const w=a.directional[_];w.direction.setFromMatrixPosition(F.matrixWorld),o.setFromMatrixPosition(F.target.matrixWorld),w.direction.sub(o),w.direction.transformDirection(M),_++}else if(F.isSpotLight){const w=a.spot[x];w.position.setFromMatrixPosition(F.matrixWorld),w.position.applyMatrix4(M),w.direction.setFromMatrixPosition(F.matrixWorld),o.setFromMatrixPosition(F.target.matrixWorld),w.direction.sub(o),w.direction.transformDirection(M),x++}else if(F.isRectAreaLight){const w=a.rectArea[E];w.position.setFromMatrixPosition(F.matrixWorld),w.position.applyMatrix4(M),u.identity(),c.copy(F.matrixWorld),c.premultiply(M),u.extractRotation(c),w.halfWidth.set(F.width*.5,0,0),w.halfHeight.set(0,F.height*.5,0),w.halfWidth.applyMatrix4(u),w.halfHeight.applyMatrix4(u),E++}else if(F.isPointLight){const w=a.point[v];w.position.setFromMatrixPosition(F.matrixWorld),w.position.applyMatrix4(M),v++}else if(F.isHemisphereLight){const w=a.hemi[C];w.direction.setFromMatrixPosition(F.matrixWorld),w.direction.transformDirection(M),C++}}}return{setup:h,setupView:p,state:a}}function mx(r){const e=new RC(r),n=[],a=[],o=[];function c(v){_.camera=v,n.length=0,a.length=0,o.length=0}function u(v){n.push(v)}function h(v){a.push(v)}function p(v){o.push(v)}function d(){e.setup(n)}function g(v){e.setupView(n,v)}const _={lightsArray:n,shadowsArray:a,lightProbeGridArray:o,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:_,setupLights:d,setupLightsView:g,pushLight:u,pushShadow:h,pushLightProbeGrid:p}}function CC(r){let e=new WeakMap;function n(o,c=0){const u=e.get(o);let h;return u===void 0?(h=new mx(r),e.set(o,[h])):c>=u.length?(h=new mx(r),u.push(h)):h=u[c],h}function a(){e=new WeakMap}return{get:n,dispose:a}}const wC=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,DC=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,LC=[new $(1,0,0),new $(-1,0,0),new $(0,1,0),new $(0,-1,0),new $(0,0,1),new $(0,0,-1)],NC=[new $(0,-1,0),new $(0,-1,0),new $(0,0,1),new $(0,0,-1),new $(0,-1,0),new $(0,-1,0)],gx=new dt,yl=new $,zd=new $;function UC(r,e,n){let a=new nm;const o=new gt,c=new gt,u=new Yt,h=new _b,p=new vb,d={},g=n.maxTextureSize,_={[za]:qn,[qn]:za,[ta]:ta},v=new oa({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new gt},radius:{value:4}},vertexShader:wC,fragmentShader:DC}),x=v.clone();x.defines.HORIZONTAL_PASS=1;const E=new wi;E.setAttribute("position",new Yn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const C=new En(E,v),M=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=bu;let S=this.type;this.render=function(U,N,T){if(M.enabled===!1||M.autoUpdate===!1&&M.needsUpdate===!1||U.length===0)return;this.type===PM&&(Ke("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=bu);const O=r.getRenderTarget(),X=r.getActiveCubeFace(),G=r.getActiveMipmapLevel(),Z=r.state;Z.setBlending(Ba),Z.buffers.depth.getReversed()===!0?Z.buffers.color.setClear(0,0,0,0):Z.buffers.color.setClear(1,1,1,1),Z.buffers.depth.setTest(!0),Z.setScissorTest(!1);const ce=S!==this.type;ce&&N.traverse(function(ge){ge.material&&(Array.isArray(ge.material)?ge.material.forEach(j=>j.needsUpdate=!0):ge.material.needsUpdate=!0)});for(let ge=0,j=U.length;ge<j;ge++){const I=U[ge],z=I.shadow;if(z===void 0){Ke("WebGLShadowMap:",I,"has no shadow.");continue}if(z.autoUpdate===!1&&z.needsUpdate===!1)continue;o.copy(z.mapSize);const Q=z.getFrameExtents();o.multiply(Q),c.copy(z.mapSize),(o.x>g||o.y>g)&&(o.x>g&&(c.x=Math.floor(g/Q.x),o.x=c.x*Q.x,z.mapSize.x=c.x),o.y>g&&(c.y=Math.floor(g/Q.y),o.y=c.y*Q.y,z.mapSize.y=c.y));const de=r.state.buffers.depth.getReversed();if(z.camera._reversedDepth=de,z.map===null||ce===!0){if(z.map!==null&&(z.map.depthTexture!==null&&(z.map.depthTexture.dispose(),z.map.depthTexture=null),z.map.dispose()),this.type===Ml){if(I.isPointLight){Ke("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}z.map=new sa(o.x,o.y,{format:sr,type:Ha,minFilter:Rn,magFilter:Rn,generateMipmaps:!1}),z.map.texture.name=I.name+".shadowMap",z.map.depthTexture=new uo(o.x,o.y,Ri),z.map.depthTexture.name=I.name+".shadowMapDepth",z.map.depthTexture.format=Ga,z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=An,z.map.depthTexture.magFilter=An}else I.isPointLight?(z.map=new ly(o.x),z.map.depthTexture=new ub(o.x,ra)):(z.map=new sa(o.x,o.y),z.map.depthTexture=new uo(o.x,o.y,ra)),z.map.depthTexture.name=I.name+".shadowMap",z.map.depthTexture.format=Ga,this.type===bu?(z.map.depthTexture.compareFunction=de?Qp:Zp,z.map.depthTexture.minFilter=Rn,z.map.depthTexture.magFilter=Rn):(z.map.depthTexture.compareFunction=null,z.map.depthTexture.minFilter=An,z.map.depthTexture.magFilter=An);z.camera.updateProjectionMatrix()}const ve=z.map.isWebGLCubeRenderTarget?6:1;for(let D=0;D<ve;D++){if(z.map.isWebGLCubeRenderTarget)r.setRenderTarget(z.map,D),r.clear();else{D===0&&(r.setRenderTarget(z.map),r.clear());const Y=z.getViewport(D);u.set(c.x*Y.x,c.y*Y.y,c.x*Y.z,c.y*Y.w),Z.viewport(u)}if(I.isPointLight){const Y=z.camera,Ee=z.matrix,Re=I.distance||Y.far;Re!==Y.far&&(Y.far=Re,Y.updateProjectionMatrix()),yl.setFromMatrixPosition(I.matrixWorld),Y.position.copy(yl),zd.copy(Y.position),zd.add(LC[D]),Y.up.copy(NC[D]),Y.lookAt(zd),Y.updateMatrixWorld(),Ee.makeTranslation(-yl.x,-yl.y,-yl.z),gx.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),z._frustum.setFromProjectionMatrix(gx,Y.coordinateSystem,Y.reversedDepth)}else z.updateMatrices(I);a=z.getFrustum(),w(N,T,z.camera,I,this.type)}z.isPointLightShadow!==!0&&this.type===Ml&&B(z,T),z.needsUpdate=!1}S=this.type,M.needsUpdate=!1,r.setRenderTarget(O,X,G)};function B(U,N){const T=e.update(C);v.defines.VSM_SAMPLES!==U.blurSamples&&(v.defines.VSM_SAMPLES=U.blurSamples,x.defines.VSM_SAMPLES=U.blurSamples,v.needsUpdate=!0,x.needsUpdate=!0),U.mapPass===null&&(U.mapPass=new sa(o.x,o.y,{format:sr,type:Ha})),v.uniforms.shadow_pass.value=U.map.depthTexture,v.uniforms.resolution.value=U.mapSize,v.uniforms.radius.value=U.radius,r.setRenderTarget(U.mapPass),r.clear(),r.renderBufferDirect(N,null,T,v,C,null),x.uniforms.shadow_pass.value=U.mapPass.texture,x.uniforms.resolution.value=U.mapSize,x.uniforms.radius.value=U.radius,r.setRenderTarget(U.map),r.clear(),r.renderBufferDirect(N,null,T,x,C,null)}function F(U,N,T,O){let X=null;const G=T.isPointLight===!0?U.customDistanceMaterial:U.customDepthMaterial;if(G!==void 0)X=G;else if(X=T.isPointLight===!0?p:h,r.localClippingEnabled&&N.clipShadows===!0&&Array.isArray(N.clippingPlanes)&&N.clippingPlanes.length!==0||N.displacementMap&&N.displacementScale!==0||N.alphaMap&&N.alphaTest>0||N.map&&N.alphaTest>0||N.alphaToCoverage===!0){const Z=X.uuid,ce=N.uuid;let ge=d[Z];ge===void 0&&(ge={},d[Z]=ge);let j=ge[ce];j===void 0&&(j=X.clone(),ge[ce]=j,N.addEventListener("dispose",P)),X=j}if(X.visible=N.visible,X.wireframe=N.wireframe,O===Ml?X.side=N.shadowSide!==null?N.shadowSide:N.side:X.side=N.shadowSide!==null?N.shadowSide:_[N.side],X.alphaMap=N.alphaMap,X.alphaTest=N.alphaToCoverage===!0?.5:N.alphaTest,X.map=N.map,X.clipShadows=N.clipShadows,X.clippingPlanes=N.clippingPlanes,X.clipIntersection=N.clipIntersection,X.displacementMap=N.displacementMap,X.displacementScale=N.displacementScale,X.displacementBias=N.displacementBias,X.wireframeLinewidth=N.wireframeLinewidth,X.linewidth=N.linewidth,T.isPointLight===!0&&X.isMeshDistanceMaterial===!0){const Z=r.properties.get(X);Z.light=T}return X}function w(U,N,T,O,X){if(U.visible===!1)return;if(U.layers.test(N.layers)&&(U.isMesh||U.isLine||U.isPoints)&&(U.castShadow||U.receiveShadow&&X===Ml)&&(!U.frustumCulled||a.intersectsObject(U))){U.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,U.matrixWorld);const ce=e.update(U),ge=U.material;if(Array.isArray(ge)){const j=ce.groups;for(let I=0,z=j.length;I<z;I++){const Q=j[I],de=ge[Q.materialIndex];if(de&&de.visible){const ve=F(U,de,O,X);U.onBeforeShadow(r,U,N,T,ce,ve,Q),r.renderBufferDirect(T,null,ce,ve,U,Q),U.onAfterShadow(r,U,N,T,ce,ve,Q)}}}else if(ge.visible){const j=F(U,ge,O,X);U.onBeforeShadow(r,U,N,T,ce,j,null),r.renderBufferDirect(T,null,ce,j,U,null),U.onAfterShadow(r,U,N,T,ce,j,null)}}const Z=U.children;for(let ce=0,ge=Z.length;ce<ge;ce++)w(Z[ce],N,T,O,X)}function P(U){U.target.removeEventListener("dispose",P);for(const T in d){const O=d[T],X=U.target.uuid;X in O&&(O[X].dispose(),delete O[X])}}}function OC(r,e){function n(){let k=!1;const Te=new Yt;let me=null;const Ce=new Yt(0,0,0,0);return{setMask:function(Ie){me!==Ie&&!k&&(r.colorMask(Ie,Ie,Ie,Ie),me=Ie)},setLocked:function(Ie){k=Ie},setClear:function(Ie,Se,We,Ge,tn){tn===!0&&(Ie*=Ge,Se*=Ge,We*=Ge),Te.set(Ie,Se,We,Ge),Ce.equals(Te)===!1&&(r.clearColor(Ie,Se,We,Ge),Ce.copy(Te))},reset:function(){k=!1,me=null,Ce.set(-1,0,0,0)}}}function a(){let k=!1,Te=!1,me=null,Ce=null,Ie=null;return{setReversed:function(Se){if(Te!==Se){const We=e.get("EXT_clip_control");Se?We.clipControlEXT(We.LOWER_LEFT_EXT,We.ZERO_TO_ONE_EXT):We.clipControlEXT(We.LOWER_LEFT_EXT,We.NEGATIVE_ONE_TO_ONE_EXT),Te=Se;const Ge=Ie;Ie=null,this.setClear(Ge)}},getReversed:function(){return Te},setTest:function(Se){Se?Me(r.DEPTH_TEST):ze(r.DEPTH_TEST)},setMask:function(Se){me!==Se&&!k&&(r.depthMask(Se),me=Se)},setFunc:function(Se){if(Te&&(Se=_E[Se]),Ce!==Se){switch(Se){case Wd:r.depthFunc(r.NEVER);break;case qd:r.depthFunc(r.ALWAYS);break;case Yd:r.depthFunc(r.LESS);break;case ro:r.depthFunc(r.LEQUAL);break;case Kd:r.depthFunc(r.EQUAL);break;case Zd:r.depthFunc(r.GEQUAL);break;case Qd:r.depthFunc(r.GREATER);break;case Jd:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}Ce=Se}},setLocked:function(Se){k=Se},setClear:function(Se){Ie!==Se&&(Ie=Se,Te&&(Se=1-Se),r.clearDepth(Se))},reset:function(){k=!1,me=null,Ce=null,Ie=null,Te=!1}}}function o(){let k=!1,Te=null,me=null,Ce=null,Ie=null,Se=null,We=null,Ge=null,tn=null;return{setTest:function(Ot){k||(Ot?Me(r.STENCIL_TEST):ze(r.STENCIL_TEST))},setMask:function(Ot){Te!==Ot&&!k&&(r.stencilMask(Ot),Te=Ot)},setFunc:function(Ot,ni,ii){(me!==Ot||Ce!==ni||Ie!==ii)&&(r.stencilFunc(Ot,ni,ii),me=Ot,Ce=ni,Ie=ii)},setOp:function(Ot,ni,ii){(Se!==Ot||We!==ni||Ge!==ii)&&(r.stencilOp(Ot,ni,ii),Se=Ot,We=ni,Ge=ii)},setLocked:function(Ot){k=Ot},setClear:function(Ot){tn!==Ot&&(r.clearStencil(Ot),tn=Ot)},reset:function(){k=!1,Te=null,me=null,Ce=null,Ie=null,Se=null,We=null,Ge=null,tn=null}}}const c=new n,u=new a,h=new o,p=new WeakMap,d=new WeakMap;let g={},_={},v={},x=new WeakMap,E=[],C=null,M=!1,S=null,B=null,F=null,w=null,P=null,U=null,N=null,T=new st(0,0,0),O=0,X=!1,G=null,Z=null,ce=null,ge=null,j=null;const I=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,Q=0;const de=r.getParameter(r.VERSION);de.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(de)[1]),z=Q>=1):de.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(de)[1]),z=Q>=2);let ve=null,D={};const Y=r.getParameter(r.SCISSOR_BOX),Ee=r.getParameter(r.VIEWPORT),Re=new Yt().fromArray(Y),Pe=new Yt().fromArray(Ee);function ae(k,Te,me,Ce){const Ie=new Uint8Array(4),Se=r.createTexture();r.bindTexture(k,Se),r.texParameteri(k,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(k,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let We=0;We<me;We++)k===r.TEXTURE_3D||k===r.TEXTURE_2D_ARRAY?r.texImage3D(Te,0,r.RGBA,1,1,Ce,0,r.RGBA,r.UNSIGNED_BYTE,Ie):r.texImage2D(Te+We,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,Ie);return Se}const ye={};ye[r.TEXTURE_2D]=ae(r.TEXTURE_2D,r.TEXTURE_2D,1),ye[r.TEXTURE_CUBE_MAP]=ae(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),ye[r.TEXTURE_2D_ARRAY]=ae(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),ye[r.TEXTURE_3D]=ae(r.TEXTURE_3D,r.TEXTURE_3D,1,1),c.setClear(0,0,0,1),u.setClear(1),h.setClear(0),Me(r.DEPTH_TEST),u.setFunc(ro),rn(!1),on(ev),Me(r.CULL_FACE),At(Ba);function Me(k){g[k]!==!0&&(r.enable(k),g[k]=!0)}function ze(k){g[k]!==!1&&(r.disable(k),g[k]=!1)}function it(k,Te){return v[k]!==Te?(r.bindFramebuffer(k,Te),v[k]=Te,k===r.DRAW_FRAMEBUFFER&&(v[r.FRAMEBUFFER]=Te),k===r.FRAMEBUFFER&&(v[r.DRAW_FRAMEBUFFER]=Te),!0):!1}function je(k,Te){let me=E,Ce=!1;if(k){me=x.get(Te),me===void 0&&(me=[],x.set(Te,me));const Ie=k.textures;if(me.length!==Ie.length||me[0]!==r.COLOR_ATTACHMENT0){for(let Se=0,We=Ie.length;Se<We;Se++)me[Se]=r.COLOR_ATTACHMENT0+Se;me.length=Ie.length,Ce=!0}}else me[0]!==r.BACK&&(me[0]=r.BACK,Ce=!0);Ce&&r.drawBuffers(me)}function Jt(k){return C!==k?(r.useProgram(k),C=k,!0):!1}const pt={[er]:r.FUNC_ADD,[BM]:r.FUNC_SUBTRACT,[FM]:r.FUNC_REVERSE_SUBTRACT};pt[zM]=r.MIN,pt[HM]=r.MAX;const Tt={[GM]:r.ZERO,[VM]:r.ONE,[kM]:r.SRC_COLOR,[kd]:r.SRC_ALPHA,[ZM]:r.SRC_ALPHA_SATURATE,[YM]:r.DST_COLOR,[WM]:r.DST_ALPHA,[XM]:r.ONE_MINUS_SRC_COLOR,[Xd]:r.ONE_MINUS_SRC_ALPHA,[KM]:r.ONE_MINUS_DST_COLOR,[qM]:r.ONE_MINUS_DST_ALPHA,[QM]:r.CONSTANT_COLOR,[JM]:r.ONE_MINUS_CONSTANT_COLOR,[jM]:r.CONSTANT_ALPHA,[$M]:r.ONE_MINUS_CONSTANT_ALPHA};function At(k,Te,me,Ce,Ie,Se,We,Ge,tn,Ot){if(k===Ba){M===!0&&(ze(r.BLEND),M=!1);return}if(M===!1&&(Me(r.BLEND),M=!0),k!==IM){if(k!==S||Ot!==X){if((B!==er||P!==er)&&(r.blendEquation(r.FUNC_ADD),B=er,P=er),Ot)switch(k){case no:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case tv:r.blendFunc(r.ONE,r.ONE);break;case nv:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case iv:r.blendFuncSeparate(r.DST_COLOR,r.ONE_MINUS_SRC_ALPHA,r.ZERO,r.ONE);break;default:at("WebGLState: Invalid blending: ",k);break}else switch(k){case no:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case tv:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE,r.ONE,r.ONE);break;case nv:at("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case iv:at("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:at("WebGLState: Invalid blending: ",k);break}F=null,w=null,U=null,N=null,T.set(0,0,0),O=0,S=k,X=Ot}return}Ie=Ie||Te,Se=Se||me,We=We||Ce,(Te!==B||Ie!==P)&&(r.blendEquationSeparate(pt[Te],pt[Ie]),B=Te,P=Ie),(me!==F||Ce!==w||Se!==U||We!==N)&&(r.blendFuncSeparate(Tt[me],Tt[Ce],Tt[Se],Tt[We]),F=me,w=Ce,U=Se,N=We),(Ge.equals(T)===!1||tn!==O)&&(r.blendColor(Ge.r,Ge.g,Ge.b,tn),T.copy(Ge),O=tn),S=k,X=!1}function _t(k,Te){k.side===ta?ze(r.CULL_FACE):Me(r.CULL_FACE);let me=k.side===qn;Te&&(me=!me),rn(me),k.blending===no&&k.transparent===!1?At(Ba):At(k.blending,k.blendEquation,k.blendSrc,k.blendDst,k.blendEquationAlpha,k.blendSrcAlpha,k.blendDstAlpha,k.blendColor,k.blendAlpha,k.premultipliedAlpha),u.setFunc(k.depthFunc),u.setTest(k.depthTest),u.setMask(k.depthWrite),c.setMask(k.colorWrite);const Ce=k.stencilWrite;h.setTest(Ce),Ce&&(h.setMask(k.stencilWriteMask),h.setFunc(k.stencilFunc,k.stencilRef,k.stencilFuncMask),h.setOp(k.stencilFail,k.stencilZFail,k.stencilZPass)),hn(k.polygonOffset,k.polygonOffsetFactor,k.polygonOffsetUnits),k.alphaToCoverage===!0?Me(r.SAMPLE_ALPHA_TO_COVERAGE):ze(r.SAMPLE_ALPHA_TO_COVERAGE)}function rn(k){G!==k&&(k?r.frontFace(r.CW):r.frontFace(r.CCW),G=k)}function on(k){k!==UM?(Me(r.CULL_FACE),k!==Z&&(k===ev?r.cullFace(r.BACK):k===OM?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):ze(r.CULL_FACE),Z=k}function ln(k){k!==ce&&(z&&r.lineWidth(k),ce=k)}function hn(k,Te,me){k?(Me(r.POLYGON_OFFSET_FILL),(ge!==Te||j!==me)&&(ge=Te,j=me,u.getReversed()&&(Te=-Te),r.polygonOffset(Te,me))):ze(r.POLYGON_OFFSET_FILL)}function Qt(k){k?Me(r.SCISSOR_TEST):ze(r.SCISSOR_TEST)}function cn(k){k===void 0&&(k=r.TEXTURE0+I-1),ve!==k&&(r.activeTexture(k),ve=k)}function q(k,Te,me){me===void 0&&(ve===null?me=r.TEXTURE0+I-1:me=ve);let Ce=D[me];Ce===void 0&&(Ce={type:void 0,texture:void 0},D[me]=Ce),(Ce.type!==k||Ce.texture!==Te)&&(ve!==me&&(r.activeTexture(me),ve=me),r.bindTexture(k,Te||ye[k]),Ce.type=k,Ce.texture=Te)}function kt(){const k=D[ve];k!==void 0&&k.type!==void 0&&(r.bindTexture(k.type,null),k.type=void 0,k.texture=void 0)}function Lt(){try{r.compressedTexImage2D(...arguments)}catch(k){at("WebGLState:",k)}}function L(){try{r.compressedTexImage3D(...arguments)}catch(k){at("WebGLState:",k)}}function b(){try{r.texSubImage2D(...arguments)}catch(k){at("WebGLState:",k)}}function J(){try{r.texSubImage3D(...arguments)}catch(k){at("WebGLState:",k)}}function se(){try{r.compressedTexSubImage2D(...arguments)}catch(k){at("WebGLState:",k)}}function fe(){try{r.compressedTexSubImage3D(...arguments)}catch(k){at("WebGLState:",k)}}function be(){try{r.texStorage2D(...arguments)}catch(k){at("WebGLState:",k)}}function we(){try{r.texStorage3D(...arguments)}catch(k){at("WebGLState:",k)}}function ue(){try{r.texImage2D(...arguments)}catch(k){at("WebGLState:",k)}}function he(){try{r.texImage3D(...arguments)}catch(k){at("WebGLState:",k)}}function Ae(k){return _[k]!==void 0?_[k]:r.getParameter(k)}function Be(k,Te){_[k]!==Te&&(r.pixelStorei(k,Te),_[k]=Te)}function Ne(k){Re.equals(k)===!1&&(r.scissor(k.x,k.y,k.z,k.w),Re.copy(k))}function De(k){Pe.equals(k)===!1&&(r.viewport(k.x,k.y,k.z,k.w),Pe.copy(k))}function Ze(k,Te){let me=d.get(Te);me===void 0&&(me=new WeakMap,d.set(Te,me));let Ce=me.get(k);Ce===void 0&&(Ce=r.getUniformBlockIndex(Te,k.name),me.set(k,Ce))}function $e(k,Te){const Ce=d.get(Te).get(k);p.get(Te)!==Ce&&(r.uniformBlockBinding(Te,Ce,k.__bindingPointIndex),p.set(Te,Ce))}function rt(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),u.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),r.pixelStorei(r.PACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,!1),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,r.BROWSER_DEFAULT_WEBGL),r.pixelStorei(r.PACK_ROW_LENGTH,0),r.pixelStorei(r.PACK_SKIP_PIXELS,0),r.pixelStorei(r.PACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_ROW_LENGTH,0),r.pixelStorei(r.UNPACK_IMAGE_HEIGHT,0),r.pixelStorei(r.UNPACK_SKIP_PIXELS,0),r.pixelStorei(r.UNPACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_SKIP_IMAGES,0),g={},_={},ve=null,D={},v={},x=new WeakMap,E=[],C=null,M=!1,S=null,B=null,F=null,w=null,P=null,U=null,N=null,T=new st(0,0,0),O=0,X=!1,G=null,Z=null,ce=null,ge=null,j=null,Re.set(0,0,r.canvas.width,r.canvas.height),Pe.set(0,0,r.canvas.width,r.canvas.height),c.reset(),u.reset(),h.reset()}return{buffers:{color:c,depth:u,stencil:h},enable:Me,disable:ze,bindFramebuffer:it,drawBuffers:je,useProgram:Jt,setBlending:At,setMaterial:_t,setFlipSided:rn,setCullFace:on,setLineWidth:ln,setPolygonOffset:hn,setScissorTest:Qt,activeTexture:cn,bindTexture:q,unbindTexture:kt,compressedTexImage2D:Lt,compressedTexImage3D:L,texImage2D:ue,texImage3D:he,pixelStorei:Be,getParameter:Ae,updateUBOMapping:Ze,uniformBlockBinding:$e,texStorage2D:be,texStorage3D:we,texSubImage2D:b,texSubImage3D:J,compressedTexSubImage2D:se,compressedTexSubImage3D:fe,scissor:Ne,viewport:De,reset:rt}}function PC(r,e,n,a,o,c,u){const h=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,p=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new gt,g=new WeakMap,_=new Set;let v;const x=new WeakMap;let E=!1;try{E=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function C(L,b){return E?new OffscreenCanvas(L,b):Ul("canvas")}function M(L,b,J){let se=1;const fe=Lt(L);if((fe.width>J||fe.height>J)&&(se=J/Math.max(fe.width,fe.height)),se<1)if(typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&L instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&L instanceof ImageBitmap||typeof VideoFrame<"u"&&L instanceof VideoFrame){const be=Math.floor(se*fe.width),we=Math.floor(se*fe.height);v===void 0&&(v=C(be,we));const ue=b?C(be,we):v;return ue.width=be,ue.height=we,ue.getContext("2d").drawImage(L,0,0,be,we),Ke("WebGLRenderer: Texture has been resized from ("+fe.width+"x"+fe.height+") to ("+be+"x"+we+")."),ue}else return"data"in L&&Ke("WebGLRenderer: Image in DataTexture is too big ("+fe.width+"x"+fe.height+")."),L;return L}function S(L){return L.generateMipmaps}function B(L){r.generateMipmap(L)}function F(L){return L.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:L.isWebGL3DRenderTarget?r.TEXTURE_3D:L.isWebGLArrayRenderTarget||L.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function w(L,b,J,se,fe,be=!1){if(L!==null){if(r[L]!==void 0)return r[L];Ke("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+L+"'")}let we;se&&(we=e.get("EXT_texture_norm16"),we||Ke("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let ue=b;if(b===r.RED&&(J===r.FLOAT&&(ue=r.R32F),J===r.HALF_FLOAT&&(ue=r.R16F),J===r.UNSIGNED_BYTE&&(ue=r.R8),J===r.UNSIGNED_SHORT&&we&&(ue=we.R16_EXT),J===r.SHORT&&we&&(ue=we.R16_SNORM_EXT)),b===r.RED_INTEGER&&(J===r.UNSIGNED_BYTE&&(ue=r.R8UI),J===r.UNSIGNED_SHORT&&(ue=r.R16UI),J===r.UNSIGNED_INT&&(ue=r.R32UI),J===r.BYTE&&(ue=r.R8I),J===r.SHORT&&(ue=r.R16I),J===r.INT&&(ue=r.R32I)),b===r.RG&&(J===r.FLOAT&&(ue=r.RG32F),J===r.HALF_FLOAT&&(ue=r.RG16F),J===r.UNSIGNED_BYTE&&(ue=r.RG8),J===r.UNSIGNED_SHORT&&we&&(ue=we.RG16_EXT),J===r.SHORT&&we&&(ue=we.RG16_SNORM_EXT)),b===r.RG_INTEGER&&(J===r.UNSIGNED_BYTE&&(ue=r.RG8UI),J===r.UNSIGNED_SHORT&&(ue=r.RG16UI),J===r.UNSIGNED_INT&&(ue=r.RG32UI),J===r.BYTE&&(ue=r.RG8I),J===r.SHORT&&(ue=r.RG16I),J===r.INT&&(ue=r.RG32I)),b===r.RGB_INTEGER&&(J===r.UNSIGNED_BYTE&&(ue=r.RGB8UI),J===r.UNSIGNED_SHORT&&(ue=r.RGB16UI),J===r.UNSIGNED_INT&&(ue=r.RGB32UI),J===r.BYTE&&(ue=r.RGB8I),J===r.SHORT&&(ue=r.RGB16I),J===r.INT&&(ue=r.RGB32I)),b===r.RGBA_INTEGER&&(J===r.UNSIGNED_BYTE&&(ue=r.RGBA8UI),J===r.UNSIGNED_SHORT&&(ue=r.RGBA16UI),J===r.UNSIGNED_INT&&(ue=r.RGBA32UI),J===r.BYTE&&(ue=r.RGBA8I),J===r.SHORT&&(ue=r.RGBA16I),J===r.INT&&(ue=r.RGBA32I)),b===r.RGB&&(J===r.UNSIGNED_SHORT&&we&&(ue=we.RGB16_EXT),J===r.SHORT&&we&&(ue=we.RGB16_SNORM_EXT),J===r.UNSIGNED_INT_5_9_9_9_REV&&(ue=r.RGB9_E5),J===r.UNSIGNED_INT_10F_11F_11F_REV&&(ue=r.R11F_G11F_B10F)),b===r.RGBA){const he=be?Iu:St.getTransfer(fe);J===r.FLOAT&&(ue=r.RGBA32F),J===r.HALF_FLOAT&&(ue=r.RGBA16F),J===r.UNSIGNED_BYTE&&(ue=he===Ht?r.SRGB8_ALPHA8:r.RGBA8),J===r.UNSIGNED_SHORT&&we&&(ue=we.RGBA16_EXT),J===r.SHORT&&we&&(ue=we.RGBA16_SNORM_EXT),J===r.UNSIGNED_SHORT_4_4_4_4&&(ue=r.RGBA4),J===r.UNSIGNED_SHORT_5_5_5_1&&(ue=r.RGB5_A1)}return(ue===r.R16F||ue===r.R32F||ue===r.RG16F||ue===r.RG32F||ue===r.RGBA16F||ue===r.RGBA32F)&&e.get("EXT_color_buffer_float"),ue}function P(L,b){let J;return L?b===null||b===ra||b===wl?J=r.DEPTH24_STENCIL8:b===Ri?J=r.DEPTH32F_STENCIL8:b===Cl&&(J=r.DEPTH24_STENCIL8,Ke("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):b===null||b===ra||b===wl?J=r.DEPTH_COMPONENT24:b===Ri?J=r.DEPTH_COMPONENT32F:b===Cl&&(J=r.DEPTH_COMPONENT16),J}function U(L,b){return S(L)===!0||L.isFramebufferTexture&&L.minFilter!==An&&L.minFilter!==Rn?Math.log2(Math.max(b.width,b.height))+1:L.mipmaps!==void 0&&L.mipmaps.length>0?L.mipmaps.length:L.isCompressedTexture&&Array.isArray(L.image)?b.mipmaps.length:1}function N(L){const b=L.target;b.removeEventListener("dispose",N),O(b),b.isVideoTexture&&g.delete(b),b.isHTMLTexture&&_.delete(b)}function T(L){const b=L.target;b.removeEventListener("dispose",T),G(b)}function O(L){const b=a.get(L);if(b.__webglInit===void 0)return;const J=L.source,se=x.get(J);if(se){const fe=se[b.__cacheKey];fe.usedTimes--,fe.usedTimes===0&&X(L),Object.keys(se).length===0&&x.delete(J)}a.remove(L)}function X(L){const b=a.get(L);r.deleteTexture(b.__webglTexture);const J=L.source,se=x.get(J);delete se[b.__cacheKey],u.memory.textures--}function G(L){const b=a.get(L);if(L.depthTexture&&(L.depthTexture.dispose(),a.remove(L.depthTexture)),L.isWebGLCubeRenderTarget)for(let se=0;se<6;se++){if(Array.isArray(b.__webglFramebuffer[se]))for(let fe=0;fe<b.__webglFramebuffer[se].length;fe++)r.deleteFramebuffer(b.__webglFramebuffer[se][fe]);else r.deleteFramebuffer(b.__webglFramebuffer[se]);b.__webglDepthbuffer&&r.deleteRenderbuffer(b.__webglDepthbuffer[se])}else{if(Array.isArray(b.__webglFramebuffer))for(let se=0;se<b.__webglFramebuffer.length;se++)r.deleteFramebuffer(b.__webglFramebuffer[se]);else r.deleteFramebuffer(b.__webglFramebuffer);if(b.__webglDepthbuffer&&r.deleteRenderbuffer(b.__webglDepthbuffer),b.__webglMultisampledFramebuffer&&r.deleteFramebuffer(b.__webglMultisampledFramebuffer),b.__webglColorRenderbuffer)for(let se=0;se<b.__webglColorRenderbuffer.length;se++)b.__webglColorRenderbuffer[se]&&r.deleteRenderbuffer(b.__webglColorRenderbuffer[se]);b.__webglDepthRenderbuffer&&r.deleteRenderbuffer(b.__webglDepthRenderbuffer)}const J=L.textures;for(let se=0,fe=J.length;se<fe;se++){const be=a.get(J[se]);be.__webglTexture&&(r.deleteTexture(be.__webglTexture),u.memory.textures--),a.remove(J[se])}a.remove(L)}let Z=0;function ce(){Z=0}function ge(){return Z}function j(L){Z=L}function I(){const L=Z;return L>=o.maxTextures&&Ke("WebGLTextures: Trying to use "+L+" texture units while this GPU supports only "+o.maxTextures),Z+=1,L}function z(L){const b=[];return b.push(L.wrapS),b.push(L.wrapT),b.push(L.wrapR||0),b.push(L.magFilter),b.push(L.minFilter),b.push(L.anisotropy),b.push(L.internalFormat),b.push(L.format),b.push(L.type),b.push(L.generateMipmaps),b.push(L.premultiplyAlpha),b.push(L.flipY),b.push(L.unpackAlignment),b.push(L.colorSpace),b.join()}function Q(L,b){const J=a.get(L);if(L.isVideoTexture&&q(L),L.isRenderTargetTexture===!1&&L.isExternalTexture!==!0&&L.version>0&&J.__version!==L.version){const se=L.image;if(se===null)Ke("WebGLRenderer: Texture marked for update but no image data found.");else if(se.complete===!1)Ke("WebGLRenderer: Texture marked for update but image is incomplete");else{ze(J,L,b);return}}else L.isExternalTexture&&(J.__webglTexture=L.sourceTexture?L.sourceTexture:null);n.bindTexture(r.TEXTURE_2D,J.__webglTexture,r.TEXTURE0+b)}function de(L,b){const J=a.get(L);if(L.isRenderTargetTexture===!1&&L.version>0&&J.__version!==L.version){ze(J,L,b);return}else L.isExternalTexture&&(J.__webglTexture=L.sourceTexture?L.sourceTexture:null);n.bindTexture(r.TEXTURE_2D_ARRAY,J.__webglTexture,r.TEXTURE0+b)}function ve(L,b){const J=a.get(L);if(L.isRenderTargetTexture===!1&&L.version>0&&J.__version!==L.version){ze(J,L,b);return}n.bindTexture(r.TEXTURE_3D,J.__webglTexture,r.TEXTURE0+b)}function D(L,b){const J=a.get(L);if(L.isCubeDepthTexture!==!0&&L.version>0&&J.__version!==L.version){it(J,L,b);return}n.bindTexture(r.TEXTURE_CUBE_MAP,J.__webglTexture,r.TEXTURE0+b)}const Y={[lo]:r.REPEAT,[na]:r.CLAMP_TO_EDGE,[Nu]:r.MIRRORED_REPEAT},Ee={[An]:r.NEAREST,[Ox]:r.NEAREST_MIPMAP_NEAREST,[El]:r.NEAREST_MIPMAP_LINEAR,[Rn]:r.LINEAR,[Tu]:r.LINEAR_MIPMAP_NEAREST,[Pa]:r.LINEAR_MIPMAP_LINEAR},Re={[oE]:r.NEVER,[hE]:r.ALWAYS,[lE]:r.LESS,[Zp]:r.LEQUAL,[cE]:r.EQUAL,[Qp]:r.GEQUAL,[uE]:r.GREATER,[fE]:r.NOTEQUAL};function Pe(L,b){if(b.type===Ri&&e.has("OES_texture_float_linear")===!1&&(b.magFilter===Rn||b.magFilter===Tu||b.magFilter===El||b.magFilter===Pa||b.minFilter===Rn||b.minFilter===Tu||b.minFilter===El||b.minFilter===Pa)&&Ke("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(L,r.TEXTURE_WRAP_S,Y[b.wrapS]),r.texParameteri(L,r.TEXTURE_WRAP_T,Y[b.wrapT]),(L===r.TEXTURE_3D||L===r.TEXTURE_2D_ARRAY)&&r.texParameteri(L,r.TEXTURE_WRAP_R,Y[b.wrapR]),r.texParameteri(L,r.TEXTURE_MAG_FILTER,Ee[b.magFilter]),r.texParameteri(L,r.TEXTURE_MIN_FILTER,Ee[b.minFilter]),b.compareFunction&&(r.texParameteri(L,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(L,r.TEXTURE_COMPARE_FUNC,Re[b.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(b.magFilter===An||b.minFilter!==El&&b.minFilter!==Pa||b.type===Ri&&e.has("OES_texture_float_linear")===!1)return;if(b.anisotropy>1||a.get(b).__currentAnisotropy){const J=e.get("EXT_texture_filter_anisotropic");r.texParameterf(L,J.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,o.getMaxAnisotropy())),a.get(b).__currentAnisotropy=b.anisotropy}}}function ae(L,b){let J=!1;L.__webglInit===void 0&&(L.__webglInit=!0,b.addEventListener("dispose",N));const se=b.source;let fe=x.get(se);fe===void 0&&(fe={},x.set(se,fe));const be=z(b);if(be!==L.__cacheKey){fe[be]===void 0&&(fe[be]={texture:r.createTexture(),usedTimes:0},u.memory.textures++,J=!0),fe[be].usedTimes++;const we=fe[L.__cacheKey];we!==void 0&&(fe[L.__cacheKey].usedTimes--,we.usedTimes===0&&X(b)),L.__cacheKey=be,L.__webglTexture=fe[be].texture}return J}function ye(L,b,J){return Math.floor(Math.floor(L/J)/b)}function Me(L,b,J,se){const be=L.updateRanges;if(be.length===0)n.texSubImage2D(r.TEXTURE_2D,0,0,0,b.width,b.height,J,se,b.data);else{be.sort((Be,Ne)=>Be.start-Ne.start);let we=0;for(let Be=1;Be<be.length;Be++){const Ne=be[we],De=be[Be],Ze=Ne.start+Ne.count,$e=ye(De.start,b.width,4),rt=ye(Ne.start,b.width,4);De.start<=Ze+1&&$e===rt&&ye(De.start+De.count-1,b.width,4)===$e?Ne.count=Math.max(Ne.count,De.start+De.count-Ne.start):(++we,be[we]=De)}be.length=we+1;const ue=n.getParameter(r.UNPACK_ROW_LENGTH),he=n.getParameter(r.UNPACK_SKIP_PIXELS),Ae=n.getParameter(r.UNPACK_SKIP_ROWS);n.pixelStorei(r.UNPACK_ROW_LENGTH,b.width);for(let Be=0,Ne=be.length;Be<Ne;Be++){const De=be[Be],Ze=Math.floor(De.start/4),$e=Math.ceil(De.count/4),rt=Ze%b.width,k=Math.floor(Ze/b.width),Te=$e,me=1;n.pixelStorei(r.UNPACK_SKIP_PIXELS,rt),n.pixelStorei(r.UNPACK_SKIP_ROWS,k),n.texSubImage2D(r.TEXTURE_2D,0,rt,k,Te,me,J,se,b.data)}L.clearUpdateRanges(),n.pixelStorei(r.UNPACK_ROW_LENGTH,ue),n.pixelStorei(r.UNPACK_SKIP_PIXELS,he),n.pixelStorei(r.UNPACK_SKIP_ROWS,Ae)}}function ze(L,b,J){let se=r.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(se=r.TEXTURE_2D_ARRAY),b.isData3DTexture&&(se=r.TEXTURE_3D);const fe=ae(L,b),be=b.source;n.bindTexture(se,L.__webglTexture,r.TEXTURE0+J);const we=a.get(be);if(be.version!==we.__version||fe===!0){if(n.activeTexture(r.TEXTURE0+J),(typeof ImageBitmap<"u"&&b.image instanceof ImageBitmap)===!1){const me=St.getPrimaries(St.workingColorSpace),Ce=b.colorSpace===Ts?null:St.getPrimaries(b.colorSpace),Ie=b.colorSpace===Ts||me===Ce?r.NONE:r.BROWSER_DEFAULT_WEBGL;n.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,b.flipY),n.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),n.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ie)}n.pixelStorei(r.UNPACK_ALIGNMENT,b.unpackAlignment);let he=M(b.image,!1,o.maxTextureSize);he=kt(b,he);const Ae=c.convert(b.format,b.colorSpace),Be=c.convert(b.type);let Ne=w(b.internalFormat,Ae,Be,b.normalized,b.colorSpace,b.isVideoTexture);Pe(se,b);let De;const Ze=b.mipmaps,$e=b.isVideoTexture!==!0,rt=we.__version===void 0||fe===!0,k=be.dataReady,Te=U(b,he);if(b.isDepthTexture)Ne=P(b.format===nr,b.type),rt&&($e?n.texStorage2D(r.TEXTURE_2D,1,Ne,he.width,he.height):n.texImage2D(r.TEXTURE_2D,0,Ne,he.width,he.height,0,Ae,Be,null));else if(b.isDataTexture)if(Ze.length>0){$e&&rt&&n.texStorage2D(r.TEXTURE_2D,Te,Ne,Ze[0].width,Ze[0].height);for(let me=0,Ce=Ze.length;me<Ce;me++)De=Ze[me],$e?k&&n.texSubImage2D(r.TEXTURE_2D,me,0,0,De.width,De.height,Ae,Be,De.data):n.texImage2D(r.TEXTURE_2D,me,Ne,De.width,De.height,0,Ae,Be,De.data);b.generateMipmaps=!1}else $e?(rt&&n.texStorage2D(r.TEXTURE_2D,Te,Ne,he.width,he.height),k&&Me(b,he,Ae,Be)):n.texImage2D(r.TEXTURE_2D,0,Ne,he.width,he.height,0,Ae,Be,he.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){$e&&rt&&n.texStorage3D(r.TEXTURE_2D_ARRAY,Te,Ne,Ze[0].width,Ze[0].height,he.depth);for(let me=0,Ce=Ze.length;me<Ce;me++)if(De=Ze[me],b.format!==Ci)if(Ae!==null)if($e){if(k)if(b.layerUpdates.size>0){const Ie=Kv(De.width,De.height,b.format,b.type);for(const Se of b.layerUpdates){const We=De.data.subarray(Se*Ie/De.data.BYTES_PER_ELEMENT,(Se+1)*Ie/De.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,me,0,0,Se,De.width,De.height,1,Ae,We)}b.clearLayerUpdates()}else n.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,me,0,0,0,De.width,De.height,he.depth,Ae,De.data)}else n.compressedTexImage3D(r.TEXTURE_2D_ARRAY,me,Ne,De.width,De.height,he.depth,0,De.data,0,0);else Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else $e?k&&n.texSubImage3D(r.TEXTURE_2D_ARRAY,me,0,0,0,De.width,De.height,he.depth,Ae,Be,De.data):n.texImage3D(r.TEXTURE_2D_ARRAY,me,Ne,De.width,De.height,he.depth,0,Ae,Be,De.data)}else{$e&&rt&&n.texStorage2D(r.TEXTURE_2D,Te,Ne,Ze[0].width,Ze[0].height);for(let me=0,Ce=Ze.length;me<Ce;me++)De=Ze[me],b.format!==Ci?Ae!==null?$e?k&&n.compressedTexSubImage2D(r.TEXTURE_2D,me,0,0,De.width,De.height,Ae,De.data):n.compressedTexImage2D(r.TEXTURE_2D,me,Ne,De.width,De.height,0,De.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):$e?k&&n.texSubImage2D(r.TEXTURE_2D,me,0,0,De.width,De.height,Ae,Be,De.data):n.texImage2D(r.TEXTURE_2D,me,Ne,De.width,De.height,0,Ae,Be,De.data)}else if(b.isDataArrayTexture)if($e){if(rt&&n.texStorage3D(r.TEXTURE_2D_ARRAY,Te,Ne,he.width,he.height,he.depth),k)if(b.layerUpdates.size>0){const me=Kv(he.width,he.height,b.format,b.type);for(const Ce of b.layerUpdates){const Ie=he.data.subarray(Ce*me/he.data.BYTES_PER_ELEMENT,(Ce+1)*me/he.data.BYTES_PER_ELEMENT);n.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,Ce,he.width,he.height,1,Ae,Be,Ie)}b.clearLayerUpdates()}else n.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,he.width,he.height,he.depth,Ae,Be,he.data)}else n.texImage3D(r.TEXTURE_2D_ARRAY,0,Ne,he.width,he.height,he.depth,0,Ae,Be,he.data);else if(b.isData3DTexture)$e?(rt&&n.texStorage3D(r.TEXTURE_3D,Te,Ne,he.width,he.height,he.depth),k&&n.texSubImage3D(r.TEXTURE_3D,0,0,0,0,he.width,he.height,he.depth,Ae,Be,he.data)):n.texImage3D(r.TEXTURE_3D,0,Ne,he.width,he.height,he.depth,0,Ae,Be,he.data);else if(b.isFramebufferTexture){if(rt)if($e)n.texStorage2D(r.TEXTURE_2D,Te,Ne,he.width,he.height);else{let me=he.width,Ce=he.height;for(let Ie=0;Ie<Te;Ie++)n.texImage2D(r.TEXTURE_2D,Ie,Ne,me,Ce,0,Ae,Be,null),me>>=1,Ce>>=1}}else if(b.isHTMLTexture){if("texElementImage2D"in r){const me=r.canvas;if(me.hasAttribute("layoutsubtree")||me.setAttribute("layoutsubtree","true"),he.parentNode!==me){me.appendChild(he),_.add(b),me.onpaint=Ce=>{const Ie=Ce.changedElements;for(const Se of _)Ie.includes(Se.image)&&(Se.needsUpdate=!0)},me.requestPaint();return}if(r.texElementImage2D.length===3)r.texElementImage2D(r.TEXTURE_2D,r.RGBA8,he);else{const Ie=r.RGBA,Se=r.RGBA,We=r.UNSIGNED_BYTE;r.texElementImage2D(r.TEXTURE_2D,0,Ie,Se,We,he)}r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)}}else if(Ze.length>0){if($e&&rt){const me=Lt(Ze[0]);n.texStorage2D(r.TEXTURE_2D,Te,Ne,me.width,me.height)}for(let me=0,Ce=Ze.length;me<Ce;me++)De=Ze[me],$e?k&&n.texSubImage2D(r.TEXTURE_2D,me,0,0,Ae,Be,De):n.texImage2D(r.TEXTURE_2D,me,Ne,Ae,Be,De);b.generateMipmaps=!1}else if($e){if(rt){const me=Lt(he);n.texStorage2D(r.TEXTURE_2D,Te,Ne,me.width,me.height)}k&&n.texSubImage2D(r.TEXTURE_2D,0,0,0,Ae,Be,he)}else n.texImage2D(r.TEXTURE_2D,0,Ne,Ae,Be,he);S(b)&&B(se),we.__version=be.version,b.onUpdate&&b.onUpdate(b)}L.__version=b.version}function it(L,b,J){if(b.image.length!==6)return;const se=ae(L,b),fe=b.source;n.bindTexture(r.TEXTURE_CUBE_MAP,L.__webglTexture,r.TEXTURE0+J);const be=a.get(fe);if(fe.version!==be.__version||se===!0){n.activeTexture(r.TEXTURE0+J);const we=St.getPrimaries(St.workingColorSpace),ue=b.colorSpace===Ts?null:St.getPrimaries(b.colorSpace),he=b.colorSpace===Ts||we===ue?r.NONE:r.BROWSER_DEFAULT_WEBGL;n.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,b.flipY),n.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),n.pixelStorei(r.UNPACK_ALIGNMENT,b.unpackAlignment),n.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,he);const Ae=b.isCompressedTexture||b.image[0].isCompressedTexture,Be=b.image[0]&&b.image[0].isDataTexture,Ne=[];for(let Se=0;Se<6;Se++)!Ae&&!Be?Ne[Se]=M(b.image[Se],!0,o.maxCubemapSize):Ne[Se]=Be?b.image[Se].image:b.image[Se],Ne[Se]=kt(b,Ne[Se]);const De=Ne[0],Ze=c.convert(b.format,b.colorSpace),$e=c.convert(b.type),rt=w(b.internalFormat,Ze,$e,b.normalized,b.colorSpace),k=b.isVideoTexture!==!0,Te=be.__version===void 0||se===!0,me=fe.dataReady;let Ce=U(b,De);Pe(r.TEXTURE_CUBE_MAP,b);let Ie;if(Ae){k&&Te&&n.texStorage2D(r.TEXTURE_CUBE_MAP,Ce,rt,De.width,De.height);for(let Se=0;Se<6;Se++){Ie=Ne[Se].mipmaps;for(let We=0;We<Ie.length;We++){const Ge=Ie[We];b.format!==Ci?Ze!==null?k?me&&n.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,0,0,Ge.width,Ge.height,Ze,Ge.data):n.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,rt,Ge.width,Ge.height,0,Ge.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):k?me&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,0,0,Ge.width,Ge.height,Ze,$e,Ge.data):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We,rt,Ge.width,Ge.height,0,Ze,$e,Ge.data)}}}else{if(Ie=b.mipmaps,k&&Te){Ie.length>0&&Ce++;const Se=Lt(Ne[0]);n.texStorage2D(r.TEXTURE_CUBE_MAP,Ce,rt,Se.width,Se.height)}for(let Se=0;Se<6;Se++)if(Be){k?me&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,0,0,Ne[Se].width,Ne[Se].height,Ze,$e,Ne[Se].data):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,rt,Ne[Se].width,Ne[Se].height,0,Ze,$e,Ne[Se].data);for(let We=0;We<Ie.length;We++){const tn=Ie[We].image[Se].image;k?me&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,0,0,tn.width,tn.height,Ze,$e,tn.data):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,rt,tn.width,tn.height,0,Ze,$e,tn.data)}}else{k?me&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,0,0,Ze,$e,Ne[Se]):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,0,rt,Ze,$e,Ne[Se]);for(let We=0;We<Ie.length;We++){const Ge=Ie[We];k?me&&n.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,0,0,Ze,$e,Ge.image[Se]):n.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Se,We+1,rt,Ze,$e,Ge.image[Se])}}}S(b)&&B(r.TEXTURE_CUBE_MAP),be.__version=fe.version,b.onUpdate&&b.onUpdate(b)}L.__version=b.version}function je(L,b,J,se,fe,be){const we=c.convert(J.format,J.colorSpace),ue=c.convert(J.type),he=w(J.internalFormat,we,ue,J.normalized,J.colorSpace),Ae=a.get(b),Be=a.get(J);if(Be.__renderTarget=b,!Ae.__hasExternalTextures){const Ne=Math.max(1,b.width>>be),De=Math.max(1,b.height>>be);fe===r.TEXTURE_3D||fe===r.TEXTURE_2D_ARRAY?n.texImage3D(fe,be,he,Ne,De,b.depth,0,we,ue,null):n.texImage2D(fe,be,he,Ne,De,0,we,ue,null)}n.bindFramebuffer(r.FRAMEBUFFER,L),cn(b)?h.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,se,fe,Be.__webglTexture,0,Qt(b)):(fe===r.TEXTURE_2D||fe>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&fe<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,se,fe,Be.__webglTexture,be),n.bindFramebuffer(r.FRAMEBUFFER,null)}function Jt(L,b,J){if(r.bindRenderbuffer(r.RENDERBUFFER,L),b.depthBuffer){const se=b.depthTexture,fe=se&&se.isDepthTexture?se.type:null,be=P(b.stencilBuffer,fe),we=b.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;cn(b)?h.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Qt(b),be,b.width,b.height):J?r.renderbufferStorageMultisample(r.RENDERBUFFER,Qt(b),be,b.width,b.height):r.renderbufferStorage(r.RENDERBUFFER,be,b.width,b.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,we,r.RENDERBUFFER,L)}else{const se=b.textures;for(let fe=0;fe<se.length;fe++){const be=se[fe],we=c.convert(be.format,be.colorSpace),ue=c.convert(be.type),he=w(be.internalFormat,we,ue,be.normalized,be.colorSpace);cn(b)?h.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Qt(b),he,b.width,b.height):J?r.renderbufferStorageMultisample(r.RENDERBUFFER,Qt(b),he,b.width,b.height):r.renderbufferStorage(r.RENDERBUFFER,he,b.width,b.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function pt(L,b,J){const se=b.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(r.FRAMEBUFFER,L),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const fe=a.get(b.depthTexture);if(fe.__renderTarget=b,(!fe.__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),se){if(fe.__webglInit===void 0&&(fe.__webglInit=!0,b.depthTexture.addEventListener("dispose",N)),fe.__webglTexture===void 0){fe.__webglTexture=r.createTexture(),n.bindTexture(r.TEXTURE_CUBE_MAP,fe.__webglTexture),Pe(r.TEXTURE_CUBE_MAP,b.depthTexture);const Ae=c.convert(b.depthTexture.format),Be=c.convert(b.depthTexture.type);let Ne;b.depthTexture.format===Ga?Ne=r.DEPTH_COMPONENT24:b.depthTexture.format===nr&&(Ne=r.DEPTH24_STENCIL8);for(let De=0;De<6;De++)r.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+De,0,Ne,b.width,b.height,0,Ae,Be,null)}}else Q(b.depthTexture,0);const be=fe.__webglTexture,we=Qt(b),ue=se?r.TEXTURE_CUBE_MAP_POSITIVE_X+J:r.TEXTURE_2D,he=b.depthTexture.format===nr?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;if(b.depthTexture.format===Ga)cn(b)?h.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,he,ue,be,0,we):r.framebufferTexture2D(r.FRAMEBUFFER,he,ue,be,0);else if(b.depthTexture.format===nr)cn(b)?h.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,he,ue,be,0,we):r.framebufferTexture2D(r.FRAMEBUFFER,he,ue,be,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function Tt(L){const b=a.get(L),J=L.isWebGLCubeRenderTarget===!0;if(b.__boundDepthTexture!==L.depthTexture){const se=L.depthTexture;if(b.__depthDisposeCallback&&b.__depthDisposeCallback(),se){const fe=()=>{delete b.__boundDepthTexture,delete b.__depthDisposeCallback,se.removeEventListener("dispose",fe)};se.addEventListener("dispose",fe),b.__depthDisposeCallback=fe}b.__boundDepthTexture=se}if(L.depthTexture&&!b.__autoAllocateDepthBuffer)if(J)for(let se=0;se<6;se++)pt(b.__webglFramebuffer[se],L,se);else{const se=L.texture.mipmaps;se&&se.length>0?pt(b.__webglFramebuffer[0],L,0):pt(b.__webglFramebuffer,L,0)}else if(J){b.__webglDepthbuffer=[];for(let se=0;se<6;se++)if(n.bindFramebuffer(r.FRAMEBUFFER,b.__webglFramebuffer[se]),b.__webglDepthbuffer[se]===void 0)b.__webglDepthbuffer[se]=r.createRenderbuffer(),Jt(b.__webglDepthbuffer[se],L,!1);else{const fe=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,be=b.__webglDepthbuffer[se];r.bindRenderbuffer(r.RENDERBUFFER,be),r.framebufferRenderbuffer(r.FRAMEBUFFER,fe,r.RENDERBUFFER,be)}}else{const se=L.texture.mipmaps;if(se&&se.length>0?n.bindFramebuffer(r.FRAMEBUFFER,b.__webglFramebuffer[0]):n.bindFramebuffer(r.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer===void 0)b.__webglDepthbuffer=r.createRenderbuffer(),Jt(b.__webglDepthbuffer,L,!1);else{const fe=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,be=b.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,be),r.framebufferRenderbuffer(r.FRAMEBUFFER,fe,r.RENDERBUFFER,be)}}n.bindFramebuffer(r.FRAMEBUFFER,null)}function At(L,b,J){const se=a.get(L);b!==void 0&&je(se.__webglFramebuffer,L,L.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),J!==void 0&&Tt(L)}function _t(L){const b=L.texture,J=a.get(L),se=a.get(b);L.addEventListener("dispose",T);const fe=L.textures,be=L.isWebGLCubeRenderTarget===!0,we=fe.length>1;if(we||(se.__webglTexture===void 0&&(se.__webglTexture=r.createTexture()),se.__version=b.version,u.memory.textures++),be){J.__webglFramebuffer=[];for(let ue=0;ue<6;ue++)if(b.mipmaps&&b.mipmaps.length>0){J.__webglFramebuffer[ue]=[];for(let he=0;he<b.mipmaps.length;he++)J.__webglFramebuffer[ue][he]=r.createFramebuffer()}else J.__webglFramebuffer[ue]=r.createFramebuffer()}else{if(b.mipmaps&&b.mipmaps.length>0){J.__webglFramebuffer=[];for(let ue=0;ue<b.mipmaps.length;ue++)J.__webglFramebuffer[ue]=r.createFramebuffer()}else J.__webglFramebuffer=r.createFramebuffer();if(we)for(let ue=0,he=fe.length;ue<he;ue++){const Ae=a.get(fe[ue]);Ae.__webglTexture===void 0&&(Ae.__webglTexture=r.createTexture(),u.memory.textures++)}if(L.samples>0&&cn(L)===!1){J.__webglMultisampledFramebuffer=r.createFramebuffer(),J.__webglColorRenderbuffer=[],n.bindFramebuffer(r.FRAMEBUFFER,J.__webglMultisampledFramebuffer);for(let ue=0;ue<fe.length;ue++){const he=fe[ue];J.__webglColorRenderbuffer[ue]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,J.__webglColorRenderbuffer[ue]);const Ae=c.convert(he.format,he.colorSpace),Be=c.convert(he.type),Ne=w(he.internalFormat,Ae,Be,he.normalized,he.colorSpace,L.isXRRenderTarget===!0),De=Qt(L);r.renderbufferStorageMultisample(r.RENDERBUFFER,De,Ne,L.width,L.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ue,r.RENDERBUFFER,J.__webglColorRenderbuffer[ue])}r.bindRenderbuffer(r.RENDERBUFFER,null),L.depthBuffer&&(J.__webglDepthRenderbuffer=r.createRenderbuffer(),Jt(J.__webglDepthRenderbuffer,L,!0)),n.bindFramebuffer(r.FRAMEBUFFER,null)}}if(be){n.bindTexture(r.TEXTURE_CUBE_MAP,se.__webglTexture),Pe(r.TEXTURE_CUBE_MAP,b);for(let ue=0;ue<6;ue++)if(b.mipmaps&&b.mipmaps.length>0)for(let he=0;he<b.mipmaps.length;he++)je(J.__webglFramebuffer[ue][he],L,b,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ue,he);else je(J.__webglFramebuffer[ue],L,b,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ue,0);S(b)&&B(r.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(we){for(let ue=0,he=fe.length;ue<he;ue++){const Ae=fe[ue],Be=a.get(Ae);let Ne=r.TEXTURE_2D;(L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(Ne=L.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),n.bindTexture(Ne,Be.__webglTexture),Pe(Ne,Ae),je(J.__webglFramebuffer,L,Ae,r.COLOR_ATTACHMENT0+ue,Ne,0),S(Ae)&&B(Ne)}n.unbindTexture()}else{let ue=r.TEXTURE_2D;if((L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(ue=L.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),n.bindTexture(ue,se.__webglTexture),Pe(ue,b),b.mipmaps&&b.mipmaps.length>0)for(let he=0;he<b.mipmaps.length;he++)je(J.__webglFramebuffer[he],L,b,r.COLOR_ATTACHMENT0,ue,he);else je(J.__webglFramebuffer,L,b,r.COLOR_ATTACHMENT0,ue,0);S(b)&&B(ue),n.unbindTexture()}L.depthBuffer&&Tt(L)}function rn(L){const b=L.textures;for(let J=0,se=b.length;J<se;J++){const fe=b[J];if(S(fe)){const be=F(L),we=a.get(fe).__webglTexture;n.bindTexture(be,we),B(be),n.unbindTexture()}}}const on=[],ln=[];function hn(L){if(L.samples>0){if(cn(L)===!1){const b=L.textures,J=L.width,se=L.height;let fe=r.COLOR_BUFFER_BIT;const be=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,we=a.get(L),ue=b.length>1;if(ue)for(let Ae=0;Ae<b.length;Ae++)n.bindFramebuffer(r.FRAMEBUFFER,we.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ae,r.RENDERBUFFER,null),n.bindFramebuffer(r.FRAMEBUFFER,we.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ae,r.TEXTURE_2D,null,0);n.bindFramebuffer(r.READ_FRAMEBUFFER,we.__webglMultisampledFramebuffer);const he=L.texture.mipmaps;he&&he.length>0?n.bindFramebuffer(r.DRAW_FRAMEBUFFER,we.__webglFramebuffer[0]):n.bindFramebuffer(r.DRAW_FRAMEBUFFER,we.__webglFramebuffer);for(let Ae=0;Ae<b.length;Ae++){if(L.resolveDepthBuffer&&(L.depthBuffer&&(fe|=r.DEPTH_BUFFER_BIT),L.stencilBuffer&&L.resolveStencilBuffer&&(fe|=r.STENCIL_BUFFER_BIT)),ue){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,we.__webglColorRenderbuffer[Ae]);const Be=a.get(b[Ae]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,Be,0)}r.blitFramebuffer(0,0,J,se,0,0,J,se,fe,r.NEAREST),p===!0&&(on.length=0,ln.length=0,on.push(r.COLOR_ATTACHMENT0+Ae),L.depthBuffer&&L.resolveDepthBuffer===!1&&(on.push(be),ln.push(be),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,ln)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,on))}if(n.bindFramebuffer(r.READ_FRAMEBUFFER,null),n.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),ue)for(let Ae=0;Ae<b.length;Ae++){n.bindFramebuffer(r.FRAMEBUFFER,we.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ae,r.RENDERBUFFER,we.__webglColorRenderbuffer[Ae]);const Be=a.get(b[Ae]).__webglTexture;n.bindFramebuffer(r.FRAMEBUFFER,we.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Ae,r.TEXTURE_2D,Be,0)}n.bindFramebuffer(r.DRAW_FRAMEBUFFER,we.__webglMultisampledFramebuffer)}else if(L.depthBuffer&&L.resolveDepthBuffer===!1&&p){const b=L.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[b])}}}function Qt(L){return Math.min(o.maxSamples,L.samples)}function cn(L){const b=a.get(L);return L.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function q(L){const b=u.render.frame;g.get(L)!==b&&(g.set(L,b),L.update())}function kt(L,b){const J=L.colorSpace,se=L.format,fe=L.type;return L.isCompressedTexture===!0||L.isVideoTexture===!0||J!==gi&&J!==Ts&&(St.getTransfer(J)===Ht?(se!==Ci||fe!==mi)&&Ke("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):at("WebGLTextures: Unsupported texture color space:",J)),b}function Lt(L){return typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement?(d.width=L.naturalWidth||L.width,d.height=L.naturalHeight||L.height):typeof VideoFrame<"u"&&L instanceof VideoFrame?(d.width=L.displayWidth,d.height=L.displayHeight):(d.width=L.width,d.height=L.height),d}this.allocateTextureUnit=I,this.resetTextureUnits=ce,this.getTextureUnits=ge,this.setTextureUnits=j,this.setTexture2D=Q,this.setTexture2DArray=de,this.setTexture3D=ve,this.setTextureCube=D,this.rebindTextures=At,this.setupRenderTarget=_t,this.updateRenderTargetMipmap=rn,this.updateMultisampleRenderTarget=hn,this.setupDepthRenderbuffer=Tt,this.setupFrameBufferTexture=je,this.useMultisampledRTT=cn,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function IC(r,e){function n(a,o=Ts){let c;const u=St.getTransfer(o);if(a===mi)return r.UNSIGNED_BYTE;if(a===kp)return r.UNSIGNED_SHORT_4_4_4_4;if(a===Xp)return r.UNSIGNED_SHORT_5_5_5_1;if(a===Bx)return r.UNSIGNED_INT_5_9_9_9_REV;if(a===Fx)return r.UNSIGNED_INT_10F_11F_11F_REV;if(a===Px)return r.BYTE;if(a===Ix)return r.SHORT;if(a===Cl)return r.UNSIGNED_SHORT;if(a===Vp)return r.INT;if(a===ra)return r.UNSIGNED_INT;if(a===Ri)return r.FLOAT;if(a===Ha)return r.HALF_FLOAT;if(a===zx)return r.ALPHA;if(a===Hx)return r.RGB;if(a===Ci)return r.RGBA;if(a===Ga)return r.DEPTH_COMPONENT;if(a===nr)return r.DEPTH_STENCIL;if(a===Wp)return r.RED;if(a===qp)return r.RED_INTEGER;if(a===sr)return r.RG;if(a===Yp)return r.RG_INTEGER;if(a===Kp)return r.RGBA_INTEGER;if(a===Au||a===Ru||a===Cu||a===wu)if(u===Ht)if(c=e.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(a===Au)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(a===Ru)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(a===Cu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(a===wu)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=e.get("WEBGL_compressed_texture_s3tc"),c!==null){if(a===Au)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(a===Ru)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(a===Cu)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(a===wu)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(a===jd||a===$d||a===ep||a===tp)if(c=e.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(a===jd)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(a===$d)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(a===ep)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(a===tp)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(a===np||a===ip||a===ap||a===sp||a===rp||a===Uu||a===op)if(c=e.get("WEBGL_compressed_texture_etc"),c!==null){if(a===np||a===ip)return u===Ht?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(a===ap)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(a===sp)return c.COMPRESSED_R11_EAC;if(a===rp)return c.COMPRESSED_SIGNED_R11_EAC;if(a===Uu)return c.COMPRESSED_RG11_EAC;if(a===op)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(a===lp||a===cp||a===up||a===fp||a===hp||a===dp||a===pp||a===mp||a===gp||a===_p||a===vp||a===xp||a===yp||a===Sp)if(c=e.get("WEBGL_compressed_texture_astc"),c!==null){if(a===lp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(a===cp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(a===up)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(a===fp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(a===hp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(a===dp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(a===pp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(a===mp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(a===gp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(a===_p)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(a===vp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(a===xp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(a===yp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(a===Sp)return u===Ht?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(a===Mp||a===Ep||a===bp)if(c=e.get("EXT_texture_compression_bptc"),c!==null){if(a===Mp)return u===Ht?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(a===Ep)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(a===bp)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(a===Tp||a===Ap||a===Ou||a===Rp)if(c=e.get("EXT_texture_compression_rgtc"),c!==null){if(a===Tp)return c.COMPRESSED_RED_RGTC1_EXT;if(a===Ap)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(a===Ou)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(a===Rp)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return a===wl?r.UNSIGNED_INT_24_8:r[a]!==void 0?r[a]:null}return{convert:n}}const BC=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,FC=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class zC{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,n){if(this.texture===null){const a=new ey(e.texture);(e.depthNear!==n.depthNear||e.depthFar!==n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=a}}getMesh(e){if(this.texture!==null&&this.mesh===null){const n=e.cameras[0].viewport,a=new oa({vertexShader:BC,fragmentShader:FC,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new En(new Xu(20,20),a)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class HC extends rr{constructor(e,n){super();const a=this;let o=null,c=1,u=null,h="local-floor",p=1,d=null,g=null,_=null,v=null,x=null,E=null;const C=typeof XRWebGLBinding<"u",M=new zC,S={},B=n.getContextAttributes();let F=null,w=null;const P=[],U=[],N=new gt;let T=null;const O=new ti;O.viewport=new Yt;const X=new ti;X.viewport=new Yt;const G=[O,X],Z=new Gb;let ce=null,ge=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ae){let ye=P[ae];return ye===void 0&&(ye=new hd,P[ae]=ye),ye.getTargetRaySpace()},this.getControllerGrip=function(ae){let ye=P[ae];return ye===void 0&&(ye=new hd,P[ae]=ye),ye.getGripSpace()},this.getHand=function(ae){let ye=P[ae];return ye===void 0&&(ye=new hd,P[ae]=ye),ye.getHandSpace()};function j(ae){const ye=U.indexOf(ae.inputSource);if(ye===-1)return;const Me=P[ye];Me!==void 0&&(Me.update(ae.inputSource,ae.frame,d||u),Me.dispatchEvent({type:ae.type,data:ae.inputSource}))}function I(){o.removeEventListener("select",j),o.removeEventListener("selectstart",j),o.removeEventListener("selectend",j),o.removeEventListener("squeeze",j),o.removeEventListener("squeezestart",j),o.removeEventListener("squeezeend",j),o.removeEventListener("end",I),o.removeEventListener("inputsourceschange",z);for(let ae=0;ae<P.length;ae++){const ye=U[ae];ye!==null&&(U[ae]=null,P[ae].disconnect(ye))}ce=null,ge=null,M.reset();for(const ae in S)delete S[ae];e.setRenderTarget(F),x=null,v=null,_=null,o=null,w=null,Pe.stop(),a.isPresenting=!1,e.setPixelRatio(T),e.setSize(N.width,N.height,!1),a.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ae){c=ae,a.isPresenting===!0&&Ke("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ae){h=ae,a.isPresenting===!0&&Ke("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return d||u},this.setReferenceSpace=function(ae){d=ae},this.getBaseLayer=function(){return v!==null?v:x},this.getBinding=function(){return _===null&&C&&(_=new XRWebGLBinding(o,n)),_},this.getFrame=function(){return E},this.getSession=function(){return o},this.setSession=async function(ae){if(o=ae,o!==null){if(F=e.getRenderTarget(),o.addEventListener("select",j),o.addEventListener("selectstart",j),o.addEventListener("selectend",j),o.addEventListener("squeeze",j),o.addEventListener("squeezestart",j),o.addEventListener("squeezeend",j),o.addEventListener("end",I),o.addEventListener("inputsourceschange",z),B.xrCompatible!==!0&&await n.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(N),C&&"createProjectionLayer"in XRWebGLBinding.prototype){let Me=null,ze=null,it=null;B.depth&&(it=B.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,Me=B.stencil?nr:Ga,ze=B.stencil?wl:ra);const je={colorFormat:n.RGBA8,depthFormat:it,scaleFactor:c};_=this.getBinding(),v=_.createProjectionLayer(je),o.updateRenderState({layers:[v]}),e.setPixelRatio(1),e.setSize(v.textureWidth,v.textureHeight,!1),w=new sa(v.textureWidth,v.textureHeight,{format:Ci,type:mi,depthTexture:new uo(v.textureWidth,v.textureHeight,ze,void 0,void 0,void 0,void 0,void 0,void 0,Me),stencilBuffer:B.stencil,colorSpace:e.outputColorSpace,samples:B.antialias?4:0,resolveDepthBuffer:v.ignoreDepthValues===!1,resolveStencilBuffer:v.ignoreDepthValues===!1})}else{const Me={antialias:B.antialias,alpha:!0,depth:B.depth,stencil:B.stencil,framebufferScaleFactor:c};x=new XRWebGLLayer(o,n,Me),o.updateRenderState({baseLayer:x}),e.setPixelRatio(1),e.setSize(x.framebufferWidth,x.framebufferHeight,!1),w=new sa(x.framebufferWidth,x.framebufferHeight,{format:Ci,type:mi,colorSpace:e.outputColorSpace,stencilBuffer:B.stencil,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1})}w.isXRRenderTarget=!0,this.setFoveation(p),d=null,u=await o.requestReferenceSpace(h),Pe.setContext(o),Pe.start(),a.isPresenting=!0,a.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(o!==null)return o.environmentBlendMode},this.getDepthTexture=function(){return M.getDepthTexture()};function z(ae){for(let ye=0;ye<ae.removed.length;ye++){const Me=ae.removed[ye],ze=U.indexOf(Me);ze>=0&&(U[ze]=null,P[ze].disconnect(Me))}for(let ye=0;ye<ae.added.length;ye++){const Me=ae.added[ye];let ze=U.indexOf(Me);if(ze===-1){for(let je=0;je<P.length;je++)if(je>=U.length){U.push(Me),ze=je;break}else if(U[je]===null){U[je]=Me,ze=je;break}if(ze===-1)break}const it=P[ze];it&&it.connect(Me)}}const Q=new $,de=new $;function ve(ae,ye,Me){Q.setFromMatrixPosition(ye.matrixWorld),de.setFromMatrixPosition(Me.matrixWorld);const ze=Q.distanceTo(de),it=ye.projectionMatrix.elements,je=Me.projectionMatrix.elements,Jt=it[14]/(it[10]-1),pt=it[14]/(it[10]+1),Tt=(it[9]+1)/it[5],At=(it[9]-1)/it[5],_t=(it[8]-1)/it[0],rn=(je[8]+1)/je[0],on=Jt*_t,ln=Jt*rn,hn=ze/(-_t+rn),Qt=hn*-_t;if(ye.matrixWorld.decompose(ae.position,ae.quaternion,ae.scale),ae.translateX(Qt),ae.translateZ(hn),ae.matrixWorld.compose(ae.position,ae.quaternion,ae.scale),ae.matrixWorldInverse.copy(ae.matrixWorld).invert(),it[10]===-1)ae.projectionMatrix.copy(ye.projectionMatrix),ae.projectionMatrixInverse.copy(ye.projectionMatrixInverse);else{const cn=Jt+hn,q=pt+hn,kt=on-Qt,Lt=ln+(ze-Qt),L=Tt*pt/q*cn,b=At*pt/q*cn;ae.projectionMatrix.makePerspective(kt,Lt,L,b,cn,q),ae.projectionMatrixInverse.copy(ae.projectionMatrix).invert()}}function D(ae,ye){ye===null?ae.matrixWorld.copy(ae.matrix):ae.matrixWorld.multiplyMatrices(ye.matrixWorld,ae.matrix),ae.matrixWorldInverse.copy(ae.matrixWorld).invert()}this.updateCamera=function(ae){if(o===null)return;let ye=ae.near,Me=ae.far;M.texture!==null&&(M.depthNear>0&&(ye=M.depthNear),M.depthFar>0&&(Me=M.depthFar)),Z.near=X.near=O.near=ye,Z.far=X.far=O.far=Me,(ce!==Z.near||ge!==Z.far)&&(o.updateRenderState({depthNear:Z.near,depthFar:Z.far}),ce=Z.near,ge=Z.far),Z.layers.mask=ae.layers.mask|6,O.layers.mask=Z.layers.mask&-5,X.layers.mask=Z.layers.mask&-3;const ze=ae.parent,it=Z.cameras;D(Z,ze);for(let je=0;je<it.length;je++)D(it[je],ze);it.length===2?ve(Z,O,X):Z.projectionMatrix.copy(O.projectionMatrix),Y(ae,Z,ze)};function Y(ae,ye,Me){Me===null?ae.matrix.copy(ye.matrixWorld):(ae.matrix.copy(Me.matrixWorld),ae.matrix.invert(),ae.matrix.multiply(ye.matrixWorld)),ae.matrix.decompose(ae.position,ae.quaternion,ae.scale),ae.updateMatrixWorld(!0),ae.projectionMatrix.copy(ye.projectionMatrix),ae.projectionMatrixInverse.copy(ye.projectionMatrixInverse),ae.isPerspectiveCamera&&(ae.fov=co*2*Math.atan(1/ae.projectionMatrix.elements[5]),ae.zoom=1)}this.getCamera=function(){return Z},this.getFoveation=function(){if(!(v===null&&x===null))return p},this.setFoveation=function(ae){p=ae,v!==null&&(v.fixedFoveation=ae),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=ae)},this.hasDepthSensing=function(){return M.texture!==null},this.getDepthSensingMesh=function(){return M.getMesh(Z)},this.getCameraTexture=function(ae){return S[ae]};let Ee=null;function Re(ae,ye){if(g=ye.getViewerPose(d||u),E=ye,g!==null){const Me=g.views;x!==null&&(e.setRenderTargetFramebuffer(w,x.framebuffer),e.setRenderTarget(w));let ze=!1;Me.length!==Z.cameras.length&&(Z.cameras.length=0,ze=!0);for(let pt=0;pt<Me.length;pt++){const Tt=Me[pt];let At=null;if(x!==null)At=x.getViewport(Tt);else{const rn=_.getViewSubImage(v,Tt);At=rn.viewport,pt===0&&(e.setRenderTargetTextures(w,rn.colorTexture,rn.depthStencilTexture),e.setRenderTarget(w))}let _t=G[pt];_t===void 0&&(_t=new ti,_t.layers.enable(pt),_t.viewport=new Yt,G[pt]=_t),_t.matrix.fromArray(Tt.transform.matrix),_t.matrix.decompose(_t.position,_t.quaternion,_t.scale),_t.projectionMatrix.fromArray(Tt.projectionMatrix),_t.projectionMatrixInverse.copy(_t.projectionMatrix).invert(),_t.viewport.set(At.x,At.y,At.width,At.height),pt===0&&(Z.matrix.copy(_t.matrix),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale)),ze===!0&&Z.cameras.push(_t)}const it=o.enabledFeatures;if(it&&it.includes("depth-sensing")&&o.depthUsage=="gpu-optimized"&&C){_=a.getBinding();const pt=_.getDepthInformation(Me[0]);pt&&pt.isValid&&pt.texture&&M.init(pt,o.renderState)}if(it&&it.includes("camera-access")&&C){e.state.unbindTexture(),_=a.getBinding();for(let pt=0;pt<Me.length;pt++){const Tt=Me[pt].camera;if(Tt){let At=S[Tt];At||(At=new ey,S[Tt]=At);const _t=_.getCameraImage(Tt);At.sourceTexture=_t}}}}for(let Me=0;Me<P.length;Me++){const ze=U[Me],it=P[Me];ze!==null&&it!==void 0&&it.update(ze,ye,d||u)}Ee&&Ee(ae,ye),ye.detectedPlanes&&a.dispatchEvent({type:"planesdetected",data:ye}),E=null}const Pe=new ry;Pe.setAnimationLoop(Re),this.setAnimationLoop=function(ae){Ee=ae},this.dispose=function(){}}}const GC=new dt,dy=new lt;dy.set(-1,0,0,0,1,0,0,0,1);function VC(r,e){function n(M,S){M.matrixAutoUpdate===!0&&M.updateMatrix(),S.value.copy(M.matrix)}function a(M,S){S.color.getRGB(M.fogColor.value,ty(r)),S.isFog?(M.fogNear.value=S.near,M.fogFar.value=S.far):S.isFogExp2&&(M.fogDensity.value=S.density)}function o(M,S,B,F,w){S.isNodeMaterial?S.uniformsNeedUpdate=!1:S.isMeshBasicMaterial?c(M,S):S.isMeshLambertMaterial?(c(M,S),S.envMap&&(M.envMapIntensity.value=S.envMapIntensity)):S.isMeshToonMaterial?(c(M,S),_(M,S)):S.isMeshPhongMaterial?(c(M,S),g(M,S),S.envMap&&(M.envMapIntensity.value=S.envMapIntensity)):S.isMeshStandardMaterial?(c(M,S),v(M,S),S.isMeshPhysicalMaterial&&x(M,S,w)):S.isMeshMatcapMaterial?(c(M,S),E(M,S)):S.isMeshDepthMaterial?c(M,S):S.isMeshDistanceMaterial?(c(M,S),C(M,S)):S.isMeshNormalMaterial?c(M,S):S.isLineBasicMaterial?(u(M,S),S.isLineDashedMaterial&&h(M,S)):S.isPointsMaterial?p(M,S,B,F):S.isSpriteMaterial?d(M,S):S.isShadowMaterial?(M.color.value.copy(S.color),M.opacity.value=S.opacity):S.isShaderMaterial&&(S.uniformsNeedUpdate=!1)}function c(M,S){M.opacity.value=S.opacity,S.color&&M.diffuse.value.copy(S.color),S.emissive&&M.emissive.value.copy(S.emissive).multiplyScalar(S.emissiveIntensity),S.map&&(M.map.value=S.map,n(S.map,M.mapTransform)),S.alphaMap&&(M.alphaMap.value=S.alphaMap,n(S.alphaMap,M.alphaMapTransform)),S.bumpMap&&(M.bumpMap.value=S.bumpMap,n(S.bumpMap,M.bumpMapTransform),M.bumpScale.value=S.bumpScale,S.side===qn&&(M.bumpScale.value*=-1)),S.normalMap&&(M.normalMap.value=S.normalMap,n(S.normalMap,M.normalMapTransform),M.normalScale.value.copy(S.normalScale),S.side===qn&&M.normalScale.value.negate()),S.displacementMap&&(M.displacementMap.value=S.displacementMap,n(S.displacementMap,M.displacementMapTransform),M.displacementScale.value=S.displacementScale,M.displacementBias.value=S.displacementBias),S.emissiveMap&&(M.emissiveMap.value=S.emissiveMap,n(S.emissiveMap,M.emissiveMapTransform)),S.specularMap&&(M.specularMap.value=S.specularMap,n(S.specularMap,M.specularMapTransform)),S.alphaTest>0&&(M.alphaTest.value=S.alphaTest);const B=e.get(S),F=B.envMap,w=B.envMapRotation;F&&(M.envMap.value=F,M.envMapRotation.value.setFromMatrix4(GC.makeRotationFromEuler(w)).transpose(),F.isCubeTexture&&F.isRenderTargetTexture===!1&&M.envMapRotation.value.premultiply(dy),M.reflectivity.value=S.reflectivity,M.ior.value=S.ior,M.refractionRatio.value=S.refractionRatio),S.lightMap&&(M.lightMap.value=S.lightMap,M.lightMapIntensity.value=S.lightMapIntensity,n(S.lightMap,M.lightMapTransform)),S.aoMap&&(M.aoMap.value=S.aoMap,M.aoMapIntensity.value=S.aoMapIntensity,n(S.aoMap,M.aoMapTransform))}function u(M,S){M.diffuse.value.copy(S.color),M.opacity.value=S.opacity,S.map&&(M.map.value=S.map,n(S.map,M.mapTransform))}function h(M,S){M.dashSize.value=S.dashSize,M.totalSize.value=S.dashSize+S.gapSize,M.scale.value=S.scale}function p(M,S,B,F){M.diffuse.value.copy(S.color),M.opacity.value=S.opacity,M.size.value=S.size*B,M.scale.value=F*.5,S.map&&(M.map.value=S.map,n(S.map,M.uvTransform)),S.alphaMap&&(M.alphaMap.value=S.alphaMap,n(S.alphaMap,M.alphaMapTransform)),S.alphaTest>0&&(M.alphaTest.value=S.alphaTest)}function d(M,S){M.diffuse.value.copy(S.color),M.opacity.value=S.opacity,M.rotation.value=S.rotation,S.map&&(M.map.value=S.map,n(S.map,M.mapTransform)),S.alphaMap&&(M.alphaMap.value=S.alphaMap,n(S.alphaMap,M.alphaMapTransform)),S.alphaTest>0&&(M.alphaTest.value=S.alphaTest)}function g(M,S){M.specular.value.copy(S.specular),M.shininess.value=Math.max(S.shininess,1e-4)}function _(M,S){S.gradientMap&&(M.gradientMap.value=S.gradientMap)}function v(M,S){M.metalness.value=S.metalness,S.metalnessMap&&(M.metalnessMap.value=S.metalnessMap,n(S.metalnessMap,M.metalnessMapTransform)),M.roughness.value=S.roughness,S.roughnessMap&&(M.roughnessMap.value=S.roughnessMap,n(S.roughnessMap,M.roughnessMapTransform)),S.envMap&&(M.envMapIntensity.value=S.envMapIntensity)}function x(M,S,B){M.ior.value=S.ior,S.sheen>0&&(M.sheenColor.value.copy(S.sheenColor).multiplyScalar(S.sheen),M.sheenRoughness.value=S.sheenRoughness,S.sheenColorMap&&(M.sheenColorMap.value=S.sheenColorMap,n(S.sheenColorMap,M.sheenColorMapTransform)),S.sheenRoughnessMap&&(M.sheenRoughnessMap.value=S.sheenRoughnessMap,n(S.sheenRoughnessMap,M.sheenRoughnessMapTransform))),S.clearcoat>0&&(M.clearcoat.value=S.clearcoat,M.clearcoatRoughness.value=S.clearcoatRoughness,S.clearcoatMap&&(M.clearcoatMap.value=S.clearcoatMap,n(S.clearcoatMap,M.clearcoatMapTransform)),S.clearcoatRoughnessMap&&(M.clearcoatRoughnessMap.value=S.clearcoatRoughnessMap,n(S.clearcoatRoughnessMap,M.clearcoatRoughnessMapTransform)),S.clearcoatNormalMap&&(M.clearcoatNormalMap.value=S.clearcoatNormalMap,n(S.clearcoatNormalMap,M.clearcoatNormalMapTransform),M.clearcoatNormalScale.value.copy(S.clearcoatNormalScale),S.side===qn&&M.clearcoatNormalScale.value.negate())),S.dispersion>0&&(M.dispersion.value=S.dispersion),S.iridescence>0&&(M.iridescence.value=S.iridescence,M.iridescenceIOR.value=S.iridescenceIOR,M.iridescenceThicknessMinimum.value=S.iridescenceThicknessRange[0],M.iridescenceThicknessMaximum.value=S.iridescenceThicknessRange[1],S.iridescenceMap&&(M.iridescenceMap.value=S.iridescenceMap,n(S.iridescenceMap,M.iridescenceMapTransform)),S.iridescenceThicknessMap&&(M.iridescenceThicknessMap.value=S.iridescenceThicknessMap,n(S.iridescenceThicknessMap,M.iridescenceThicknessMapTransform))),S.transmission>0&&(M.transmission.value=S.transmission,M.transmissionSamplerMap.value=B.texture,M.transmissionSamplerSize.value.set(B.width,B.height),S.transmissionMap&&(M.transmissionMap.value=S.transmissionMap,n(S.transmissionMap,M.transmissionMapTransform)),M.thickness.value=S.thickness,S.thicknessMap&&(M.thicknessMap.value=S.thicknessMap,n(S.thicknessMap,M.thicknessMapTransform)),M.attenuationDistance.value=S.attenuationDistance,M.attenuationColor.value.copy(S.attenuationColor)),S.anisotropy>0&&(M.anisotropyVector.value.set(S.anisotropy*Math.cos(S.anisotropyRotation),S.anisotropy*Math.sin(S.anisotropyRotation)),S.anisotropyMap&&(M.anisotropyMap.value=S.anisotropyMap,n(S.anisotropyMap,M.anisotropyMapTransform))),M.specularIntensity.value=S.specularIntensity,M.specularColor.value.copy(S.specularColor),S.specularColorMap&&(M.specularColorMap.value=S.specularColorMap,n(S.specularColorMap,M.specularColorMapTransform)),S.specularIntensityMap&&(M.specularIntensityMap.value=S.specularIntensityMap,n(S.specularIntensityMap,M.specularIntensityMapTransform))}function E(M,S){S.matcap&&(M.matcap.value=S.matcap)}function C(M,S){const B=e.get(S).light;M.referencePosition.value.setFromMatrixPosition(B.matrixWorld),M.nearDistance.value=B.shadow.camera.near,M.farDistance.value=B.shadow.camera.far}return{refreshFogUniforms:a,refreshMaterialUniforms:o}}function kC(r,e,n,a){let o={},c={},u=[];const h=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function p(w,P){const U=P.program;a.uniformBlockBinding(w,U)}function d(w,P){let U=o[w.id];U===void 0&&(M(w),U=g(w),o[w.id]=U,w.addEventListener("dispose",B));const N=P.program;a.updateUBOMapping(w,N);const T=e.render.frame;c[w.id]!==T&&(v(w),c[w.id]=T)}function g(w){const P=_();w.__bindingPointIndex=P;const U=r.createBuffer(),N=w.__size,T=w.usage;return r.bindBuffer(r.UNIFORM_BUFFER,U),r.bufferData(r.UNIFORM_BUFFER,N,T),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,P,U),U}function _(){for(let w=0;w<h;w++)if(u.indexOf(w)===-1)return u.push(w),w;return at("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function v(w){const P=o[w.id],U=w.uniforms,N=w.__cache;r.bindBuffer(r.UNIFORM_BUFFER,P);for(let T=0,O=U.length;T<O;T++){const X=U[T];if(Array.isArray(X))for(let G=0,Z=X.length;G<Z;G++)x(X[G],T,G,N);else x(X,T,0,N)}r.bindBuffer(r.UNIFORM_BUFFER,null)}function x(w,P,U,N){if(C(w,P,U,N)===!0){const T=w.__offset,O=w.value;if(Array.isArray(O)){let X=0;for(let G=0;G<O.length;G++){const Z=O[G],ce=S(Z);E(Z,w.__data,X),typeof Z!="number"&&typeof Z!="boolean"&&!Z.isMatrix3&&!ArrayBuffer.isView(Z)&&(X+=ce.storage/Float32Array.BYTES_PER_ELEMENT)}}else E(O,w.__data,0);r.bufferSubData(r.UNIFORM_BUFFER,T,w.__data)}}function E(w,P,U){typeof w=="number"||typeof w=="boolean"?P[0]=w:w.isMatrix3?(P[0]=w.elements[0],P[1]=w.elements[1],P[2]=w.elements[2],P[3]=0,P[4]=w.elements[3],P[5]=w.elements[4],P[6]=w.elements[5],P[7]=0,P[8]=w.elements[6],P[9]=w.elements[7],P[10]=w.elements[8],P[11]=0):ArrayBuffer.isView(w)?P.set(new w.constructor(w.buffer,w.byteOffset,P.length)):w.toArray(P,U)}function C(w,P,U,N){const T=w.value,O=P+"_"+U;if(N[O]===void 0)return typeof T=="number"||typeof T=="boolean"?N[O]=T:ArrayBuffer.isView(T)?N[O]=T.slice():N[O]=T.clone(),!0;{const X=N[O];if(typeof T=="number"||typeof T=="boolean"){if(X!==T)return N[O]=T,!0}else{if(ArrayBuffer.isView(T))return!0;if(X.equals(T)===!1)return X.copy(T),!0}}return!1}function M(w){const P=w.uniforms;let U=0;const N=16;for(let O=0,X=P.length;O<X;O++){const G=Array.isArray(P[O])?P[O]:[P[O]];for(let Z=0,ce=G.length;Z<ce;Z++){const ge=G[Z],j=Array.isArray(ge.value)?ge.value:[ge.value];for(let I=0,z=j.length;I<z;I++){const Q=j[I],de=S(Q),ve=U%N,D=ve%de.boundary,Y=ve+D;U+=D,Y!==0&&N-Y<de.storage&&(U+=N-Y),ge.__data=new Float32Array(de.storage/Float32Array.BYTES_PER_ELEMENT),ge.__offset=U,U+=de.storage}}}const T=U%N;return T>0&&(U+=N-T),w.__size=U,w.__cache={},this}function S(w){const P={boundary:0,storage:0};return typeof w=="number"||typeof w=="boolean"?(P.boundary=4,P.storage=4):w.isVector2?(P.boundary=8,P.storage=8):w.isVector3||w.isColor?(P.boundary=16,P.storage=12):w.isVector4?(P.boundary=16,P.storage=16):w.isMatrix3?(P.boundary=48,P.storage=48):w.isMatrix4?(P.boundary=64,P.storage=64):w.isTexture?Ke("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(w)?(P.boundary=16,P.storage=w.byteLength):Ke("WebGLRenderer: Unsupported uniform value type.",w),P}function B(w){const P=w.target;P.removeEventListener("dispose",B);const U=u.indexOf(P.__bindingPointIndex);u.splice(U,1),r.deleteBuffer(o[P.id]),delete o[P.id],delete c[P.id]}function F(){for(const w in o)r.deleteBuffer(o[w]);u=[],o={},c={}}return{bind:p,update:d,dispose:F}}const XC=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ji=null;function WC(){return ji===null&&(ji=new em(XC,16,16,sr,Ha),ji.name="DFG_LUT",ji.minFilter=Rn,ji.magFilter=Rn,ji.wrapS=na,ji.wrapT=na,ji.generateMipmaps=!1,ji.needsUpdate=!0),ji}class qC{constructor(e={}){const{canvas:n=mE(),context:a=null,depth:o=!0,stencil:c=!1,alpha:u=!1,antialias:h=!1,premultipliedAlpha:p=!0,preserveDrawingBuffer:d=!1,powerPreference:g="default",failIfMajorPerformanceCaveat:_=!1,reversedDepthBuffer:v=!1,outputBufferType:x=mi}=e;this.isWebGLRenderer=!0;let E;if(a!==null){if(typeof WebGLRenderingContext<"u"&&a instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");E=a.getContextAttributes().alpha}else E=u;const C=x,M=new Set([Kp,Yp,qp]),S=new Set([mi,ra,Cl,wl,kp,Xp]),B=new Uint32Array(4),F=new Int32Array(4),w=new $;let P=null,U=null;const N=[],T=[];let O=null;this.domElement=n,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=aa,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const X=this;let G=!1,Z=null,ce=null,ge=null,j=null;this._outputColorSpace=Nn;let I=0,z=0,Q=null,de=-1,ve=null;const D=new Yt,Y=new Yt;let Ee=null;const Re=new st(0);let Pe=0,ae=n.width,ye=n.height,Me=1,ze=null,it=null;const je=new Yt(0,0,ae,ye),Jt=new Yt(0,0,ae,ye);let pt=!1;const Tt=new nm;let At=!1,_t=!1;const rn=new dt,on=new $,ln=new Yt,hn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Qt=!1;function cn(){return Q===null?Me:1}let q=a;function kt(A,W){return n.getContext(A,W)}try{const A={alpha:!0,depth:o,stencil:c,antialias:h,premultipliedAlpha:p,preserveDrawingBuffer:d,powerPreference:g,failIfMajorPerformanceCaveat:_};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${zp}`),n.addEventListener("webglcontextlost",tn,!1),n.addEventListener("webglcontextrestored",Ot,!1),n.addEventListener("webglcontextcreationerror",ni,!1),q===null){const W="webgl2";if(q=kt(W,A),q===null)throw kt(W)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}}catch(A){throw at("WebGLRenderer: "+A.message),A}let Lt,L,b,J,se,fe,be,we,ue,he,Ae,Be,Ne,De,Ze,$e,rt,k,Te,me,Ce,Ie,Se;function We(){Lt=new WA(q),Lt.init(),Ce=new IC(q,Lt),L=new BA(q,Lt,e,Ce),b=new OC(q,Lt),L.reversedDepthBuffer&&v&&b.buffers.depth.setReversed(!0),ce=q.createFramebuffer(),ge=q.createFramebuffer(),j=q.createFramebuffer(),J=new KA(q),se=new yC,fe=new PC(q,Lt,b,se,L,Ce,J),be=new XA(X),we=new jb(q),Ie=new PA(q,we),ue=new qA(q,we,J,Ie),he=new QA(q,ue,we,Ie,J),k=new ZA(q,L,fe),Ze=new FA(se),Ae=new xC(X,be,Lt,L,Ie,Ze),Be=new VC(X,se),Ne=new MC,De=new CC(Lt),rt=new OA(X,be,b,he,E,p),$e=new UC(X,he,L),Se=new kC(q,J,L,b),Te=new IA(q,Lt,J),me=new YA(q,Lt,J),J.programs=Ae.programs,X.capabilities=L,X.extensions=Lt,X.properties=se,X.renderLists=Ne,X.shadowMap=$e,X.state=b,X.info=J}We(),C!==mi&&(O=new jA(C,n.width,n.height,h,o,c));const Ge=new HC(X,q);this.xr=Ge,this.getContext=function(){return q},this.getContextAttributes=function(){return q.getContextAttributes()},this.forceContextLoss=function(){const A=Lt.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){const A=Lt.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return Me},this.setPixelRatio=function(A){A!==void 0&&(Me=A,this.setSize(ae,ye,!1))},this.getSize=function(A){return A.set(ae,ye)},this.setSize=function(A,W,re=!0){if(Ge.isPresenting){Ke("WebGLRenderer: Can't change size while VR device is presenting.");return}ae=A,ye=W,n.width=Math.floor(A*Me),n.height=Math.floor(W*Me),re===!0&&(n.style.width=A+"px",n.style.height=W+"px"),O!==null&&O.setSize(n.width,n.height),this.setViewport(0,0,A,W)},this.getDrawingBufferSize=function(A){return A.set(ae*Me,ye*Me).floor()},this.setDrawingBufferSize=function(A,W,re){ae=A,ye=W,Me=re,n.width=Math.floor(A*re),n.height=Math.floor(W*re),this.setViewport(0,0,A,W)},this.setEffects=function(A){if(C===mi){at("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(A){for(let W=0;W<A.length;W++)if(A[W].isOutputPass===!0){Ke("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}O.setEffects(A||[])},this.getCurrentViewport=function(A){return A.copy(D)},this.getViewport=function(A){return A.copy(je)},this.setViewport=function(A,W,re,ne){A.isVector4?je.set(A.x,A.y,A.z,A.w):je.set(A,W,re,ne),b.viewport(D.copy(je).multiplyScalar(Me).round())},this.getScissor=function(A){return A.copy(Jt)},this.setScissor=function(A,W,re,ne){A.isVector4?Jt.set(A.x,A.y,A.z,A.w):Jt.set(A,W,re,ne),b.scissor(Y.copy(Jt).multiplyScalar(Me).round())},this.getScissorTest=function(){return pt},this.setScissorTest=function(A){b.setScissorTest(pt=A)},this.setOpaqueSort=function(A){ze=A},this.setTransparentSort=function(A){it=A},this.getClearColor=function(A){return A.copy(rt.getClearColor())},this.setClearColor=function(){rt.setClearColor(...arguments)},this.getClearAlpha=function(){return rt.getClearAlpha()},this.setClearAlpha=function(){rt.setClearAlpha(...arguments)},this.clear=function(A=!0,W=!0,re=!0){let ne=0;if(A){let ie=!1;if(Q!==null){const Ue=Q.texture.format;ie=M.has(Ue)}if(ie){const Ue=Q.texture.type,He=S.has(Ue),Le=rt.getClearColor(),ke=rt.getClearAlpha(),Ve=Le.r,et=Le.g,ct=Le.b;He?(B[0]=Ve,B[1]=et,B[2]=ct,B[3]=ke,q.clearBufferuiv(q.COLOR,0,B)):(F[0]=Ve,F[1]=et,F[2]=ct,F[3]=ke,q.clearBufferiv(q.COLOR,0,F))}else ne|=q.COLOR_BUFFER_BIT}W&&(ne|=q.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),re&&(ne|=q.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),ne!==0&&q.clear(ne)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(A){A.setRenderer(this),Z=A},this.dispose=function(){n.removeEventListener("webglcontextlost",tn,!1),n.removeEventListener("webglcontextrestored",Ot,!1),n.removeEventListener("webglcontextcreationerror",ni,!1),rt.dispose(),Ne.dispose(),De.dispose(),se.dispose(),be.dispose(),he.dispose(),Ie.dispose(),Se.dispose(),Ae.dispose(),Ge.dispose(),Ge.removeEventListener("sessionstart",gn),Ge.removeEventListener("sessionend",On),Kn.stop()};function tn(A){A.preventDefault(),Bu("WebGLRenderer: Context Lost."),G=!0}function Ot(){Bu("WebGLRenderer: Context Restored."),G=!1;const A=J.autoReset,W=$e.enabled,re=$e.autoUpdate,ne=$e.needsUpdate,ie=$e.type;We(),J.autoReset=A,$e.enabled=W,$e.autoUpdate=re,$e.needsUpdate=ne,$e.type=ie}function ni(A){at("WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function ii(A){const W=A.target;W.removeEventListener("dispose",ii),xo(W)}function xo(A){yo(A),se.remove(A)}function yo(A){const W=se.get(A).programs;W!==void 0&&(W.forEach(function(re){Ae.releaseProgram(re)}),A.isShaderMaterial&&Ae.releaseShaderCache(A))}this.renderBufferDirect=function(A,W,re,ne,ie,Ue){W===null&&(W=hn);const He=ie.isMesh&&ie.matrixWorld.determinantAffine()<0,Le=qa(A,W,re,ne,ie);b.setMaterial(ne,He);let ke=re.index,Ve=1;if(ne.wireframe===!0){if(ke=ue.getWireframeAttribute(re),ke===void 0)return;Ve=2}const et=re.drawRange,ct=re.attributes.position;let Ye=et.start*Ve,Ct=(et.start+et.count)*Ve;Ue!==null&&(Ye=Math.max(Ye,Ue.start*Ve),Ct=Math.min(Ct,(Ue.start+Ue.count)*Ve)),ke!==null?(Ye=Math.max(Ye,0),Ct=Math.min(Ct,ke.count)):ct!=null&&(Ye=Math.max(Ye,0),Ct=Math.min(Ct,ct.count));const nn=Ct-Ye;if(nn<0||nn===1/0)return;Ie.setup(ie,ne,Le,re,ke);let Kt,Pt=Te;if(ke!==null&&(Kt=we.get(ke),Pt=me,Pt.setIndex(Kt)),ie.isMesh)ne.wireframe===!0?(b.setLineWidth(ne.wireframeLinewidth*cn()),Pt.setMode(q.LINES)):Pt.setMode(q.TRIANGLES);else if(ie.isLine){let It=ne.linewidth;It===void 0&&(It=1),b.setLineWidth(It*cn()),ie.isLineSegments?Pt.setMode(q.LINES):ie.isLineLoop?Pt.setMode(q.LINE_LOOP):Pt.setMode(q.LINE_STRIP)}else ie.isPoints?Pt.setMode(q.POINTS):ie.isSprite&&Pt.setMode(q.TRIANGLES);if(ie.isBatchedMesh)if(Lt.get("WEBGL_multi_draw"))Pt.renderMultiDraw(ie._multiDrawStarts,ie._multiDrawCounts,ie._multiDrawCount);else{const It=ie._multiDrawStarts,Fe=ie._multiDrawCounts,zn=ie._multiDrawCount,vt=ke?we.get(ke).bytesPerElement:1,bn=se.get(ne).currentProgram.getUniforms();for(let ai=0;ai<zn;ai++)bn.setValue(q,"_gl_DrawID",ai),Pt.render(It[ai]/vt,Fe[ai])}else if(ie.isInstancedMesh)Pt.renderInstances(Ye,nn,ie.count);else if(re.isInstancedBufferGeometry){const It=re._maxInstanceCount!==void 0?re._maxInstanceCount:1/0,Fe=Math.min(re.instanceCount,It);Pt.renderInstances(Ye,nn,Fe)}else Pt.render(Ye,nn)};function So(A,W,re){A.transparent===!0&&A.side===ta&&A.forceSinglePass===!1?(A.side=qn,A.needsUpdate=!0,Wa(A,W,re),A.side=za,A.needsUpdate=!0,Wa(A,W,re),A.side=ta):Wa(A,W,re)}this.compile=function(A,W,re=null){re===null&&(re=A),U=De.get(re),U.init(W),T.push(U),re.traverseVisible(function(ie){ie.isLight&&ie.layers.test(W.layers)&&(U.pushLight(ie),ie.castShadow&&U.pushShadow(ie))}),A!==re&&A.traverseVisible(function(ie){ie.isLight&&ie.layers.test(W.layers)&&(U.pushLight(ie),ie.castShadow&&U.pushShadow(ie))}),U.setupLights();const ne=new Set;return A.traverse(function(ie){if(!(ie.isMesh||ie.isPoints||ie.isLine||ie.isSprite))return;const Ue=ie.material;if(Ue)if(Array.isArray(Ue))for(let He=0;He<Ue.length;He++){const Le=Ue[He];So(Le,re,ie),ne.add(Le)}else So(Ue,re,ie),ne.add(Ue)}),U=T.pop(),ne},this.compileAsync=function(A,W,re=null){const ne=this.compile(A,W,re);return new Promise(ie=>{function Ue(){if(ne.forEach(function(He){se.get(He).currentProgram.isReady()&&ne.delete(He)}),ne.size===0){ie(A);return}setTimeout(Ue,10)}Lt.get("KHR_parallel_shader_compile")!==null?Ue():setTimeout(Ue,10)})};let or=null;function Wi(A){or&&or(A)}function gn(){Kn.stop()}function On(){Kn.start()}const Kn=new ry;Kn.setAnimationLoop(Wi),typeof self<"u"&&Kn.setContext(self),this.setAnimationLoop=function(A){or=A,Ge.setAnimationLoop(A),A===null?Kn.stop():Kn.start()},Ge.addEventListener("sessionstart",gn),Ge.addEventListener("sessionend",On),this.render=function(A,W){if(W!==void 0&&W.isCamera!==!0){at("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(G===!0)return;Z!==null&&Z.renderStart(A,W);const re=Ge.enabled===!0&&Ge.isPresenting===!0,ne=O!==null&&(Q===null||re)&&O.begin(X,Q);if(A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),Ge.enabled===!0&&Ge.isPresenting===!0&&(O===null||O.isCompositing()===!1)&&(Ge.cameraAutoUpdate===!0&&Ge.updateCamera(W),W=Ge.getCamera()),A.isScene===!0&&A.onBeforeRender(X,A,W,Q),U=De.get(A,T.length),U.init(W),U.state.textureUnits=fe.getTextureUnits(),T.push(U),rn.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),Tt.setFromProjectionMatrix(rn,ia,W.reversedDepth),_t=this.localClippingEnabled,At=Ze.init(this.clippingPlanes,_t),P=Ne.get(A,N.length),P.init(),N.push(P),Ge.enabled===!0&&Ge.isPresenting===!0){const He=X.xr.getDepthSensingMesh();He!==null&&Cs(He,W,-1/0,X.sortObjects)}Cs(A,W,0,X.sortObjects),P.finish(),X.sortObjects===!0&&P.sort(ze,it,W.reversedDepth),Qt=Ge.enabled===!1||Ge.isPresenting===!1||Ge.hasDepthSensing()===!1,Qt&&rt.addToRenderList(P,A),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),At===!0&&Ze.beginShadows();const ie=U.state.shadowsArray;if($e.render(ie,A,W),At===!0&&Ze.endShadows(),(ne&&O.hasRenderPass())===!1){const He=P.opaque,Le=P.transmissive;if(U.setupLights(),W.isArrayCamera){const ke=W.cameras;if(Le.length>0)for(let Ve=0,et=ke.length;Ve<et;Ve++){const ct=ke[Ve];zl(He,Le,A,ct)}Qt&&rt.render(A);for(let Ve=0,et=ke.length;Ve<et;Ve++){const ct=ke[Ve];Fl(P,A,ct,ct.viewport)}}else Le.length>0&&zl(He,Le,A,W),Qt&&rt.render(A),Fl(P,A,W)}Q!==null&&z===0&&(fe.updateMultisampleRenderTarget(Q),fe.updateRenderTargetMipmap(Q)),ne&&O.end(X),A.isScene===!0&&A.onAfterRender(X,A,W),Ie.resetDefaultState(),de=-1,ve=null,T.pop(),T.length>0?(U=T[T.length-1],fe.setTextureUnits(U.state.textureUnits),At===!0&&Ze.setGlobalState(X.clippingPlanes,U.state.camera)):U=null,N.pop(),N.length>0?P=N[N.length-1]:P=null,Z!==null&&Z.renderEnd()};function Cs(A,W,re,ne){if(A.visible===!1)return;if(A.layers.test(W.layers)){if(A.isGroup)re=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(W);else if(A.isLightProbeGrid)U.pushLightProbeGrid(A);else if(A.isLight)U.pushLight(A),A.castShadow&&U.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||Tt.intersectsSprite(A)){ne&&ln.setFromMatrixPosition(A.matrixWorld).applyMatrix4(rn);const He=he.update(A),Le=A.material;Le.visible&&P.push(A,He,Le,re,ln.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(!A.frustumCulled||Tt.intersectsObject(A))){const He=he.update(A),Le=A.material;if(ne&&(A.boundingSphere!==void 0?(A.boundingSphere===null&&A.computeBoundingSphere(),ln.copy(A.boundingSphere.center)):(He.boundingSphere===null&&He.computeBoundingSphere(),ln.copy(He.boundingSphere.center)),ln.applyMatrix4(A.matrixWorld).applyMatrix4(rn)),Array.isArray(Le)){const ke=He.groups;for(let Ve=0,et=ke.length;Ve<et;Ve++){const ct=ke[Ve],Ye=Le[ct.materialIndex];Ye&&Ye.visible&&P.push(A,He,Ye,re,ln.z,ct)}}else Le.visible&&P.push(A,He,Le,re,ln.z,null)}}const Ue=A.children;for(let He=0,Le=Ue.length;He<Le;He++)Cs(Ue[He],W,re,ne)}function Fl(A,W,re,ne){const{opaque:ie,transmissive:Ue,transparent:He}=A;U.setupLightsView(re),At===!0&&Ze.setGlobalState(X.clippingPlanes,re),ne&&b.viewport(D.copy(ne)),ie.length>0&&ws(ie,W,re),Ue.length>0&&ws(Ue,W,re),He.length>0&&ws(He,W,re),b.buffers.depth.setTest(!0),b.buffers.depth.setMask(!0),b.buffers.color.setMask(!0),b.setPolygonOffset(!1)}function zl(A,W,re,ne){if((re.isScene===!0?re.overrideMaterial:null)!==null)return;if(U.state.transmissionRenderTarget[ne.id]===void 0){const Ye=Lt.has("EXT_color_buffer_half_float")||Lt.has("EXT_color_buffer_float");U.state.transmissionRenderTarget[ne.id]=new sa(1,1,{generateMipmaps:!0,type:Ye?Ha:mi,minFilter:Pa,samples:Math.max(4,L.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:St.workingColorSpace})}const Ue=U.state.transmissionRenderTarget[ne.id],He=ne.viewport||D;Ue.setSize(He.z*X.transmissionResolutionScale,He.w*X.transmissionResolutionScale);const Le=X.getRenderTarget(),ke=X.getActiveCubeFace(),Ve=X.getActiveMipmapLevel();X.setRenderTarget(Ue),X.getClearColor(Re),Pe=X.getClearAlpha(),Pe<1&&X.setClearColor(16777215,.5),X.clear(),Qt&&rt.render(re);const et=X.toneMapping;X.toneMapping=aa;const ct=ne.viewport;if(ne.viewport!==void 0&&(ne.viewport=void 0),U.setupLightsView(ne),At===!0&&Ze.setGlobalState(X.clippingPlanes,ne),ws(A,re,ne),fe.updateMultisampleRenderTarget(Ue),fe.updateRenderTargetMipmap(Ue),Lt.has("WEBGL_multisampled_render_to_texture")===!1){let Ye=!1;for(let Ct=0,nn=W.length;Ct<nn;Ct++){const Kt=W[Ct],{object:Pt,geometry:It,material:Fe,group:zn}=Kt;if(Fe.side===ta&&Pt.layers.test(ne.layers)){const vt=Fe.side;Fe.side=qn,Fe.needsUpdate=!0,Xa(Pt,re,ne,It,Fe,zn),Fe.side=vt,Fe.needsUpdate=!0,Ye=!0}}Ye===!0&&(fe.updateMultisampleRenderTarget(Ue),fe.updateRenderTargetMipmap(Ue))}X.setRenderTarget(Le,ke,Ve),X.setClearColor(Re,Pe),ct!==void 0&&(ne.viewport=ct),X.toneMapping=et}function ws(A,W,re){const ne=W.isScene===!0?W.overrideMaterial:null;for(let ie=0,Ue=A.length;ie<Ue;ie++){const He=A[ie],{object:Le,geometry:ke,group:Ve}=He;let et=He.material;et.allowOverride===!0&&ne!==null&&(et=ne),Le.layers.test(re.layers)&&Xa(Le,W,re,ke,et,Ve)}}function Xa(A,W,re,ne,ie,Ue){A.onBeforeRender(X,W,re,ne,ie,Ue),A.modelViewMatrix.multiplyMatrices(re.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),ie.onBeforeRender(X,W,re,ne,A,Ue),ie.transparent===!0&&ie.side===ta&&ie.forceSinglePass===!1?(ie.side=qn,ie.needsUpdate=!0,X.renderBufferDirect(re,W,ne,ie,A,Ue),ie.side=za,ie.needsUpdate=!0,X.renderBufferDirect(re,W,ne,ie,A,Ue),ie.side=ta):X.renderBufferDirect(re,W,ne,ie,A,Ue),A.onAfterRender(X,W,re,ne,ie,Ue)}function Wa(A,W,re){W.isScene!==!0&&(W=hn);const ne=se.get(A),ie=U.state.lights,Ue=U.state.shadowsArray,He=ie.state.version,Le=Ae.getParameters(A,ie.state,Ue,W,re,U.state.lightProbeGridArray),ke=Ae.getProgramCacheKey(Le);let Ve=ne.programs;ne.environment=A.isMeshStandardMaterial||A.isMeshLambertMaterial||A.isMeshPhongMaterial?W.environment:null,ne.fog=W.fog;const et=A.isMeshStandardMaterial||A.isMeshLambertMaterial&&!A.envMap||A.isMeshPhongMaterial&&!A.envMap;ne.envMap=be.get(A.envMap||ne.environment,et),ne.envMapRotation=ne.environment!==null&&A.envMap===null?W.environmentRotation:A.envMapRotation,Ve===void 0&&(A.addEventListener("dispose",ii),Ve=new Map,ne.programs=Ve);let ct=Ve.get(ke);if(ct!==void 0){if(ne.currentProgram===ct&&ne.lightsStateVersion===He)return fa(A,Le),ct}else Le.uniforms=Ae.getUniforms(A),Z!==null&&A.isNodeMaterial&&Z.build(A,re,Le),A.onBeforeCompile(Le,X),ct=Ae.acquireProgram(Le,ke),Ve.set(ke,ct),ne.uniforms=Le.uniforms;const Ye=ne.uniforms;return(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&(Ye.clippingPlanes=Ze.uniform),fa(A,Le),ne.needsLights=Hl(A),ne.lightsStateVersion=He,ne.needsLights&&(Ye.ambientLightColor.value=ie.state.ambient,Ye.lightProbe.value=ie.state.probe,Ye.directionalLights.value=ie.state.directional,Ye.directionalLightShadows.value=ie.state.directionalShadow,Ye.spotLights.value=ie.state.spot,Ye.spotLightShadows.value=ie.state.spotShadow,Ye.rectAreaLights.value=ie.state.rectArea,Ye.ltc_1.value=ie.state.rectAreaLTC1,Ye.ltc_2.value=ie.state.rectAreaLTC2,Ye.pointLights.value=ie.state.point,Ye.pointLightShadows.value=ie.state.pointShadow,Ye.hemisphereLights.value=ie.state.hemi,Ye.directionalShadowMatrix.value=ie.state.directionalShadowMatrix,Ye.spotLightMatrix.value=ie.state.spotLightMatrix,Ye.spotLightMap.value=ie.state.spotLightMap,Ye.pointShadowMatrix.value=ie.state.pointShadowMatrix),ne.lightProbeGrid=U.state.lightProbeGridArray.length>0,ne.currentProgram=ct,ne.uniformsList=null,ct}function ua(A){if(A.uniformsList===null){const W=A.currentProgram.getUniforms();A.uniformsList=Lu.seqWithValue(W.seq,A.uniforms)}return A.uniformsList}function fa(A,W){const re=se.get(A);re.outputColorSpace=W.outputColorSpace,re.batching=W.batching,re.batchingColor=W.batchingColor,re.instancing=W.instancing,re.instancingColor=W.instancingColor,re.instancingMorph=W.instancingMorph,re.skinning=W.skinning,re.morphTargets=W.morphTargets,re.morphNormals=W.morphNormals,re.morphColors=W.morphColors,re.morphTargetsCount=W.morphTargetsCount,re.numClippingPlanes=W.numClippingPlanes,re.numIntersection=W.numClipIntersection,re.vertexAlphas=W.vertexAlphas,re.vertexTangents=W.vertexTangents,re.toneMapping=W.toneMapping}function Ds(A,W){if(A.length===0)return null;if(A.length===1)return A[0].texture!==null?A[0]:null;w.setFromMatrixPosition(W.matrixWorld);for(let re=0,ne=A.length;re<ne;re++){const ie=A[re];if(ie.texture!==null&&ie.boundingBox.containsPoint(w))return ie}return null}function qa(A,W,re,ne,ie){W.isScene!==!0&&(W=hn),fe.resetTextureUnits();const Ue=W.fog,He=ne.isMeshStandardMaterial||ne.isMeshLambertMaterial||ne.isMeshPhongMaterial?W.environment:null,Le=Q===null?X.outputColorSpace:Q.isXRRenderTarget===!0?Q.texture.colorSpace:St.workingColorSpace,ke=ne.isMeshStandardMaterial||ne.isMeshLambertMaterial&&!ne.envMap||ne.isMeshPhongMaterial&&!ne.envMap,Ve=be.get(ne.envMap||He,ke),et=ne.vertexColors===!0&&!!re.attributes.color&&re.attributes.color.itemSize===4,ct=!!re.attributes.tangent&&(!!ne.normalMap||ne.anisotropy>0),Ye=!!re.morphAttributes.position,Ct=!!re.morphAttributes.normal,nn=!!re.morphAttributes.color;let Kt=aa;ne.toneMapped&&(Q===null||Q.isXRRenderTarget===!0)&&(Kt=X.toneMapping);const Pt=re.morphAttributes.position||re.morphAttributes.normal||re.morphAttributes.color,It=Pt!==void 0?Pt.length:0,Fe=se.get(ne),zn=U.state.lights;if(At===!0&&(_t===!0||A!==ve)){const Ut=A===ve&&ne.id===de;Ze.setState(ne,A,Ut)}let vt=!1;ne.version===Fe.__version?(Fe.needsLights&&Fe.lightsStateVersion!==zn.state.version||Fe.outputColorSpace!==Le||ie.isBatchedMesh&&Fe.batching===!1||!ie.isBatchedMesh&&Fe.batching===!0||ie.isBatchedMesh&&Fe.batchingColor===!0&&ie.colorTexture===null||ie.isBatchedMesh&&Fe.batchingColor===!1&&ie.colorTexture!==null||ie.isInstancedMesh&&Fe.instancing===!1||!ie.isInstancedMesh&&Fe.instancing===!0||ie.isSkinnedMesh&&Fe.skinning===!1||!ie.isSkinnedMesh&&Fe.skinning===!0||ie.isInstancedMesh&&Fe.instancingColor===!0&&ie.instanceColor===null||ie.isInstancedMesh&&Fe.instancingColor===!1&&ie.instanceColor!==null||ie.isInstancedMesh&&Fe.instancingMorph===!0&&ie.morphTexture===null||ie.isInstancedMesh&&Fe.instancingMorph===!1&&ie.morphTexture!==null||Fe.envMap!==Ve||ne.fog===!0&&Fe.fog!==Ue||Fe.numClippingPlanes!==void 0&&(Fe.numClippingPlanes!==Ze.numPlanes||Fe.numIntersection!==Ze.numIntersection)||Fe.vertexAlphas!==et||Fe.vertexTangents!==ct||Fe.morphTargets!==Ye||Fe.morphNormals!==Ct||Fe.morphColors!==nn||Fe.toneMapping!==Kt||Fe.morphTargetsCount!==It||!!Fe.lightProbeGrid!=U.state.lightProbeGridArray.length>0)&&(vt=!0):(vt=!0,Fe.__version=ne.version);let bn=Fe.currentProgram;vt===!0&&(bn=Wa(ne,W,ie),Z&&ne.isNodeMaterial&&Z.onUpdateProgram(ne,bn,Fe));let ai=!1,Di=!1,si=!1;const Bt=bn.getUniforms(),an=Fe.uniforms;if(b.useProgram(bn.program)&&(ai=!0,Di=!0,si=!0),ne.id!==de&&(de=ne.id,Di=!0),Fe.needsLights){const Ut=Ds(U.state.lightProbeGridArray,ie);Fe.lightProbeGrid!==Ut&&(Fe.lightProbeGrid=Ut,Di=!0)}if(ai||ve!==A){b.buffers.depth.getReversed()&&A.reversedDepth!==!0&&(A._reversedDepth=!0,A.updateProjectionMatrix()),Bt.setValue(q,"projectionMatrix",A.projectionMatrix),Bt.setValue(q,"viewMatrix",A.matrixWorldInverse);const qi=Bt.map.cameraPosition;qi!==void 0&&qi.setValue(q,on.setFromMatrixPosition(A.matrixWorld)),L.logarithmicDepthBuffer&&Bt.setValue(q,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),(ne.isMeshPhongMaterial||ne.isMeshToonMaterial||ne.isMeshLambertMaterial||ne.isMeshBasicMaterial||ne.isMeshStandardMaterial||ne.isShaderMaterial)&&Bt.setValue(q,"isOrthographic",A.isOrthographicCamera===!0),ve!==A&&(ve=A,Di=!0,si=!0)}if(Fe.needsLights&&(zn.state.directionalShadowMap.length>0&&Bt.setValue(q,"directionalShadowMap",zn.state.directionalShadowMap,fe),zn.state.spotShadowMap.length>0&&Bt.setValue(q,"spotShadowMap",zn.state.spotShadowMap,fe),zn.state.pointShadowMap.length>0&&Bt.setValue(q,"pointShadowMap",zn.state.pointShadowMap,fe)),ie.isSkinnedMesh){Bt.setOptional(q,ie,"bindMatrix"),Bt.setOptional(q,ie,"bindMatrixInverse");const Ut=ie.skeleton;Ut&&(Ut.boneTexture===null&&Ut.computeBoneTexture(),Bt.setValue(q,"boneTexture",Ut.boneTexture,fe))}ie.isBatchedMesh&&(Bt.setOptional(q,ie,"batchingTexture"),Bt.setValue(q,"batchingTexture",ie._matricesTexture,fe),Bt.setOptional(q,ie,"batchingIdTexture"),Bt.setValue(q,"batchingIdTexture",ie._indirectTexture,fe),Bt.setOptional(q,ie,"batchingColorTexture"),ie._colorsTexture!==null&&Bt.setValue(q,"batchingColorTexture",ie._colorsTexture,fe));const Li=re.morphAttributes;if((Li.position!==void 0||Li.normal!==void 0||Li.color!==void 0)&&k.update(ie,re,bn),(Di||Fe.receiveShadow!==ie.receiveShadow)&&(Fe.receiveShadow=ie.receiveShadow,Bt.setValue(q,"receiveShadow",ie.receiveShadow)),(ne.isMeshStandardMaterial||ne.isMeshLambertMaterial||ne.isMeshPhongMaterial)&&ne.envMap===null&&W.environment!==null&&(an.envMapIntensity.value=W.environmentIntensity),an.dfgLUT!==void 0&&(an.dfgLUT.value=WC()),Di){if(Bt.setValue(q,"toneMappingExposure",X.toneMappingExposure),Fe.needsLights&&_n(an,si),Ue&&ne.fog===!0&&Be.refreshFogUniforms(an,Ue),Be.refreshMaterialUniforms(an,ne,Me,ye,U.state.transmissionRenderTarget[A.id]),Fe.needsLights&&Fe.lightProbeGrid){const Ut=Fe.lightProbeGrid;an.probesSH.value=Ut.texture,an.probesMin.value.copy(Ut.boundingBox.min),an.probesMax.value.copy(Ut.boundingBox.max),an.probesResolution.value.copy(Ut.resolution)}Lu.upload(q,ua(Fe),an,fe)}if(ne.isShaderMaterial&&ne.uniformsNeedUpdate===!0&&(Lu.upload(q,ua(Fe),an,fe),ne.uniformsNeedUpdate=!1),ne.isSpriteMaterial&&Bt.setValue(q,"center",ie.center),Bt.setValue(q,"modelViewMatrix",ie.modelViewMatrix),Bt.setValue(q,"normalMatrix",ie.normalMatrix),Bt.setValue(q,"modelMatrix",ie.matrixWorld),ne.uniformsGroups!==void 0){const Ut=ne.uniformsGroups;for(let qi=0,Ya=Ut.length;qi<Ya;qi++){const Ls=Ut[qi];Se.update(Ls,bn),Se.bind(Ls,bn)}}return bn}function _n(A,W){A.ambientLightColor.needsUpdate=W,A.lightProbe.needsUpdate=W,A.directionalLights.needsUpdate=W,A.directionalLightShadows.needsUpdate=W,A.pointLights.needsUpdate=W,A.pointLightShadows.needsUpdate=W,A.spotLights.needsUpdate=W,A.spotLightShadows.needsUpdate=W,A.rectAreaLights.needsUpdate=W,A.hemisphereLights.needsUpdate=W}function Hl(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return I},this.getActiveMipmapLevel=function(){return z},this.getRenderTarget=function(){return Q},this.setRenderTargetTextures=function(A,W,re){const ne=se.get(A);ne.__autoAllocateDepthBuffer=A.resolveDepthBuffer===!1,ne.__autoAllocateDepthBuffer===!1&&(ne.__useRenderToTexture=!1),se.get(A.texture).__webglTexture=W,se.get(A.depthTexture).__webglTexture=ne.__autoAllocateDepthBuffer?void 0:re,ne.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(A,W){const re=se.get(A);re.__webglFramebuffer=W,re.__useDefaultFramebuffer=W===void 0},this.setRenderTarget=function(A,W=0,re=0){Q=A,I=W,z=re;let ne=null,ie=!1,Ue=!1;if(A){const Le=se.get(A);if(Le.__useDefaultFramebuffer!==void 0){b.bindFramebuffer(q.FRAMEBUFFER,Le.__webglFramebuffer),D.copy(A.viewport),Y.copy(A.scissor),Ee=A.scissorTest,b.viewport(D),b.scissor(Y),b.setScissorTest(Ee),de=-1;return}else if(Le.__webglFramebuffer===void 0)fe.setupRenderTarget(A);else if(Le.__hasExternalTextures)fe.rebindTextures(A,se.get(A.texture).__webglTexture,se.get(A.depthTexture).__webglTexture);else if(A.depthBuffer){const et=A.depthTexture;if(Le.__boundDepthTexture!==et){if(et!==null&&se.has(et)&&(A.width!==et.image.width||A.height!==et.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");fe.setupDepthRenderbuffer(A)}}const ke=A.texture;(ke.isData3DTexture||ke.isDataArrayTexture||ke.isCompressedArrayTexture)&&(Ue=!0);const Ve=se.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(Array.isArray(Ve[W])?ne=Ve[W][re]:ne=Ve[W],ie=!0):A.samples>0&&fe.useMultisampledRTT(A)===!1?ne=se.get(A).__webglMultisampledFramebuffer:Array.isArray(Ve)?ne=Ve[re]:ne=Ve,D.copy(A.viewport),Y.copy(A.scissor),Ee=A.scissorTest}else D.copy(je).multiplyScalar(Me).floor(),Y.copy(Jt).multiplyScalar(Me).floor(),Ee=pt;if(re!==0&&(ne=ce),b.bindFramebuffer(q.FRAMEBUFFER,ne)&&b.drawBuffers(A,ne),b.viewport(D),b.scissor(Y),b.setScissorTest(Ee),ie){const Le=se.get(A.texture);q.framebufferTexture2D(q.FRAMEBUFFER,q.COLOR_ATTACHMENT0,q.TEXTURE_CUBE_MAP_POSITIVE_X+W,Le.__webglTexture,re)}else if(Ue){const Le=W;for(let ke=0;ke<A.textures.length;ke++){const Ve=se.get(A.textures[ke]);q.framebufferTextureLayer(q.FRAMEBUFFER,q.COLOR_ATTACHMENT0+ke,Ve.__webglTexture,re,Le)}}else if(A!==null&&re!==0){const Le=se.get(A.texture);q.framebufferTexture2D(q.FRAMEBUFFER,q.COLOR_ATTACHMENT0,q.TEXTURE_2D,Le.__webglTexture,re)}de=-1},this.readRenderTargetPixels=function(A,W,re,ne,ie,Ue,He,Le=0){if(!(A&&A.isWebGLRenderTarget)){at("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ke=se.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&He!==void 0&&(ke=ke[He]),ke){b.bindFramebuffer(q.FRAMEBUFFER,ke);try{const Ve=A.textures[Le],et=Ve.format,ct=Ve.type;if(A.textures.length>1&&q.readBuffer(q.COLOR_ATTACHMENT0+Le),!L.textureFormatReadable(et)){at("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!L.textureTypeReadable(ct)){at("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=A.width-ne&&re>=0&&re<=A.height-ie&&q.readPixels(W,re,ne,ie,Ce.convert(et),Ce.convert(ct),Ue)}finally{const Ve=Q!==null?se.get(Q).__webglFramebuffer:null;b.bindFramebuffer(q.FRAMEBUFFER,Ve)}}},this.readRenderTargetPixelsAsync=async function(A,W,re,ne,ie,Ue,He,Le=0){if(!(A&&A.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let ke=se.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&He!==void 0&&(ke=ke[He]),ke)if(W>=0&&W<=A.width-ne&&re>=0&&re<=A.height-ie){b.bindFramebuffer(q.FRAMEBUFFER,ke);const Ve=A.textures[Le],et=Ve.format,ct=Ve.type;if(A.textures.length>1&&q.readBuffer(q.COLOR_ATTACHMENT0+Le),!L.textureFormatReadable(et))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!L.textureTypeReadable(ct))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Ye=q.createBuffer();q.bindBuffer(q.PIXEL_PACK_BUFFER,Ye),q.bufferData(q.PIXEL_PACK_BUFFER,Ue.byteLength,q.STREAM_READ),q.readPixels(W,re,ne,ie,Ce.convert(et),Ce.convert(ct),0);const Ct=Q!==null?se.get(Q).__webglFramebuffer:null;b.bindFramebuffer(q.FRAMEBUFFER,Ct);const nn=q.fenceSync(q.SYNC_GPU_COMMANDS_COMPLETE,0);return q.flush(),await gE(q,nn,4),q.bindBuffer(q.PIXEL_PACK_BUFFER,Ye),q.getBufferSubData(q.PIXEL_PACK_BUFFER,0,Ue),q.deleteBuffer(Ye),q.deleteSync(nn),Ue}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(A,W=null,re=0){const ne=Math.pow(2,-re),ie=Math.floor(A.image.width*ne),Ue=Math.floor(A.image.height*ne),He=W!==null?W.x:0,Le=W!==null?W.y:0;fe.setTexture2D(A,0),q.copyTexSubImage2D(q.TEXTURE_2D,re,0,0,He,Le,ie,Ue),b.unbindTexture()},this.copyTextureToTexture=function(A,W,re=null,ne=null,ie=0,Ue=0){let He,Le,ke,Ve,et,ct,Ye,Ct,nn;const Kt=A.isCompressedTexture?A.mipmaps[Ue]:A.image;if(re!==null)He=re.max.x-re.min.x,Le=re.max.y-re.min.y,ke=re.isBox3?re.max.z-re.min.z:1,Ve=re.min.x,et=re.min.y,ct=re.isBox3?re.min.z:0;else{const an=Math.pow(2,-ie);He=Math.floor(Kt.width*an),Le=Math.floor(Kt.height*an),A.isDataArrayTexture?ke=Kt.depth:A.isData3DTexture?ke=Math.floor(Kt.depth*an):ke=1,Ve=0,et=0,ct=0}ne!==null?(Ye=ne.x,Ct=ne.y,nn=ne.z):(Ye=0,Ct=0,nn=0);const Pt=Ce.convert(W.format),It=Ce.convert(W.type);let Fe;W.isData3DTexture?(fe.setTexture3D(W,0),Fe=q.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(fe.setTexture2DArray(W,0),Fe=q.TEXTURE_2D_ARRAY):(fe.setTexture2D(W,0),Fe=q.TEXTURE_2D),b.activeTexture(q.TEXTURE0),b.pixelStorei(q.UNPACK_FLIP_Y_WEBGL,W.flipY),b.pixelStorei(q.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),b.pixelStorei(q.UNPACK_ALIGNMENT,W.unpackAlignment);const zn=b.getParameter(q.UNPACK_ROW_LENGTH),vt=b.getParameter(q.UNPACK_IMAGE_HEIGHT),bn=b.getParameter(q.UNPACK_SKIP_PIXELS),ai=b.getParameter(q.UNPACK_SKIP_ROWS),Di=b.getParameter(q.UNPACK_SKIP_IMAGES);b.pixelStorei(q.UNPACK_ROW_LENGTH,Kt.width),b.pixelStorei(q.UNPACK_IMAGE_HEIGHT,Kt.height),b.pixelStorei(q.UNPACK_SKIP_PIXELS,Ve),b.pixelStorei(q.UNPACK_SKIP_ROWS,et),b.pixelStorei(q.UNPACK_SKIP_IMAGES,ct);const si=A.isDataArrayTexture||A.isData3DTexture,Bt=W.isDataArrayTexture||W.isData3DTexture;if(A.isDepthTexture){const an=se.get(A),Li=se.get(W),Ut=se.get(an.__renderTarget),qi=se.get(Li.__renderTarget);b.bindFramebuffer(q.READ_FRAMEBUFFER,Ut.__webglFramebuffer),b.bindFramebuffer(q.DRAW_FRAMEBUFFER,qi.__webglFramebuffer);for(let Ya=0;Ya<ke;Ya++)si&&(q.framebufferTextureLayer(q.READ_FRAMEBUFFER,q.COLOR_ATTACHMENT0,se.get(A).__webglTexture,ie,ct+Ya),q.framebufferTextureLayer(q.DRAW_FRAMEBUFFER,q.COLOR_ATTACHMENT0,se.get(W).__webglTexture,Ue,nn+Ya)),q.blitFramebuffer(Ve,et,He,Le,Ye,Ct,He,Le,q.DEPTH_BUFFER_BIT,q.NEAREST);b.bindFramebuffer(q.READ_FRAMEBUFFER,null),b.bindFramebuffer(q.DRAW_FRAMEBUFFER,null)}else if(ie!==0||A.isRenderTargetTexture||se.has(A)){const an=se.get(A),Li=se.get(W);b.bindFramebuffer(q.READ_FRAMEBUFFER,ge),b.bindFramebuffer(q.DRAW_FRAMEBUFFER,j);for(let Ut=0;Ut<ke;Ut++)si?q.framebufferTextureLayer(q.READ_FRAMEBUFFER,q.COLOR_ATTACHMENT0,an.__webglTexture,ie,ct+Ut):q.framebufferTexture2D(q.READ_FRAMEBUFFER,q.COLOR_ATTACHMENT0,q.TEXTURE_2D,an.__webglTexture,ie),Bt?q.framebufferTextureLayer(q.DRAW_FRAMEBUFFER,q.COLOR_ATTACHMENT0,Li.__webglTexture,Ue,nn+Ut):q.framebufferTexture2D(q.DRAW_FRAMEBUFFER,q.COLOR_ATTACHMENT0,q.TEXTURE_2D,Li.__webglTexture,Ue),ie!==0?q.blitFramebuffer(Ve,et,He,Le,Ye,Ct,He,Le,q.COLOR_BUFFER_BIT,q.NEAREST):Bt?q.copyTexSubImage3D(Fe,Ue,Ye,Ct,nn+Ut,Ve,et,He,Le):q.copyTexSubImage2D(Fe,Ue,Ye,Ct,Ve,et,He,Le);b.bindFramebuffer(q.READ_FRAMEBUFFER,null),b.bindFramebuffer(q.DRAW_FRAMEBUFFER,null)}else Bt?A.isDataTexture||A.isData3DTexture?q.texSubImage3D(Fe,Ue,Ye,Ct,nn,He,Le,ke,Pt,It,Kt.data):W.isCompressedArrayTexture?q.compressedTexSubImage3D(Fe,Ue,Ye,Ct,nn,He,Le,ke,Pt,Kt.data):q.texSubImage3D(Fe,Ue,Ye,Ct,nn,He,Le,ke,Pt,It,Kt):A.isDataTexture?q.texSubImage2D(q.TEXTURE_2D,Ue,Ye,Ct,He,Le,Pt,It,Kt.data):A.isCompressedTexture?q.compressedTexSubImage2D(q.TEXTURE_2D,Ue,Ye,Ct,Kt.width,Kt.height,Pt,Kt.data):q.texSubImage2D(q.TEXTURE_2D,Ue,Ye,Ct,He,Le,Pt,It,Kt);b.pixelStorei(q.UNPACK_ROW_LENGTH,zn),b.pixelStorei(q.UNPACK_IMAGE_HEIGHT,vt),b.pixelStorei(q.UNPACK_SKIP_PIXELS,bn),b.pixelStorei(q.UNPACK_SKIP_ROWS,ai),b.pixelStorei(q.UNPACK_SKIP_IMAGES,Di),Ue===0&&W.generateMipmaps&&q.generateMipmap(Fe),b.unbindTexture()},this.initRenderTarget=function(A){se.get(A).__webglFramebuffer===void 0&&fe.setupRenderTarget(A)},this.initTexture=function(A){A.isCubeTexture?fe.setTextureCube(A,0):A.isData3DTexture?fe.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?fe.setTexture2DArray(A,0):fe.setTexture2D(A,0),b.unbindTexture()},this.resetState=function(){I=0,z=0,Q=null,b.reset(),Ie.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return ia}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const n=this.getContext();n.drawingBufferColorSpace=St._getDrawingBufferColorSpace(e),n.unpackColorSpace=St._getUnpackColorSpace()}}function _x(r,e){if(e===aE)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),r;if(e===Cp||e===Gx){let n=r.getIndex();if(n===null){const u=[],h=r.getAttribute("position");if(h!==void 0){for(let p=0;p<h.count;p++)u.push(p);r.setIndex(u),n=r.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),r}const a=n.count-2,o=[];if(e===Cp)for(let u=1;u<=a;u++)o.push(n.getX(0)),o.push(n.getX(u)),o.push(n.getX(u+1));else for(let u=0;u<a;u++)u%2===0?(o.push(n.getX(u)),o.push(n.getX(u+1)),o.push(n.getX(u+2))):(o.push(n.getX(u+2)),o.push(n.getX(u+1)),o.push(n.getX(u)));o.length/3!==a&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const c=r.clone();return c.setIndex(o),c.clearGroups(),c}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),r}function YC(r){const e=new Map,n=new Map,a=r.clone();return py(r,a,function(o,c){e.set(c,o),n.set(o,c)}),a.traverse(function(o){if(!o.isSkinnedMesh)return;const c=o,u=e.get(o),h=u.skeleton.bones;c.skeleton=u.skeleton.clone(),c.bindMatrix.copy(u.bindMatrix),c.skeleton.bones=h.map(function(p){return n.get(p)}),c.bind(c.skeleton,c.bindMatrix)}),a}function py(r,e,n){n(r,e);for(let a=0;a<r.children.length;a++)py(r.children[a],e.children[a],n)}class KC extends _o{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(n){return new $C(n)}),this.register(function(n){return new ew(n)}),this.register(function(n){return new cw(n)}),this.register(function(n){return new uw(n)}),this.register(function(n){return new fw(n)}),this.register(function(n){return new nw(n)}),this.register(function(n){return new iw(n)}),this.register(function(n){return new aw(n)}),this.register(function(n){return new sw(n)}),this.register(function(n){return new jC(n)}),this.register(function(n){return new rw(n)}),this.register(function(n){return new tw(n)}),this.register(function(n){return new lw(n)}),this.register(function(n){return new ow(n)}),this.register(function(n){return new QC(n)}),this.register(function(n){return new vx(n,mt.EXT_MESHOPT_COMPRESSION)}),this.register(function(n){return new vx(n,mt.KHR_MESHOPT_COMPRESSION)}),this.register(function(n){return new hw(n)})}load(e,n,a,o){const c=this;let u;if(this.resourcePath!=="")u=this.resourcePath;else if(this.path!==""){const d=Rl.extractUrlBase(e);u=Rl.resolveURL(d,this.path)}else u=Rl.extractUrlBase(e);this.manager.itemStart(e);const h=function(d){o?o(d):console.error(d),c.manager.itemError(e),c.manager.itemEnd(e)},p=new iy(this.manager);p.setPath(this.path),p.setResponseType("arraybuffer"),p.setRequestHeader(this.requestHeader),p.setWithCredentials(this.withCredentials),p.load(e,function(d){try{c.parse(d,u,function(g){n(g),c.manager.itemEnd(e)},h)}catch(g){h(g)}},a,h)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,n,a,o){let c;const u={},h={},p=new TextDecoder;if(typeof e=="string")c=JSON.parse(e);else if(e instanceof ArrayBuffer)if(p.decode(new Uint8Array(e,0,4))===my){try{u[mt.KHR_BINARY_GLTF]=new dw(e)}catch(_){o&&o(_);return}c=JSON.parse(u[mt.KHR_BINARY_GLTF].content)}else c=JSON.parse(p.decode(e));else c=e;if(c.asset===void 0||c.asset.version[0]<2){o&&o(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const d=new Aw(c,{path:n||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});d.fileLoader.setRequestHeader(this.requestHeader);for(let g=0;g<this.pluginCallbacks.length;g++){const _=this.pluginCallbacks[g](d);_.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),h[_.name]=_,u[_.name]=!0}if(c.extensionsUsed)for(let g=0;g<c.extensionsUsed.length;++g){const _=c.extensionsUsed[g],v=c.extensionsRequired||[];switch(_){case mt.KHR_MATERIALS_UNLIT:u[_]=new JC;break;case mt.KHR_DRACO_MESH_COMPRESSION:u[_]=new pw(c,this.dracoLoader);break;case mt.KHR_TEXTURE_TRANSFORM:u[_]=new mw;break;case mt.KHR_MESH_QUANTIZATION:u[_]=new gw;break;default:v.indexOf(_)>=0&&h[_]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+_+'".')}}d.setExtensions(u),d.setPlugins(h),d.parse(a,o)}parseAsync(e,n){const a=this;return new Promise(function(o,c){a.parse(e,n,o,c)})}}function ZC(){let r={};return{get:function(e){return r[e]},add:function(e,n){r[e]=n},remove:function(e){delete r[e]},removeAll:function(){r={}}}}function mn(r,e,n){const a=r.json.materials[e];return a.extensions&&a.extensions[n]?a.extensions[n]:null}const mt={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",KHR_MESHOPT_COMPRESSION:"KHR_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class QC{constructor(e){this.parser=e,this.name=mt.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const e=this.parser,n=this.parser.json.nodes||[];for(let a=0,o=n.length;a<o;a++){const c=n[a];c.extensions&&c.extensions[this.name]&&c.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,c.extensions[this.name].light)}}_loadLight(e){const n=this.parser,a="light:"+e;let o=n.cache.get(a);if(o)return o;const c=n.json,p=((c.extensions&&c.extensions[this.name]||{}).lights||[])[e];let d;const g=new st(16777215);p.color!==void 0&&g.setRGB(p.color[0],p.color[1],p.color[2],gi);const _=p.range!==void 0?p.range:0;switch(p.type){case"directional":d=new Du(g),d.target.position.set(0,0,-1),d.add(d.target);break;case"point":d=new sy(g),d.distance=_;break;case"spot":d=new Ib(g),d.distance=_,p.spot=p.spot||{},p.spot.innerConeAngle=p.spot.innerConeAngle!==void 0?p.spot.innerConeAngle:0,p.spot.outerConeAngle=p.spot.outerConeAngle!==void 0?p.spot.outerConeAngle:Math.PI/4,d.angle=p.spot.outerConeAngle,d.penumbra=1-p.spot.innerConeAngle/p.spot.outerConeAngle,d.target.position.set(0,0,-1),d.add(d.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+p.type)}return d.position.set(0,0,0),$i(d,p),p.intensity!==void 0&&(d.intensity=p.intensity),d.name=n.createUniqueName(p.name||"light_"+e),o=Promise.resolve(d),n.cache.add(a,o),o}getDependency(e,n){if(e==="light")return this._loadLight(n)}createNodeAttachment(e){const n=this,a=this.parser,c=a.json.nodes[e],h=(c.extensions&&c.extensions[this.name]||{}).light;return h===void 0?null:this._loadLight(h).then(function(p){return a._getNodeRef(n.cache,h,p)})}}class JC{constructor(){this.name=mt.KHR_MATERIALS_UNLIT}getMaterialType(){return ir}extendParams(e,n,a){const o=[];e.color=new st(1,1,1),e.opacity=1;const c=n.pbrMetallicRoughness;if(c){if(Array.isArray(c.baseColorFactor)){const u=c.baseColorFactor;e.color.setRGB(u[0],u[1],u[2],gi),e.opacity=u[3]}c.baseColorTexture!==void 0&&o.push(a.assignTexture(e,"map",c.baseColorTexture,Nn))}return Promise.all(o)}}class jC{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);return a===null||a.emissiveStrength!==void 0&&(n.emissiveIntensity=a.emissiveStrength),Promise.resolve()}}class $C{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];if(a.clearcoatFactor!==void 0&&(n.clearcoat=a.clearcoatFactor),a.clearcoatTexture!==void 0&&o.push(this.parser.assignTexture(n,"clearcoatMap",a.clearcoatTexture)),a.clearcoatRoughnessFactor!==void 0&&(n.clearcoatRoughness=a.clearcoatRoughnessFactor),a.clearcoatRoughnessTexture!==void 0&&o.push(this.parser.assignTexture(n,"clearcoatRoughnessMap",a.clearcoatRoughnessTexture)),a.clearcoatNormalTexture!==void 0&&(o.push(this.parser.assignTexture(n,"clearcoatNormalMap",a.clearcoatNormalTexture)),a.clearcoatNormalTexture.scale!==void 0)){const c=a.clearcoatNormalTexture.scale;n.clearcoatNormalScale=new gt(c,c)}return Promise.all(o)}}class ew{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_DISPERSION}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);return a===null||(n.dispersion=a.dispersion!==void 0?a.dispersion:0),Promise.resolve()}}class tw{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];return a.iridescenceFactor!==void 0&&(n.iridescence=a.iridescenceFactor),a.iridescenceTexture!==void 0&&o.push(this.parser.assignTexture(n,"iridescenceMap",a.iridescenceTexture)),a.iridescenceIor!==void 0&&(n.iridescenceIOR=a.iridescenceIor),n.iridescenceThicknessRange===void 0&&(n.iridescenceThicknessRange=[100,400]),a.iridescenceThicknessMinimum!==void 0&&(n.iridescenceThicknessRange[0]=a.iridescenceThicknessMinimum),a.iridescenceThicknessMaximum!==void 0&&(n.iridescenceThicknessRange[1]=a.iridescenceThicknessMaximum),a.iridescenceThicknessTexture!==void 0&&o.push(this.parser.assignTexture(n,"iridescenceThicknessMap",a.iridescenceThicknessTexture)),Promise.all(o)}}class nw{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_SHEEN}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];if(n.sheenColor=new st(0,0,0),n.sheenRoughness=0,n.sheen=1,a.sheenColorFactor!==void 0){const c=a.sheenColorFactor;n.sheenColor.setRGB(c[0],c[1],c[2],gi)}return a.sheenRoughnessFactor!==void 0&&(n.sheenRoughness=a.sheenRoughnessFactor),a.sheenColorTexture!==void 0&&o.push(this.parser.assignTexture(n,"sheenColorMap",a.sheenColorTexture,Nn)),a.sheenRoughnessTexture!==void 0&&o.push(this.parser.assignTexture(n,"sheenRoughnessMap",a.sheenRoughnessTexture)),Promise.all(o)}}class iw{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];return a.transmissionFactor!==void 0&&(n.transmission=a.transmissionFactor),a.transmissionTexture!==void 0&&o.push(this.parser.assignTexture(n,"transmissionMap",a.transmissionTexture)),Promise.all(o)}}class aw{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_VOLUME}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];n.thickness=a.thicknessFactor!==void 0?a.thicknessFactor:0,a.thicknessTexture!==void 0&&o.push(this.parser.assignTexture(n,"thicknessMap",a.thicknessTexture)),n.attenuationDistance=a.attenuationDistance||1/0;const c=a.attenuationColor||[1,1,1];return n.attenuationColor=new st().setRGB(c[0],c[1],c[2],gi),Promise.all(o)}}class sw{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_IOR}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);return a===null||(n.ior=a.ior!==void 0?a.ior:1.5,n.ior===0&&(n.ior=1e3)),Promise.resolve()}}class rw{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_SPECULAR}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];n.specularIntensity=a.specularFactor!==void 0?a.specularFactor:1,a.specularTexture!==void 0&&o.push(this.parser.assignTexture(n,"specularIntensityMap",a.specularTexture));const c=a.specularColorFactor||[1,1,1];return n.specularColor=new st().setRGB(c[0],c[1],c[2],gi),a.specularColorTexture!==void 0&&o.push(this.parser.assignTexture(n,"specularColorMap",a.specularColorTexture,Nn)),Promise.all(o)}}class ow{constructor(e){this.parser=e,this.name=mt.EXT_MATERIALS_BUMP}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];return n.bumpScale=a.bumpFactor!==void 0?a.bumpFactor:1,a.bumpTexture!==void 0&&o.push(this.parser.assignTexture(n,"bumpMap",a.bumpTexture)),Promise.all(o)}}class lw{constructor(e){this.parser=e,this.name=mt.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){return mn(this.parser,e,this.name)!==null?ca:null}extendMaterialParams(e,n){const a=mn(this.parser,e,this.name);if(a===null)return Promise.resolve();const o=[];return a.anisotropyStrength!==void 0&&(n.anisotropy=a.anisotropyStrength),a.anisotropyRotation!==void 0&&(n.anisotropyRotation=a.anisotropyRotation),a.anisotropyTexture!==void 0&&o.push(this.parser.assignTexture(n,"anisotropyMap",a.anisotropyTexture)),Promise.all(o)}}class cw{constructor(e){this.parser=e,this.name=mt.KHR_TEXTURE_BASISU}loadTexture(e){const n=this.parser,a=n.json,o=a.textures[e];if(!o.extensions||!o.extensions[this.name])return null;const c=o.extensions[this.name],u=n.options.ktx2Loader;if(!u){if(a.extensionsRequired&&a.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return n.loadTextureImage(e,c.source,u)}}class uw{constructor(e){this.parser=e,this.name=mt.EXT_TEXTURE_WEBP}loadTexture(e){const n=this.name,a=this.parser,o=a.json,c=o.textures[e];if(!c.extensions||!c.extensions[n])return null;const u=c.extensions[n],h=o.images[u.source];let p=a.textureLoader;if(h.uri){const d=a.options.manager.getHandler(h.uri);d!==null&&(p=d)}return a.loadTextureImage(e,u.source,p)}}class fw{constructor(e){this.parser=e,this.name=mt.EXT_TEXTURE_AVIF}loadTexture(e){const n=this.name,a=this.parser,o=a.json,c=o.textures[e];if(!c.extensions||!c.extensions[n])return null;const u=c.extensions[n],h=o.images[u.source];let p=a.textureLoader;if(h.uri){const d=a.options.manager.getHandler(h.uri);d!==null&&(p=d)}return a.loadTextureImage(e,u.source,p)}}class vx{constructor(e,n){this.name=n,this.parser=e}loadBufferView(e){const n=this.parser.json,a=n.bufferViews[e];if(a.extensions&&a.extensions[this.name]){const o=a.extensions[this.name],c=this.parser.getDependency("buffer",o.buffer),u=this.parser.options.meshoptDecoder;if(!u||!u.supported){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return c.then(function(h){const p=o.byteOffset||0,d=o.byteLength||0,g=o.count,_=o.byteStride,v=new Uint8Array(h,p,d);return u.decodeGltfBufferAsync?u.decodeGltfBufferAsync(g,_,v,o.mode,o.filter).then(function(x){return x.buffer}):u.ready.then(function(){const x=new ArrayBuffer(g*_);return u.decodeGltfBuffer(new Uint8Array(x),g,_,v,o.mode,o.filter),x})})}else return null}}class hw{constructor(e){this.name=mt.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){const n=this.parser.json,a=n.nodes[e];if(!a.extensions||!a.extensions[this.name]||a.mesh===void 0)return null;const o=n.meshes[a.mesh];for(const d of o.primitives)if(d.mode!==Ai.TRIANGLES&&d.mode!==Ai.TRIANGLE_STRIP&&d.mode!==Ai.TRIANGLE_FAN&&d.mode!==void 0)return null;const u=a.extensions[this.name].attributes,h=[],p={};for(const d in u)h.push(this.parser.getDependency("accessor",u[d]).then(g=>(p[d]=g,p[d])));return h.length<1?null:(h.push(this.parser.createNodeMesh(e)),Promise.all(h).then(d=>{const g=d.pop(),_=g.isGroup?g.children:[g],v=d[0].count,x=[];for(const E of _){const C=new dt,M=new $,S=new ka,B=new $(1,1,1),F=new Qx(E.geometry,E.material,v);for(let w=0;w<v;w++)p.TRANSLATION&&M.fromBufferAttribute(p.TRANSLATION,w),p.ROTATION&&S.fromBufferAttribute(p.ROTATION,w),p.SCALE&&B.fromBufferAttribute(p.SCALE,w),F.setMatrixAt(w,C.compose(M,S,B));for(const w in p)if(w==="_COLOR_0"){const P=p[w];F.instanceColor=new Dp(P.array,P.itemSize,P.normalized)}else w!=="TRANSLATION"&&w!=="ROTATION"&&w!=="SCALE"&&E.geometry.setAttribute(w,p[w]);en.prototype.copy.call(F,E),this.parser.assignFinalMaterial(F),x.push(F)}return g.isGroup?(g.clear(),g.add(...x),g):x[0]}))}}const my="glTF",Sl=12,xx={JSON:1313821514,BIN:5130562};class dw{constructor(e){this.name=mt.KHR_BINARY_GLTF,this.content=null,this.body=null;const n=new DataView(e,0,Sl),a=new TextDecoder;if(this.header={magic:a.decode(new Uint8Array(e.slice(0,4))),version:n.getUint32(4,!0),length:n.getUint32(8,!0)},this.header.magic!==my)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const o=this.header.length-Sl,c=new DataView(e,Sl);let u=0;for(;u<o;){const h=c.getUint32(u,!0);u+=4;const p=c.getUint32(u,!0);if(u+=4,p===xx.JSON){const d=new Uint8Array(e,Sl+u,h);this.content=a.decode(d)}else if(p===xx.BIN){const d=Sl+u;this.body=e.slice(d,d+h)}u+=h}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class pw{constructor(e,n){if(!n)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=mt.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=n,this.dracoLoader.preload()}decodePrimitive(e,n){const a=this.json,o=this.dracoLoader,c=e.extensions[this.name].bufferView,u=e.extensions[this.name].attributes,h={},p={},d={};for(const g in u){const _=Pp[g]||g.toLowerCase();h[_]=u[g]}for(const g in e.attributes){const _=Pp[g]||g.toLowerCase();if(u[g]!==void 0){const v=a.accessors[e.attributes[g]],x=so[v.componentType];d[_]=x.name,p[_]=v.normalized===!0}}return n.getDependency("bufferView",c).then(function(g){return new Promise(function(_,v){o.decodeDracoFile(g,function(x){for(const E in x.attributes){const C=x.attributes[E],M=p[E];M!==void 0&&(C.normalized=M)}_(x)},h,d,gi,v)})})}}class mw{constructor(){this.name=mt.KHR_TEXTURE_TRANSFORM}extendTexture(e,n){return(n.texCoord===void 0||n.texCoord===e.channel)&&n.offset===void 0&&n.rotation===void 0&&n.scale===void 0||(e=e.clone(),n.texCoord!==void 0&&(e.channel=n.texCoord),n.offset!==void 0&&e.offset.fromArray(n.offset),n.rotation!==void 0&&(e.rotation=n.rotation),n.scale!==void 0&&e.repeat.fromArray(n.scale),e.needsUpdate=!0),e}}class gw{constructor(){this.name=mt.KHR_MESH_QUANTIZATION}}class gy extends po{constructor(e,n,a,o){super(e,n,a,o)}copySampleValue_(e){const n=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o*3+o;for(let u=0;u!==o;u++)n[u]=a[c+u];return n}interpolate_(e,n,a,o){const c=this.resultBuffer,u=this.sampleValues,h=this.valueSize,p=h*2,d=h*3,g=o-n,_=(a-n)/g,v=_*_,x=v*_,E=e*d,C=E-d,M=-2*x+3*v,S=x-v,B=1-M,F=S-v+_;for(let w=0;w!==h;w++){const P=u[C+w+h],U=u[C+w+p]*g,N=u[E+w+h],T=u[E+w]*g;c[w]=B*P+F*U+M*N+S*T}return c}}const _w=new ka;class vw extends gy{interpolate_(e,n,a,o){const c=super.interpolate_(e,n,a,o);return _w.fromArray(c).normalize().toArray(c),c}}const Ai={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},so={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},yx={9728:An,9729:Rn,9984:Ox,9985:Tu,9986:El,9987:Pa},Sx={33071:na,33648:Nu,10497:lo},Hd={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},Pp={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},Es={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},xw={CUBICSPLINE:void 0,LINEAR:Ll,STEP:Dl},Gd={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function yw(r){return r.DefaultMaterial===void 0&&(r.DefaultMaterial=new Ol({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:za})),r.DefaultMaterial}function js(r,e,n){for(const a in n.extensions)r[a]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[a]=n.extensions[a])}function $i(r,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(r.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function Sw(r,e,n){let a=!1,o=!1,c=!1;for(let d=0,g=e.length;d<g;d++){const _=e[d];if(_.POSITION!==void 0&&(a=!0),_.NORMAL!==void 0&&(o=!0),_.COLOR_0!==void 0&&(c=!0),a&&o&&c)break}if(!a&&!o&&!c)return Promise.resolve(r);const u=[],h=[],p=[];for(let d=0,g=e.length;d<g;d++){const _=e[d];if(a){const v=_.POSITION!==void 0?n.getDependency("accessor",_.POSITION):r.attributes.position;u.push(v)}if(o){const v=_.NORMAL!==void 0?n.getDependency("accessor",_.NORMAL):r.attributes.normal;h.push(v)}if(c){const v=_.COLOR_0!==void 0?n.getDependency("accessor",_.COLOR_0):r.attributes.color;p.push(v)}}return Promise.all([Promise.all(u),Promise.all(h),Promise.all(p)]).then(function(d){const g=d[0],_=d[1],v=d[2];return a&&(r.morphAttributes.position=g),o&&(r.morphAttributes.normal=_),c&&(r.morphAttributes.color=v),r.morphTargetsRelative=!0,r})}function Mw(r,e){if(r.updateMorphTargets(),e.weights!==void 0)for(let n=0,a=e.weights.length;n<a;n++)r.morphTargetInfluences[n]=e.weights[n];if(e.extras&&Array.isArray(e.extras.targetNames)){const n=e.extras.targetNames;if(r.morphTargetInfluences.length===n.length){r.morphTargetDictionary={};for(let a=0,o=n.length;a<o;a++)r.morphTargetDictionary[n[a]]=a}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function Ew(r){let e;const n=r.extensions&&r.extensions[mt.KHR_DRACO_MESH_COMPRESSION];if(n?e="draco:"+n.bufferView+":"+n.indices+":"+Vd(n.attributes):e=r.indices+":"+Vd(r.attributes)+":"+r.mode,r.targets!==void 0)for(let a=0,o=r.targets.length;a<o;a++)e+=":"+Vd(r.targets[a]);return e}function Vd(r){let e="";const n=Object.keys(r).sort();for(let a=0,o=n.length;a<o;a++)e+=n[a]+":"+r[n[a]]+";";return e}function Ip(r){switch(r){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function bw(r){return r.search(/\.jpe?g($|\?)/i)>0||r.search(/^data\:image\/jpeg/)===0?"image/jpeg":r.search(/\.webp($|\?)/i)>0||r.search(/^data\:image\/webp/)===0?"image/webp":r.search(/\.ktx2($|\?)/i)>0||r.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const Tw=new dt;class Aw{constructor(e={},n={}){this.json=e,this.extensions={},this.plugins={},this.options=n,this.cache=new ZC,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let a=!1,o=-1,c=!1,u=-1;if(typeof navigator<"u"&&typeof navigator.userAgent<"u"){const h=navigator.userAgent;a=/^((?!chrome|android).)*safari/i.test(h)===!0;const p=h.match(/Version\/(\d+)/);o=a&&p?parseInt(p[1],10):-1,c=h.indexOf("Firefox")>-1,u=c?h.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||a&&o<17||c&&u<98?this.textureLoader=new Ub(this.options.manager):this.textureLoader=new zb(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new iy(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,n){const a=this,o=this.json,c=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(u){return u._markDefs&&u._markDefs()}),Promise.all(this._invokeAll(function(u){return u.beforeRoot&&u.beforeRoot()})).then(function(){return Promise.all([a.getDependencies("scene"),a.getDependencies("animation"),a.getDependencies("camera")])}).then(function(u){const h={scene:u[0][o.scene||0],scenes:u[0],animations:u[1],cameras:u[2],asset:o.asset,parser:a,userData:{}};return js(c,h,o),$i(h,o),Promise.all(a._invokeAll(function(p){return p.afterRoot&&p.afterRoot(h)})).then(function(){for(const p of h.scenes)p.updateMatrixWorld();e(h)})}).catch(n)}_markDefs(){const e=this.json.nodes||[],n=this.json.skins||[],a=this.json.meshes||[];for(let o=0,c=n.length;o<c;o++){const u=n[o].joints;for(let h=0,p=u.length;h<p;h++)e[u[h]].isBone=!0}for(let o=0,c=e.length;o<c;o++){const u=e[o];u.mesh!==void 0&&(this._addNodeRef(this.meshCache,u.mesh),u.skin!==void 0&&(a[u.mesh].isSkinnedMesh=!0)),u.camera!==void 0&&this._addNodeRef(this.cameraCache,u.camera)}}_addNodeRef(e,n){n!==void 0&&(e.refs[n]===void 0&&(e.refs[n]=e.uses[n]=0),e.refs[n]++)}_getNodeRef(e,n,a){if(e.refs[n]<=1)return a;const o=a.clone(),c=(u,h)=>{const p=this.associations.get(u);p!=null&&this.associations.set(h,p);for(const[d,g]of u.children.entries())c(g,h.children[d])};return c(a,o),o.name+="_instance_"+e.uses[n]++,o}_invokeOne(e){const n=Object.values(this.plugins);n.push(this);for(let a=0;a<n.length;a++){const o=e(n[a]);if(o)return o}return null}_invokeAll(e){const n=Object.values(this.plugins);n.unshift(this);const a=[];for(let o=0;o<n.length;o++){const c=e(n[o]);c&&a.push(c)}return a}getDependency(e,n){const a=e+":"+n;let o=this.cache.get(a);if(!o){switch(e){case"scene":o=this.loadScene(n);break;case"node":o=this._invokeOne(function(c){return c.loadNode&&c.loadNode(n)});break;case"mesh":o=this._invokeOne(function(c){return c.loadMesh&&c.loadMesh(n)});break;case"accessor":o=this.loadAccessor(n);break;case"bufferView":o=this._invokeOne(function(c){return c.loadBufferView&&c.loadBufferView(n)});break;case"buffer":o=this.loadBuffer(n);break;case"material":o=this._invokeOne(function(c){return c.loadMaterial&&c.loadMaterial(n)});break;case"texture":o=this._invokeOne(function(c){return c.loadTexture&&c.loadTexture(n)});break;case"skin":o=this.loadSkin(n);break;case"animation":o=this._invokeOne(function(c){return c.loadAnimation&&c.loadAnimation(n)});break;case"camera":o=this.loadCamera(n);break;default:if(o=this._invokeOne(function(c){return c!=this&&c.getDependency&&c.getDependency(e,n)}),!o)throw new Error("Unknown type: "+e);break}this.cache.add(a,o)}return o}getDependencies(e){let n=this.cache.get(e);if(!n){const a=this,o=this.json[e+(e==="mesh"?"es":"s")]||[];n=Promise.all(o.map(function(c,u){return a.getDependency(e,u)})),this.cache.add(e,n)}return n}loadBuffer(e){const n=this.json.buffers[e],a=this.fileLoader;if(n.type&&n.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+n.type+" buffer type is not supported.");if(n.uri===void 0&&e===0)return Promise.resolve(this.extensions[mt.KHR_BINARY_GLTF].body);const o=this.options;return new Promise(function(c,u){a.load(Rl.resolveURL(n.uri,o.path),c,void 0,function(){u(new Error('THREE.GLTFLoader: Failed to load buffer "'+n.uri+'".'))})})}loadBufferView(e){const n=this.json.bufferViews[e];return this.getDependency("buffer",n.buffer).then(function(a){const o=n.byteLength||0,c=n.byteOffset||0;return a.slice(c,c+o)})}loadAccessor(e){const n=this,a=this.json,o=this.json.accessors[e];if(o.bufferView===void 0&&o.sparse===void 0){const u=Hd[o.type],h=so[o.componentType],p=o.normalized===!0,d=new h(o.count*u);return Promise.resolve(new Yn(d,u,p))}const c=[];return o.bufferView!==void 0?c.push(this.getDependency("bufferView",o.bufferView)):c.push(null),o.sparse!==void 0&&(c.push(this.getDependency("bufferView",o.sparse.indices.bufferView)),c.push(this.getDependency("bufferView",o.sparse.values.bufferView))),Promise.all(c).then(function(u){const h=u[0],p=Hd[o.type],d=so[o.componentType],g=d.BYTES_PER_ELEMENT,_=g*p,v=o.byteOffset||0,x=o.bufferView!==void 0?a.bufferViews[o.bufferView].byteStride:void 0,E=o.normalized===!0;let C,M;if(x&&x!==_){const S=Math.floor(v/x),B="InterleavedBuffer:"+o.bufferView+":"+o.componentType+":"+S+":"+o.count;let F=n.cache.get(B);F||(C=new d(h,S*x,o.count*x/g),F=new JE(C,x/g),n.cache.add(B,F)),M=new $p(F,p,v%x/g,E)}else h===null?C=new d(o.count*p):C=new d(h,v,o.count*p),M=new Yn(C,p,E);if(o.sparse!==void 0){const S=Hd.SCALAR,B=so[o.sparse.indices.componentType],F=o.sparse.indices.byteOffset||0,w=o.sparse.values.byteOffset||0,P=new B(u[1],F,o.sparse.count*S),U=new d(u[2],w,o.sparse.count*p);h!==null&&(M=new Yn(M.array.slice(),M.itemSize,M.normalized)),M.normalized=!1;for(let N=0,T=P.length;N<T;N++){const O=P[N];if(M.setX(O,U[N*p]),p>=2&&M.setY(O,U[N*p+1]),p>=3&&M.setZ(O,U[N*p+2]),p>=4&&M.setW(O,U[N*p+3]),p>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}M.normalized=E}return M})}loadTexture(e){const n=this.json,a=this.options,c=n.textures[e].source,u=n.images[c];let h=this.textureLoader;if(u.uri){const p=a.manager.getHandler(u.uri);p!==null&&(h=p)}return this.loadTextureImage(e,c,h)}loadTextureImage(e,n,a){const o=this,c=this.json,u=c.textures[e],h=c.images[n],p=(h.uri||h.bufferView)+":"+u.sampler;if(this.textureCache[p])return this.textureCache[p];const d=this.loadImageSource(n,a).then(function(g){g.flipY=!1,g.name=u.name||h.name||"",g.name===""&&typeof h.uri=="string"&&h.uri.startsWith("data:image/")===!1&&(g.name=h.uri);const v=(c.samplers||{})[u.sampler]||{};return g.magFilter=yx[v.magFilter]||Rn,g.minFilter=yx[v.minFilter]||Pa,g.wrapS=Sx[v.wrapS]||lo,g.wrapT=Sx[v.wrapT]||lo,g.generateMipmaps=!g.isCompressedTexture&&g.minFilter!==An&&g.minFilter!==Rn,o.associations.set(g,{textures:e}),g}).catch(function(){return null});return this.textureCache[p]=d,d}loadImageSource(e,n){const a=this,o=this.json,c=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(_=>_.clone());const u=o.images[e],h=self.URL||self.webkitURL;let p=u.uri||"",d=!1;if(u.bufferView!==void 0)p=a.getDependency("bufferView",u.bufferView).then(function(_){d=!0;const v=new Blob([_],{type:u.mimeType});return p=h.createObjectURL(v),p});else if(u.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");const g=Promise.resolve(p).then(function(_){return new Promise(function(v,x){let E=v;n.isImageBitmapLoader===!0&&(E=function(C){const M=new Un(C);M.needsUpdate=!0,v(M)}),n.load(Rl.resolveURL(_,c.path),E,void 0,x)})}).then(function(_){return d===!0&&h.revokeObjectURL(p),$i(_,u),_.userData.mimeType=u.mimeType||bw(u.uri),_}).catch(function(_){throw console.error("THREE.GLTFLoader: Couldn't load texture",p),_});return this.sourceCache[e]=g,g}assignTexture(e,n,a,o){const c=this;return this.getDependency("texture",a.index).then(function(u){if(!u)return null;if(a.texCoord!==void 0&&a.texCoord>0&&(u=u.clone(),u.channel=a.texCoord),c.extensions[mt.KHR_TEXTURE_TRANSFORM]){const h=a.extensions!==void 0?a.extensions[mt.KHR_TEXTURE_TRANSFORM]:void 0;if(h){const p=c.associations.get(u);u=c.extensions[mt.KHR_TEXTURE_TRANSFORM].extendTexture(u,h),c.associations.set(u,p)}}return o!==void 0&&(u.colorSpace=o),e[n]=u,u})}assignFinalMaterial(e){const n=e.geometry;let a=e.material;const o=n.attributes.tangent===void 0,c=n.attributes.color!==void 0,u=n.attributes.normal===void 0;if(e.isPoints){const h="PointsMaterial:"+a.uuid;let p=this.cache.get(h);p||(p=new jx,Vi.prototype.copy.call(p,a),p.color.copy(a.color),p.map=a.map,p.sizeAttenuation=!1,this.cache.add(h,p)),a=p}else if(e.isLine){const h="LineBasicMaterial:"+a.uuid;let p=this.cache.get(h);p||(p=new Jx,Vi.prototype.copy.call(p,a),p.color.copy(a.color),p.map=a.map,this.cache.add(h,p)),a=p}if(o||c||u){let h="ClonedMaterial:"+a.uuid+":";o&&(h+="derivative-tangents:"),c&&(h+="vertex-colors:"),u&&(h+="flat-shading:");let p=this.cache.get(h);p||(p=a.clone(),c&&(p.vertexColors=!0),u&&(p.flatShading=!0),o&&(p.normalScale&&(p.normalScale.y*=-1),p.clearcoatNormalScale&&(p.clearcoatNormalScale.y*=-1)),this.cache.add(h,p),this.associations.set(p,this.associations.get(a))),a=p}e.material=a}getMaterialType(){return Ol}loadMaterial(e){const n=this,a=this.json,o=this.extensions,c=a.materials[e];let u;const h={},p=c.extensions||{},d=[];if(p[mt.KHR_MATERIALS_UNLIT]){const _=o[mt.KHR_MATERIALS_UNLIT];u=_.getMaterialType(),d.push(_.extendParams(h,c,n))}else{const _=c.pbrMetallicRoughness||{};if(h.color=new st(1,1,1),h.opacity=1,Array.isArray(_.baseColorFactor)){const v=_.baseColorFactor;h.color.setRGB(v[0],v[1],v[2],gi),h.opacity=v[3]}_.baseColorTexture!==void 0&&d.push(n.assignTexture(h,"map",_.baseColorTexture,Nn)),h.metalness=_.metallicFactor!==void 0?_.metallicFactor:1,h.roughness=_.roughnessFactor!==void 0?_.roughnessFactor:1,_.metallicRoughnessTexture!==void 0&&(d.push(n.assignTexture(h,"metalnessMap",_.metallicRoughnessTexture)),d.push(n.assignTexture(h,"roughnessMap",_.metallicRoughnessTexture))),u=this._invokeOne(function(v){return v.getMaterialType&&v.getMaterialType(e)}),d.push(Promise.all(this._invokeAll(function(v){return v.extendMaterialParams&&v.extendMaterialParams(e,h)})))}c.doubleSided===!0&&(h.side=ta);const g=c.alphaMode||Gd.OPAQUE;if(g===Gd.BLEND?(h.transparent=!0,h.depthWrite=!1):(h.transparent=!1,g===Gd.MASK&&(h.alphaTest=c.alphaCutoff!==void 0?c.alphaCutoff:.5)),c.normalTexture!==void 0&&u!==ir&&(d.push(n.assignTexture(h,"normalMap",c.normalTexture)),h.normalScale=new gt(1,1),c.normalTexture.scale!==void 0)){const _=c.normalTexture.scale;h.normalScale.set(_,_)}if(c.occlusionTexture!==void 0&&u!==ir&&(d.push(n.assignTexture(h,"aoMap",c.occlusionTexture)),c.occlusionTexture.strength!==void 0&&(h.aoMapIntensity=c.occlusionTexture.strength)),c.emissiveFactor!==void 0&&u!==ir){const _=c.emissiveFactor;h.emissive=new st().setRGB(_[0],_[1],_[2],gi)}return c.emissiveTexture!==void 0&&u!==ir&&d.push(n.assignTexture(h,"emissiveMap",c.emissiveTexture,Nn)),Promise.all(d).then(function(){const _=new u(h);return c.name&&(_.name=c.name),$i(_,c),n.associations.set(_,{materials:e}),c.extensions&&js(o,_,c),_})}createUniqueName(e){const n=Vt.sanitizeNodeName(e||"");return n in this.nodeNamesUsed?n+"_"+ ++this.nodeNamesUsed[n]:(this.nodeNamesUsed[n]=0,n)}loadGeometries(e){const n=this,a=this.extensions,o=this.primitiveCache;function c(h){return a[mt.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(h,n).then(function(p){return Mx(p,h,n)})}const u=[];for(let h=0,p=e.length;h<p;h++){const d=e[h],g=Ew(d),_=o[g];if(_)u.push(_.promise);else{let v;d.extensions&&d.extensions[mt.KHR_DRACO_MESH_COMPRESSION]?v=c(d):v=Mx(new wi,d,n),o[g]={primitive:d,promise:v},u.push(v)}}return Promise.all(u)}loadMesh(e){const n=this,a=this.json,o=this.extensions,c=a.meshes[e],u=c.primitives,h=[];for(let p=0,d=u.length;p<d;p++){const g=u[p].material===void 0?yw(this.cache):this.getDependency("material",u[p].material);h.push(g)}return h.push(n.loadGeometries(u)),Promise.all(h).then(function(p){const d=p.slice(0,p.length-1),g=p[p.length-1],_=[];for(let x=0,E=g.length;x<E;x++){const C=g[x],M=u[x];let S;const B=d[x];if(M.mode===Ai.TRIANGLES||M.mode===Ai.TRIANGLE_STRIP||M.mode===Ai.TRIANGLE_FAN||M.mode===void 0)S=c.isSkinnedMesh===!0?new tb(C,B):new En(C,B),S.isSkinnedMesh===!0&&S.normalizeSkinWeights(),M.mode===Ai.TRIANGLE_STRIP?S.geometry=_x(S.geometry,Gx):M.mode===Ai.TRIANGLE_FAN&&(S.geometry=_x(S.geometry,Cp));else if(M.mode===Ai.LINES)S=new ob(C,B);else if(M.mode===Ai.LINE_STRIP)S=new im(C,B);else if(M.mode===Ai.LINE_LOOP)S=new lb(C,B);else if(M.mode===Ai.POINTS)S=new cb(C,B);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+M.mode);Object.keys(S.geometry.morphAttributes).length>0&&Mw(S,c),S.name=n.createUniqueName(c.name||"mesh_"+e),$i(S,c),M.extensions&&js(o,S,M),n.assignFinalMaterial(S),_.push(S)}for(let x=0,E=_.length;x<E;x++)n.associations.set(_[x],{meshes:e,primitives:x});if(_.length===1)return c.extensions&&js(o,_[0],c),_[0];const v=new As;c.extensions&&js(o,v,c),n.associations.set(v,{meshes:e});for(let x=0,E=_.length;x<E;x++)v.add(_[x]);return v})}loadCamera(e){let n;const a=this.json.cameras[e],o=a[a.type];if(!o){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return a.type==="perspective"?n=new ti(OE.radToDeg(o.yfov),o.aspectRatio||1,o.znear||1,o.zfar||2e6):a.type==="orthographic"&&(n=new Bl(-o.xmag,o.xmag,o.ymag,-o.ymag,o.znear,o.zfar)),a.name&&(n.name=this.createUniqueName(a.name)),$i(n,a),Promise.resolve(n)}loadSkin(e){const n=this.json.skins[e],a=[];for(let o=0,c=n.joints.length;o<c;o++)a.push(this._loadNodeShallow(n.joints[o]));return n.inverseBindMatrices!==void 0?a.push(this.getDependency("accessor",n.inverseBindMatrices)):a.push(null),Promise.all(a).then(function(o){const c=o.pop(),u=o,h=[],p=[];for(let d=0,g=u.length;d<g;d++){const _=u[d];if(_){h.push(_);const v=new dt;c!==null&&v.fromArray(c.array,d*16),p.push(v)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',n.joints[d])}return new tm(h,p)})}loadAnimation(e){const n=this.json,a=this,o=n.animations[e],c=o.name?o.name:"animation_"+e,u=[],h=[],p=[],d=[],g=[];for(let _=0,v=o.channels.length;_<v;_++){const x=o.channels[_],E=o.samplers[x.sampler],C=x.target,M=C.node,S=o.parameters!==void 0?o.parameters[E.input]:E.input,B=o.parameters!==void 0?o.parameters[E.output]:E.output;C.node!==void 0&&(u.push(this.getDependency("node",M)),h.push(this.getDependency("accessor",S)),p.push(this.getDependency("accessor",B)),d.push(E),g.push(C))}return Promise.all([Promise.all(u),Promise.all(h),Promise.all(p),Promise.all(d),Promise.all(g)]).then(function(_){const v=_[0],x=_[1],E=_[2],C=_[3],M=_[4],S=[];for(let F=0,w=v.length;F<w;F++){const P=v[F],U=x[F],N=E[F],T=C[F],O=M[F];if(P===void 0)continue;P.updateMatrix&&P.updateMatrix();const X=a._createAnimationTracks(P,U,N,T,O);if(X)for(let G=0;G<X.length;G++)S.push(X[G])}const B=new Ab(c,void 0,S);return $i(B,o),B})}createNodeMesh(e){const n=this.json,a=this,o=n.nodes[e];return o.mesh===void 0?null:a.getDependency("mesh",o.mesh).then(function(c){const u=a._getNodeRef(a.meshCache,o.mesh,c);return o.weights!==void 0&&u.traverse(function(h){if(h.isMesh)for(let p=0,d=o.weights.length;p<d;p++)h.morphTargetInfluences[p]=o.weights[p]}),u})}loadNode(e){const n=this.json,a=this,o=n.nodes[e],c=a._loadNodeShallow(e),u=[],h=o.children||[];for(let d=0,g=h.length;d<g;d++)u.push(a.getDependency("node",h[d]));const p=o.skin===void 0?Promise.resolve(null):a.getDependency("skin",o.skin);return Promise.all([c,Promise.all(u),p]).then(function(d){const g=d[0],_=d[1],v=d[2];v!==null&&g.traverse(function(x){x.isSkinnedMesh&&x.bind(v,Tw)});for(let x=0,E=_.length;x<E;x++)g.add(_[x]);if(g.userData.pivot!==void 0&&_.length>0){const x=g.userData.pivot,E=_[0];g.pivot=new $().fromArray(x),g.position.x-=x[0],g.position.y-=x[1],g.position.z-=x[2],E.position.set(0,0,0),delete g.userData.pivot}return g})}_loadNodeShallow(e){const n=this.json,a=this.extensions,o=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];const c=n.nodes[e],u=c.name?o.createUniqueName(c.name):"",h=[],p=o._invokeOne(function(d){return d.createNodeMesh&&d.createNodeMesh(e)});return p&&h.push(p),c.camera!==void 0&&h.push(o.getDependency("camera",c.camera).then(function(d){return o._getNodeRef(o.cameraCache,c.camera,d)})),o._invokeAll(function(d){return d.createNodeAttachment&&d.createNodeAttachment(e)}).forEach(function(d){h.push(d)}),this.nodeCache[e]=Promise.all(h).then(function(d){let g;if(c.isBone===!0?g=new Zx:d.length>1?g=new As:d.length===1?g=d[0]:g=new en,g!==d[0])for(let _=0,v=d.length;_<v;_++)g.add(d[_]);if(c.name&&(g.userData.name=c.name,g.name=u),$i(g,c),c.extensions&&js(a,g,c),c.matrix!==void 0){const _=new dt;_.fromArray(c.matrix),g.applyMatrix4(_)}else c.translation!==void 0&&g.position.fromArray(c.translation),c.rotation!==void 0&&g.quaternion.fromArray(c.rotation),c.scale!==void 0&&g.scale.fromArray(c.scale);if(!o.associations.has(g))o.associations.set(g,{});else if(c.mesh!==void 0&&o.meshCache.refs[c.mesh]>1){const _=o.associations.get(g);o.associations.set(g,{..._})}return o.associations.get(g).nodes=e,g}),this.nodeCache[e]}loadScene(e){const n=this.extensions,a=this.json.scenes[e],o=this,c=new As;a.name&&(c.name=o.createUniqueName(a.name)),$i(c,a),a.extensions&&js(n,c,a);const u=a.nodes||[],h=[];for(let p=0,d=u.length;p<d;p++)h.push(o.getDependency("node",u[p]));return Promise.all(h).then(function(p){for(let g=0,_=p.length;g<_;g++){const v=p[g];v.parent!==null?c.add(YC(v)):c.add(v)}const d=g=>{const _=new Map;for(const[v,x]of o.associations)(v instanceof Vi||v instanceof Un)&&_.set(v,x);return g.traverse(v=>{const x=o.associations.get(v);x!=null&&_.set(v,x)}),_};return o.associations=d(c),c})}_createAnimationTracks(e,n,a,o,c){const u=[],h=e.name?e.name:e.uuid,p=[];function d(x){x.morphTargetInfluences&&p.push(x.name?x.name:x.uuid)}Es[c.path]===Es.weights?(d(e),e.isGroup&&e.children.forEach(d)):p.push(h);let g;switch(Es[c.path]){case Es.weights:g=Pl;break;case Es.rotation:g=Il;break;case Es.translation:case Es.scale:g=Hu;break;default:switch(a.itemSize){case 1:g=Pl;break;case 2:case 3:default:g=Hu;break}break}const _=o.interpolation!==void 0?xw[o.interpolation]:Ll,v=this._getArrayFromAccessor(a);for(let x=0,E=p.length;x<E;x++){const C=new g(p[x]+"."+Es[c.path],n.array,v,_);o.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(C),u.push(C)}return u}_getArrayFromAccessor(e){let n=e.array;if(e.normalized){const a=Ip(n.constructor),o=new Float32Array(n.length);for(let c=0,u=n.length;c<u;c++)o[c]=n[c]*a;n=o}return n}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(a){const o=this instanceof Il?vw:gy;return new o(this.times,this.values,this.getValueSize()/3,a)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function Rw(r,e,n){const a=e.attributes,o=new ki;if(a.POSITION!==void 0){const h=n.json.accessors[a.POSITION],p=h.min,d=h.max;if(p!==void 0&&d!==void 0){if(o.set(new $(p[0],p[1],p[2]),new $(d[0],d[1],d[2])),h.normalized){const g=Ip(so[h.componentType]);o.min.multiplyScalar(g),o.max.multiplyScalar(g)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const c=e.targets;if(c!==void 0){const h=new $,p=new $;for(let d=0,g=c.length;d<g;d++){const _=c[d];if(_.POSITION!==void 0){const v=n.json.accessors[_.POSITION],x=v.min,E=v.max;if(x!==void 0&&E!==void 0){if(p.setX(Math.max(Math.abs(x[0]),Math.abs(E[0]))),p.setY(Math.max(Math.abs(x[1]),Math.abs(E[1]))),p.setZ(Math.max(Math.abs(x[2]),Math.abs(E[2]))),v.normalized){const C=Ip(so[v.componentType]);p.multiplyScalar(C)}h.max(p)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}o.expandByVector(h)}r.boundingBox=o;const u=new la;o.getCenter(u.center),u.radius=o.min.distanceTo(o.max)/2,r.boundingSphere=u}function Mx(r,e,n){const a=e.attributes,o=[];function c(u,h){return n.getDependency("accessor",u).then(function(p){r.setAttribute(h,p)})}for(const u in a){const h=Pp[u]||u.toLowerCase();h in r.attributes||o.push(c(a[u],h))}if(e.indices!==void 0&&!r.index){const u=n.getDependency("accessor",e.indices).then(function(h){r.setIndex(h)});o.push(u)}return St.workingColorSpace!==gi&&"COLOR_0"in a&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${St.workingColorSpace}" not supported.`),$i(r,e),Rw(r,e,n),Promise.all(o).then(function(){return e.targets!==void 0?Sw(r,e.targets,n):r})}class Cw extends qx{constructor(){super(),this.name="RoomEnvironment",this.position.y=-3.5;const e=new ho;e.deleteAttribute("uv");const n=new Ol({side:qn}),a=new Ol,o=new sy(16777215,900,28,2);o.position.set(.418,16.199,.3),this.add(o);const c=new En(e,n);c.position.set(-.757,13.219,.717),c.scale.set(31.713,28.305,28.591),this.add(c);const u=new Qx(e,a,6),h=new en;h.position.set(-10.906,2.009,1.846),h.rotation.set(0,-.195,0),h.scale.set(2.328,7.905,4.651),h.updateMatrix(),u.setMatrixAt(0,h.matrix),h.position.set(-5.607,-.754,-.758),h.rotation.set(0,.994,0),h.scale.set(1.97,1.534,3.955),h.updateMatrix(),u.setMatrixAt(1,h.matrix),h.position.set(6.167,.857,7.803),h.rotation.set(0,.561,0),h.scale.set(3.927,6.285,3.687),h.updateMatrix(),u.setMatrixAt(2,h.matrix),h.position.set(-2.017,.018,6.124),h.rotation.set(0,.333,0),h.scale.set(2.002,4.566,2.064),h.updateMatrix(),u.setMatrixAt(3,h.matrix),h.position.set(2.291,-.756,-2.621),h.rotation.set(0,-.286,0),h.scale.set(1.546,1.552,1.496),h.updateMatrix(),u.setMatrixAt(4,h.matrix),h.position.set(-2.193,-.369,-5.547),h.rotation.set(0,.516,0),h.scale.set(3.875,3.487,2.986),h.updateMatrix(),u.setMatrixAt(5,h.matrix),this.add(u);const p=new En(e,to(50));p.position.set(-16.116,14.37,8.208),p.scale.set(.1,2.428,2.739),this.add(p);const d=new En(e,to(50));d.position.set(-16.109,18.021,-8.207),d.scale.set(.1,2.425,2.751),this.add(d);const g=new En(e,to(17));g.position.set(14.904,12.198,-1.832),g.scale.set(.15,4.265,6.331),this.add(g);const _=new En(e,to(43));_.position.set(-.462,8.89,14.52),_.scale.set(4.38,5.441,.088),this.add(_);const v=new En(e,to(20));v.position.set(3.235,11.486,-12.541),v.scale.set(2.5,2,.1),this.add(v);const x=new En(e,to(100));x.position.set(0,20,0),x.scale.set(1,.1,1),this.add(x)}dispose(){const e=new Set;this.traverse(n=>{n.isMesh&&(e.add(n.geometry),e.add(n.material))});for(const n of e)n.dispose()}}function to(r){return new gb({color:0,emissive:16777215,emissiveIntensity:r})}const ww="./models/yuanbai-perception-sculpture.glb?v=e45928b1b882",bs={exposure:.78,environment:.24,hemisphere:.25,key:1.25,fill:.38,rim:.55,breath:.035},Dw={"Rusty iron":{roughness:.82,metalness:.22,opaque:!0},"Material.001":{roughness:.9,metalness:0},"材质.005":{roughness:.9,metalness:0},"材质.001":{roughness:.96,metalness:0},"材质.006":{roughness:.96,metalness:0}};function Ex(r){const e=new Set,n=new Set,a=new Set;r.traverse(o=>{if(o.geometry&&a.add(o.geometry),o.material)for(const c of[].concat(o.material)){n.add(c);for(const u of Object.values(c))u!=null&&u.isTexture&&e.add(u)}}),e.forEach(o=>o.dispose()),n.forEach(o=>o.dispose()),a.forEach(o=>o.dispose())}function Lw({projectionRef:r}){const e=Je.useRef(null);return Je.useEffect(()=>{const n=e.current;if(!n)return;const a=window.matchMedia("(max-width: 820px)"),o=window.matchMedia("(prefers-reduced-motion: reduce)"),c=window.matchMedia("(hover: hover) and (pointer: fine)"),u=new qx,h=new Bl(-4,4,3,-3,.1,80);h.position.set(0,10.6,7.1),h.lookAt(0,0,0),h.updateMatrixWorld();let p;try{p=new qC({alpha:!0,antialias:!0,powerPreference:"low-power"})}catch{n.dataset.state="fallback";return}p.outputColorSpace=Nn,p.toneMapping=Gp,p.toneMappingExposure=bs.exposure,p.setClearColor(0,0),n.appendChild(p.domElement),n.dataset.state="loading";const d=new Cw,g=new Np(p),_=g.fromScene(d,.04);u.environment=_.texture,u.environmentIntensity=bs.environment,d.dispose(),g.dispose(),u.add(new Ob("#dfdfda","#201c19",bs.hemisphere));const v=new Du("#fff1e1",bs.key);v.position.set(-3.5,8,4),u.add(v);const x=new Du("#bdc9d2",bs.fill);x.position.set(5,3,4),u.add(x);const E=new Du("#cfb9a6",bs.rim);E.position.set(1.5,4,-5),u.add(E);const C=new As;u.add(C);let M=null,S=!0,B=0,F=0,w=-1/0,P=3.8,U=2.6;const N={x:0,y:0},T=r.current,O=T==null?void 0:T.getContext("2d"),X=()=>{const I=Math.max(n.clientWidth,1),z=Math.max(n.clientHeight,1),Q=I/z,de=Math.max(U,P/Q)*1.14;h.left=-de*Q,h.right=de*Q,h.top=de,h.bottom=-de,h.updateProjectionMatrix(),p.setPixelRatio(Math.min(window.devicePixelRatio,a.matches?1.5:2)),p.setSize(I,z,!1),T&&(T.width=256,T.height=Math.max(1,Math.round(256/Q))),w=-1/0},G=new ResizeObserver(X);G.observe(n),X(),new KC().load(ww,I=>{if(!S){Ex(I.scene);return}M=I.scene;const z=new ki().setFromObject(M);M.position.sub(z.getCenter(new $)),M.traverse(de=>{if(de.isMesh)for(const ve of[].concat(de.material)){ve.map&&(ve.map.anisotropy=Math.min(4,p.capabilities.getMaxAnisotropy()));const D=Dw[ve.name];D&&(ve.roughnessMap||(ve.roughness=D.roughness),ve.metalnessMap||(ve.metalness=D.metalness),D.opaque&&ve.opacity===1&&(ve.transparent=!1,ve.depthWrite=!0))}}),C.add(M),C.updateMatrixWorld(!0);const Q=new ki().setFromObject(C);P=0,U=0;for(const de of[Q.min.x,Q.max.x])for(const ve of[Q.min.y,Q.max.y])for(const D of[Q.min.z,Q.max.z]){const Y=new $(de,ve,D).applyMatrix4(h.matrixWorldInverse);P=Math.max(P,Math.abs(Y.x)),U=Math.max(U,Math.abs(Y.y))}X(),n.dataset.state="ready"},void 0,()=>{S&&(n.dataset.state="fallback")});const Z=I=>{!c.matches||o.matches||(N.x=(I.clientX/window.innerWidth-.5)*2,N.y=(I.clientY/window.innerHeight-.5)*2)},ce=()=>{N.x=0,N.y=0},ge=()=>{ce(),w=-1/0};window.addEventListener("pointermove",Z,{passive:!0}),window.addEventListener("blur",ce),document.documentElement.addEventListener("pointerleave",ce),o.addEventListener("change",ge);const j=I=>{if(B=requestAnimationFrame(j),document.hidden)return;F||(F=I);const z=(I-F)/1e3,Q=o.matches?0:1;C.position.y=Math.sin(z*.55)*.075*Q,C.rotation.y+=(N.x*.08*Q-C.rotation.y)*.06,C.rotation.x+=(-N.y*.035*Q-C.rotation.x)*.06,v.intensity=bs.key+Math.sin(z*Math.PI/4)*bs.breath*Q,p.render(u,h),O&&M&&I-w>(Q?160:1e3)&&(O.clearRect(0,0,T.width,T.height),O.drawImage(p.domElement,0,0,T.width,T.height),w=I)};return B=requestAnimationFrame(j),()=>{S=!1,cancelAnimationFrame(B),G.disconnect(),window.removeEventListener("pointermove",Z),window.removeEventListener("blur",ce),document.documentElement.removeEventListener("pointerleave",ce),o.removeEventListener("change",ge),M&&Ex(M),_.dispose(),O==null||O.clearRect(0,0,T.width,T.height),p.dispose(),p.domElement.remove()}},[r]),Je.createElement("div",{ref:e,className:"portal-sculpture","aria-hidden":"true"})}const Nw="./brand/yuanbai-mark.svg",Eu=[{id:"explore",eyebrow:"黑暗探索 / EXPLORE",title:"探索元白",description:"走进九乘九的黑暗网格，让元白楼的轮廓在脚下逐格亮起。循着光与声音，拾起一座楼的记忆。",action:"进入探索模式",icon:NM,href:"game/?from=home"}];function Uw({experience:r,onActivate:e}){const n=r.icon,a=r.href;return Qe.jsxs("a",{className:`portal-card portal-card-${r.id}`,href:a,onMouseEnter:()=>e(r.id),onFocus:()=>e(r.id),"aria-label":`${r.title}：${r.description}`,children:[Qe.jsx("div",{className:"portal-card-head",children:Qe.jsx("span",{children:r.eyebrow})}),Qe.jsxs("div",{className:"portal-card-title",children:[Qe.jsx("span",{className:"portal-accent","aria-hidden":"true"}),Qe.jsx("h2",{children:r.title})]}),Qe.jsx("div",{className:"portal-card-icon","aria-hidden":"true",children:Qe.jsx(n,{size:72,weight:"thin"})}),Qe.jsx("p",{children:r.description}),Qe.jsxs("span",{className:"portal-card-action",children:[Qe.jsx("span",{children:r.action}),Qe.jsx(Tx,{size:22,weight:"bold"})]})]})}function Ow(){const r=Je.useRef(null),e=Je.useRef(null),[n,a]=Je.useState("explore"),[o,c]=Je.useState(()=>new Date),u=Je.useMemo(()=>Eu.find(p=>p.id===n)||Eu[0],[n]);Je.useEffect(()=>{document.title="感知元白 · 元白感知实验室";const p=window.setInterval(()=>c(new Date),1e3),d=window.matchMedia("(hover: hover) and (pointer: fine)"),g=window.matchMedia("(prefers-reduced-motion: reduce)"),_=x=>{var C,M;if(x.pointerType==="touch"||!d.matches||g.matches)return;const E=(x.clientY/window.innerHeight-.5)*-52;(C=r.current)==null||C.style.setProperty("--scale-left-y",`${E.toFixed(2)}px`),(M=r.current)==null||M.style.setProperty("--scale-right-y",`${(-E*.78).toFixed(2)}px`)};window.addEventListener("pointermove",_,{passive:!0});const v=x=>{if(x.key!=="1")return;const E=Eu[Number(x.key)-1];x.repeat||x.ctrlKey||x.altKey||x.metaKey||["INPUT","TEXTAREA","SELECT"].includes(x.target.tagName)||window.location.assign(E.href)};return window.addEventListener("keydown",v),()=>{window.clearInterval(p),window.removeEventListener("keydown",v),window.removeEventListener("pointermove",_)}},[]);const h=Array.from({length:13},(p,d)=>d===0?"+3.0":d===3?"+1.5":d===6?"0.0":d===9?"-1.5":d===12?"-3.0":"");return Qe.jsxs("main",{ref:r,className:`portal portal-active-${n}`,children:[Qe.jsxs("header",{className:"portal-header",children:[Qe.jsxs("div",{className:"portal-brand",children:[Qe.jsx("img",{src:Nw,alt:"元白楼标志"}),Qe.jsxs("span",{className:"portal-brand-copy",children:[Qe.jsx("strong",{children:"元白感知实验室"}),Qe.jsx("span",{children:"YUANBAI PERCEPTION LAB"})]})]}),Qe.jsxs("p",{children:["让建筑",Qe.jsx("br",{}),"再次与人相遇"]})]}),Qe.jsxs("div",{className:"portal-status","aria-label":"项目状态",children:[Qe.jsx("span",{className:"portal-live-dot"}),Qe.jsx("span",{children:"ONLINE"}),Qe.jsx("span",{children:"未来设计学院"}),Qe.jsx("span",{children:"珠海"}),Qe.jsx("time",{dateTime:o.toISOString(),children:o.toLocaleTimeString("zh-CN",{hour12:!1})})]}),Qe.jsxs("section",{className:"portal-stage","aria-label":"元白感知实验装置",children:[Qe.jsx("span",{className:"portal-top-light","aria-hidden":"true"}),Qe.jsx(Lw,{projectionRef:e}),Qe.jsx("span",{className:"portal-floor-projection","aria-hidden":"true",children:Qe.jsx("canvas",{ref:e,width:"256",height:"160"})}),Qe.jsxs("div",{className:"portal-scale portal-scale-left","aria-hidden":"true",children:[Qe.jsx("i",{className:"portal-scale-marker"}),Qe.jsx("div",{className:"portal-scale-strip",children:h.map((p,d)=>Qe.jsxs("span",{children:[Qe.jsx("b",{children:p}),Qe.jsx("i",{})]},`left-${d}`))})]}),Qe.jsxs("div",{className:"portal-scale portal-scale-right","aria-hidden":"true",children:[Qe.jsx("i",{className:"portal-scale-marker"}),Qe.jsx("div",{className:"portal-scale-strip",children:h.map((p,d)=>Qe.jsxs("span",{children:[Qe.jsx("i",{}),Qe.jsx("b",{children:p})]},`right-${d}`))})]}),Qe.jsxs("div",{className:"portal-model-copy",children:[Qe.jsx("span",{children:"感知元白"}),Qe.jsx("strong",{children:u.eyebrow}),Qe.jsx("p",{children:"从空间出发，拾起一座楼的记忆。"})]})]}),Qe.jsxs("nav",{className:"portal-navigation","aria-label":"元白体验入口",children:[Eu.map(p=>Qe.jsx(Uw,{experience:p,onActivate:a},p.id)),Qe.jsxs("a",{className:"school-replay-link",href:"tutorial/",children:[Qe.jsx("span",{children:"探索规则 · 查看互动教学"}),Qe.jsx(Tx,{size:18,weight:"bold","aria-hidden":"true"})]})]}),Qe.jsx("footer",{className:"portal-footer",children:Qe.jsx("span",{children:"YUANBAI PERCEPTION LAB · ARCHITECTURE × PEOPLE × MEMORY"})})]})}CM.createRoot(document.getElementById("root")).render(Qe.jsx(Ow,{}));
