﻿param([string]$SourcePublic = 'D:\yuanbai\public')
$ErrorActionPreference = 'Stop'
$backup = $null
$writing = $false
try {
  $source = [IO.Path]::GetFullPath($SourcePublic).TrimEnd('\')
  if (!(Test-Path -LiteralPath $source -PathType Container)) { throw "找不到网站目录：$source" }
  $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  $plan = @()
  $missing = @()
  foreach ($entry in $manifest.files) {
    $found = $null
    $candidates = @()
    if ($entry.payload) { $candidates += Join-Path $PSScriptRoot $entry.payload }
    else { foreach ($relative in $entry.reuse) { $candidates += Join-Path $source $relative } }
    foreach ($candidate in $candidates) {
      if ((Test-Path -LiteralPath $candidate -PathType Leaf) -and (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash -eq $entry.sha256) { $found=$candidate; break }
    }
    if (!$found) { $missing += $entry.path; continue }
    $plan += [pscustomobject]@{ Entry=$entry; Source=$found }
  }
  if ($missing.Count) {
    $missing | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'missing-files.txt') -Encoding UTF8
    throw ('现有文件缺失或版本不同，网站尚未修改。请提供 missing-files.txt：' + ($missing -join ', '))
  }
  $stamp = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
  $backup = Join-Path (Split-Path -Parent (Split-Path -Parent $source)) ('yuanbai-backups\before-v6-' + $stamp)
  $stage = Join-Path $backup 'new-public'
  New-Item -ItemType Directory -Path $stage -Force | Out-Null
  foreach ($item in $plan) {
    $dest = Join-Path $stage $item.Entry.path
    New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
    Copy-Item -LiteralPath $item.Source -Destination $dest
    if ((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -ne $item.Entry.sha256) { throw "暂存文件校验失败：$dest" }
  }
  # Back up before publishing. Do not delete old assets: already-open games may still use them.
  Copy-Item -LiteralPath $source -Destination (Join-Path $backup 'public') -Recurse
  foreach ($item in $plan) {
    $oldFile = Join-Path $source $item.Entry.path
    if (Test-Path -LiteralPath $oldFile -PathType Leaf) {
      $backupFile = Join-Path (Join-Path $backup 'public') $item.Entry.path
      if ((Get-FileHash -LiteralPath $oldFile -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $backupFile -Algorithm SHA256).Hash) { throw "备份校验失败：$oldFile" }
    }
  }
  $writing = $true
  # Publish assets first, page entrypoints last, so every new page has its dependencies ready.
  $ordered = $plan | Sort-Object @{Expression={ if ($_.Entry.path -match '(^|/)index\.html$') { 1 } else { 0 } }}, @{Expression={$_.Entry.path}}
  foreach ($item in $ordered) {
    $dest = Join-Path $source $item.Entry.path
    New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $stage $item.Entry.path) -Destination $dest -Force
    if ((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -ne $item.Entry.sha256) { throw "上线文件校验失败：$dest" }
  }
  Write-Host '升级完成，所有新版文件已校验。' -ForegroundColor Green
  Write-Host "备份位置：$backup\public"
  Write-Host '首页：http://oa.design.bnuzh.edu.cn/yuanbai/explore/'
  Write-Host '游戏：http://oa.design.bnuzh.edu.cn/yuanbai/game/'
  Write-Host '只更新网页文件；Nginx、排行榜接口、数据库没有改动。'
} catch {
  if ($writing) { Write-Host "更新中断，请使用备份恢复：$backup\public" -ForegroundColor Yellow }
  Write-Host $_.Exception.Message -ForegroundColor Red
  exit 1
}
